package com.ly.adp.csc.controller;

import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.net.HttpHeaders;
import com.ly.adp.csc.service.ISacPcDlrClueInfoService;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.context.BusicenInvoker;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * <p>
 * CSC客制化PC线索服务 前端控制器
 * </p>
 *
 * @author CaiYunXiang
 * @since 2022-05-07
 */
@RestController
@Api(value = "CSC客制化PC线索服务", tags = "CSC客制化PC线索服务")
@RequestMapping(value = "/ly/adp/csc/sacPcClueInfo", produces = { MediaType.APPLICATION_JSON_VALUE })
public class SacPcClueInfoController {
	@Autowired
	ISacPcDlrClueInfoService sacPcClueInfoService;
	
	@ApiOperation(value = "PC门店全部回访单查询", notes = "PC门店全部回访单查询")
	@RequestMapping(value = "/entireReviewInfo.do", method = RequestMethod.POST)
	public ListResult<Map<String, Object>> entireReviewInfo(@RequestHeader(name = "authorization", required = false) String token, @RequestBody(required = false) ParamPage<Map<String, Object>> dataInfo) {
		return BusicenInvoker.doList(() -> sacPcClueInfoService.entireReviewInfo(dataInfo, token)).result();
	}
	
	@ApiOperation(value = "PC门店全部线索单查询", notes = "PC门店全部线索单查询")
	@RequestMapping(value = "/entireDlrClueInfo.do", method = RequestMethod.POST)
	public ListResult<Map<String, Object>> entireDlrClueInfo(@RequestHeader(name = "authorization", required = false) String token, @RequestBody(required = false) ParamPage<Map<String, Object>> dataInfo) {
		return BusicenInvoker.doList(() -> sacPcClueInfoService.entireDlrClueInfo(dataInfo, token)).result();
	}
	
	@ApiOperation(value = "PC门店全部线索查询导出", notes = "PC门店全部线索查询导出")
	@PostMapping(value = "/entireDlrClueInfoExport.do")
	public OptResult entireDlrClueInfoExport(@RequestHeader(HttpHeaders.AUTHORIZATION) String token,@RequestBody(required = false) Map<String, Object> dataInfo, HttpServletResponse response) {
		return BusicenInvoker.doOpt(() -> {return sacPcClueInfoService.entireDlrClueInfoExport(dataInfo, token, response);}).result();
	}
}

