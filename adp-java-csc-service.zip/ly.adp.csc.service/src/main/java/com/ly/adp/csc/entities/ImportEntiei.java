package com.ly.adp.csc.entities;

import java.util.List;

public class ImportEntiei {

	private int succeed;
	private int fail;
	private List<String> strInfo;

	public int getSucceed() {
		return succeed;
	}

	public void setSucceed(int succeed) {
		this.succeed = succeed;
	}

	public int getFail() {
		return fail;
	}

	public void setFail(int fail) {
		this.fail = fail;
	}

	public List<String> getStrInfo() {
		return strInfo;
	}

	public void setStrInfo(List<String> strInfo) {
		this.strInfo = strInfo;
	}

}
