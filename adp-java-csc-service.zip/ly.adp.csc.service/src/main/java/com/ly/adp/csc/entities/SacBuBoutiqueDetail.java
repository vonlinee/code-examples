package com.ly.adp.csc.entities;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

/**
 * <p>
 * 精品明细表
 * </p>
 *
 * @author CaiYunXiang
 * @since 2022-04-20
 */
@TableName("t_sac_bu_boutique_detail")
public class SacBuBoutiqueDetail implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 明细ID
     */
    @TableId("DETAIL_ID")
    private String detailId;

    /**
     * 申请ID
     */
    @TableField("APPLY_ID")
    private String applyId;

    /**
     * 精品SKU编码
     */
    @TableField("BOUTIQUE_CODE")
    private String boutiqueCode;

    /**
     * 精品名称
     */
    @TableField("BOUTIQUE_NAME")
    private String boutiqueName;

    /**
     * 门店ID
     */
    @TableField("DLR_ID")
    private String dlrId;

    /**
     * 门店编码
     */
    @TableField("DLR_CODE")
    private String dlrCode;

    /**
     * 门店名称
     */
    @TableField("DLR_NAME")
    private String dlrName;

    /**
     * 精品上架数量
     */
    @TableField("BOUTIQUE_PUTAWAY_NUM")
    private String boutiquePutawayNum;

    /**
     * 精品下架数量
     */
    @TableField("BOUTIQUE_SOLD_OUT_NUM")
    private String boutiqueSoldOutNum;

    /**
     * 精品状态(0：新增 1：已上架)
     */
    @TableField("BOUTIQUE_STATUS")
    private String boutiqueStatus;

    /**
     * 扩展字段1
     */
    @TableField("COLUMN1")
    private String column1;

    /**
     * 扩展字段2
     */
    @TableField("COLUMN2")
    private String column2;

    /**
     * 扩展字段3
     */
    @TableField("COLUMN3")
    private String column3;

    /**
     * 扩展字段4
     */
    @TableField("COLUMN4")
    private String column4;

    /**
     * 扩展字段5
     */
    @TableField("COLUMN5")
    private String column5;

    /**
     * 备注
     */
    @TableField("REMARK")
    private String remark;

    /**
     * 创建人
     */
    @TableField(value = "CREATOR", fill = FieldFill.INSERT)
    private String creator;

    /**
     * 创建人名称
     */
    @TableField(value = "CREATED_NAME", fill = FieldFill.INSERT)
    private String createdName;

    /**
     * 创建时间
     */
    @TableField(value = "CREATED_DATE", fill = FieldFill.INSERT)
    private LocalDateTime createdDate;

    /**
     * 最后更新人员
     */
    @TableField(value = "MODIFIER", fill = FieldFill.INSERT_UPDATE)
    private String modifier;

    /**
     * 最后更新人员名称
     */
    @TableField(value = "MODIFY_NAME", fill = FieldFill.INSERT_UPDATE)
    private String modifyName;

    /**
     * 最后更新时间
     */
    @TableField(value = "LAST_UPDATED_DATE", fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime lastUpdatedDate;

    /**
     * 是否可用
     */
    @TableField("IS_ENABLE")
    private String isEnable;

    /**
     * 并发控制ID
     */
    @TableField(value = "UPDATE_CONTROL_ID", fill = FieldFill.INSERT_UPDATE)
    private String updateControlId;

    public String getDetailId() {
        return detailId;
    }

    public void setDetailId(String detailId) {
        this.detailId = detailId;
    }
    public String getApplyId() {
        return applyId;
    }

    public void setApplyId(String applyId) {
        this.applyId = applyId;
    }
    public String getBoutiqueCode() {
        return boutiqueCode;
    }

    public void setBoutiqueCode(String boutiqueCode) {
        this.boutiqueCode = boutiqueCode;
    }
    public String getBoutiqueName() {
        return boutiqueName;
    }

    public void setBoutiqueName(String boutiqueName) {
        this.boutiqueName = boutiqueName;
    }
    public String getDlrId() {
        return dlrId;
    }

    public void setDlrId(String dlrId) {
        this.dlrId = dlrId;
    }
    public String getDlrCode() {
        return dlrCode;
    }

    public void setDlrCode(String dlrCode) {
        this.dlrCode = dlrCode;
    }
    public String getDlrName() {
        return dlrName;
    }

    public void setDlrName(String dlrName) {
        this.dlrName = dlrName;
    }
    public String getBoutiquePutawayNum() {
        return boutiquePutawayNum;
    }

    public void setBoutiquePutawayNum(String boutiquePutawayNum) {
        this.boutiquePutawayNum = boutiquePutawayNum;
    }
    public String getBoutiqueSoldOutNum() {
        return boutiqueSoldOutNum;
    }

    public void setBoutiqueSoldOutNum(String boutiqueSoldOutNum) {
        this.boutiqueSoldOutNum = boutiqueSoldOutNum;
    }
    public String getBoutiqueStatus() {
        return boutiqueStatus;
    }

    public void setBoutiqueStatus(String boutiqueStatus) {
        this.boutiqueStatus = boutiqueStatus;
    }
    public String getColumn1() {
        return column1;
    }

    public void setColumn1(String column1) {
        this.column1 = column1;
    }
    public String getColumn2() {
        return column2;
    }

    public void setColumn2(String column2) {
        this.column2 = column2;
    }
    public String getColumn3() {
        return column3;
    }

    public void setColumn3(String column3) {
        this.column3 = column3;
    }
    public String getColumn4() {
        return column4;
    }

    public void setColumn4(String column4) {
        this.column4 = column4;
    }
    public String getColumn5() {
        return column5;
    }

    public void setColumn5(String column5) {
        this.column5 = column5;
    }
    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }
    public String getCreatedName() {
        return createdName;
    }

    public void setCreatedName(String createdName) {
        this.createdName = createdName;
    }
    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }
    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier;
    }
    public String getModifyName() {
        return modifyName;
    }

    public void setModifyName(String modifyName) {
        this.modifyName = modifyName;
    }
    public LocalDateTime getLastUpdatedDate() {
        return lastUpdatedDate;
    }

    public void setLastUpdatedDate(LocalDateTime lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }
    public String getIsEnable() {
        return isEnable;
    }

    public void setIsEnable(String isEnable) {
        this.isEnable = isEnable;
    }
    public String getUpdateControlId() {
        return updateControlId;
    }

    public void setUpdateControlId(String updateControlId) {
        this.updateControlId = updateControlId;
    }

    @Override
    public String toString() {
        return "SacBuBoutiqueDetail{" +
        "detailId=" + detailId +
        ", applyId=" + applyId +
        ", boutiqueCode=" + boutiqueCode +
        ", boutiqueName=" + boutiqueName +
        ", dlrId=" + dlrId +
        ", dlrCode=" + dlrCode +
        ", dlrName=" + dlrName +
        ", boutiquePutawayNum=" + boutiquePutawayNum +
        ", boutiqueSoldOutNum=" + boutiqueSoldOutNum +
        ", boutiqueStatus=" + boutiqueStatus +
        ", column1=" + column1 +
        ", column2=" + column2 +
        ", column3=" + column3 +
        ", column4=" + column4 +
        ", column5=" + column5 +
        ", remark=" + remark +
        ", creator=" + creator +
        ", createdName=" + createdName +
        ", createdDate=" + createdDate +
        ", modifier=" + modifier +
        ", modifyName=" + modifyName +
        ", lastUpdatedDate=" + lastUpdatedDate +
        ", isEnable=" + isEnable +
        ", updateControlId=" + updateControlId +
        "}";
    }
}
