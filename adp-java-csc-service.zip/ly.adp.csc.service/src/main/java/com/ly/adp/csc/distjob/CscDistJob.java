package com.ly.adp.csc.distjob;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ly.adp.csc.service.ISacClueCenterService;
import com.ly.adp.csc.service.ISacComplaintsInfoService;
import com.ly.adp.csc.service.ISacOnecustInfoService;
import com.ly.adp.csc.service.ISacOnetaskInfoService;
import com.ly.adp.csc.service.ISacOnetaskLeadInTempService;
import com.ly.mp.acc.manage.service.IAccBuActivityService;

@Component
public class CscDistJob {

	@Autowired
	ISacOnecustInfoService sacOnecustInfoService;
	@Autowired
	ISacOnetaskInfoService sacOnetaskInfoService;
	@Autowired
	ISacComplaintsInfoService sacComplaintsInfoService;
	@Autowired
	ISacOnetaskLeadInTempService sacOnetaskLeadInTempService;
	@Autowired
	ISacClueCenterService sacClueCenterService;
	@Autowired
	IAccBuActivityService accBuActivityService;
	
	public void cscDistjob001() {
		// 客户信息变更记录定时（接口表到业务表）
		System.out.println("ADP_CSC_DISTJOB_DS001进来" + LocalDateTime.now());
		sacOnecustInfoService.SacOnecustChangeLogDbjob();
	}
	
	public void cscDistjob002() {
		// 任务人员导入定时调用（接口表到业务表）
		System.out.println("ADP_CSC_DISTJOB_DS002进来" + LocalDateTime.now());
		sacOnetaskLeadInTempService.taskInfoDbjob();
	}
	
	public void cscDistjob003() {
		// 任务发送消息定时调用
		System.out.println("ADP_CSC_DISTJOB_DS003进来" + LocalDateTime.now());
		sacOnetaskLeadInTempService.taskMsgDbjob();
	}
	
	public void cscDistjob004() {
		// 诉工单异常关单定时调用
		System.out.println("ADP_CSC_DISTJOB_DS004进来" + LocalDateTime.now());
		sacComplaintsInfoService.complaintsDbjob();
	}
	
	
	public void cscDistjob005() {
		// 任务发布对象导入定时调用
		System.out.println("ADP_CSC_DISTJOB_DS005进来" + LocalDateTime.now());
		sacOnetaskInfoService.taskPublishJob();
	}
	
	public void cscDistjob006() {
		// 任务周期重复执行定时调用
		System.out.println("ADP_CSC_DISTJOB_DS006进来" + LocalDateTime.now());
		sacOnetaskInfoService.cycleExecuteTask();
	}
	
	public void cscDistjob007() {
		// 超24小时线索自动分配定时调用
		System.out.println("ADP_CSC_DISTJOB_DS007进来" + LocalDateTime.now());
		sacClueCenterService.clueAutoAsgnDbjob();
	}
	public void cscDistjob008() {
		// 活动状态更新：获取活动类型为非APP的活动，以及已审核的，到了发布时间的活动，更新发布状态为已发布
		System.out.println("ADP_CSC_DISTJOB_DS008进来" + LocalDateTime.now());
		accBuActivityService.updateActivityStatusDistJob();
	}
}
