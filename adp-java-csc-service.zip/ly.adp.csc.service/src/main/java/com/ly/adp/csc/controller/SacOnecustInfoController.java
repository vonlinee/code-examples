package com.ly.adp.csc.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.net.HttpHeaders;
import com.ly.adp.csc.entities.in.SacOneCustResumeIn;
import com.ly.adp.csc.entities.in.SacOnecustInfoIn;
import com.ly.adp.csc.service.ISacOneCustResumeService;
import com.ly.adp.csc.service.ISacOnecustInfoService;
import com.ly.mp.busicen.common.context.BusicenInvoker;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Api(value = "CSC客户信息服务", tags = "CSC客户信息服务")
@RestController
@RequestMapping(value = "/ly/adp/csc/onecustinfo", produces = { MediaType.APPLICATION_JSON_VALUE })
public class SacOnecustInfoController {
	@Autowired
	ISacOnecustInfoService sacOnecustInfoService;
	@Autowired
	ISacOneCustResumeService sacOneCustResumeService;

	@ApiOperation(value = "客户信息查询", notes = "客户查询")
	@PostMapping(value = "/queryonecustinfo.do")
	public ListResult<Map<String, Object>> sacOnecustInfoFindInfo(
			@RequestHeader(HttpHeaders.AUTHORIZATION) String token,
			@RequestBody(required = false) SacOnecustInfoIn dateInfo) {
		return BusicenInvoker.doList(() -> {
			return sacOnecustInfoService.sacOnecustInfoFindInfo(dateInfo);
		}).result();
	}

	@ApiOperation(value = "客户信息维护", notes = "客户信息维护")
	@PostMapping(value = "/save.do")
	public EntityResult<Map<String, Object>> sacOnecustInfoSaveInfo(
			@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) Map<String, Object> dateInfo) {
		return BusicenInvoker.doEntity(() -> {
			return sacOnecustInfoService.sacOnecustInfoSaveInfo(dateInfo, authentication);
		}).result();
	}

	@ApiOperation(value = "客户履历查询", notes = "客户履历查询")
	@PostMapping(value = "/queryresume.do")
	public ListResult<Map<String, Object>> sacOnecustResumeFindAll(
			@RequestHeader(HttpHeaders.AUTHORIZATION) String token,
			@RequestBody(required = false) SacOneCustResumeIn dataInfo) {
		return BusicenInvoker.doList(() -> sacOneCustResumeService.sacOnecustResumeFindAll(dataInfo)).result();
	}

	@ApiOperation(value = "客户履历保存", notes = "客户履历保存")
	@PostMapping(value = "/resumesave.do")
	public EntityResult<Map<String, Object>> sacOnecustResumeSaveInfo(
			@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) Map<String, Object> dateInfo) {
		return BusicenInvoker.doEntity(() -> {
			return sacOneCustResumeService.sacOnecustResumeSaveInfo(dateInfo, authentication);
		}).result();

	}

	@ApiOperation(value = "客户信息变更记录查询", notes = "客户信息变更记录查询")
	@PostMapping(value = "/querycustlog.do")
	public ListResult<Map<String, Object>> sacOnecustChangeLogFindInfo(
			@RequestHeader(HttpHeaders.AUTHORIZATION) String token,
			@RequestBody(required = false) SacOnecustInfoIn dateInfo) {
		return BusicenInvoker.doList(() -> {
			return sacOnecustInfoService.sacOnecustChangeLogFindInfo(dateInfo, token);
		}).result();
	}

	@ApiOperation(value = "客户信息变更记录定时(临时)", notes = "客户信息变更记录定时(临时)")
	@PostMapping(value = "/logdbjob.do")
	public void SacOnecustChangeLogDbjob(@RequestHeader(HttpHeaders.AUTHORIZATION) String token) {
		sacOnecustInfoService.SacOnecustChangeLogDbjob();
	}

	@ApiOperation(value = "客户信息刷新保存", notes = "客户信息刷新保存")
	@PostMapping(value = "/SacOnecustRefresh.do")
	public EntityResult<Map<String, Object>> SacOnecustRefresh(
			@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) Map<String, Object> dateInfo) {
		return BusicenInvoker.doEntity(() -> {
			return sacOnecustInfoService.SacOnecustRefresh(dateInfo, authentication);
		}).result();
	}
	
	@ApiOperation(value = "CDP参数加密解密", notes = "CDP参数加密解密")
	@PostMapping(value = "/crackCipher")
	public OptResult crackCipher(@RequestBody(required = false) Map<String, Object> dateInfo) {
		return BusicenInvoker.doOpt(() -> {
			return sacOnecustInfoService.crackCipher(dateInfo);
		}).result();
	}
}
