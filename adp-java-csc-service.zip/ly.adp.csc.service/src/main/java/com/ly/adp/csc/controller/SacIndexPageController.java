package com.ly.adp.csc.controller;

import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import com.ly.mp.bucn.pack.entity.ParamPage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.net.HttpHeaders;
import com.ly.adp.csc.service.ISacBasisLogService;
import com.ly.adp.csc.service.ISacIndexPageInfoService;
import com.ly.mp.busicen.common.context.BusicenInvoker;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Api(value = "CSC首页信息服务", tags = "CSC首页信息服务")
@RestController
@RequestMapping(value = "/ly/sac/indexpage/", produces = { MediaType.APPLICATION_JSON_VALUE })
public class SacIndexPageController {

	@Autowired
	ISacIndexPageInfoService sacIndexPageService;
	
	@Autowired
	ISacBasisLogService sacBasisLogService;

	@ApiOperation(value = "查询首页显示信息", notes = "查询首页显示信息")
	@PostMapping(value = "/queryinfobydlr.do")
	public EntityResult<Map<String, Object>> sacTestDriveReviewRecordFindAll(
			@RequestHeader(HttpHeaders.AUTHORIZATION) String token,
			@RequestBody(required = false) Map<String, Object> dataInfo) {
		return BusicenInvoker.doEntity(() -> sacIndexPageService.sacIndexPageInfoQueryByDlr(token, dataInfo)).result();
	}

	@ApiOperation(value = "根据岗位获取员工信息", notes = "根据岗位获取员工信息")
	@PostMapping(value = "/locationempinfo.do")
	public ListResult<Map<String, Object>> locationEmpInfo(@RequestHeader(HttpHeaders.AUTHORIZATION) String token,
			@RequestBody(required = false) Map<String, Object> dataInfo) {
		return BusicenInvoker.doList(() -> sacIndexPageService.locationEmpInfo(token, dataInfo)).result();
	}
	
	@ApiOperation(value = "查询首页线索热度比例", notes = "查询首页线索热度比例")
	@PostMapping(value = "/queryHeatRatio.do")
	public EntityResult<Map<String, Object>> queryHeatRatio(
			@RequestHeader(HttpHeaders.AUTHORIZATION) String token,
			@RequestBody(required = false) Map<String, Object> dataInfo) {
		return BusicenInvoker.doEntity(() -> sacIndexPageService.queryHeatRatio(token, dataInfo)).result();
	}
	
	@ApiOperation(value = "看板指标-线索指标", notes = "看板指标-线索指标")
	@PostMapping(value = "/queryClueDlrReport.do")
	public EntityResult<Map<String, Object>> queryClueDlrReport(
			@RequestHeader(HttpHeaders.AUTHORIZATION) String token,
			@RequestBody(required = false) Map<String, Object> dataInfo) {
		return BusicenInvoker.doEntity(() -> sacIndexPageService.queryAdpReportForm(token, dataInfo)).result();
	}
	
	@ApiOperation(value = "看板指标-试驾指标", notes = "看板指标-试驾指标")
	@PostMapping(value = "/queryTestDriveReport.do")
	public EntityResult<Map<String, Object>> queryTestDriveReport(
			@RequestHeader(HttpHeaders.AUTHORIZATION) String token,
			@RequestBody(required = false) Map<String, Object> dataInfo) {
		return BusicenInvoker.doEntity(() -> sacIndexPageService.queryTestDriveReport(token, dataInfo)).result();
	}
	
	@ApiOperation(value = "看板指标-活动指标", notes = "看板指标-活动指标")
	@PostMapping(value = "/queryActivityReport.do")
	public EntityResult<Map<String, Object>> queryActivityReport(
			@RequestHeader(HttpHeaders.AUTHORIZATION) String token,
			@RequestBody(required = false) Map<String, Object> dataInfo) {
		return BusicenInvoker.doEntity(() -> sacIndexPageService.queryActivityReport(token, dataInfo)).result();
	}
	
	@ApiOperation(value = "看板指标-报表展板-线索和订单数量", notes = "看板指标-报表展板-线索和订单数量")
	@PostMapping(value = "/queryReportBoardClueAndOrder.do")
	public EntityResult<Map<String, Object>> queryReportBoardClueAndOrder(
			@RequestHeader(HttpHeaders.AUTHORIZATION) String token,
			@RequestBody(required = false) Map<String, Object> dataInfo) {
		return BusicenInvoker.doEntity(() -> sacIndexPageService.queryReportBoardClueAndOrder(token, dataInfo)).result();
	}
	
	@ApiOperation(value = "看板指标-报表展板-门店数量", notes = "看板指标-报表展板-门店数量")
	@PostMapping(value = "/queryReportBoardDlr.do")
	public EntityResult<Map<String, Object>> queryReportBoardDlr(
			@RequestHeader(HttpHeaders.AUTHORIZATION) String token,
			@RequestBody(required = false) Map<String, Object> dataInfo) {
		return BusicenInvoker.doEntity(() -> sacIndexPageService.queryReportBoardDlr(token, dataInfo)).result();
	}
	
	@ApiOperation(value = "看板指标-报表展板-活动数量", notes = "看板指标-报表展板-活动数量")
	@PostMapping(value = "/queryReportBoardAct.do")
	public EntityResult<Map<String, Object>> queryReportBoardAct(
			@RequestHeader(HttpHeaders.AUTHORIZATION) String token,
			@RequestBody(required = false) Map<String, Object> dataInfo) {
		return BusicenInvoker.doEntity(() -> sacIndexPageService.queryReportBoardAct(token, dataInfo)).result();
	}
	
	@ApiOperation(value = "看板指标-报表展板-展车试驾车数量", notes = "看板指标-报表展板-展车试驾车数量")
	@PostMapping(value = "/queryReportBoardCar.do")
	public EntityResult<Map<String, Object>> queryReportBoardCar(
			@RequestHeader(HttpHeaders.AUTHORIZATION) String token,
			@RequestBody(required = false) Map<String, Object> dataInfo) {
		return BusicenInvoker.doEntity(() -> sacIndexPageService.queryReportBoardCar(token, dataInfo)).result();
	}
	
	@ApiOperation(value = "用户分组界面线索统计", notes = "用户分组界面线索统计")
	@PostMapping(value = "/queryUserGroupClueReport.do")
	public EntityResult<Map<String, Object>> queryUserGroupClueReport(
			@RequestHeader(HttpHeaders.AUTHORIZATION) String token,
			@RequestBody(required = false) Map<String, Object> dataInfo) {
		return BusicenInvoker.doEntity(() -> sacIndexPageService.queryUserGroupClueReport(token, dataInfo)).result();
	}
	
	@ApiOperation(value = "切店日志记录新增", notes = "切店日志记录新增")
	@PostMapping(value = "/userSwitchDlrLogRecord.do")
	public OptResult switchDlrLogRecord(
			@RequestHeader(HttpHeaders.AUTHORIZATION) String token,
			@RequestBody(required = false) Map<String, Object> dataInfo) {
		return BusicenInvoker.doOpt(() -> sacBasisLogService.sacSwitcchDlrLogInsertOne(dataInfo, token)).result();
	}
	
	@ApiOperation(value = "销售顾问日报汇总", notes = "销售顾问日报汇总")
	@PostMapping(value = "/querySaleConstantReport.do")
	public EntityResult<Map<String, Object>> querySaleConstantReport(
			@RequestHeader(HttpHeaders.AUTHORIZATION) String token,
			@RequestBody(required = false) Map<String, Object> dataInfo) {
		return BusicenInvoker.doEntity(() -> sacIndexPageService.querySaleConstantReport(token, dataInfo)).result();
	}
	
	@ApiOperation(value = "线索指标统计报表", notes = "线索指标统计报表")
	@PostMapping(value = "/queryClueStatisticalReport.do")
	public ListResult<Map<String, Object>> queryClueStatisticalReport(
			@RequestHeader(HttpHeaders.AUTHORIZATION) String token,
			@RequestBody(required = false) Map<String, Object> dataInfo) {
		return BusicenInvoker.doList(() -> sacIndexPageService.queryClueStatisticalReport(token, dataInfo)).result();
	}
	
	@ApiOperation(value = "线索指标统计报表导出", notes = "线索指标统计报表导出")
	@PostMapping(value = "/queryClueStatisticalReportExport.do")
	public OptResult queryClueStatisticalReportExport(@RequestHeader(HttpHeaders.AUTHORIZATION) String token,@RequestBody(required = false) Map<String, Object> dataInfo, HttpServletResponse response) {
		return BusicenInvoker.doOpt(() -> {return sacIndexPageService.queryClueStatisticalReportExport(dataInfo, token, response);}).result();
	}

	@ApiOperation(value = "城市与休眠线索报表", notes = "城市与休眠线索报表")
	@PostMapping(value = "/queryClueDormancyReport.do")
	public ListResult<Map<String, Object>> queryClueDormancyReport(
			@RequestHeader(HttpHeaders.AUTHORIZATION) String token,
			@RequestBody(required = false) ParamPage<Map<String, Object>> dataInfo) {
		return BusicenInvoker.doList(() -> sacIndexPageService.queryClueDormancyReport(token, dataInfo)).result();
	}

	@ApiOperation(value = "城市与休眠线索报表导出", notes = "城市与休眠线索报表导出")
	@PostMapping(value = "/queryClueDormancyReportExport.do")
	public OptResult queryClueDormancyReportExport(@RequestHeader(HttpHeaders.AUTHORIZATION) String token,
												   @RequestBody(required = false) ParamPage<Map<String, Object>> dataInfo, HttpServletResponse response) {
		return BusicenInvoker.doOpt(() -> {return sacIndexPageService.queryClueDormancyReportExport(dataInfo, token, response);}).result();
	}

	@ApiOperation(value = "市场类活动报表", notes = "市场类活动报表")
	@PostMapping(value = "/queryMarketActivityReport.do")
	public ListResult<Map<String, Object>> queryMarketActivityReport(
			@RequestHeader(HttpHeaders.AUTHORIZATION) String token,
			@RequestBody(required = false) ParamPage<Map<String, Object>> dataInfo) {
		return BusicenInvoker.doList(() -> sacIndexPageService.queryMarketActivityReport(token, dataInfo)).result();
	}

	@ApiOperation(value = "市场类活动报表导出", notes = "市场类活动报表导出")
	@PostMapping(value = "/queryMarketActivityReportExport.do")
	public OptResult queryMarketActivityReportExport(@RequestHeader(HttpHeaders.AUTHORIZATION) String token,@RequestBody(required = false) ParamPage<Map<String, Object>> dataInfo, HttpServletResponse response) {
		return BusicenInvoker.doOpt(() -> {return sacIndexPageService.queryMarketActivityReportExport(dataInfo, token, response);}).result();
	}
}