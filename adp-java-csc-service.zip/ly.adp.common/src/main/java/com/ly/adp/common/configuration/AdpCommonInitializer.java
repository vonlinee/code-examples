package com.ly.adp.common.configuration;

import com.ly.mp.component.conf.web.CommonInitializer;
import com.ly.mp.component.helper.SessionHelper;
import org.apache.commons.lang.StringUtils;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@Configuration
public class AdpCommonInitializer extends CommonInitializer {
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        super.addInterceptors(registry);
        registry.addInterceptor(this.bucnInterceptor()).addPathPatterns(new String[]{"/**/*.do"}).excludePathPatterns(new String[]{"/mp/login/**"}).excludePathPatterns(new String[]{"/mp/api/**"}).excludePathPatterns(new String[]{"/mp/pay/weixin/app/gateway.do"}).excludePathPatterns(new String[]{"/mp/log/run/add.do"}).excludePathPatterns(new String[]{"/mp/identity/**"}).excludePathPatterns(new String[]{"/mp/wfETX/**"}).excludePathPatterns(new String[]{"/mp/framework/sysetload.do"}).excludePathPatterns(new String[]{"/mp/framework/modifyPassword.do"}).excludePathPatterns(new String[]{"/mp/framework/getBlacklist.do"});
    }

    @Bean
    public BucnInterceptor bucnInterceptor(){
        return new BucnInterceptor();
    }

    public static class BucnInterceptor implements HandlerInterceptor{

        @Override
        public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
            String strToken = request.getParameter("token");
            if (!StringUtils.isEmpty(strToken)) {
                SessionHelper.get("busicen"+ strToken);//延长 "busicen"+ strToken 缓存时间
            }
            return true;
        }
    }
}
