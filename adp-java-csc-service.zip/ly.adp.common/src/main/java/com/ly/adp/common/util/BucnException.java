package com.ly.adp.common.util;

public class BucnException extends RuntimeException {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public BucnException(String message) {
        super(message);
    }

    public static BucnException create(String message) {
        return new BucnException(message);
    }

}