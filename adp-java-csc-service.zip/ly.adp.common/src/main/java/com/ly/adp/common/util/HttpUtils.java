package com.ly.adp.common.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.zip.GZIPInputStream;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSONObject;
import com.ly.mp.busicen.common.util.LogBuilder;

/**
 *
 * @author ly
 *
 */
public class HttpUtils {

	private static Logger log = LoggerFactory.getLogger(HttpUtils.class);

	/**
	 * 支持的Http method
	 */
	private enum HttpMethod {
		POST, DELETE, GET, PUT, HEAD;
	}

	/**
	 * POST方法提交Http请求，语义为“增加” <br/>
	 * 注意：Http方法中只有POST方法才能使用body来提交内容
	 * 
	 * @param url            资源路径（如果url中已经包含参数，则params应该为null）
	 * @param params         参数
	 * @param connectTimeout 连接超时时间（单位为ms）
	 * @param readTimeout    读取超时时间（单位为ms）
	 * @param charset        字符集（一般该为“utf-8”）
	 * @return
	 */
	public static String post(String url, Map params, int connectTimeout, int readTimeout, String charset) {
		return invokeUrl(url, params, null, connectTimeout, readTimeout, charset, HttpMethod.POST);
	}

	/**
	 * POST方法提交Http请求，语义为“增加” <br/>
	 * 注意：Http方法中只有POST方法才能使用body来提交内容
	 * 
	 * @param url            资源路径（如果url中已经包含参数，则params应该为null）
	 * @param params         参数
	 * @param headers        请求头参数
	 * @param connectTimeout 连接超时时间（单位为ms）
	 * @param readTimeout    读取超时时间（单位为ms）
	 * @param charset        字符集（一般该为“utf-8”）
	 * @return
	 */
	public static String post(String url, Map params, Map<String, String> headers, int connectTimeout, int readTimeout,
			String charset) {
		return invokeUrl(url, params, headers, connectTimeout, readTimeout, charset, HttpMethod.POST);
	}

	/**
	 * GET方法提交Http请求，语义为“查询”
	 * 
	 * @param url            资源路径（如果url中已经包含参数，则params应该为null）
	 * @param params         参数
	 * @param connectTimeout 连接超时时间（单位为ms）
	 * @param readTimeout    读取超时时间（单位为ms）
	 * @param charset        字符集（一般该为“utf-8”）
	 * @return
	 */
	public static String get(String url, Map params, int connectTimeout, int readTimeout, String charset) {
		return invokeUrl(url, params, null, connectTimeout, readTimeout, charset, HttpMethod.GET);
	}

	/**
	 * GET方法提交Http请求，语义为“查询”
	 * 
	 * @param url            资源路径（如果url中已经包含参数，则params应该为null）
	 * @param params         参数
	 * @param headers        请求头参数
	 * @param connectTimeout 连接超时时间（单位为ms）
	 * @param readTimeout    读取超时时间（单位为ms）
	 * @param charset        字符集（一般该为“utf-8”）
	 * @return
	 */
	public static String get(String url, Map params, Map<String, String> headers, int connectTimeout, int readTimeout,
			String charset) {
		return invokeUrl(url, params, headers, connectTimeout, readTimeout, charset, HttpMethod.GET);
	}

	/**
	 * PUT方法提交Http请求，语义为“更改” <br/>
	 * 注意：PUT方法也是使用url提交参数内容而非body，所以参数最大长度收到服务器端实现的限制，Resin大概是8K
	 * 
	 * @param url            资源路径（如果url中已经包含参数，则params应该为null）
	 * @param params         参数
	 * @param connectTimeout 连接超时时间（单位为ms）
	 * @param readTimeout    读取超时时间（单位为ms）
	 * @param charset        字符集（一般该为“utf-8”）
	 * @return
	 */
	public static String put(String url, Map params, int connectTimeout, int readTimeout, String charset) {
		return invokeUrl(url, params, null, connectTimeout, readTimeout, charset, HttpMethod.PUT);
	}

	/**
	 * PUT方法提交Http请求，语义为“更改” <br/>
	 * 注意：PUT方法也是使用url提交参数内容而非body，所以参数最大长度收到服务器端实现的限制，Resin大概是8K
	 * 
	 * @param url            资源路径（如果url中已经包含参数，则params应该为null）
	 * @param params         参数
	 * @param headers        请求头参数
	 * @param connectTimeout 连接超时时间（单位为ms）
	 * @param readTimeout    读取超时时间（单位为ms）
	 * @param charset        字符集（一般该为“utf-8”）
	 * @return
	 */
	public static String put(String url, Map params, Map<String, String> headers, int connectTimeout, int readTimeout,
			String charset) {
		return invokeUrl(url, params, headers, connectTimeout, readTimeout, charset, HttpMethod.PUT);
	}

	/**
	 * DELETE方法提交Http请求，语义为“删除”
	 * 
	 * @param url            资源路径（如果url中已经包含参数，则params应该为null）
	 * @param params         参数
	 * @param connectTimeout 连接超时时间（单位为ms）
	 * @param readTimeout    读取超时时间（单位为ms）
	 * @param charset        字符集（一般该为“utf-8”）
	 * @return
	 */
	public static String delete(String url, Map params, int connectTimeout, int readTimeout, String charset) {
		return invokeUrl(url, params, null, connectTimeout, readTimeout, charset, HttpMethod.DELETE);
	}

	/**
	 * DELETE方法提交Http请求，语义为“删除”
	 * 
	 * @param url            资源路径（如果url中已经包含参数，则params应该为null）
	 * @param params         参数
	 * @param headers        请求头参数
	 * @param connectTimeout 连接超时时间（单位为ms）
	 * @param readTimeout    读取超时时间（单位为ms）
	 * @param charset        字符集（一般该为“utf-8”）
	 * @return
	 */
	public static String delete(String url, Map params, Map<String, String> headers, int connectTimeout,
			int readTimeout, String charset) {
		return invokeUrl(url, params, headers, connectTimeout, readTimeout, charset, HttpMethod.DELETE);
	}

	/**
	 * HEAD方法提交Http请求，语义同GET方法 <br/>
	 * 跟GET方法不同的是，用该方法请求，服务端不返回message body只返回头信息，能节省带宽
	 * 
	 * @param url            资源路径（如果url中已经包含参数，则params应该为null）
	 * @param params         参数
	 * @param connectTimeout 连接超时时间（单位为ms）
	 * @param readTimeout    读取超时时间（单位为ms）
	 * @param charset        字符集（一般该为“utf-8”）
	 * @return
	 */
	public static String head(String url, Map params, int connectTimeout, int readTimeout, String charset) {
		return invokeUrl(url, params, null, connectTimeout, readTimeout, charset, HttpMethod.HEAD);
	}

	/**
	 * HEAD方法提交Http请求，语义同GET方法 <br/>
	 * 跟GET方法不同的是，用该方法请求，服务端不返回message body只返回头信息，能节省带宽
	 * 
	 * @param url            资源路径（如果url中已经包含参数，则params应该为null）
	 * @param params         参数
	 * @param headers        请求头参数
	 * @param connectTimeout 连接超时时间（单位为ms）
	 * @param readTimeout    读取超时时间（单位为ms）
	 * @param charset        字符集（一般该为“utf-8”）
	 * @return
	 */
	public static String head(String url, Map params, Map<String, String> headers, int connectTimeout, int readTimeout,
			String charset) {
		return invokeUrl(url, params, headers, connectTimeout, readTimeout, charset, HttpMethod.HEAD);
	}

	/*
	 * public static void main(String[] args) { Map params = new HashMap();
	 * params.put("phoneNo", "中文"); String str = HttpUtil.get(
	 * "http://localhost:9092/elis_smp_als_dmz/do/app/activitySupport/demo", params,
	 * 3000, 3000, "UTF-8"); System.out.println(str); }
	 */

	public static String sendPost(String url, String api, String appId, String nonceStr, String timestamp, String param,
			String sign, int connectTimeout, int readTimeOut) {
		BufferedWriter out = null;
		BufferedReader in = null;
		StringBuilder result = new StringBuilder();
		try {
			URL realUrl = new URL(url);
			// 打开和URL之间的连接
			URLConnection conn = realUrl.openConnection();
			conn.setRequestProperty("sign", sign);
			conn.setRequestProperty("api", api);
			conn.setRequestProperty("appid", appId);
			conn.setRequestProperty("noncestr", nonceStr);// 随机uuid字符串
			conn.setRequestProperty("timestamp", timestamp);// 13秒毫秒时间戳
			conn.setRequestProperty("Content-Type", "application/json");
			// 设置通用的请求属性
			conn.setRequestProperty("accept", "*/*");
			conn.setRequestProperty("connection", "Keep-Alive");
			conn.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
			conn.setConnectTimeout(connectTimeout);
			conn.setReadTimeout(readTimeOut);
			// 发送POST请求必须设置如下两行
			conn.setDoOutput(true);
			conn.setDoInput(true);

			out = new BufferedWriter(new OutputStreamWriter(conn.getOutputStream(), StandardCharsets.UTF_8));
			out.write(param);
			out.flush();
			in = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
			String line;
			while ((line = in.readLine()) != null) {
				result.append(line);
			}
		} catch (Exception e) {
			// connect timed out
			// Read timed out
			return e.getLocalizedMessage();
		}
		// 使用finally块来关闭输出流、输入流
		finally {
			try {
				if (out != null) {
					out.close();
				}
				if (in != null) {
					in.close();
				}
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		return result.toString();
	}

	public static String byteHEX(byte ib) {
		char[] Digit = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
		char[] ob = new char[2];
		ob[0] = Digit[(ib >>> 4) & 0X0F];
		ob[1] = Digit[ib & 0X0F];
		String s = new String(ob);
		return s;
	}

	public static String getMd5Hex(String str) {
		try {
			MessageDigest digist = MessageDigest.getInstance("MD5");
			byte[] rs = digist.digest(str.getBytes("UTF-8"));
			StringBuffer digestHexStr = new StringBuffer();
			for (int i = 0; i < 16; i++) {
				digestHexStr.append(byteHEX(rs[i]));
			}
			return digestHexStr.toString();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static String getMd5_X32(String appId, String api, String jsonVin, String nonceStr, String timestamp,
			String appKey, boolean capitalize) {
		String str = appId + api + jsonVin + nonceStr + timestamp + appKey;
		try {
			MessageDigest md5 = MessageDigest.getInstance("MD5");
			md5.update((str).getBytes(StandardCharsets.UTF_8));
			byte[] b = md5.digest();
			int i;
			StringBuilder buf = new StringBuilder("");
			for (byte value : b) {
				i = value;
				if (i < 0) {
					i += 256;
				}
				if (i < 16) {
					buf.append("0");
				}
				buf.append(Integer.toHexString(i));
			}
			if (capitalize) {
				return buf.toString().toUpperCase();
			}
			return buf.toString();
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	/**
	 * RestTemplate方式
	 * 
	 * @param soap
	 */
	public static Map<String, String> restTemplate(String soap, String url, String soapAction) {
		RestTemplate template = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		Map<String, String> map = new HashMap<>();
		headers.add("SOAPAction", soapAction);
		headers.add("Content-Type", "text/xml;charset=UTF-8");
		org.springframework.http.HttpEntity<String> entity = new org.springframework.http.HttpEntity<>(soap, headers);
		ResponseEntity<String> response = template.postForEntity(url, entity, String.class);
		if (response.getStatusCode() == org.springframework.http.HttpStatus.OK) {
			String back = template.postForEntity(url, entity, String.class).getBody();
			System.out.println("restTemplate返回soap：" + back);
			map.put("result", "1");
			map.put("message", back);
			return map;
		} else {
			System.out.println("restTemplate返回状态码：" + response.getStatusCode());
			map.put("result", "0");
			map.put("message", response.getStatusCode() + "DOA Webservice接口调用异常!");
			return map;
		}
	}

	/**
	 * 向指定 URL 发送POST方法的请求(仅供参考)
	 * 
	 * @param url   发送请求的 URL
	 * @param param 请求参数，请求参数应该是 name1=value1&name2=value2 的形式。
	 * @return 所代表远程资源的响应结果
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private static String invokeUrl(String url, Map params, Map<String, String> headers, int connectTimeout,
			int readTimeout, String encoding, HttpMethod method) {
		// 构造请求参数字符串
		StringBuilder paramsStr = null;
		String reqType = "";
		if (headers != null && headers.containsKey("content-type")) {
			reqType = headers.get("content-type");
		}
		if (params != null) {
			paramsStr = new StringBuilder();
			Set<Map.Entry> entries = params.entrySet();
			if ("application/json".equals(reqType)) {
				JSONObject jsonObj = new JSONObject(params);
				paramsStr.append(jsonObj.toJSONString());
			} else {
				for (Map.Entry entry : entries) {
					String value = (entry.getValue() != null) ? (String.valueOf(entry.getValue())) : "";
					paramsStr.append(entry.getKey() + "=" + value + "&");
				}
			}

			// 只有POST方法才能通过OutputStream(即form的形式)提交参数
			if (method != HttpMethod.POST) {
				url += "?" + paramsStr.toString();
			}
		}

		URL uUrl = null;
		HttpURLConnection conn = null;
		BufferedWriter out = null;
		BufferedReader in = null;
		try {
			// 创建和初始化连接
			uUrl = new URL(url);
			conn = (HttpURLConnection) uUrl.openConnection();
			if (reqType != null && reqType.contains("application/json")) {
				// conn.setRequestProperty("content-type", "application/json");
			} else {
				conn.setRequestProperty("content-type", "application/x-www-form-urlencoded");
			}
			conn.setRequestMethod(method.toString());
			conn.setDoOutput(true);
			conn.setDoInput(true);
			// 设置连接超时时间
			conn.setConnectTimeout(connectTimeout);
			// 设置读取超时时间
			conn.setReadTimeout(readTimeout);
			// 指定请求header参数
			if (headers != null && headers.size() > 0) {
				Set<String> headerSet = headers.keySet();
				for (String key : headerSet) {
					conn.setRequestProperty(key, headers.get(key));
				}
			}

			if (paramsStr != null && method == HttpMethod.POST) {
				// 发送请求参数
				out = new BufferedWriter(new OutputStreamWriter(conn.getOutputStream(), encoding));
				out.write(paramsStr.toString());
				out.flush();
			}

			// 接收返回结果
			StringBuilder result = new StringBuilder();
			String encodingRes = conn.getContentEncoding();
			if (encodingRes != null && encodingRes.equals("gzip")) { // 如果服务器压缩了要解压，不然是乱码
				GZIPInputStream gZIPInputStream = new GZIPInputStream(conn.getInputStream());
				BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(gZIPInputStream));
				String line = null;
				while ((line = bufferedReader.readLine()) != null) {
					// 转化为UTF-8的编码格式
					line = new String(line.getBytes(encoding));
					result.append(line);
				}
				bufferedReader.close();
			} else {
				in = new BufferedReader(new InputStreamReader(conn.getInputStream(), encoding));
				if (in != null) {
					String line = "";
					while ((line = in.readLine()) != null) {
						result.append(line);
					}
				}
			}

			return result.toString();
		} catch (Exception e) {
			e.printStackTrace();
			log.error(LogBuilder.getErrParams(LogBuilder.Module.CIP, "HTTP请求错误",
					new StringBuilder().append("url【").append(url).append("】").append("params【").append(paramsStr)
							.append("】").append("headers【").append(headers).append("】").append("connectTimeout【")
							.append(connectTimeout).append("】").append("readTimeout【").append(readTimeout).append("】")
							.append("encoding【").append(encoding).append("】").append("method【").append(method)
							.append("】").append("Exception【").append(ExceptionUtils.getStackTrace(e)).append("】")
							.toString()));
			// 处理错误流，提高http连接被重用的几率

			try {
				byte[] buf = new byte[100];
				InputStream es = conn.getErrorStream();
				if (es != null) {
					while (es.read(buf) > 0) {
						;
					}
					es.close();
				}
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				if (out != null) {
					out.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				if (in != null) {
					in.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			// 关闭连接
			if (conn != null) {
				conn.disconnect();
			}
		}
		return null;
	}

}
