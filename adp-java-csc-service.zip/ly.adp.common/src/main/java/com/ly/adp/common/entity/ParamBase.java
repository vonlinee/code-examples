package com.ly.adp.common.entity;

import java.io.Serializable;

public class ParamBase<T> implements Serializable {

    T param;

    public T getParam() {
        return param;
    }

    public void setParam(T param) {
        this.param = param;
    }
}