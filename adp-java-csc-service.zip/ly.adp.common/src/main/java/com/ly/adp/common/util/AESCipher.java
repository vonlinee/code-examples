package com.ly.adp.common.util;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

public class AESCipher {
	private static final String KEY_ALGORITHM = "AES";
	private static final String DEFAULT_CIPHER_ALGORITHM = "AES/ECB/PKCS5Padding";
	KeyGenerator keyGenerator = KeyGenerator.getInstance(KEY_ALGORITHM);
	private static Cipher encryptCipher;
	private static Cipher decryptCipher;

	public AESCipher(String aesKey) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException {
		SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG");
		secureRandom.setSeed(aesKey.getBytes());
		keyGenerator.init(256, secureRandom);
		SecretKey secretKey = keyGenerator.generateKey();
		SecretKeySpec secretKeySpec = new SecretKeySpec(secretKey.getEncoded(), KEY_ALGORITHM);
		encryptCipher = Cipher.getInstance(DEFAULT_CIPHER_ALGORITHM);
		encryptCipher.init(Cipher.ENCRYPT_MODE, secretKeySpec);
		decryptCipher = Cipher.getInstance(DEFAULT_CIPHER_ALGORITHM);
		decryptCipher.init(Cipher.DECRYPT_MODE, secretKeySpec);
	}

	public String encrypt(String content) throws BadPaddingException, IllegalBlockSizeException {
		if (content == null) {
			return null;
		}
		if (StringUtils.isBlank(content)) {
			return "";
		}
		byte[] byteContent = content.getBytes(StandardCharsets.UTF_8);
		byte[] bytes = encryptCipher.doFinal(byteContent);
		return Base64.encodeBase64String(bytes);
	}

	public String decrypt(String content) throws BadPaddingException, IllegalBlockSizeException {
		if (content == null) {
			return null;
		}
		if (StringUtils.isBlank(content)) {
			return "";
		}
		byte[] bytes = decryptCipher.doFinal(Base64.decodeBase64(content));
		return new String(bytes, StandardCharsets.UTF_8);
	}
}