package com.ly.mp.busicen.common.context;

public class BusicenException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public BusicenException(String message) {
		super(message);
	}
	
	public static BusicenException create(String message) {
		return new BusicenException(message);
	}

}
