package com.ly.mp.busicen.common.entity;

import java.io.Serializable;

public class WfParamEntity implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7630682809824856632L;
	
	private String token ;
	private String subJson;
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getSubJson() {
		return subJson;
	}
	public void setSubJson(String subJson) {
		this.subJson = subJson;
	}
	
	

}
