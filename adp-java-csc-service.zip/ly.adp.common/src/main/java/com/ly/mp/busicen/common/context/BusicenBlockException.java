package com.ly.mp.busicen.common.context;

public class BusicenBlockException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public BusicenBlockException(String message) {
		super(message);
	}
	
	public static BusicenBlockException create(String message) {
		return new BusicenBlockException(message);
	}

}
