package com.ly.mp.busicen.common.response;

/**
 * 返回结果类
 * @author ly-wangjz
 * @date   2018-7-25
 */
public class Result {

    /** 结果编码. */
    private String result;

    /** 提示信息. */
    private String msg;
    
    /** 当前页数 */
    private long pageindex;
    
    /** 总页数 */
    private long pages;
    
    /** 总记录数 */
    private long records;
    
    /** 传输数据. */
    private Object rows;

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}


	public long getPageindex() {
		return pageindex;
	}

	public void setPageindex(long pageindex) {
		this.pageindex = pageindex;
	}

	public long getPages() {
		return pages;
	}

	public void setPages(long pages) {
		this.pages = pages;
	}

	public long getRecords() {
		return records;
	}

	public void setRecords(long records) {
		this.records = records;
	}

	public void setRecords(int records) {
		this.records = records;
	}

	public Object getRows() {
		return rows;
	}

	public void setRows(Object rows) {
		this.rows = rows;
	}
}