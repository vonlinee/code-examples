package com.ly.mp.busicen.common.entity;

public class ResultVo {
    private  String  uploaded;
    private  String  fileName;
    private  String  url;
    private  ErrorVo error;

    public String getUploaded() {
        return uploaded;
    }

    public void setUploaded(String uploaded) {
        this.uploaded = uploaded;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public ErrorVo getError() {
        return error;
    }

    public void setError(ErrorVo error) {
        this.error = error;
    }
}



