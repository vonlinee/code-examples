package com.ly.mp.busicen.common.exception;

/**
 * 全局异常类
 * @author ly-wangjz
 * @date   2018-7-25
 */
public class AppException extends RuntimeException {

	private static final long serialVersionUID = 4208261145917345624L;
	
	public AppException (String msg) {
		super(msg);
	}
}
