package com.ly.mp.busicen.common.util;

public interface Serializer {
    String toString(Object object);

    Object toObject(String string) throws ClassNotFoundException;
}