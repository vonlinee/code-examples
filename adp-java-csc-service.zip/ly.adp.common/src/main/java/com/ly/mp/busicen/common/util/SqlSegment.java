package com.ly.mp.busicen.common.util;

import java.util.Map;

public class SqlSegment {
	protected String sqlClause;

	public SqlSegment(String sqlClause) {
		this.sqlClause = sqlClause;
	}
	@Override
	public String toString() {
		return this.sqlClause;
	}

	public void parse(Map<String, Object> dicParam, StringBuilder builder) {
		builder.append(this.sqlClause);
		builder.append(" ");
	}
}
