package com.ly.mp.busicen.common.excel;

import java.util.List;

public class ExcelDataObject<T> {

	private String title;

	private String[][] columns;

	private List<T> data;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String[][] getColumns() {
		return columns;
	}

	public void setColumns(String[][] columns) {
		this.columns = columns;
	}

	public List<T> getData() {
		return data;
	}

	public void setData(List<T> data) {
		this.data = data;
	}

}
