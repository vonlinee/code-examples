package com.ly.mp.busicen.common.context;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class BusicenTransactionConvert {
	

	@Pointcut("@annotation(io.seata.spring.annotation.GlobalTransactional)")
	public void pointcut() {
		
	}
	
	

}
