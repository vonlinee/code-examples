package com.ly.mp.busicen.common.annotation;

import java.lang.annotation.*;

@Target({ElementType.METHOD, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Documented
public @interface WfProjectAction {
    String prefix() default "";

    Class className() default void.class;
}
