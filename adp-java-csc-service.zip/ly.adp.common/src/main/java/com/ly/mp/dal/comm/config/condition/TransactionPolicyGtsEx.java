package com.ly.mp.dal.comm.config.condition;

public class TransactionPolicyGtsEx extends TransactionPolicy {
    public static final String TRANSACTIONPOLICY_GTSEX = "gtsx";

    public TransactionPolicyGtsEx() {
    }

    protected String getTransactionPolicy() {
        return TRANSACTIONPOLICY_GTSEX;
    }
}
