package com.ly.mp.busicen.common.config;

import com.baomidou.mybatisplus.core.incrementer.IKeyGenerator;

public class MybatisKeyGenerator implements IKeyGenerator {


	@Override
	public String executeSql(String incrementerName) {
		return "select UUID_SHORT() from dual";
	}

}