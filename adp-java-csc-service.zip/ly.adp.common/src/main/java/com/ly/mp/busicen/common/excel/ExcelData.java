package com.ly.mp.busicen.common.excel;

import java.util.List;
import java.util.Map;

public class ExcelData {
	
	private String title;
	
	private String[][] columns;
	
	private List<Map<String, Object>> data;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String[][] getColumns() {
		return columns;
	}

	public void setColumns(String[][] columns) {
		this.columns = columns;
	}

	public List<Map<String, Object>> getData() {
		return data;
	}

	public void setData(List<Map<String, Object>> data) {
		this.data = data;
	}	

}
