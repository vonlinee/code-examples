package com.ly.mp.busicen.common.util;

public enum PercentSignStyle
{
    /// <summary>
    /// 左右显示，如 %word%
    /// </summary>
    Both,

    /// <summary>
    /// 在左，如 %word
    /// </summary>
    Left,

    /// <summary>
    /// 在右，如 word%
    /// </summary>
    Right,

    /// <summary>
    /// 无
    /// </summary>
    None
}
