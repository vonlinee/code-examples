package com.ly.mp.busicen.common.constant;

public enum SuccessEnum {
	SUCCESS("1","成功");
	
	private String result;
	private String msg;
	
	private SuccessEnum(String result,String msg) {
		this.result = result;
		this.msg = msg;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

}
