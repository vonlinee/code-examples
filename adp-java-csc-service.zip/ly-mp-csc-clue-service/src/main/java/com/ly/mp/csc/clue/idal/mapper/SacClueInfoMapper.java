package com.ly.mp.csc.clue.idal.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ly.mp.csc.clue.entities.SacClueInfo;

/**
 * <p>
 * 总部线索表 Mapper 接口
 * </p>
 *
 * @author ly-busicen
 * @since 2021-08-20
 */
public interface SacClueInfoMapper extends BaseMapper<SacClueInfo> {

	/**
	 * 分页查询
	 * @param page
	 * @param param
	 * @return
	 */
	List<Map<String, Object>> selectByPage(Page<Map<String, Object>> page, @Param("param")Map<String, Object> param);
	List<Map<String, Object>> selectHisByPage(Page<Map<String, Object>> page, @Param("param")Map<String, Object> param);
	List<Map<String, Object>> selectDistinctDataByPage(Page<Map<String, Object>> page, @Param("param")Map<String, Object> param);

	/**
	 * 根据id获取对象
	 * @param id
	 * @return
	 */
	Map<String, Object> selectMapById(@Param("param")Map<String, Object> param);
	Map<String, Object> selectHisById(@Param("param")Map<String, Object> param);

	/**
	 * 插入
	 * @param mapParm
	 * @return
	 */
	public int insertSacClueInfo(@Param("param")Map<String, Object> mapParm);

	/**
	 * 更新
	 * @param mapParm
	 * @return
	 */
	public int updateSacClueInfo(@Param("param")Map<String, Object> mapParm);


	/**
	 * 总部线索查重
	 * @param clue
	 * @return
	 */
	int checkRepeat(@Param("param")Map<String, Object> mapParm);


	List<Map<String, Object>> clueServerQueryDetailFromHeadquarters(@Param("param")Map<String, Object> param);

}
