package com.ly.mp.csc.clue.util;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ly.mp.component.helper.StringHelper;

public class FieldMappingUtil {

	public static Map<String, Map<String, Object>> getHeaderMappingMap(List<Map<String, Object>> fieldMappingList) {
		Map<String, Map<String, Object>> headerMappingMap = new LinkedHashMap<>();
		fieldMappingList.forEach(item->{
			headerMappingMap.put((String)item.get("mappingFiledCode"), item);
		});
		return headerMappingMap;
	}

	/**
	 * 把映射属性转换成实体属性
	 * @param inputInfoMap
	 * @param inputJsonStr
	 * @param headerMappingMap
	 * @return
	 */
	public static Map<String, Object> tranField(Map<String, Object> inputInfoMap, String inputJsonStr, Map<String, Map<String, Object>> headerMappingMap) {
		JSONObject columnJson = new JSONObject();
		if(!StringHelper.IsEmptyOrNull(inputJsonStr)){
			JSONObject oldJson = JSON.parseObject(inputJsonStr);
			columnJson.putAll(oldJson);
		}

		Map<String, Object> targetMap = new HashMap<>();
		inputInfoMap.forEach((k, v)->{
			Map<String, Object> config = headerMappingMap.get(k);
			if(config == null) {
				targetMap.put(k, v);
			} else {
				String filedType = (String)config.get("filedType");
				String filedCode = (String)config.get("filedCode");
				// 1: 内置字段
				if("1".equals(filedType)) {
					targetMap.put(filedCode, v);
				} else {
					columnJson.put(filedCode, v);
				}
			}
		});

		Map<String, Object> outInfo = new HashMap<>();
		outInfo.put("targetFields", targetMap);
		outInfo.put("targetJson", columnJson.toJSONString());
		return outInfo;
	}
}
