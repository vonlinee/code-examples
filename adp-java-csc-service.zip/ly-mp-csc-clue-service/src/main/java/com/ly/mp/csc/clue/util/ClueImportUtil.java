package com.ly.mp.csc.clue.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.entities.SacClueInfoDlrTemporary;
import com.ly.mp.csc.clue.idal.mapper.SacChannelInfoMapper;

/**
 * excel导入潜客单工具类
 * @since 2021-8-19
 * @author ly-zhengzc
 *
 */
@Component
public class ClueImportUtil {

	/** 电话校验 */
	private static Pattern pa = Pattern
			.compile("^(((0\\d{2,3}-?)?(1|2|3|4|5|6|7|8|9)\\d{6,7})|(1(3|4|5|6|7|8|9)\\d{9}))$");

	/** 2到8个字的汉字,或者2到16个字的英文 */
	private static Pattern paName = Pattern.compile("^[-0-9A-Za-z\\u4e00-\\u9fa5]+$");

	/** 2到8个字的汉字,或者2到16个字的英文,或者数字 */
	//private static Pattern paALL = Pattern.compile("^[A-Za-z0-9\\u4e00-\\u9fa5]+$");

	/** 校验客户名称 */
	public static void checkCustName(String custName) {
		Assert.hasText(custName, "客户姓名不能为空");
		Assert.isTrue(paName.matcher(custName).matches(), "【" + custName + "】客户姓名格式错误，请输入2到8个字的汉字，或者2到16位的英文字母");
	}

	/** 校验电话号码 */
	public static void checkPhone(String phone, String checkName, long countExcelPhone, long countDbPhone) {
		// 电话号码非空校验
		Assert.hasText(phone, "[" + checkName + "]不能为空");
		// 电话号码长度校验
		Assert.isTrue(phone.length() <= 12 && phone.length() >= 7, "[" + checkName + "]长度不能小于7位且不能大于12位");
		// 电话号码格式校验
		Assert.isTrue(pa.matcher(phone).matches(), "【" + phone + "】[" + checkName + "]电话格式错误！请输入正确的格式");
		// 电话号码Excel查重
		Assert.isTrue(countExcelPhone == 1, "excel文档中，存在相同[" + checkName + "]【" + phone + "】无法导入");
		// 电话号码业务表查重
		// Assert.isTrue(countDbPhone == 0, "业务表中，存在相同[" + checkName + "]【" + phone + "】无法导入");
	}

	/** 校验性别字段 */
	public static void checkGenderName(Map<String, Object> infoTemporary) {
		String gender = (String)infoTemporary.get("genderName");
		if ("男".equals(gender)) {
			infoTemporary.put("genderCode","1");
		} else if ("女".equals(gender)) {
			infoTemporary.put("genderCode","0");
		} else {
			throw new IllegalArgumentException("性别只能为男或女");
		}
	}
	public static void checkGenderName(SacClueInfoDlrTemporary record) {
		String gender = record.getGenderName();
		if ("男".equals(gender)) {
			record.setGenderCode("1");
		} else if ("女".equals(gender)) {
			record.setGenderCode("0");
		} else {
			throw new IllegalArgumentException("性别只能为男或女");
		}
	}

	/** 校验excel文件类型 */
	public static void checkExtensionName(String fileName) {
		String subffix = fileName.substring(fileName.lastIndexOf(".") + 1);
		Assert.isTrue(subffix.equalsIgnoreCase("xlsx"), "该文件不是.xlsx (excel)文件!");
	}

	/** 检查Excel表单第一行的表头 */
	public static void checkSheetHeader(Sheet hssfSheet, Map<String, Integer> headerConfig) {
		List<String> columnTitleList = new ArrayList<>();
		Row headRow = hssfSheet.getRow(0);
		headRow.forEach(cell -> {
			columnTitleList.add(cell.getStringCellValue());
		});
		headerConfig.forEach((title,cellIndex)->{
			int index = columnTitleList.indexOf(title);
			if(index != -1) {
				headerConfig.put(title, index);
			}
			Assert.isTrue(index != -1, "excel表头必须包含【" + title + "】");
		});
	}

	public static  ListResult<String> listResult(List<String> errRowInfoList) {
		return listResult(errRowInfoList, "查询成功");
	}
	public static  ListResult<String> listResult(List<String> errRowInfoList, String msg) {
		ListResult<String> result = new ListResult<>();
		result.setRows(errRowInfoList);
		result.setRecords(errRowInfoList.size());
		result.setPages(1);
		result.setPageindex(1);
		result.setResult("1");
		result.setMsg(msg);
		return result;
	}


	public static Map<String, Integer> getHeaderConfig(List<Map<String, Object>> fieldMappingList) {
		Map<String, Integer> headerMap = new LinkedHashMap<>();
		fieldMappingList.forEach(item->{
			headerMap.put((String)item.get("mappingFiledCode"), null);
		});
		return headerMap;
	}
	public static List<String> getColumnConfigList(List<Map<String, Object>> fieldMappingList) {
		List<String> headerList = new ArrayList<>();
		fieldMappingList.forEach(item->{
			headerList.add((String)item.get("filedCode"));
		});
		return headerList;
	}

	private static void _fillChannel(Map<String, Object> infoTemporary, String infoChanMName, String channelCode) {
		infoTemporary.put("channelName", infoChanMName);
		infoTemporary.put("channelCode", channelCode);
	}

	public static String fillChannelName(Map<String, Object> infoTemporary, Map<String, String> channelNameMap) {
		String errInfo = "";
		try {
			// 一级信息来源名称
			String infoChanMName = (String)infoTemporary.get("infoChanMName");
			if(StringUtils.isNotBlank(infoChanMName)) {
				Assert.isTrue(channelNameMap.containsKey("一级-" + infoChanMName), "一级信息来源名称不存在！[" + infoChanMName + "]");
				infoTemporary.put("infoChanMCode", channelNameMap.get("一级-" + infoChanMName));
				_fillChannel(infoTemporary, infoChanMName, (String)infoTemporary.get("infoChanMCode"));
			} else {
				return errInfo;
			}
		} catch (Exception e) {
			errInfo += e.getMessage() + ", ";
			return errInfo;
		}
		try {
			// 二级信息来源名称
			String infoChanDName = (String)infoTemporary.get("infoChanDName");
			if(StringUtils.isNotBlank(infoChanDName)) {
				Assert.isTrue(channelNameMap.containsKey("二级-" + infoChanDName), "二级信息来源名称不存在！[" + infoChanDName + "]");
				infoTemporary.put("infoChanDCode", channelNameMap.get("二级-" + infoChanDName));
				_fillChannel(infoTemporary, infoChanDName, (String)infoTemporary.get("infoChanDCode"));
			} else {
				return errInfo;
			}
		} catch (Exception e) {
			errInfo += e.getMessage() + ", ";
			return errInfo;
		}
		try {
			// 三级信息来源名称
			String infoChanDdName = (String)infoTemporary.get("infoChanDdName");
			if(StringUtils.isNotBlank(infoChanDdName)) {
				Assert.isTrue(channelNameMap.containsKey("三级-" + infoChanDdName), "三级信息来源名称不存在！[" + infoChanDdName + "]");
				infoTemporary.put("infoChanDdCode", channelNameMap.get("三级-" + infoChanDdName));
				_fillChannel(infoTemporary, infoChanDdName, (String)infoTemporary.get("infoChanDdCode"));
			} else {
				return errInfo;
			}
		} catch (Exception e) {
			errInfo += e.getMessage() + ", ";
			return errInfo;
		}
		return errInfo;
	}

	// 值列表填充
	public static String fillLookupValue(Map<String, Object> infoTemporary, Map<String, Map<String, String>> allLookupValueMap) {
		String errInfo = "";
		try {
			String testDriveDateName = (String)infoTemporary.get("testDriveDateName");
			if(StringUtils.isNotBlank(testDriveDateName)) {
				Map<String, String> lookupValueMapDriveTime = allLookupValueMap.get("BUCN_CLUE_DRIVE_TIME");
				Assert.isTrue(lookupValueMapDriveTime.containsKey(testDriveDateName), "【试乘试驾时间】值列表不存在！[" + testDriveDateName + "]");
				infoTemporary.put("testDriveDate", lookupValueMapDriveTime.get(testDriveDateName));
			}
		} catch (Exception e) {
			errInfo += e.getMessage() + ", ";
		}
		try {
			String planBuyDateName = (String)infoTemporary.get("planBuyDateName");
			if(StringUtils.isNotBlank(planBuyDateName)) {
				Map<String, String> lookupValueMapPlanTime = allLookupValueMap.get("BUCN_CLUE_PLAN_TIME");
				Assert.isTrue(lookupValueMapPlanTime.containsKey(planBuyDateName), "【预计购车时间】值列表不存在！[" + planBuyDateName + "]");
				infoTemporary.put("planBuyDate", lookupValueMapPlanTime.get(planBuyDateName));
			}
		} catch (Exception e) {
			errInfo += e.getMessage() + ", ";
		}
		try {
			String genderName = (String)infoTemporary.get("genderName");
			if(StringUtils.isNotBlank(genderName)) {
				Map<String, String> lookupValueMapGender = allLookupValueMap.get("LX010");
				Assert.isTrue(lookupValueMapGender.containsKey(genderName), "【性别】值列表不存在！[" + genderName + "]");
				infoTemporary.put("genderCode", lookupValueMapGender.get(genderName));
			}
		} catch (Exception e) {
			errInfo += e.getMessage() + ", ";
		}

		try {
			String businessHeatName = (String)infoTemporary.get("businessHeatName");
			if(StringUtils.isNotBlank(businessHeatName)) {
				Map<String, String> lookupValueMapGender = allLookupValueMap.get("BUCN_CLUE_HOT");
				Assert.isTrue(lookupValueMapGender.containsKey(businessHeatName), "【商机热度】值列表不存在！[" + businessHeatName + "]");
				infoTemporary.put("businessHeatCode", lookupValueMapGender.get(businessHeatName));
			}
		} catch (Exception e) {
			errInfo += e.getMessage() + ", ";
		}
		return errInfo;
	}
	public static String fillLookupValueClueStatusName(Map<String, Object> infoTemporary, Map<String, Map<String, String>> allLookupValueMap) {
		String errInfo = "";
		try {
			String statusName = (String)infoTemporary.get("statusName");
			if(StringUtils.isNotBlank(statusName)) {
				Map<String, String> lookupValueMapPvclueStatus = allLookupValueMap.get("BUCN_PVCLUE_STATUS");
				Assert.isTrue(lookupValueMapPvclueStatus.containsKey(statusName), "【商机状态】值列表不存在！[" + statusName + "]");
				infoTemporary.put("statusCode", lookupValueMapPvclueStatus.get(statusName));
			}
		} catch (Exception e) {
			errInfo += e.getMessage() + ", ";
		}
		return errInfo;
	}

	public static String fillLookupValueDlrClueStatusName(Map<String, Object> infoTemporary, Map<String, Map<String, String>> allLookupValueMap) {
		String errInfo = "";
		try {
			String statusName = (String)infoTemporary.get("statusName");
			if(StringUtils.isNotBlank(statusName)) {
				Map<String, String> lookupValueMapPvclueStatus = allLookupValueMap.get("BUCN_DLRCLUE_STATUS");
				Assert.isTrue(lookupValueMapPvclueStatus.containsKey(statusName), "【线索状态】值列表不存在！[" + statusName + "]");
				infoTemporary.put("statusCode", lookupValueMapPvclueStatus.get(statusName));
			}
		} catch (Exception e) {
			errInfo += e.getMessage() + ", ";
		}
		return errInfo;
	}

	// 意向车系编码填充
	public static String fillCarSeriesCode(Map<String, Object> infoTemporary, Map<String, String> carSeriesNameCodeMap) {
		String errInfo = "";
		try {
			// 意向车系名称
			String intenSeriesName = (String)infoTemporary.get("intenSeriesName");
			if(StringUtils.isNotBlank(intenSeriesName)) {
				String intenSeriesCode = carSeriesNameCodeMap.get(intenSeriesName);
				Assert.isTrue(!StringHelper.IsEmptyOrNull(intenSeriesCode), "【意向车系名称】对应的编码不存在！【" + intenSeriesName + "】");
				infoTemporary.put("intenSeriesCode", intenSeriesCode);
			}
		} catch (Exception e) {
			errInfo += e.getMessage() + ", ";
		}
		return errInfo;
	}

	public static Map<String, Object> getInfoData(List<String> headerList, List<String> rowDataList) {
		Map<String, Object> infoMap = new HashMap<>();
		for(int i = 0; i < headerList.size(); i++) {
			infoMap.put(headerList.get(i), rowDataList.get(i));
		}
		return infoMap;
	}

	public static List<String> getRowData(Sheet sheet, int rowIndex, int columnSize) {
		List<String> headerList = new ArrayList<>();
		DataFormatter formatter = new DataFormatter();
		Row row = sheet.getRow(rowIndex);
		for(int colIndex = 0; colIndex < columnSize; colIndex++) {
			Cell cell = row.getCell(colIndex);
			headerList.add(formatter.formatCellValue(cell));
		}
		return headerList;
	}
	public static List<String> getRowHeader(Sheet sheet, int rowIndex) {
		List<String> headerList = new ArrayList<>();
		DataFormatter formatter = new DataFormatter();
		sheet.getRow(rowIndex).forEach(cell -> {
			headerList.add(formatter.formatCellValue(cell));
		});
		return headerList;
	}

	@SuppressWarnings("unchecked")
	public static List<Map<String, Object>> getInfoTemporaryList(Sheet sheet, List<String> excelHeaderList, Map<String, Map<String, Object>> headerMappingMap) {
		List<Map<String, Object>> excelDataList = new ArrayList<>();
		for (int j = 1; j <= sheet.getLastRowNum(); j++) {
			if(sheet.getRow(j) == null) {
				continue;
			} else {
				List<String> rowData = ClueImportUtil.getRowData(sheet, j, excelHeaderList.size());
				Map<String, Object> infoData = ClueImportUtil.getInfoData(excelHeaderList, rowData);

				Map<String, Object> outInfo = FieldMappingUtil.tranField(infoData, null, headerMappingMap);

				Map<String, Object> infoTemporary = new HashMap<>();
				infoTemporary.putAll((Map<String, Object>)outInfo.get("targetFields"));
				infoTemporary.put("extendsJson", outInfo.get("targetJson"));
				excelDataList.add(infoTemporary);
			}
		}
		return excelDataList;
	}

	@Autowired SacChannelInfoMapper channelInfoMapper;
	public Map<String, String> getChannelNameMap() {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("isEnable", "1");
		List<Map<String, Object>> channelList = channelInfoMapper.selectByAll(paramMap);

		Map<String, String> channelNameMap = new HashMap<>();
		for(Map<String, Object> map: channelList) {
			channelNameMap.put((String)map.get("channelLevelName") + "-" + (String)map.get("channelName"), (String)map.get("channelCode"));
		}
		return channelNameMap;
	}



}
