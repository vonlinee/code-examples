package com.ly.mp.csc.clue.service;

import com.ly.mp.csc.clue.entities.SacDbReviewNode;
import com.baomidou.mybatisplus.extension.service.IService;

import com.ly.mp.component.entities.EntityResult;
import java.util.Map;

/**
 * <p>
 * 回访节点表 服务类
 * </p>
 *
 * @author ly-busicen
 * @since 2021-09-10
 */
public interface ISacDbReviewNodeService extends IService<SacDbReviewNode> {

	
	/**
	 * 根据主键判断插入或更新
	 * @param info
	 * @return
	 */
	EntityResult<Map<String, Object>> sacDbReviewNodeSave(Map<String, Object> mapParam, String token);
	
}
