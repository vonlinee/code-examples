package com.ly.mp.csc.clue.idal.mapper;

import com.ly.mp.csc.clue.entities.DbCarBrand;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 车辆品牌 Mapper 接口
 * </p>
 *
 * @author ly-linliq
 * @since 2021-09-07
 */
public interface SacDbCarBrandMapper extends BaseMapper<DbCarBrand> {

	 public List<Map<String,Object>> selectDbCarBrand(Page<Map<String, Object>> page,@Param("param") Map<String,Object> map);
}