package com.ly.mp.csc.clue.enums;

/**
 * 回访审核状态 值列表BUCN_SHSTATUS
 * @author ly-shenyw
 *
 */
public enum TransferAuditTypeEnum {
	/**
	 * 调入店审核
	 */
	inDlr("1","调入店审核"),

	/**
	 * 调出店审核
	 */
	outDlr("2","调出店审核"),

	/**
	 * 区域经理审核
	 */
	areaManager("3","区域经理审核");

	private String result;
	private String msg;

	private TransferAuditTypeEnum(String result, String msg) {
		this.result = result;
		this.msg = msg;
	}

	public String getResult() {
		return result;
	}

	public String getMsg() {
		return msg;
	}

	//根据result获取枚举
	public static TransferAuditTypeEnum fromString(String code) {
		for (TransferAuditTypeEnum b : TransferAuditTypeEnum.values()) {
			if (b.getResult().equalsIgnoreCase(code)) {
				return b;
			}
		}
		return null;
	}
}

