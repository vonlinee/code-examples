package com.ly.mp.csc.clue.entities;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
/**
 * 附件表
 * t_sac_attachment
 * @author ly-zhengzc
 * @since 2021-12-9
 */
@TableName(value = "t_sac_attachment")
public class SacAttachment implements Serializable {
	private static final long serialVersionUID = 1L;

	/** 附件ID */
	@TableId("ATTACHMENT_ID")
	private String attachmentId;

	/** 业务单ID */
	@TableField("BILL_ID")
	private String billId;

	/** 业务单类型 */
	@TableField("BILL_TYPE")
	private String billType;

	/** 附件名称 */
	@TableField("FILE_NAME")
	private String fileName;

	/** 附件扩展名 */
	@TableField("FILE_EXTENSION")
	private String fileExtension;

	/** 附件路径 */
	@TableField("FILE_PATH")
	private String filePath;

	/** 扩展字段1 */
	@TableField("COLUMN1")
	private String column1;

	/** 扩展字段2 */
	@TableField("COLUMN2")
	private String column2;

	/** 扩展字段3 */
	@TableField("COLUMN3")
	private String column3;

	/** 扩展字段4 */
	@TableField("COLUMN4")
	private String column4;

	/** 扩展字段5 */
	@TableField("COLUMN5")
	private String column5;

	/** 厂商标识ID */
	@TableField("OEM_ID")
	private String oemId;

	/** 集团标识ID */
	@TableField("GROUP_ID")
	private String groupId;

	/** 创建人ID */
	@TableField("CREATOR")
	private String creator;

	/** 创建人 */
	@TableField("CREATED_NAME")
	private String createdName;

	/** 创建日期 */
	@TableField("CREATED_DATE")
	private LocalDateTime createdDate;

	/** 修改人ID */
	@TableField("MODIFIER")
	private String modifier;

	/** 修改人 */
	@TableField("MODIFY_NAME")
	private String modifyName;

	/** 最后更新日期 */
	@TableField("LAST_UPDATED_DATE")
	private LocalDateTime lastUpdatedDate;

	/** 是否可用 */
	@TableField("IS_ENABLE")
	private String isEnable;

	/** 并发控制ID */
	@TableField("UPDATE_CONTROL_ID")
	private String updateControlId;

	public String getAttachmentId() {
		return attachmentId;
	}

	public void setAttachmentId(String attachmentId) {
		this.attachmentId = attachmentId;
	}

	public String getBillId() {
		return billId;
	}

	public void setBillId(String billId) {
		this.billId = billId;
	}

	public String getBillType() {
		return billType;
	}

	public void setBillType(String billType) {
		this.billType = billType;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileExtension() {
		return fileExtension;
	}

	public void setFileExtension(String fileExtension) {
		this.fileExtension = fileExtension;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public String getColumn1() {
		return column1;
	}

	public void setColumn1(String column1) {
		this.column1 = column1;
	}

	public String getColumn2() {
		return column2;
	}

	public void setColumn2(String column2) {
		this.column2 = column2;
	}

	public String getColumn3() {
		return column3;
	}

	public void setColumn3(String column3) {
		this.column3 = column3;
	}

	public String getColumn4() {
		return column4;
	}

	public void setColumn4(String column4) {
		this.column4 = column4;
	}

	public String getColumn5() {
		return column5;
	}

	public void setColumn5(String column5) {
		this.column5 = column5;
	}

	public String getOemId() {
		return oemId;
	}

	public void setOemId(String oemId) {
		this.oemId = oemId;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getCreatedName() {
		return createdName;
	}

	public void setCreatedName(String createdName) {
		this.createdName = createdName;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifier() {
		return modifier;
	}

	public void setModifier(String modifier) {
		this.modifier = modifier;
	}

	public String getModifyName() {
		return modifyName;
	}

	public void setModifyName(String modifyName) {
		this.modifyName = modifyName;
	}

	public LocalDateTime getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(LocalDateTime lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getIsEnable() {
		return isEnable;
	}

	public void setIsEnable(String isEnable) {
		this.isEnable = isEnable;
	}

	public String getUpdateControlId() {
		return updateControlId;
	}

	public void setUpdateControlId(String updateControlId) {
		this.updateControlId = updateControlId;
	}

	@Override
	public String toString() {
		return "SacAttachment [attachmentId=" + attachmentId + ", billId=" + billId + ", billType=" + billType
				+ ", fileName=" + fileName + ", fileExtension=" + fileExtension + ", filePath=" + filePath + "]";
	}
}
