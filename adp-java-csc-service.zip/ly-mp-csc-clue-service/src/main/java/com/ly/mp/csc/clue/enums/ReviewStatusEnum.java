package com.ly.mp.csc.clue.enums;

/**
 * 回访状态枚举 
 * 对应值列表：BUCN_REVIEW_STATUS
 * @author ly-shenyw
 *
 */
public enum ReviewStatusEnum {

	/**
	 * 待回访
	 */
	unreview("0","待回访"),
	
	/**
	 * 回访中
	 */
	reviewing("1","回访中"),
	
	/**
	 * 回访结束
	 */
	end("2","回访结束");
	
	private String result;
	private String msg;
	
	private ReviewStatusEnum(String result, String msg) {
		this.result = result;
		this.msg = msg;
	}

	public String getResult() {
		return result;
	}

	public String getMsg() {
		return msg;
	}
	
	//根据result获取枚举
	public static ReviewStatusEnum fromString(String code) {
        for (ReviewStatusEnum b : ReviewStatusEnum.values()) {
            if (b.getResult().equalsIgnoreCase(code)) {
                return b;
            }
        }
        return null;
	}
}
