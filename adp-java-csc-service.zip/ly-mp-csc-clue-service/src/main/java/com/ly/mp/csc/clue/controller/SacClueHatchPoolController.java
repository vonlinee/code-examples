package com.ly.mp.csc.clue.controller;


import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.context.BusicenInvoker;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.service.ISacClueHatchPoolService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * <p>
 * 总部线索孵化池表 前端控制器
 * </p>
 *
 * @author ly-linliq
 * @since 2021-10-26
 */
@Api(value = "总部线索孵化池服务", tags = { "总部线索孵化池服务" })
@RestController
@RequestMapping("/ly/sac/sacClueHatchPool")
public class SacClueHatchPoolController {

	@Autowired
	ISacClueHatchPoolService sacClueHatchPoolService;
	
	@ApiOperation(value="线索孵化池线索激活",notes="线索孵化池线索激活")
	@RequestMapping(value="/clueactivate.do",method=RequestMethod.POST)
	public OptResult sacClueHatchPoolActivate(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) ParamBase<Map<String, Object>> queryCondition) throws Exception{
		queryCondition.getParam().put("token", authentication);
		return BusicenInvoker.doOpt(()->sacClueHatchPoolService.sacClueHatchPoolActivate(queryCondition.getParam())).result();
	}
	@ApiOperation(value="线索孵化池线索查询",notes="线索孵化池线索查询")
	@RequestMapping(value="/poolcluequery.do",method=RequestMethod.POST)
	public ListResult<Map<String,Object>> sacClueHatchPoolQueryList(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) ParamPage<Map<String, Object>> queryCondition) throws Exception{
		queryCondition.getParam().put("token", authentication);
		return BusicenInvoker.doList(()->sacClueHatchPoolService.sacClueHatchPoolQueryList(queryCondition)).result();
	}
	
	@ApiOperation(value="线索回收测试",notes="线索回收测试")
	@RequestMapping(value="/cluerecycle.do",method=RequestMethod.POST)
	public OptResult sacClueHatchPoolRecycle(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) ParamBase<Map<String, Object>> queryCondition) throws Exception{
		queryCondition.getParam().put("token", authentication);
		return BusicenInvoker.doOpt(()->sacClueHatchPoolService.recycleClueHandle(queryCondition.getParam(),authentication)).result();
	}
}