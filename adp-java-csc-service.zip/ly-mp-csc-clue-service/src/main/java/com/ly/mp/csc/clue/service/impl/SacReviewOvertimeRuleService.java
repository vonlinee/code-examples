package com.ly.mp.csc.clue.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegist;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegistor;
import com.ly.bucn.component.interceptor.annotation.Interceptor;
import com.ly.bucn.component.message.Message;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.constant.UserBusiEntity;
import com.ly.mp.busi.base.context.BusicenContext;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.busi.base.handler.OptResultBuilder;
import com.ly.mp.busicen.rule.field.IFireFieldRule;
import com.ly.mp.busicen.rule.field.execution.ValidResultCtn;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.entities.SacReviewOvertimeRule;
import com.ly.mp.csc.clue.helper.BusicenDbBaseUtils;
import com.ly.mp.csc.clue.idal.mapper.SacReviewOvertimeRuleMapper;
import com.ly.mp.csc.clue.service.ISacReviewOvertimeRuleService;

/**
 * com.ly.mp.csc.clue.service.impl.SacReviewOvertimeRuleServiceImpl
 * 超期规则服务实现类
 * @author zhouhao
 * @date 2021/8/17 14:22
 * Modification History:
 * Date               Author          Version            Description
 *---------------------------------------------------------------------*
 * 2021/9/14 14:28     linliq           v1.0.0            修改报错问题
 */
@Service
public class SacReviewOvertimeRuleService extends ServiceImpl<SacReviewOvertimeRuleMapper, SacReviewOvertimeRule> implements ISacReviewOvertimeRuleService, InterceptorWrapperRegist {

    @Autowired
    Message message;
    @Autowired
    IFireFieldRule fireFieldRule;

    @Override
    public ListResult<Map<String,Object>> queryListReviewOvertimeRuleInfo(ParamPage<Map<String,Object>> dataInfo,String token){
        ListResult<Map<String,Object>> result = new ListResult<Map<String,Object>>();
        try {
        	UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
        	dataInfo.getParam().put("orgCode", userBusiEntity.getDlrCode());
            int pageIndex=dataInfo.getPageIndex();
            int pageSize=dataInfo.getPageSize();
            //默认查询可用的数据
            dataInfo.getParam().put("isEnable", "1");
            //查本组织的
            dataInfo.getParam().put("orgCode", userBusiEntity.getOrgCode());
            Page<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);
            List<Map<String, Object>> list = baseMapper.selectByAll(page, dataInfo.getParam());
            page.setRecords(list);
            result = BusicenUtils.page2ListResult(page);
        }catch (Exception e){
            e.printStackTrace();
            log.error("queryListReviewOvertimeRuleInfo:",e);
            throw e;
        }
        return result;
    }

    @Override
    @Interceptor("csc_clue_reviewovertimeruleinfo")
    public OptResult saveReviewOvertimeRuleInfo(Map<String,Object> map , String token){
        try {
        	if(StringHelper.IsEmptyOrNull(map.get("isEnable"))) {
        		map.put("isEnable", "1");
        	}
            SacReviewOvertimeRule vo = BusicenUtils.map2Object(map,SacReviewOvertimeRule.class);
            UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
            vo.setCreatedName(userBusiEntity.getEmpName());
            vo.setModifyName(userBusiEntity.getEmpName());
            vo.setOrgCode(userBusiEntity.getDlrCode());
            vo.setOrgName(userBusiEntity.getDlrName());
            BusicenDbBaseUtils.baseSaveById(vo,baseMapper,null,"",false,token);
            return OptResultBuilder.createOk().build();
        } catch (Exception e) {
            e.printStackTrace();
            log.error("saveReviewOvertimeRuleInfo", e);
            throw e;
        }
    }

    @Override
    public OptResult deleteReviewOvertimeRuleInfo(Map<String,Object> map , String token){
        try {
            ValidResultCtn fireRule = fireFieldRule.fireRule(map, "csc-clue-review-check-0010", "maindata");
            String resMsg = fireRule.getNotValidMessage();
            if (!fireRule.isValid()){
                throw new BusicenException(resMsg);
            }
            //先删除规则
            String ruleId = map.get("ruleId").toString();
            baseMapper.deleteById(ruleId);
            //再删除规则明细
            baseMapper.deleteByRuled(ruleId);
            return OptResultBuilder.createOk().build();
        } catch (Exception e) {
            e.printStackTrace();
            log.error("deleteReviewOvertimeRuleInfo", e);
            throw e;
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    public void regist(InterceptorWrapperRegistor registor) {
        //切点编码要和切点表里面的保持一致
        registor.before("csc_clue_reviewovertimeruleinfo_valid", (context, model)->{
            checkValidate((Map<String,Object>)context.data().getP()[0]);
        });
        registor.before("csc_clue_reviewovertimeruleinfo_repeat", (context, model)->{
            checkRepeat((Map<String,Object>)context.data().getP()[0],(String)context.data().getP()[1]);
        });
        registor.before("csc_clue_reviewovertimeruleinfo_exit", (context, model)->{
            checkExits((Map<String,Object>)context.data().getP()[0]);
        });
        registor.before("csc_clue_reviewovertimeruleinfod_valid", (context, model)->{
            checkReviewOvertimeRuleDInfo((Map<String,Object>)context.data().getP()[0]);
        });
        registor.before("csc_clue_reviewovertimeruleinfod_exits", (context, model)->{
            checkReviewOvertimeRuleDExits((Map<String,Object>)context.data().getP()[0]);
        });
        registor.after("csc_clue_reviewovertimeruleinfo_msg", (context, model)->{
            checkAfter((Map<String,Object>)context.data().getP()[0]);
        });
    }

    public void checkReviewOvertimeRuleDExits(Map<String,Object> mapParam)
    {
    	try {
			if(!StringHelper.IsEmptyOrNull(mapParam.get("id"))){
				int size = baseMapper.checkReviewOvertimeRuleDExits((String)mapParam.get("id"));
				if (size == 0) {
					throw new BusicenException(message.get("CLUE-REVIEWASSIGN-29"));
				}
			}
			//判断时间段是否重复
			if(baseMapper.checkReviewOverTimed(mapParam)>0){
	            throw new BusicenException(message.get("CLUE-REVIEWOVERTIMERULED-01"));
	        }
		}catch(Exception ex)
		{
			throw ex;
		}
    }
    
    public void checkExits(Map<String,Object> mapParam)
    {
    	try {
			if(!StringHelper.IsEmptyOrNull(mapParam.get("ruleId"))){
				int size = baseMapper.checkReviewOvertimeRuleExists((String)mapParam.get("ruleId"));
				if (size == 0) {
					throw new BusicenException(message.get("CLUE-REVIEWASSIGN-29"));
				}
			}
		}catch(Exception ex)
		{
			throw ex;
		}
    }
    
    public void checkValidate(Map<String,Object> mapParam)
    {
        ValidResultCtn fireRule = fireFieldRule.fireRule(mapParam, "csc-clue-review-check-0002", "maindata");
        String resMsg = fireRule.getNotValidMessage();
        if (!fireRule.isValid()){
            throw new BusicenException(resMsg);
        }
    }

    public void checkRepeat(Map<String,Object> mapParam,String token)
    {
    	UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
    	mapParam.put("orgCode", userBusiEntity.getDlrCode());
    	if(baseMapper.checkReviewOverTime(mapParam)>=1){
    		throw new BusicenException(message.get("CLUE-REVIEWASSIGN-25"));
    	}
    }

    public void checkAfter(Map<String,Object> mapParam) {

    }

    @Override
    public ListResult<Map<String,Object>> queryListReviewOvertimeRuleDInfo(ParamPage<Map<String,Object>> dataInfo){
    	//校验必填字段
        ListResult<Map<String,Object>> result = new ListResult<Map<String,Object>>();
        try {
        	
        	ValidResultCtn fireRule = fireFieldRule.fireRule(dataInfo.getParam(), "csc-clue-review-check-0010", "maindata");
            String resMsg = fireRule.getNotValidMessage();
            if (!fireRule.isValid()){
                throw new BusicenException(resMsg);
            }
            String token=String.valueOf(dataInfo.getParam().get("token"));
            UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
        	dataInfo.getParam().put("orgCode", userBusiEntity.getDlrCode());
            int pageIndex=dataInfo.getPageIndex();
            int pageSize=dataInfo.getPageSize();

            Page<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);
            List<Map<String, Object>> list = baseMapper.queryListRuleD(page, dataInfo.getParam());
            page.setRecords(list);
            result = BusicenUtils.page2ListResult(page);
        }catch (Exception e){
            e.printStackTrace();
            log.error("queryListReviewOvertimeRuleDInfo:",e);
            throw e;
        }
        return result;
    }

    public void checkReviewOvertimeRuleDInfo(Map<String,Object> mapParam)
    {
        ValidResultCtn fireRule = fireFieldRule.fireRule(mapParam, "csc-clue-review-check-0011", "maindata");
        String resMsg = fireRule.getNotValidMessage();
        if (!fireRule.isValid()){
            throw new BusicenException(resMsg);
        }
        //判断开始时间是否小于结束时间
        String[]array1 = String.valueOf(mapParam.get("startTime")).split(":");
		int startTime = Integer.valueOf(array1[0])*3600+Integer.valueOf(array1[1])*60+Integer.valueOf(array1[2]);
		String[]array2 = String.valueOf(mapParam.get("endTime")).split(":");
		int endTime = Integer.valueOf(array2[0])*3600+Integer.valueOf(array2[1])*60+Integer.valueOf(array2[2]);
		if(endTime<=startTime) {
			throw new BusicenException(message.get("CSC-MESSAGE-05"));
		}
    }

    @Override
    @Interceptor("csc_clue_reviewovertimeruleinfod")
    public OptResult saveReviewOvertimeRuleDInfo(Map<String,Object> map,String token){
        try {
            UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
            if(StringHelper.IsEmptyOrNull(map.get("id"))){
                map.put("id",StringHelper.GetGUID());
                BusicenUtils.invokeUserInfo(map, BusicenUtils.SOU.Save,token);
                map.put("creator",userBusiEntity.getUserID());
                map.put("createdName",userBusiEntity.getEmpName());
                map.put("modifier",userBusiEntity.getUserID());
                map.put("modifyName",userBusiEntity.getEmpName());
                map.put("orgCode", userBusiEntity.getDlrCode());
                map.put("orgName", userBusiEntity.getDlrName());
                if(StringHelper.IsEmptyOrNull(map.get("addDays"))) {
                	map.remove("addDays");
                }
                if(StringHelper.IsEmptyOrNull(map.get("addDynHours"))) {
                	map.remove("addDynHours");
                }
                baseMapper.insertReviewOverTimed(map);
            }else{
            	BusicenUtils.invokeUserInfo(map, BusicenUtils.SOU.Update,token);
            	map.put("modifier",userBusiEntity.getUserID());
                map.put("modifyName",userBusiEntity.getEmpName());
                if(StringHelper.IsEmptyOrNull(map.get("addDays"))) {
                	map.remove("addDays");
                }
                if(StringHelper.IsEmptyOrNull(map.get("addDynHours"))) {
                	map.remove("addDynHours");
                }
                baseMapper.updateReviewOvertimeRuled(map);
            }
        }catch (Exception e){
            e.printStackTrace();
            log.error("saveReviewOvertimeRuleDInfo:",e);
            throw e;
            //throw new BusicenException(message.get("CLUE-SYSTECONFIGVALUE-01"));
        }
        return OptResultBuilder.createOk().build();
    }

    @Override
    public OptResult deleteReviewOvertimeRuleDInfo(Map<String,Object> map,String token){
        try {
        	//检验必填字段
        	ValidResultCtn fireRule = fireFieldRule.fireRule(map, "csc-clue-review-check-0012", "maindata");
            String resMsg = fireRule.getNotValidMessage();
            if (!fireRule.isValid()){
                throw new BusicenException(resMsg);
            }
            String id = (String)map.get("id");
            baseMapper.deleteRuledInfo(id);
        }catch (Exception e){
            e.printStackTrace();
            log.error("deleteReviewOvertimeRuleDInfo:",e);
            throw e;
            //throw new BusicenException(message.get("CLUE-SYSTECONFIGVALUE-01"));
        }
        return OptResultBuilder.createOk().build();
    }
}
