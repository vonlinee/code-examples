package com.ly.mp.csc.clue.idal.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.ly.mp.csc.clue.entities.SacReviewFpSet;
import com.ly.mp.csc.clue.entities.SacReviewFpSetD;

import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * com.ly.mp.csc.clue.idal.mapper.SacReviewFpSetDMapper
 * 回访分配设置
 *
 * @author zhouhao
 * @date 2021/8/16 15:02
 */
public interface SacReviewFpSetMapper extends BaseMapper<SacReviewFpSet> {

    /**
     * com.ly.mp.csc.clue.idal.mapper.SacReviewFpSetDMapper
     * 回访分配设置查询
     *
     * @param page  分页
     * @param param 输入参数
     * @return java.util.List<com.ly.mp.csc.clue.entities.out.ReviewAssignSetOut>
     * @author zhouhao
     * @date 2021/8/16 15:03
     */
    List<Map<String, Object>> queryListReviewAssignInfo(IPage<Map<String, Object>> page, @Param("param") Map<String, Object> param);

    /**
     * com.ly.mp.csc.clue.idal.mapper.SacReviewFpSetDMapper
     * 查重校验
     *
     * @param param 输入参数
     * @return int
     * @author zhouhao
     * @date 2021/8/16 15:22
     */
    int checkReviewAssign(@Param("param") Map<String, Object> param);

    /**
     * com.ly.mp.csc.clue.idal.mapper.SacReviewFpSetDMapper
     * 按设置ID删除回访分配人员阀值
     *
     * @param setId 设置ID
     * @return int
     * @author zhouhao
     * @date 2021/8/16 15:30
     */
    int deleteBySetId(String setId);

    /**
     * com.ly.mp.csc.clue.idal.mapper.SacReviewFpSetDMapper
     * 保存回访分配设置表
     *
     * @param param 输入参数
     * @return int
     * @author zhouhao
     * @date 2021/8/16 15:36
     */
    int insertSacReviewFpSet(@Param("param") Map<String, Object> vo);

    /**
     * com.ly.mp.csc.clue.idal.mapper.SacReviewFpSetDMapper
     * 保存回访分配修改
     *
     * @param param 输入参数
     * @return int
     * @author zhouhao
     * @date 2021/8/16 17:54
     */
    int updateByPrimaryKeySetId(@Param("param") Map<String, Object> vo);

    /**
     * com.ly.mp.csc.clue.idal.mapper.SacReviewFpSetDMapper
     * 保存
     *
     * @param list 回访分配人员阀值集合
     * @return int
     * @author zhouhao
     * @date 2021/8/16 15:40
     */
    int insertSacReviewFpSetD(@Param("list") List<Map<String, Object>> list);

    /**
     * com.ly.mp.csc.clue.idal.mapper.SacReviewFpSetDMapper
     * 分配规则查询
     *
     * @param param 输入参数
     * @return java.util.List<java.util.Map < java.lang.String, java.lang.Object>>
     * @author zhouhao
     * @date 2021/8/17 10:31
     */
    List<Map<String, Object>> queryReviewRuleInfo(IPage<Map<String, Object>> page, @Param("param") Map<String, Object> param);

    Integer countBySetId(@Param("setId") String setId);


    int deleteReviewAssignInfo(@Param("setId") String setId);
    
    /**
     * 获取匹配的分配规则
     * @param param
     * @return
     */
    List<Map<String, Object>> machReviewFpRule(@Param("param") Map<String, Object> param);
    
   /**
    * 获取人员阀值及当前回访数
    * @param page
    * @param param
    * @return
    */
    List<Map<String, Object>> queryReviewPersonBySetD(IPage<Map<String, Object>> page, @Param("param") Map<String, Object> param);
    
    /**
     * 获取人员阀值列表
     * @param page
     * @param param
     * @return
     */
     List<Map<String, Object>> queryReviewFpSetD(IPage<Map<String, Object>> page, @Param("param") Map<String, Object> param);
    
}