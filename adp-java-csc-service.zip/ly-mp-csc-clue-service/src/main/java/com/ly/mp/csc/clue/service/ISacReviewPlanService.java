package com.ly.mp.csc.clue.service;

import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.entities.SacReviewPlan;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.Map;

/**
 * com.ly.mp.csc.clue.service.ISacReviewPlanService
 * 回访计划接口服务
 * @author zhouhao
 * @date 2021/8/17 13:56
 */
public interface ISacReviewPlanService extends IService<SacReviewPlan>{

    /**
     * com.ly.mp.csc.clue.service.SacReviewPlanService
     * 回访计划设置保存
     * @param map 输入参数
     * @param token token
     * @return com.ly.mp.component.entities.OptResult
     * @author zhouhao
     * @date 2021/8/17 11:55
     */
    OptResult saveReviewPlanInfo(Map<String,Object> map , String token);

    /**
     * com.ly.mp.csc.clue.service.ISacReviewPlanService
     * 回访计划查询
     * @param dataInfo 输入参数
     * @return com.ly.mp.component.entities.ListResult<java.util.Map<java.lang.String,java.lang.Object>>
     * @author zhouhao
     * @date 2021/8/17 13:55
     */
    ListResult<Map<String,Object>> queryListReviewPlanInfo(ParamPage<Map<String, Object>> dataInfo,String token);

    /**
     * 回访计划删除
     * @param map 输入参数
     * @param token token
     * @return OptResult
     */
    OptResult deleteReviewPlanInfo(Map<String,Object> map , String token);
}
