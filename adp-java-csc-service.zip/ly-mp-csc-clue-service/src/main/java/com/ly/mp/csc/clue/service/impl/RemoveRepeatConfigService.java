package com.ly.mp.csc.clue.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegist;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegistor;
import com.ly.bucn.component.interceptor.annotation.Interceptor;
import com.ly.bucn.component.message.Message;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.constant.UserBusiEntity;
import com.ly.mp.busi.base.context.BusicenContext;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.busi.base.handler.BusicenUtils.SOU;
import com.ly.mp.busi.base.handler.ResultHandler;
import com.ly.mp.busicen.rule.field.IFireFieldRule;
import com.ly.mp.busicen.rule.field.execution.ValidResultCtn;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.entities.RemoveRepeatConfig;
import com.ly.mp.csc.clue.helper.CacheDataFactory;
import com.ly.mp.csc.clue.idal.mapper.RemoveRepeatConfigMapper;
import com.ly.mp.csc.clue.service.IRemoveRepeatConfigService;
import com.ly.mp.csc.clue.util.FiledMappingUtil;

/**
 * <p>
 * 去重规则配置表 服务实现类
 * </p>
 *
 * @author ly-linliq
 * @since 2021-09-03
 */
@Service
public class RemoveRepeatConfigService extends ServiceImpl<RemoveRepeatConfigMapper, RemoveRepeatConfig>
implements IRemoveRepeatConfigService, InterceptorWrapperRegist {

	private Logger log = LoggerFactory.getLogger(RemoveRepeatConfigService.class);
	@Autowired
	RemoveRepeatConfigMapper removeRepeatConfigMapper;
	@Autowired
	FiledMappingUtil filedMappingUtil;
	@Autowired
	Message message;
	@Autowired
	IFireFieldRule fireFieldRule;
	@Autowired
	CacheDataFactory cacheDataFactory;

	@Override
	public ListResult<Map<String, Object>> queryListRemoveRepeatConfig(ParamPage<Map<String, Object>> mapParam) {
		ListResult<Map<String, Object>> result = new ListResult<Map<String, Object>>();
		String token = mapParam.getParam().get("token").toString();
		try {
			// 开启，判断店端线索去重时，不区分专营店
			_setShareOrgInfo(token, mapParam.getParam());

			int pageIndex = Integer.valueOf(mapParam.getPageIndex());
			int pageSize = Integer.valueOf(mapParam.getPageSize());

			Page<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);
			List<Map<String, Object>> list = removeRepeatConfigMapper.selectRemoveRepeatConfig(page,
					mapParam.getParam());
			if(list.size()>0) {
				for (Map<String, Object> item : list) {
					List<Map<String, Object>> columnList = new ArrayList<Map<String, Object>>();
					// 自定义参数不为空时
					if (!StringHelper.IsEmptyOrNull(item.get("custom"))) {
						columnList = filedMappingUtil.customHandle(item.get("custom").toString());
					}
					// 将参数集合放进结果集
					item.put("columnList", columnList);
				}
			}
			page.setRecords(list);
			result = BusicenUtils.page2ListResult(page);
		} catch (Exception e) {
			log.error("queryListRemoveRepeatConfig", e);
			throw e;
		}
		return result;
	}

	@Override
	@Interceptor("csc_clue_saverepeatconfig")
	public EntityResult<Map<String, Object>> repeatRuleConfigSave(Map<String, Object> mapParam) {
		EntityResult<Map<String, Object>> optResult = new EntityResult<Map<String, Object>>();
		String token = String.valueOf(mapParam.get("token"));
		try {
			Boolean updateFlag = (Boolean) mapParam.get("updateFlag");
			List<Map<String, Object>> columnList = new ArrayList<Map<String, Object>>();
			// 自定义参数不为空时
			if (!StringHelper.IsEmptyOrNull(mapParam.get("custom"))) {
				FiledMappingUtil fileMappingUtil = new FiledMappingUtil();
				columnList = fileMappingUtil.customHandle(mapParam.get("custom").toString());
			}
			// 将参数集合放进结果集
			mapParam.put("columnList", columnList);
			if (!updateFlag) {
				if (StringHelper.IsEmptyOrNull(mapParam.get("configId"))) {
					mapParam.put("configId", StringHelper.GetGUID());
				}
				if (StringHelper.IsEmptyOrNull(mapParam.get("isEnable"))) {
					mapParam.put("isEnable", "1");
				}
				BusicenUtils.invokeUserInfo(mapParam, SOU.Save, token);
				removeRepeatConfigMapper.insertRemoveRepeatConfig(mapParam);
				return ResultHandler.updateOk(mapParam);
			} else {
				BusicenUtils.invokeUserInfo(mapParam, SOU.Update, token);
				int result = removeRepeatConfigMapper.updateRemoveRepeatConfig(mapParam);

				if (result == 0) {
					if ("true".equals(mapParam.get("isHead"))) {
						optResult.setMsg(message.get("REPEAT-CONFIG-03"));
					} else {
						optResult.setMsg(message.get("REPEAT-CONFIG-05"));
					}
					optResult.setResult("0");
				} else {
					if ("true".equals(mapParam.get("isHead"))) {
						optResult.setMsg(message.get("REPEAT-CONFIG-04"));
						optResult.setResult("1");
					} else {
						optResult.setMsg(message.get("REPEAT-CONFIG-06"));
						optResult.setResult("1");
					}
				}
				optResult.setRows(mapParam);
			}
		} catch (Exception e) {
			log.error("repeatRuleConfigSave", e);
			throw e;
		}
		return optResult;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void regist(InterceptorWrapperRegistor registor) {
		registor.before("csc_clue_saverepeatconfig_valid", (context, model) -> {
			checkValidate((Map<String, Object>) context.data().getP()[0]);
		});
		registor.before("csc_clue_saverepeatconfig_exits", (context, model) -> {
			checkExits((Map<String, Object>) context.data().getP()[0]);
		});
		registor.before("csc_clue_saverepeatconfig_custom", (context, model) -> {
			checkCustom((Map<String, Object>) context.data().getP()[0]);
		});
		registor.before("csc_clue_saverepeatconfig_repeat", (context, model) -> {
			checkRepeat((Map<String, Object>) context.data().getP()[0]);
		});
	}

	public void checkValidate(Map<String, Object> mapParam) {
		ValidResultCtn fireRule = fireFieldRule.fireRule(mapParam, "csc1001001", "maindata");
		String resMsg = fireRule.getNotValidMessage();
		if (!fireRule.isValid()) {
			throw new BusicenException(resMsg);
		}
		// 当CHECK_PHONE=1的时候，CHECK_TIME才能为1
		if ("0".equals(mapParam.get("checkPhone")) && "1".equals(mapParam.get("checkTime"))) {
			throw new BusicenException("请先勾选手机号选择框");
		}
	}

	public void checkExits(Map<String, Object> mapParam) {
		try {
			Boolean updateFlag = false;
			if (!StringHelper.IsEmptyOrNull(mapParam.get("configId"))) {
				int size = baseMapper.checkRemoveRepeatConfigExists((String) mapParam.get("configId"));
				if (size > 0) {
					updateFlag = true;
				}
			}
			mapParam.put("updateFlag", updateFlag);
		} catch (Exception ex) {
			throw ex;
		}
	}

	/**
	 * 校验自定义参数的参数名,运算符,参数值
	 *
	 * @param mapParam
	 */
	public void checkCustom(Map<String, Object> mapParam) {
		try {
			// 自定义参数不为空时，分割自定义参数
			if (!StringHelper.IsEmptyOrNull(mapParam.get("custom"))) {
				filedMappingUtil.checkCustom(String.valueOf(mapParam.get("custom")));
			}
		} catch (Exception e) {
			e.printStackTrace();
			// throw new BusicenException(message.get("CLUE-SYSTECONFIGVALUE-01"));
			throw e;
		}
	}



	public void checkRepeat(Map<String, Object> mapParam) {
		String token = String.valueOf(mapParam.get("token"));
		_setShareOrgInfo(token, mapParam);
		int check = removeRepeatConfigMapper.checkRepeat(mapParam);
		if (check >= 1) {
			throw new BusicenException(message.get("CLUE-REVIEWASSIGN-10"));
		}
	}

	/**
	 * 开启，判断店端线索去重时，不区分专营店
	 * @param token
	 * @param mapParam
	 */
	private void _setShareOrgInfo(String token, Map<String, Object> mapParam) {
		UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
		if(!"dlrClue".equals(mapParam.get("clueType"))) {
			// 总部
			if("PV".equals(userBusiEntity.getDlrCode())) {
				mapParam.put("orgCode", userBusiEntity.getDlrCode());
				mapParam.put("orgName", userBusiEntity.getDlrName());
				return;
			}
		}

		String configValue = cacheDataFactory.querySysConfigValue("CLUE_DLR_SHARE_SWITCH", token);
		log.info("configValue={}", configValue);
		if("1".equals(configValue)) {
			mapParam.put("orgCode", "share");
			mapParam.put("orgName", "共享专营店");
		} else { // 每个专营店独立
			mapParam.put("orgCode", userBusiEntity.getDlrCode());
			mapParam.put("orgName", userBusiEntity.getDlrName());
		}
	}

}
