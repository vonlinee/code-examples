package com.ly.mp.csc.clue.entities;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;

/**
 * <p>
 * 网点关系映射表
 * </p>
 *
 * @author ly-busicen
 * @since 2021-09-14
 */
@TableName("t_sac_dlr_relation")
public class SacDlrRelation implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 网点关系映射ID
     */
    @TableId("RELATION_ID")
    private String relationId;

    /**
     * 原网点编码
     */
    @TableField("OLD_DLR_CODE")
    private String oldDlrCode;

    /**
     * 原网点名称
     */
    @TableField("OLD_DLR_NAME")
    private String oldDlrName;

    /**
     * 新网点编码
     */
    @TableField("NEW_DLR_CODE")
    private String newDlrCode;

    /**
     * 原网点名称
     */
    @TableField("NEW_DLR_NAME")
    private String newDlrName;

    /**
     * 渠道编码
     */
    @TableField("CHAN_CODE")
    private String chanCode;

    /**
     * 渠道名称
     */
    @TableField("CHAN_NAME")
    private String chanName;

    /**
     * 关联条件，支持=、!=、in、not in ,多个逗号分割
     */
    @TableField("WHERESTR")
    private String wherestr;

    /**
     * 扩展字段1
     */
    @TableField("COLUMN1")
    private String column1;

    /**
     * 扩展字段2
     */
    @TableField("COLUMN2")
    private String column2;

    /**
     * 扩展字段3
     */
    @TableField("COLUMN3")
    private String column3;

    /**
     * 扩展字段4
     */
    @TableField("COLUMN4")
    private String column4;

    /**
     * 扩展字段5
     */
    @TableField("COLUMN5")
    private String column5;

    /**
     * 扩展字段6
     */
    @TableField("COLUMN6")
    private String column6;

    /**
     * 扩展字段7
     */
    @TableField("COLUMN7")
    private String column7;

    /**
     * 扩展字段8
     */
    @TableField("COLUMN8")
    private String column8;

    /**
     * 扩展字段9
     */
    @TableField("COLUMN9")
    private String column9;

    /**
     * 扩展字段10
     */
    @TableField("COLUMN10")
    private String column10;

    /**
     * 厂商标识ID
     */
    @TableField("OEM_ID")
    private String oemId;

    /**
     * 集团标识ID
     */
    @TableField("GROUP_ID")
    private String groupId;

    /**
     * 厂商标识
     */
    @TableField("OEM_CODE")
    private String oemCode;

    /**
     * 集团标识
     */
    @TableField("GROUP_CODE")
    private String groupCode;

    /**
     * 创建人ID
     */
    @TableField("CREATOR")
    private String creator;

    /**
     * 创建人
     */
    @TableField("CREATED_NAME")
    private String createdName;

    /**
     * 创建日期
     */
    @TableField("CREATED_DATE")
    private LocalDateTime createdDate;

    /**
     * 修改人ID
     */
    @TableField("MODIFIER")
    private String modifier;

    /**
     * 修改人
     */
    @TableField("MODIFY_NAME")
    private String modifyName;

    /**
     * 最后更新日期
     */
    @TableField("LAST_UPDATED_DATE")
    private LocalDateTime lastUpdatedDate;

    /**
     * 是否可用
     */
    @TableField("IS_ENABLE")
    private String isEnable;

    /**
     * 并发控制ID
     */
    @TableField("UPDATE_CONTROL_ID")
    private String updateControlId;

    /**
     * 一级信息来源编码
     */
    @TableField("INFO_CHAN_M_CODE")
    private String infoChanMCode;

    /**
     * 一级信息来源名称
     */
    @TableField("INFO_CHAN_M_NAME")
    private String infoChanMName;

    /**
     * 二级信息来源编码
     */
    @TableField("INFO_CHAN_D_CODE")
    private String infoChanDCode;

    /**
     * 二级信息来源名称
     */
    @TableField("INFO_CHAN_D_NAME")
    private String infoChanDName;

    /**
     * 三级信息来源编码
     */
    @TableField("INFO_CHAN_DD_CODE")
    private String infoChanDdCode;

    /**
     * 三级信息来源名称
     */
    @TableField("INFO_CHAN_DD_NAME")
    private String infoChanDdName;

    public String getRelationId() {
        return relationId;
    }

    public void setRelationId(String relationId) {
        this.relationId = relationId;
    }
    public String getOldDlrCode() {
        return oldDlrCode;
    }

    public void setOldDlrCode(String oldDlrCode) {
        this.oldDlrCode = oldDlrCode;
    }
    public String getOldDlrName() {
        return oldDlrName;
    }

    public void setOldDlrName(String oldDlrName) {
        this.oldDlrName = oldDlrName;
    }
    public String getNewDlrCode() {
        return newDlrCode;
    }

    public void setNewDlrCode(String newDlrCode) {
        this.newDlrCode = newDlrCode;
    }
    public String getNewDlrName() {
        return newDlrName;
    }

    public void setNewDlrName(String newDlrName) {
        this.newDlrName = newDlrName;
    }
    public String getChanCode() {
        return chanCode;
    }

    public void setChanCode(String chanCode) {
        this.chanCode = chanCode;
    }
    public String getChanName() {
        return chanName;
    }

    public void setChanName(String chanName) {
        this.chanName = chanName;
    }
    public String getWherestr() {
        return wherestr;
    }

    public void setWherestr(String wherestr) {
        this.wherestr = wherestr;
    }
    public String getColumn1() {
        return column1;
    }

    public void setColumn1(String column1) {
        this.column1 = column1;
    }
    public String getColumn2() {
        return column2;
    }

    public void setColumn2(String column2) {
        this.column2 = column2;
    }
    public String getColumn3() {
        return column3;
    }

    public void setColumn3(String column3) {
        this.column3 = column3;
    }
    public String getColumn4() {
        return column4;
    }

    public void setColumn4(String column4) {
        this.column4 = column4;
    }
    public String getColumn5() {
        return column5;
    }

    public void setColumn5(String column5) {
        this.column5 = column5;
    }
    public String getColumn6() {
        return column6;
    }

    public void setColumn6(String column6) {
        this.column6 = column6;
    }
    public String getColumn7() {
        return column7;
    }

    public void setColumn7(String column7) {
        this.column7 = column7;
    }
    public String getColumn8() {
        return column8;
    }

    public void setColumn8(String column8) {
        this.column8 = column8;
    }
    public String getColumn9() {
        return column9;
    }

    public void setColumn9(String column9) {
        this.column9 = column9;
    }
    public String getColumn10() {
        return column10;
    }

    public void setColumn10(String column10) {
        this.column10 = column10;
    }
    public String getOemId() {
        return oemId;
    }

    public void setOemId(String oemId) {
        this.oemId = oemId;
    }
    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }
    public String getOemCode() {
        return oemCode;
    }

    public void setOemCode(String oemCode) {
        this.oemCode = oemCode;
    }
    public String getGroupCode() {
        return groupCode;
    }

    public void setGroupCode(String groupCode) {
        this.groupCode = groupCode;
    }
    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }
    public String getCreatedName() {
        return createdName;
    }

    public void setCreatedName(String createdName) {
        this.createdName = createdName;
    }
    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }
    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier;
    }
    public String getModifyName() {
        return modifyName;
    }

    public void setModifyName(String modifyName) {
        this.modifyName = modifyName;
    }
    public LocalDateTime getLastUpdatedDate() {
        return lastUpdatedDate;
    }

    public void setLastUpdatedDate(LocalDateTime lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }
    public String getIsEnable() {
        return isEnable;
    }

    public void setIsEnable(String isEnable) {
        this.isEnable = isEnable;
    }
    public String getUpdateControlId() {
        return updateControlId;
    }

    public void setUpdateControlId(String updateControlId) {
        this.updateControlId = updateControlId;
    }
    public String getInfoChanMCode() {
        return infoChanMCode;
    }

    public void setInfoChanMCode(String infoChanMCode) {
        this.infoChanMCode = infoChanMCode;
    }
    public String getInfoChanMName() {
        return infoChanMName;
    }

    public void setInfoChanMName(String infoChanMName) {
        this.infoChanMName = infoChanMName;
    }
    public String getInfoChanDCode() {
        return infoChanDCode;
    }

    public void setInfoChanDCode(String infoChanDCode) {
        this.infoChanDCode = infoChanDCode;
    }
    public String getInfoChanDName() {
        return infoChanDName;
    }

    public void setInfoChanDName(String infoChanDName) {
        this.infoChanDName = infoChanDName;
    }
    public String getInfoChanDdCode() {
        return infoChanDdCode;
    }

    public void setInfoChanDdCode(String infoChanDdCode) {
        this.infoChanDdCode = infoChanDdCode;
    }
    public String getInfoChanDdName() {
        return infoChanDdName;
    }

    public void setInfoChanDdName(String infoChanDdName) {
        this.infoChanDdName = infoChanDdName;
    }

    @Override
    public String toString() {
        return "DlrRelation{" +
        "relationId=" + relationId +
        ", oldDlrCode=" + oldDlrCode +
        ", oldDlrName=" + oldDlrName +
        ", newDlrCode=" + newDlrCode +
        ", newDlrName=" + newDlrName +
        ", chanCode=" + chanCode +
        ", chanName=" + chanName +
        ", wherestr=" + wherestr +
        ", column1=" + column1 +
        ", column2=" + column2 +
        ", column3=" + column3 +
        ", column4=" + column4 +
        ", column5=" + column5 +
        ", column6=" + column6 +
        ", column7=" + column7 +
        ", column8=" + column8 +
        ", column9=" + column9 +
        ", column10=" + column10 +
        ", oemId=" + oemId +
        ", groupId=" + groupId +
        ", oemCode=" + oemCode +
        ", groupCode=" + groupCode +
        ", creator=" + creator +
        ", createdName=" + createdName +
        ", createdDate=" + createdDate +
        ", modifier=" + modifier +
        ", modifyName=" + modifyName +
        ", lastUpdatedDate=" + lastUpdatedDate +
        ", isEnable=" + isEnable +
        ", updateControlId=" + updateControlId +
        ", infoChanMCode=" + infoChanMCode +
        ", infoChanMName=" + infoChanMName +
        ", infoChanDCode=" + infoChanDCode +
        ", infoChanDName=" + infoChanDName +
        ", infoChanDdCode=" + infoChanDdCode +
        ", infoChanDdName=" + infoChanDdName +
        "}";
    }
}
