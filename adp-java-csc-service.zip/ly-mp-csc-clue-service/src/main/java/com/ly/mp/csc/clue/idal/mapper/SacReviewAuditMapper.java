package com.ly.mp.csc.clue.idal.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.ly.mp.csc.clue.entities.SacReviewAudit;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 回访审核表 Mapper 接口
 * </p>
 *
 * @author ly-busicen
 * @since 2021-08-17
 */
public interface SacReviewAuditMapper extends BaseMapper<SacReviewAudit> {

	/**
     * 审核任务查询
     * @param page 分页参数
     * @param param 输入参数
     * @return List
     */
    List<Map<String, Object>> queryListAuditReviewInfo(IPage<Map<String, Object>> page, @Param("param")Map<String, Object> param);

    /**
     * 审核校验
     * @param page 分页参数
     * @param param 输入参数
     * @return List
     */
    List<Map<String, Object>> checkAuditReviewInfo(IPage<Map<String, Object>> page, @Param("param")Map<String, Object> param);

	/**
	 * 插入
	 * @param mapParm
	 * @return
	 */
	public int insertSacReviewAudit(@Param("param")Map<String, Object> mapParm);
	
	/**
	 * 更新
	 * @param mapParm
	 * @return
	 */
	public int updateSacReviewAudit(@Param("param")Map<String, Object> mapParm);

}
