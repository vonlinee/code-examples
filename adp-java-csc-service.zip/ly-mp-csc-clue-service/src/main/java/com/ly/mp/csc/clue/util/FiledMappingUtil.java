package com.ly.mp.csc.clue.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ly.bucn.component.message.Message;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.idal.mapper.SacFieldMappingConfigMapper;

/**
 * 线索公共方法
 * 
 * @author ly-linliq
 *
 */
@Component
public class FiledMappingUtil {
	@Autowired
	SacFieldMappingConfigMapper sacFieldMappingConfigMapper;
	@Autowired
	Message message;

	/**
	 * 自定义参数字段校验
	 * @param customString
	 */
	public void checkCustom(String customString) {
		// 首先以逗号分割自定义参数
		String[] strings = customString.split(";");
		// 遍历自定义参数数组,判断参数是否符合要求
		for (int i = 0; i < strings.length; i++) {
			// 判断有没有运算符
			if (!strings[i].contains("[") || !strings[i].contains("]")) {
				throw new BusicenException(message.get("CLUE-REVIEWASSIGN-19"));
			}
			// 获取参数名
			String columnName = strings[i].substring(0, strings[i].indexOf("["));
			// 获取运算符
			String operational = strings[i].substring(strings[i].indexOf("[") + 1, strings[i].indexOf("]"));
			// 获取参数值
			String str1 = strings[i].substring(0, strings[i].indexOf("]"));
			String value = strings[i].substring(str1.length() + 1, strings[i].length());

			// 判断参数名是否为空
			if (StringHelper.IsEmptyOrNull(columnName)) {
				throw new BusicenException(message.get("CLUE-REVIEWASSIGN-26"));
			}

			// 校验运算符是否为空
			if (StringHelper.IsEmptyOrNull(operational)) {
				throw new BusicenException(message.get("CLUE-REVIEWASSIGN-27"));
			}

			// 校验参数值是否为空
			if (StringHelper.IsEmptyOrNull(value)) {
				throw new BusicenException(message.get("CLUE-REVIEWASSIGN-28"));
			}
			
		}
	}
	
	/**
	 * * 处理参数，将参数名、运算符、参数值分割并返回
	 * 
	 * @author ly-linliq
	 * @param columInfo
	 * @return
	 */
	public List<Map<String, Object>> customHandle(String columInfo) {
		// 首先以逗号分割自定义参数
		String[] strings = String.valueOf(columInfo).split(";");
		// 遍历自定义参数数组,分割参数名,运算符以及值
		List<Map<String, Object>> columnList = new ArrayList<Map<String, Object>>();
		// 将参数放进一个map里,用于字段映射
		for (int i = 0; i < strings.length; i++) {
			// 获取参数名
			String columnName = strings[i].substring(0, strings[i].indexOf("["));
			// 获取运算符
			String operational = strings[i].substring(strings[i].indexOf("[") + 1, strings[i].indexOf("]"));
			// 获取参数值
			String str1 = strings[i].substring(0, strings[i].indexOf("]"));
			String value = strings[i].substring(str1.length() + 1, strings[i].length());
			//去除in/not in参数的单引号
			if("in".equals(operational)||"not in".equals(operational)) {			
				value=value.replace("'", "");
				value=value.substring(1, value.length() - 1);
			}	
			Map<String, Object> columnMap = new HashMap<String, Object>();
			columnMap.put("columnName", columnName);
			columnMap.put("operational", operational);
			columnMap.put("value", value);
			// 将参数名,运算符,参数值放进参数集合中
			columnList.add(columnMap);
		}
		return columnList;
	}

	/**
	 * 处理参数,将字段名改为数据库对应的字段
	 * 
	 * @param info
	 * @return
	 */
	public Map<String, Object> queryFieldMappingList(Map<String, Object> info) {
		String columnString = "";
		List<Map<String, Object>> columnList = (List<Map<String, Object>>) info.get("columnList");
		// 拼接参数名，以逗号分割
		for (Map<String, Object> mapParam : columnList) {
			columnString = columnString + "," + mapParam.get("columnName").toString();
		}
		info.put("columnString", columnString);
		// 查找字段映射关系
		List<Map<String, Object>> fieldList = sacFieldMappingConfigMapper.fileMappingList(info);
		List<Map<String, Object>> fieldMappingList = new ArrayList<Map<String, Object>>();
		List<Map<String, Object>> jsonFiledMappingList = new ArrayList<Map<String, Object>>();
		// 处理参数,将字段名改为数据库对应的字段
		for (Map<String, Object> item : fieldList) {
			for (Map<String, Object> iteMap : columnList) {
				if (iteMap.get("columnName").equals(item.get("mappingFiledCode"))) {
					// 处理字段映射类型为2的字段
					if ("2".equals(item.get("filedType"))) {
						iteMap.put("columnName", item.get("filedCode").toString());
						//表存放json字段的字段名
						iteMap.put("jsonColumn",item.get("dbFieldCode").toString());
						jsonFiledMappingList.add(iteMap);
						
					} else {
						// 处理字段映射类型为1的字段
						if (StringHelper.IsEmptyOrNull(item.get("dbFieldCode"))) {
							iteMap.put("columnName", item.get("filedCode").toString());
						} else {
							iteMap.put("columnName", item.get("dbFieldCode").toString());
						}
						fieldMappingList.add(iteMap);
					}
				}
			}
		}
		// 没有字段映射且字段类型为1的字段集合
		columnList.removeAll(fieldMappingList);
		columnList.removeAll(jsonFiledMappingList);
		// 将有字段映射,没有字段映射的字段集合放进一个map里
		Map<String, Object> fieldMap = new HashMap<String, Object>();
		fieldMap.put("fieldMapping", fieldMappingList);
		fieldMap.put("field", columnList);
		fieldMap.put("jsonFieldMapping", jsonFiledMappingList);
		return fieldMap;
	}

	/**
	 * 拼接有字段映射字段的sql
	 * 
	 * @param filedMappingList
	 * @return
	 */
	public String joinFieldMappingCustom(List<Map<String, Object>> filedMappingList) {
		String customString = "";
		for (Map<String, Object> map : filedMappingList) {
			if("in".equals(map.get("operational"))||"not in".equals(map.get("operational"))) {
				customString = customString + " and " + map.get("columnName").toString() +" "+ map.get("operational").toString()
						+" ("+ map.get("value").toString()+" )";
			}else {
				customString = customString + " and " + map.get("columnName").toString() +" "+ map.get("operational").toString()
						+ "'" +" "+ map.get("value").toString() + "'";
			}
		}
		return customString;

	}

	/**
	 * 拼接无字段映射字段的sql
	 * 
	 * @param filedMappingList
	 * @return
	 */
	public List<Map<String, Object>> joinNoFieldMappingCustom(List<Map<String, Object>> filedList) {
		List<Map<String, Object>> noFieldMappingList = new ArrayList<Map<String, Object>>();

		for (Map<String, Object> mapitem : filedList) {
			String condition = " ";
			if("in".equals(mapitem.get("operational"))||"not in".equals(mapitem.get("operational"))) {
				condition = condition + mapitem.get("operational").toString()+" ("+ mapitem.get("value").toString()+" )";
			}else {
				condition = condition + mapitem.get("operational").toString() + "'" + mapitem.get("value").toString() + "'";
			}
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("columnName", mapitem.get("columnName"));
			map.put("condition", condition);
			noFieldMappingList.add(map);
		}
		return noFieldMappingList;

	}

	public List<String> joinJsonFieldMappingCustom(List<Map<String, Object>> filedList) {
		List<String> jsonFiledMappingList = new ArrayList<String>();
		// JSON_EXTRACT (EXTENDS_JSON, '$.column19')='13535577002';
		for (Map<String, Object> mapitem : filedList) {
			String jsonCustom=null;
			if("in".equals(mapitem.get("operational"))||"not in".equals(mapitem.get("operational"))) {
				jsonCustom = "JSON_EXTRACT ("+mapitem.get("jsonColumn").toString()+", '$." + mapitem.get("columnName").toString() + "')"
						+" "+ mapitem.get("operational").toString() +" ("+ mapitem.get("value").toString()+" )";
			}else {
				jsonCustom = "JSON_EXTRACT ("+mapitem.get("jsonColumn").toString()+", '$." + mapitem.get("columnName").toString() + "')"
						+" "+ mapitem.get("operational").toString() +" "+ "'" + mapitem.get("value").toString() + "'";
			}
			jsonFiledMappingList.add(jsonCustom);
		}
		return jsonFiledMappingList;
	}

}
