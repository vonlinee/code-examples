package com.ly.mp.csc.clue.service;

import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.csc.clue.entities.DbSmallCarType;

import java.util.Map;

import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 车型小类 服务类
 * </p>
 *
 * @author ly-linliq
 * @since 2021-09-07
 */
public interface ISacDbSmallCarTypeService extends IService<DbSmallCarType> {
	/**
	* @Description: 车型查询
	* @author: linliq
	* @date 2021/09/07 14:36:45
	* @param mapParam
	* @return
	 */
	public ListResult<Map<String,Object>> smallCarTypeQuery(ParamPage<Map<String, Object>> mapParam);
}
