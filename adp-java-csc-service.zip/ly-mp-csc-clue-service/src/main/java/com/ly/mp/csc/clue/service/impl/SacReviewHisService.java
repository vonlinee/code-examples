package com.ly.mp.csc.clue.service.impl;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegist;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegistor;
import com.ly.bucn.component.interceptor.annotation.Interceptor;
import com.ly.mp.busi.base.constant.UserBusiEntity;
import com.ly.mp.busi.base.context.BusicenContext;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.busi.base.handler.BusicenUtils.SOU;
import com.ly.mp.busicen.rule.field.IFireFieldRule;
import com.ly.mp.busi.base.handler.ResultHandler;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.entities.SacReviewHis;
import com.ly.mp.csc.clue.enums.ReviewAssignStatusEnum;
import com.ly.mp.csc.clue.enums.ReviewStatusEnum;
import com.ly.mp.csc.clue.idal.mapper.SacReviewHisMapper;
import com.ly.mp.csc.clue.service.ISacReviewHisService;


/**
 * <p>
 * 回访任务备份表 服务实现类
 * </p>
 *
 * @author ly-busicen
 * @since 2021-08-17
 */
@Service
public class SacReviewHisService extends ServiceImpl<SacReviewHisMapper, SacReviewHis> 
implements ISacReviewHisService,InterceptorWrapperRegist {

private Logger log = LoggerFactory.getLogger(SacReviewHisService.class);
	
	@Autowired
	SacReviewHisMapper SacReviewHisMapper;

	@Autowired
	IFireFieldRule fireFieldRule;
	
	/**
	 * 添加回访记录
	 * @param mapParam
	 * @param token
	 * @return
	 */
	@Override
	@Interceptor("csc_clue_review_addrecord")
	@Transactional
	public EntityResult<Map<String, Object>> addReviewRecord(Map<String, Object> mapParam, String token){
		try{
			UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
			
			mapParam.put("nodeCode", "AddRecord");
			mapParam.put("nodeName", "添加回访记录");
			mapParam.put("reviewPersonId", userBusiEntity.getUserID());
			mapParam.put("reviewPersonName", userBusiEntity.getEmpName());
			mapParam.put("orgCode", userBusiEntity.getDlrCode());
			mapParam.put("orgName", userBusiEntity.getDlrName());
			mapParam.put("reviewStatus", ReviewStatusEnum.end.getResult());
			mapParam.put("reviewStatusName", ReviewStatusEnum.end.getMsg());
			mapParam.put("assignStatus", ReviewAssignStatusEnum.assignEd.getResult());
			mapParam.put("assignStatusName", ReviewAssignStatusEnum.assignEd.getMsg());
			mapParam.put("assignTime", LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
			
			//其他字段
			if(StringHelper.IsEmptyOrNull(mapParam.get("businessType"))){
				mapParam.put("businessType", "-1");
				mapParam.put("businessTypeName", "全部");
			}
			if(StringHelper.IsEmptyOrNull(mapParam.get("channelCode"))){
				mapParam.put("channelCode", "-1");
				mapParam.put("channelName", "-1");
			}
			
			return this.sacReviewHisSave(mapParam, token);
		}catch (Exception e) {
			throw e;
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public void regist(InterceptorWrapperRegistor registor) {
		// 添加回访记录：前置
		registor.before("csc_clue_review_addrecord_valid", (context, model) -> {
			//参数校验
			fireFieldRule.fireRuleExcpt((Map<String, Object>) context.data().getP()[0], "csc_clue_review_addrecord-check", "maindata");
		});
	}
	
	
	/**
	 * 根据主键判断插入或更新
	 * @param info
	 * @return
	 */
	@Override
	@Transactional
	public EntityResult<Map<String, Object>> sacReviewHisSave(Map<String, Object> mapParam, String token){
		try {
			Boolean updateFlag = false;
		    if (!StringHelper.IsEmptyOrNull(mapParam.get("reviewId"))) {
			    QueryWrapper<SacReviewHis> wrapper = new QueryWrapper<>();
			    wrapper.lambda().eq(SacReviewHis::getReviewId, mapParam.get("reviewId"));
		    	if (list(wrapper).size() > 0) {
		    		updateFlag = true;
				}
			}
			if(!updateFlag){
				//新增
				if (StringHelper.IsEmptyOrNull(mapParam.get("reviewId"))) {
					//主键
					mapParam.put("reviewId",UUID.randomUUID().toString());
				}
				BusicenUtils.invokeUserInfo(mapParam, SOU.Save,token);
				SacReviewHisMapper.insertSacReviewHis(mapParam);
			}else{
				//更新
				BusicenUtils.invokeUserInfo(mapParam, SOU.Update,"");
				SacReviewHisMapper.updateSacReviewHis(mapParam);
			}
			return ResultHandler.updateOk(mapParam);
		} catch (Exception e) {
			log.error("SacReviewHisSave", e);
			throw e;
		} 
	}
	
}
