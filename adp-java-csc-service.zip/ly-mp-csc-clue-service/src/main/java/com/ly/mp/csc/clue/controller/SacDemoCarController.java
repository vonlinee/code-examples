package com.ly.mp.csc.clue.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.context.BusicenInvoker;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.service.ISacDemoCarService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * <p>
 * 试驾车表 前端控制器
 * </p>
 *
 * @author ly-linliq
 * @since 2021-10-14
 */
@Api(value = "试驾车管理", tags = { "试驾车管理" })
@RestController
@RequestMapping(value = "/ly/sac/democar", produces = { MediaType.APPLICATION_JSON_VALUE })
public class SacDemoCarController {
	@Autowired
	ISacDemoCarService sacDemoCarService;

	@ApiOperation(value = "试驾车查询", notes = "试驾车查询")
	@RequestMapping(value = "/democarquerylist.do", method = RequestMethod.POST)
	public ListResult<Map<String, Object>> DemoCarQueryList(
			@RequestHeader(name = "authorization", required = false) String authentication,
			@RequestBody(required = false) ParamPage<Map<String, Object>> mapParam) {
		mapParam.getParam().put("token", authentication);
		return BusicenInvoker.doList(() -> sacDemoCarService.demoCarQueryList(mapParam)).result();
	}

	@ApiOperation(value = "试驾车保存", notes = "试驾车保存")
	@RequestMapping(value = "/democarsave.do", method = RequestMethod.POST)
	public OptResult democarSave(@RequestHeader(name = "authorization", required = false) String authentication,
			@RequestBody(required = false) ParamBase<Map<String, Object>> mapParam) {
		mapParam.getParam().put("token", authentication);
		return BusicenInvoker.doOpt(() -> sacDemoCarService.demoCarSave(mapParam)).result();
	}
}
