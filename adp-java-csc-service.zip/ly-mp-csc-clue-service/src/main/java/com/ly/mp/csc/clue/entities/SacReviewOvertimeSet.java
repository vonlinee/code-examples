package com.ly.mp.csc.clue.entities;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;

/**
 * <p>
 * 回访超时规则设置表
 * </p>
 *
 * @author ly-busicen
 * @since 2021-09-14
 */
@TableName("t_sac_review_overtime_set")
public class SacReviewOvertimeSet implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 设置ID
     */
    @TableId("SET_ID")
    private String setId;

    /**
     * 所属组织
     */
    @TableField("ORG_CODE")
    private String orgCode;

    /**
     * 所属组织名称
     */
    @TableField("ORG_NAME")
    private String orgName;

    /**
     * 回访单据类型
     */
    @TableField("BILL_TYPE")
    private String billType;

    /**
     * 回访单据类型名称
     */
    @TableField("BILL_TYPE_NAME")
    private String billTypeName;

    /**
     * 回访单据业务类型
     */
    @TableField("BUSINESS_TYPE")
    private String businessType;

    /**
     * 回访单据业务类型名称
     */
    @TableField("BUSINESS_TYPE_NAME")
    private String businessTypeName;

    /**
     * 渠道编码
     */
    @TableField("CHANNEL_CODE")
    private String channelCode;

    /**
     * 渠道名称
     */
    @TableField("CHANNEL_NAME")
    private String channelName;

    /**
     * 首次回访超时规则ID
     */
    @TableField("FIRST_RULE_ID")
    private String firstRuleId;

    /**
     * 二次回访超时规则ID
     */
    @TableField("SEC_RULE_ID")
    private String secRuleId;

    /**
     * 厂商标识ID
     */
    @TableField("OEM_ID")
    private String oemId;

    /**
     * 集团标识ID
     */
    @TableField("GROUP_ID")
    private String groupId;

    /**
     * 创建人ID
     */
    @TableField("CREATOR")
    private String creator;

    /**
     * 创建人
     */
    @TableField("CREATED_NAME")
    private String createdName;

    /**
     * 创建日期
     */
    @TableField("CREATED_DATE")
    private LocalDateTime createdDate;

    /**
     * 修改人ID
     */
    @TableField("MODIFIER")
    private String modifier;

    /**
     * 修改人
     */
    @TableField("MODIFY_NAME")
    private String modifyName;

    /**
     * 最后更新日期
     */
    @TableField("LAST_UPDATED_DATE")
    private LocalDateTime lastUpdatedDate;

    /**
     * 是否可用
     */
    @TableField("IS_ENABLE")
    private String isEnable;

    /**
     * 并发控制ID
     */
    @TableField("UPDATE_CONTROL_ID")
    private String updateControlId;

    /**
     * 一级信息来源编码
     */
    @TableField("INFO_CHAN_M_CODE")
    private String infoChanMCode;

    /**
     * 一级信息来源名称
     */
    @TableField("INFO_CHAN_M_NAME")
    private String infoChanMName;

    /**
     * 二级信息来源编码
     */
    @TableField("INFO_CHAN_D_CODE")
    private String infoChanDCode;

    /**
     * 二级信息来源名称
     */
    @TableField("INFO_CHAN_D_NAME")
    private String infoChanDName;

    /**
     * 三级信息来源编码
     */
    @TableField("INFO_CHAN_DD_CODE")
    private String infoChanDdCode;

    /**
     * 三级信息来源名称
     */
    @TableField("INFO_CHAN_DD_NAME")
    private String infoChanDdName;

    public String getSetId() {
        return setId;
    }

    public void setSetId(String setId) {
        this.setId = setId;
    }
    public String getOrgCode() {
        return orgCode;
    }

    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }
    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }
    public String getBillType() {
        return billType;
    }

    public void setBillType(String billType) {
        this.billType = billType;
    }
    public String getBillTypeName() {
        return billTypeName;
    }

    public void setBillTypeName(String billTypeName) {
        this.billTypeName = billTypeName;
    }
    public String getBusinessType() {
        return businessType;
    }

    public void setBusinessType(String businessType) {
        this.businessType = businessType;
    }
    public String getBusinessTypeName() {
        return businessTypeName;
    }

    public void setBusinessTypeName(String businessTypeName) {
        this.businessTypeName = businessTypeName;
    }
    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }
    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }
    public String getFirstRuleId() {
        return firstRuleId;
    }

    public void setFirstRuleId(String firstRuleId) {
        this.firstRuleId = firstRuleId;
    }
    public String getSecRuleId() {
        return secRuleId;
    }

    public void setSecRuleId(String secRuleId) {
        this.secRuleId = secRuleId;
    }
    public String getOemId() {
        return oemId;
    }

    public void setOemId(String oemId) {
        this.oemId = oemId;
    }
    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }
    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }
    public String getCreatedName() {
        return createdName;
    }

    public void setCreatedName(String createdName) {
        this.createdName = createdName;
    }
    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }
    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier;
    }
    public String getModifyName() {
        return modifyName;
    }

    public void setModifyName(String modifyName) {
        this.modifyName = modifyName;
    }
    public LocalDateTime getLastUpdatedDate() {
        return lastUpdatedDate;
    }

    public void setLastUpdatedDate(LocalDateTime lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }
    public String getIsEnable() {
        return isEnable;
    }

    public void setIsEnable(String isEnable) {
        this.isEnable = isEnable;
    }
    public String getUpdateControlId() {
        return updateControlId;
    }

    public void setUpdateControlId(String updateControlId) {
        this.updateControlId = updateControlId;
    }
    public String getInfoChanMCode() {
        return infoChanMCode;
    }

    public void setInfoChanMCode(String infoChanMCode) {
        this.infoChanMCode = infoChanMCode;
    }
    public String getInfoChanMName() {
        return infoChanMName;
    }

    public void setInfoChanMName(String infoChanMName) {
        this.infoChanMName = infoChanMName;
    }
    public String getInfoChanDCode() {
        return infoChanDCode;
    }

    public void setInfoChanDCode(String infoChanDCode) {
        this.infoChanDCode = infoChanDCode;
    }
    public String getInfoChanDName() {
        return infoChanDName;
    }

    public void setInfoChanDName(String infoChanDName) {
        this.infoChanDName = infoChanDName;
    }
    public String getInfoChanDdCode() {
        return infoChanDdCode;
    }

    public void setInfoChanDdCode(String infoChanDdCode) {
        this.infoChanDdCode = infoChanDdCode;
    }
    public String getInfoChanDdName() {
        return infoChanDdName;
    }

    public void setInfoChanDdName(String infoChanDdName) {
        this.infoChanDdName = infoChanDdName;
    }

    @Override
    public String toString() {
        return "ReviewOvertimeSet{" +
        "setId=" + setId +
        ", orgCode=" + orgCode +
        ", orgName=" + orgName +
        ", billType=" + billType +
        ", billTypeName=" + billTypeName +
        ", businessType=" + businessType +
        ", businessTypeName=" + businessTypeName +
        ", channelCode=" + channelCode +
        ", channelName=" + channelName +
        ", firstRuleId=" + firstRuleId +
        ", secRuleId=" + secRuleId +
        ", oemId=" + oemId +
        ", groupId=" + groupId +
        ", creator=" + creator +
        ", createdName=" + createdName +
        ", createdDate=" + createdDate +
        ", modifier=" + modifier +
        ", modifyName=" + modifyName +
        ", lastUpdatedDate=" + lastUpdatedDate +
        ", isEnable=" + isEnable +
        ", updateControlId=" + updateControlId +
        ", infoChanMCode=" + infoChanMCode +
        ", infoChanMName=" + infoChanMName +
        ", infoChanDCode=" + infoChanDCode +
        ", infoChanDName=" + infoChanDName +
        ", infoChanDdCode=" + infoChanDdCode +
        ", infoChanDdName=" + infoChanDdName +
        "}";
    }
}
