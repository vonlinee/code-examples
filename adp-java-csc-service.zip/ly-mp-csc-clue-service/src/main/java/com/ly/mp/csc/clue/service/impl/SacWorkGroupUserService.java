package com.ly.mp.csc.clue.service.impl;

import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.busi.base.handler.BusicenUtils.SOU;
import com.ly.mp.busi.base.handler.ResultHandler;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.entities.SacWorkGroupUser;
import com.ly.mp.csc.clue.idal.mapper.SacWorkGroupUserMapper;
import com.ly.mp.csc.clue.service.ISacWorkGroupUserService;


/**
 * <p>
 * 工作组用户表 服务实现类
 * </p>
 *
 * @author ly-busicen
 * @since 2021-08-17
 * Modification History:
 * Date               Author          Version            Description
 *---------------------------------------------------------------------*
 * 2021/9/14 14:28     linliq           v1.0.0            修改报错问题
 */
@Service
public class SacWorkGroupUserService extends ServiceImpl<SacWorkGroupUserMapper, SacWorkGroupUser> implements ISacWorkGroupUserService {

private Logger log = LoggerFactory.getLogger(SacWorkGroupUserService.class);
	
	@Autowired
	SacWorkGroupUserMapper sacWorkGroupUserMapper;

	/**
	 * 根据主键判断插入或更新
	 * @param info
	 * @return
	 */
	@Override
	@Transactional
	public EntityResult<Map<String, Object>> sacWorkGroupUserSave(Map<String, Object> mapParam, String token){
		try {
			Boolean updateFlag = false;
		    if (!StringHelper.IsEmptyOrNull(mapParam.get("workGroupUserId"))) {
			    QueryWrapper<SacWorkGroupUser> wrapper = new QueryWrapper<>();
			    wrapper.lambda().eq(SacWorkGroupUser::getWorkGroupUserId, mapParam.get("workGroupUserId"));
		    	if (list(wrapper).size() > 0) {
		    		updateFlag = true;
				}
			}
			if(!updateFlag){
				//新增
				if (StringHelper.IsEmptyOrNull(mapParam.get("workGroupUserId"))) {
					//主键
					mapParam.put("workGroupUserId",UUID.randomUUID().toString());
				}
				BusicenUtils.invokeUserInfo(mapParam, SOU.Save,token);
				sacWorkGroupUserMapper.insertSacWorkGroupUser(mapParam);
			}else{
				//更新
				BusicenUtils.invokeUserInfo(mapParam, SOU.Update,"");
				sacWorkGroupUserMapper.updateSacWorkGroupUser(mapParam);
			}
			return ResultHandler.updateOk(mapParam);
		} catch (Exception e) {
			log.error("sacWorkGroupUserSave", e);
			throw e;
		} 
	}
	
}
