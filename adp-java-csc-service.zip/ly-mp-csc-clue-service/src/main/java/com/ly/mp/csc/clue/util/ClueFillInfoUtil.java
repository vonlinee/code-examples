package com.ly.mp.csc.clue.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.csc.clue.idal.mapper.SacChannelInfoMapper;
import com.ly.mp.csc.clue.otherservice.ICscSysBaseDataService;
import com.ly.mp.csc.clue.otherservice.ICscSysClueService;
import com.ly.mp.csc.clue.otherservice.ICscSysOrgService;
import com.ly.mp.csc.clue.service.ISacDbCarBrandService;
import com.ly.mp.csc.clue.service.ISacDbCarColorService;
import com.ly.mp.csc.clue.service.ISacDbCarIncolorService;
import com.ly.mp.csc.clue.service.ISacDbSmallCarTypeService;

@Component
public class ClueFillInfoUtil {


	@Autowired SacChannelInfoMapper channelInfoMapper;
	public Map<String, String> getChannelNameMap() {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("isEnable", "1");
		List<Map<String, Object>> channelList = channelInfoMapper.selectByAll(paramMap);

		String seperateChar = "@#@";
		String seperateTeamChar = "@##@";

		Map<String, String> channelNameMap = new HashMap<>();
		for(Map<String, Object> map: channelList) {
			String channelCode = (String)map.get("channelCode");
			String channelName = (String)map.get("channelName");
			String parentPart = "";
			int channelLevelCode = Integer.parseInt((String)map.get("channelLevelCode"));
			if(channelLevelCode>0) {
				String parentChannelName = (String)map.get("parentChannelName");
				if(parentChannelName == null) {
					// 无效数据
					continue;
				}
				parentPart = seperateTeamChar + (channelLevelCode - 1) + seperateChar + (String)map.get("parentChannelName");
			}
			channelNameMap.put(channelLevelCode + seperateChar + channelName, channelCode + parentPart);
		}



		return channelNameMap;
	}





	@Autowired ICscSysClueService cscSysClueService;
	public Map<String, String> getCarSeriesNameCodeMap() {
		Map<String, Object> param = new HashMap<>();
		param.put("isEnable", "1");
		ParamPage<Map<String, Object>> paramPage = new ParamPage<>();
		paramPage.setPageIndex(1);
		paramPage.setPageSize(Integer.MAX_VALUE);
		paramPage.setParam(param);
		ListResult<Map<String, Object>> listResult = cscSysClueService.carSeriesQuery(paramPage);

		Map<String, String> map = new HashMap<>();
		if("1".equals(listResult.getResult())) {
			List<Map<String, Object>> rows = listResult.getRows();
			for(Map<String, Object> info: rows) {
				map.put((String)info.get("carSeriesCn"), (String)info.get("carSeriesCode"));
				// carSeriesNameCodeMap.put((String)info.get("carSeriesEn"), (String)info.get("carSeriesCode"));
			}
		}
		return map;
	}

	public Map<String, String> getCarSeriesCodeNameMap() {
		Map<String, Object> param = new HashMap<>();
		param.put("isEnable", "1");
		ParamPage<Map<String, Object>> paramPage = new ParamPage<>();
		paramPage.setPageIndex(1);
		paramPage.setPageSize(Integer.MAX_VALUE);
		paramPage.setParam(param);
		ListResult<Map<String, Object>> listResult = cscSysClueService.carSeriesQuery(paramPage);

		Map<String, String> map = new HashMap<>();
		if("1".equals(listResult.getResult())) {
			List<Map<String, Object>> rows = listResult.getRows();
			for(Map<String, Object> info: rows) {
				map.put((String)info.get("carSeriesCode"), (String)info.get("carSeriesCn"));
			}
		}
		return map;
	}


	@Autowired ISacDbSmallCarTypeService sacDbSmallCarTypeService;
	public Map<String, String> getCarTypeCodeNameMap() {
		Map<String, Object> param = new HashMap<>();
		param.put("isEnable", "1");
		ParamPage<Map<String, Object>> paramPage = new ParamPage<>();
		paramPage.setPageIndex(1);
		paramPage.setPageSize(Integer.MAX_VALUE);
		paramPage.setParam(param);
		ListResult<Map<String, Object>> listResult = sacDbSmallCarTypeService.smallCarTypeQuery(paramPage);
		Map<String, String> map = new HashMap<>();
		if("1".equals(listResult.getResult())) {
			List<Map<String, Object>> rows = listResult.getRows();
			for(Map<String, Object> info: rows) {
				map.put((String)info.get("smallCarTypeCode"), (String)info.get("smallCarTypeCn"));
			}
		}
		return map;
	}

	@Autowired ISacDbCarColorService sacDbCarColoeService;
	public Map<String, String> getCarColorCodeNameMap() {
		Map<String, Object> param = new HashMap<>();
		param.put("isEnable", "1");
		ParamPage<Map<String, Object>> paramPage = new ParamPage<>();
		paramPage.setPageIndex(1);
		paramPage.setPageSize(Integer.MAX_VALUE);
		paramPage.setParam(param);

		ListResult<Map<String, Object>> listResult = sacDbCarColoeService.carColorQuery(paramPage);
		Map<String, String> map = new HashMap<>();
		if("1".equals(listResult.getResult())) {
			List<Map<String, Object>> rows = listResult.getRows();
			for(Map<String, Object> info: rows) {
				map.put((String)info.get("carColorCode"), (String)info.get("carColorName"));
			}
		}
		return map;
	}

	@Autowired ISacDbCarIncolorService sacDbCarIncolorService;
	public Map<String, String> getCarInColorCodeNameMap() {
		Map<String, Object> param = new HashMap<>();
		param.put("isEnable", "1");
		ParamPage<Map<String, Object>> paramPage = new ParamPage<>();
		paramPage.setPageIndex(1);
		paramPage.setPageSize(Integer.MAX_VALUE);
		paramPage.setParam(param);

		ListResult<Map<String, Object>> listResult = sacDbCarIncolorService.carIncolorQuery(paramPage);
		Map<String, String> map = new HashMap<>();
		if("1".equals(listResult.getResult())) {
			List<Map<String, Object>> rows = listResult.getRows();
			for(Map<String, Object> info: rows) {
				map.put((String)info.get("carIncolorCode"), (String)info.get("carIncolorName"));
			}
		}
		return map;
	}

	@Autowired ISacDbCarBrandService sacDbCarBrandService;
	public Map<String, String> getCarBrandCodeNameMap() {
		Map<String, Object> param = new HashMap<>();
		param.put("isEnable", "1");
		ParamPage<Map<String, Object>> paramPage = new ParamPage<>();
		paramPage.setPageIndex(1);
		paramPage.setPageSize(Integer.MAX_VALUE);
		paramPage.setParam(param);

		ListResult<Map<String, Object>> listResult = sacDbCarBrandService.carBrandQuery(paramPage);
		Map<String, String> map = new HashMap<>();
		if("1".equals(listResult.getResult())) {
			List<Map<String, Object>> rows = listResult.getRows();
			for(Map<String, Object> info: rows) {
				map.put((String)info.get("carBrandCode"), (String)info.get("carBrandCn"));
			}
		}
		return map;
	}

	@Autowired ICscSysOrgService orgService;
	public Map<String, String> getDlrCodeNameMap() {
		Map<String, Object> param = new HashMap<>();
		param.put("isEnable", "1");
		ParamPage<Map<String, Object>> paramPage = new ParamPage<>();
		paramPage.setPageIndex(1);
		paramPage.setPageSize(Integer.MAX_VALUE);
		paramPage.setParam(param);

		ListResult<Map<String, Object>> listResult = orgService.getDlrInfoNoToken(paramPage);
		Map<String, String> map = new HashMap<>();
		if("1".equals(listResult.getResult())) {
			List<Map<String, Object>> rows = listResult.getRows();
			for(Map<String, Object> info: rows) {
				map.put((String)info.get("dlrCode"), (String)info.get("dlrShortName"));
			}
		}
		return map;
	}


	public Map<String, String> getIntenLevelCodeNameMap() {
		// 意向级别
		return getLookupCodeNameMap("BUCN_CLUE_LEVEL");
	}



	@Autowired ICscSysBaseDataService baseDataService;
	public Map<String, String> getLookupCodeNameMap(String lookupTypeCode) {
		String token = " ";
		ListResult<Map<String, Object>> listResult = baseDataService.mdslookupvaluefindbypage(lookupTypeCode, token);
		if("1".equals(listResult.getResult())) {
			List<Map<String, Object>> rows = listResult.getRows();
			Map<String, String> lookupValueMap = new HashMap<>();
			for(Map<String, Object> map: rows) {
				lookupValueMap.put((String)map.get("lookupValueCode"), (String)map.get("lookupValueName"));
			}
			return lookupValueMap;
		} else {
			throw new BusicenException("获取值列表出错：" + listResult.getMsg());
		}

	}
}
