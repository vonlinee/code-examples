package com.ly.mp.csc.clue.idal.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ly.mp.csc.clue.entities.SacClueInfoDlrTemporary;

/**
 * <p>
 * 店端线索表临时表 Mapper 接口
 * </p>
 *
 * @author ly-busicen
 * @since 2021-08-20
 */
public interface SacClueInfoDlrTemporaryMapper extends BaseMapper<SacClueInfoDlrTemporary> {

	/**
	 * 分页查询
	 * @param page
	 * @param param
	 * @return
	 */
	List<Map<String, Object>> selectByPage(Page<Map<String, Object>> page, @Param("param")Map<String, Object> param);

	/**
	 * 插入
	 * @param mapParm
	 * @return
	 */
	public int sacClueInfoDlrTemporaryInsert(@Param("param")Map<String, Object> mapParm);

	/**
	 * 更新
	 * @param mapParm
	 * @return
	 */
	public int sacClueInfoDlrTemporaryUpdate(@Param("param")Map<String, Object> mapParm);
}
