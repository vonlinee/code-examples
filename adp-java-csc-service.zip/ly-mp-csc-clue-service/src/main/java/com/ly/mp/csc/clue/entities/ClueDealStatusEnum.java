package com.ly.mp.csc.clue.entities;


/**
 * 商机导入状态
 * @author ly-zhengzc
 *
 */
public enum ClueDealStatusEnum {
	WAITING("0", "待处理"),	DEALING("1", "处理中"),	FAIL("2", "处理失败"),	SUCCESS("3", "处理成功");
	private ClueDealStatusEnum(String code, String desc) {
		this.code = code;
		this.desc = desc;
	}
	private String code;
	private String desc;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
}
