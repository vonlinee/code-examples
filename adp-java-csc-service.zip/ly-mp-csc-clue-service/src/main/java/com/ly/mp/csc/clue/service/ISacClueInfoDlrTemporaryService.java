package com.ly.mp.csc.clue.service;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.entities.SacClueInfoDlrTemporary;

/**
 * <p>
 * 店端线索表临时表 服务类
 * </p>
 *
 * @author ly-busicen
 * @since 2021-08-20
 */
public interface ISacClueInfoDlrTemporaryService extends IService<SacClueInfoDlrTemporary> {
	/**
	 * 分页查询
	 * @param paramPage
	 * @return
	 */
	public ListResult<Map<String, Object>> findByPage(ParamPage<Map<String, Object>> paramPage);

	/**
	 * 从Excel导入数据(店端总店线索表临时表)
	 * @param file
	 * @param token
	 * @return
	 */
	public ListResult<String> importFromExcel(MultipartFile file, String token);

	public void tempClueDlrUpdateBatch(int pageSize) ;
	/**
	 * 从Excel导入数据(店端线索表临时表)
	 * @param temporaryMap
	 * @return
	 */
	public OptResult insertClueDlrFromTemp(Map<String, Object> temporaryMap) ;

	public String checkClueInfoTemporary(Map<String, Object> infoTemporary, List<Map<String, Object>> tranFieldMapList) ;

}
