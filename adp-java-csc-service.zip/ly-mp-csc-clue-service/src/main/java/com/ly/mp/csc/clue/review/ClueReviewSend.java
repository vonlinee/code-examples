package com.ly.mp.csc.clue.review;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ly.bucn.component.interceptor.InterceptorWrapperRegist;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegistor;
import com.ly.bucn.component.interceptor.annotation.Interceptor;
import com.ly.bucn.component.strategy.annotation.Strategy;
import com.ly.mp.busicen.rule.field.IFireFieldRule;
import com.ly.mp.csc.clue.util.SendDlrUtil;

/**
 * 下发专营店
 * @author ly-shenyw
 *
 */
@Strategy(isDefault=false,names="clueReviewSend")
@Service
public class ClueReviewSend extends AbstractClueReview implements InterceptorWrapperRegist{

	@Autowired IFireFieldRule fireFieldRule;
	@Autowired SendDlrUtil sendDlrUtil;

	/**
	 * 前置操作
	 */
	@Override
	public void before(Map<String, Object> reviewMap,String token){
		//校验下发字段
		fireFieldRule.fireRuleExcpt(reviewMap, "csc-clue-review-send-check", "maindata");
	}

	/**
	 * 其他操作
	 */
	@Override
	@Interceptor("csc_clue_review_send")
	public void handle(Map<String, Object> reviewMap,String token){
		//下发时间
		reviewMap.put("sendTime",LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
		//删除回访任务
		deleteReview(reviewMap.get("reviewId").toString());
		//下发专营店，通过后置处理 可插拔，自定义实现
	}

	@SuppressWarnings("unchecked")
	@Override
	public void regist(InterceptorWrapperRegistor registor) {
		//下发专营店 可插拔，自定义实现
		registor.after("csc_clue_review_send_default", (context, model)->{
			sendDlr((Map<String,Object>)context.data().getP()[0],(String)context.data().getP()[1]);
		});
	}


	/**
	 * 下发专营店
	 * @param reviewMap
	 * @param token
	 */
	private void sendDlr(Map<String, Object> reviewParam,String token){
		String billType = (String) reviewParam.get("billType");
		String billCode = (String) reviewParam.get("billCode");
		if("CLUE".equals(billType)) {// 商机
			sendDlrUtil.send(billCode, token);
		}
	}
}
