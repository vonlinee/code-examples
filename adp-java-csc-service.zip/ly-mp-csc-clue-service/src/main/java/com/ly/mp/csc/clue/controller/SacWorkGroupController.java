package com.ly.mp.csc.clue.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.context.BusicenInvoker;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.service.ISacWorkGroupService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * com.ly.mp.csc.clue.controller.SacWorkGroupController
 * 工作组设置控制类
 * @author zhouhao
 * @date 2021/8/16 15:18
 */
@Api(value = "工作组服务", tags = { "工作组服务" })
@RestController
@RequestMapping(value = "/ly/sac/workgroup", produces = { MediaType.APPLICATION_JSON_VALUE })
public class SacWorkGroupController {
	//注入服务
	@Autowired
	ISacWorkGroupService sacWorkGroupService;
	
	@ApiOperation(value="工作组查询", notes="工作组查询")
	@RequestMapping(value = "/querylist.do", method = RequestMethod.POST)
	public ListResult<Map<String,Object>> queryListWorkGroupInfo(
			@RequestHeader(name = "authorization",required = false) String token,
			@RequestBody(required = false)ParamPage<Map<String,Object>> dataInfo){
		return BusicenInvoker.doList(()->sacWorkGroupService.queryListWorkGroupInfo(dataInfo,token)).result();
	}

	@ApiOperation(value="工作组人员信息查询", notes="工作组人员信息查询")
	@RequestMapping(value = "/querylistgroupuser.do", method = RequestMethod.POST)
	public ListResult<Map<String,Object>> queryListWorkGroupUserInfo(
			@RequestHeader(name = "authorization",required = false) String token,
			@RequestBody(required = false)ParamPage<Map<String,Object>> dataInfo){
		return BusicenInvoker.doList(()->sacWorkGroupService.queryListWorkGroupUserInfo(dataInfo,token)).result();
	}
		
	@ApiOperation(value="工作组保存", notes="工作组保存")
	@RequestMapping(value = "/save.do", method = RequestMethod.POST)
	public OptResult saveReviewPlanInfo(
			@RequestHeader(name = "authorization",required = false) String token,
			@RequestBody(required = true) ParamBase<Map<String, Object>> dataInfo){
		dataInfo.getParam().put("article","csc-clue-group-check-0001");
		return BusicenInvoker.doOpt(()->sacWorkGroupService.saveWorkGroupInfo(dataInfo.getParam(), token)).result();
	}

	@ApiOperation(value="工作组人员删除", notes="工作组人员删除")
	@RequestMapping(value = "/deluser.do", method = RequestMethod.POST)
	public OptResult deleteWorkGroupUserInfo(
			@RequestHeader(name = "authorization",required = false) String token,
			@RequestBody(required = true) ParamBase<Map<String, Object>> dataInfo){
		dataInfo.getParam().put("article","csc-clue-group-check-0003");
		return BusicenInvoker.doOpt(()->sacWorkGroupService.deleteWorkGroupUserInfo(dataInfo.getParam())).result();
	}

	@ApiOperation(value="工作组组长设置", notes="工作组组长设置")
	@RequestMapping(value = "/addleader.do", method = RequestMethod.POST)
	public OptResult saveLeader(
			@RequestHeader(name = "authorization",required = false) String token,
			@RequestBody(required = true) ParamBase<Map<String, Object>> dataInfo){
		dataInfo.getParam().put("article","csc-clue-group-check-0002");
		return BusicenInvoker.doOpt(()->sacWorkGroupService.saveLeader(dataInfo.getParam(),token)).result();
	}
	
	@ApiOperation(value="获取本组员工待回访数列表", notes="获取本组员工待回访数列表")
	@RequestMapping(value = "/selectGroupUserReviewNum.do", method = RequestMethod.POST)
	public ListResult<Map<String,Object>> selectGroupUserReviewNum(
			@RequestHeader(name = "authorization",required = false) String token,
			@RequestBody(required = false)ParamPage<Map<String,Object>> dataInfo){
		return BusicenInvoker.doList(()->sacWorkGroupService.selectGroupUserReviewNum(dataInfo,token)).result();
	}
}
