package com.ly.mp.csc.clue.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegist;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegistor;
import com.ly.bucn.component.interceptor.annotation.Interceptor;
import com.ly.bucn.component.message.Message;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.constant.UserBusiEntity;
import com.ly.mp.busi.base.context.BusicenContext;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.busi.base.handler.ListResultBuilder;
import com.ly.mp.busi.base.handler.OptResultBuilder;
import com.ly.mp.busicen.rule.field.IFireFieldRule;
import com.ly.mp.busicen.rule.field.execution.ValidResultCtn;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.entities.SacChannelInfo;
import com.ly.mp.csc.clue.helper.CacheDataFactory;
import com.ly.mp.csc.clue.idal.mapper.SacChannelInfoMapper;
import com.ly.mp.csc.clue.service.ISacChannelInfoService;
import com.ly.mp.csc.clue.service.ISacSystemConfigValueService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * com.ly.mp.csc.clue.service.impl.SacChannelInfoService
 * 渠道信息服务实现类
 * @author zhouhao
 * @date 2021/8/25 14:28
 * Modification History:
 * Date                Author          Version            Description
 *------------------------------------------------------------------------*
 * 2021/9/8 14:28     linliq           v1.0.0       添加保存前字段校验及修改查询方法
 */
@Service
public class SacChannelInfoService extends ServiceImpl<SacChannelInfoMapper, SacChannelInfo> implements ISacChannelInfoService, InterceptorWrapperRegist {

    @Autowired
    Message message;
    @Autowired
    IFireFieldRule fireFieldRule;
    @Autowired
	CacheDataFactory cacheDataFactory;

    @Override
    public ListResult<Map<String,Object>> queryListChannelInfo(ParamPage<Map<String,Object>> map, String token){
            List<Map<String, Object>> dataList = new ArrayList<>();
            Map<String,Object> mapParam =new HashMap<String, Object>();
        try {
            //查询所有渠道
            List<Map<String, Object>> allListMap = baseMapper.selectByAll(mapParam);
            
            //查询符合条件的渠道
            List<Map<String, Object>> listMap = baseMapper.selectByAll(map.getParam());
            
            //将结果加入进去
            List<Map<String, Object>> resultList = new ArrayList<>();
            
            //递归查询符合条件渠道的父渠道,直到根渠道
            for(Map<String, Object> iMap:listMap) {
            	resultList.add(iMap);
            	getParent(iMap,allListMap,resultList);
            }
            //结果去重
            Set<Map<String, Object>> set = new HashSet<Map<String, Object>>();
            set.addAll(resultList);
            resultList.clear();
            resultList.addAll(set);
            
            //遍历最新的渠道数组,获取到根渠道父渠道
            List<Map<String, Object>> channelRoot = resultList.stream().filter(k -> "-1".equals(k.get("parentChannelCode"))).collect(Collectors.toList());
            //递归循环子节点
            for(Map<String, Object> rootMap : channelRoot){
                rootMap.put("children",getChildren(rootMap, resultList));
                dataList.add(rootMap);
            }
            
            //如果isEnable不为空时，对结果进行筛选
            if(!StringHelper.IsEmptyOrNull(map.getParam().get("isEnable"))) {
            	List<Map<String, Object>> removeList= new ArrayList<Map<String,Object>>();
            	for(Map<String, Object> newMapParam:dataList) {
            		if(!newMapParam.get("isEnable").equals(map.getParam().get("isEnable"))){
            			removeList.add(newMapParam);
            			continue;
            		}
            		newMapParam.replace("children", selectChildren(newMapParam,map.getParam()));
            	}
            	dataList.removeAll(removeList);
            }
           
        }catch (Exception e){
            e.printStackTrace();
            log.error("queryListChannelInfo:",e);
            throw e;
            //throw new BusicenException(message.get("CLUE-SYSTECONFIGVALUE-01"));
        }
        return ListResultBuilder.creatOk().rows(dataList).build();
    }

    @SuppressWarnings("unchecked")
    public List<Map<String,Object>> selectChildren(Map<String,Object> newMapParam,Map<String,Object> map) {
    	if(newMapParam.isEmpty()||StringHelper.IsEmptyOrNull(newMapParam.get("children"))) {
    		return null;
    	}
    	List<Map<String, Object>> chiList= (List<Map<String, Object>>) newMapParam.get("children");
    	if(chiList.size()>0) {
    		List<Map<String, Object>> removeList= new ArrayList<Map<String,Object>>();
			for(Map<String, Object>chilMap:chiList) {
				if(!chilMap.get("isEnable").equals(map.get("isEnable"))) {
					removeList.add(chilMap);
					continue;
				}else {
					if(chilMap.get("isEnable").equals(map.get("isEnable"))) {
						chilMap.replace("children", selectChildren(chilMap,map));
					}
				}
			}
			chiList.removeAll(removeList);
    	}
		return chiList;
	}
    
    public List<Map<String,Object>> getChildren(Map<String,Object> map, List<Map<String,Object>> resultList) {
        List<Map<String,Object>> response = new ArrayList<>();
        List<Map<String,Object>> childrenList = resultList.stream().filter(one -> one.get("parentChannelCode").equals(map.get("channelCode"))).collect(Collectors.toList());
        if(!StringHelper.IsEmptyOrNull(map)){
            if (!StringHelper.IsEmptyOrNull(childrenList)) {
                for(Map<String,Object> data :childrenList){
                    Map<String, Object> children = new HashMap<>(data);
                    children.put("children",getChildren(data, resultList));
                    response.add(children);
                }
            }
        }
        return response;
    }
    
    public List<Map<String,Object>> getParent(Map<String,Object> iMap, List<Map<String,Object>> allListMap,List<Map<String,Object>> resultList) {
    	for(Map<String, Object> map:allListMap) {
    		if(iMap.get("parentChannelCode").equals(map.get("channelCode"))){
    			resultList.add(map);
    			getParent(map,allListMap,resultList);
    		}
    		if(iMap.get("parentChannelCode").equals("-1")) {
    			return resultList;
    		}
    	}
    	return resultList;
    }

    @Override
    @Interceptor("csc_clue_savechannelinfo")
    public OptResult saveChannelInfo(Map<String,Object> map,String token){
    	UserBusiEntity userBusiEntity=BusicenContext.getCurrentUserBusiInfo(token);
        try {
            boolean updateFlag = (boolean)map.get("updateFlag");
            if(!updateFlag){
                BusicenUtils.invokeUserInfo(map, BusicenUtils.SOU.Save,token);
                map.remove("createdName");
                map.remove("modifyName");
                map.put("createdName", userBusiEntity.getUserName());
                map.put("modifyName", userBusiEntity.getUserName());
                if (StringHelper.IsEmptyOrNull(map.get("id"))) {
                    //主键
                    map.put("id",StringHelper.GetGUID());
                }
                if (StringHelper.IsEmptyOrNull(map.get("isEnable"))) {
                    //默认可用
                    map.put("isEnable","1");
                }
                if(baseMapper.insertChannel(map)==0){
                    return OptResultBuilder.createFail().Msg(message.get("CLUE-CHANNELINFO-02")).result("0").build();
                }
            }else{
                BusicenUtils.invokeUserInfo(map, BusicenUtils.SOU.Update,token);
                if(baseMapper.updateById(map)==0){
                    return OptResultBuilder.createFail().Msg(message.get("CLUE-CHANNELINFO-03")).result("0").build();
                }
            }
        }catch (Exception e){
            e.printStackTrace();
            log.error("saveChannelInfo:",e);
            throw e;
           // throw new BusicenException(message.get("CLUE-SYSTECONFIGVALUE-01"));
        }
        return OptResultBuilder.createOk().build();
    }

    @SuppressWarnings("unchecked")
    @Override
    public void regist(InterceptorWrapperRegistor registor) {
        //切点编码要和切点表里面的保持一致
        registor.before("csc_clue_savechannelinfo_valid", (context, model)->{
            checkValidate((Map<String,Object>)context.data().getP()[0]);
        });
        registor.before("csc_clue_savechannelinfo_exists", (context, model)->{
            checkExists((Map<String,Object>)context.data().getP()[0]);
        });
        registor.before("csc_clue_savechannelinfo_repeat", (context, model)->{
            checkRepeat((Map<String,Object>)context.data().getP()[0]);
        });
        registor.before("csc_clue_savechannelinfo_level", (context, model)->{
            checkChannelLevel((Map<String,Object>)context.data().getP()[0]);
        });
        registor.after("csc_clue_savechannelinfo_after", (context, model)->{
            checkAfter((Map<String,Object>)context.data().getP()[0]);
        });
    }

    public void checkAfter(Map<String,Object> mapParam) {

    }

    public void checkValidate(Map<String,Object> mapParam){
        ValidResultCtn fireRule = fireFieldRule.fireRule(mapParam, "csc1001003", "maindata");
        String resMsg = fireRule.getNotValidMessage();
        if (!fireRule.isValid()){
            throw new BusicenException(resMsg);
        }
    }

    public void checkExists(Map<String,Object> mapParam){
        try {
            boolean updateFlag = false;
            if(!StringHelper.IsEmptyOrNull(mapParam.get("id"))){
                int size = baseMapper.countById((String)mapParam.get("id"));
                if (size > 0) {
                    updateFlag = true;
                }else {
                	throw new BusicenException(message.get("CLUE-REVIEWASSIGN-29"));
                }
            }
            mapParam.put("updateFlag",updateFlag);
        }catch(Exception ex)
        {
        	throw ex;
            //throw new BusicenException(message.get("CLUE-WORKGROUP-01"));
        }
    }

    public void checkRepeat(Map<String,Object> mapParam){
    	if("-1".equals(mapParam.get("channelCode"))) {
    		throw new BusicenException("渠道编码不能设为-1");
    	}
        int checkCode = baseMapper.checkChannelCodeRepeat(mapParam);
        if(checkCode>=1){
            throw new BusicenException(message.get("CLUE-REVIEWASSIGN-02"));
        }
        int check = baseMapper.checkChannelInfoRepeat(mapParam);
        if(check>=1){
            throw new BusicenException(message.get("CLUE-REVIEWASSIGN-30"));
        }
    }
    
    public void checkChannelLevel(Map<String,Object> mapParam){
    	String token=mapParam.get("token").toString();

    	
    	String level = cacheDataFactory.querySysConfigValue("CHANNEL_LEVEL_SET", token);
    	//有对渠道等级限制的话就做控制
    	if(!StringHelper.IsEmptyOrNull(level)) {
    		int code1=Integer.valueOf(String.valueOf(mapParam.get("levelCode")));
        	int code2=Integer.valueOf(level);
        	if(code1>code2) {
        		throw new BusicenException(message.get("CLUE-REVIEWASSIGN-12"));
        	}
    	}
    }

	@Override
	public ListResult<Map<String, Object>> queryListChannel(ParamPage<Map<String, Object>> mapParam, String token) {
		ListResult<Map<String, Object>> result=new ListResult<Map<String,Object>>();
		try {
			int pageIndex=Integer.valueOf(mapParam.getPageIndex());
			int pageSize=Integer.valueOf(mapParam.getPageSize());
			Page<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);
			List<Map<String, Object>> list =baseMapper.selectChannelByAll(page, mapParam.getParam());
			page.setRecords(list);
			result= BusicenUtils.page2ListResult(page);
			
		} catch (Exception e) {
			log.error("queryListChannel", e);
			throw e;
		}
		return result;
	}
	
	/**
	 * 渠道信息关系查下，根据渠道名称向上找渠道列表
	 */
	@Override
	public ListResult<Map<String, Object>> queryChannelLinkByName(ParamPage<Map<String, Object>> mapParam, String token) {
		ListResult<Map<String, Object>> result=new ListResult<Map<String,Object>>();
		try {
			int pageIndex=Integer.valueOf(mapParam.getPageIndex());
			int pageSize=Integer.valueOf(mapParam.getPageSize());
			Page<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);
			List<Map<String, Object>> list =baseMapper.queryChannelLinkByName(page, mapParam.getParam());
			page.setRecords(list);
			result= BusicenUtils.page2ListResult(page);
			
		} catch (Exception e) {
			log.error("queryChannelLinkByName", e);
			throw e;
		}
		return result;
	}
}

