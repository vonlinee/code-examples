package com.ly.mp.csc.clue.idal.mapper;

import com.ly.mp.csc.clue.entities.SacTestDriveSheet;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 试乘试驾单表 Mapper 接口
 * </p>
 *
 * @author ly-linliq
 * @since 2021-10-18
 */
public interface SacTestDriveSheetMapper extends BaseMapper<SacTestDriveSheet> {

	/**
	 * 试乘试驾单新增
	 * @param param
	 * @return
	 */
      public int insertSacTestDriveSheet(@Param("param")Map<String,Object>param);
	  
      /**
       * 试乘试驾单修改
       * @param param
       * @return
       */
	  public int updateSacTestDriveSheet(@Param("param")Map<String,Object>param);
	  
	  /**
	   * 试乘试驾单查询
	   * @param param
	   * @return
	   */
	  public List<Map<String, Object>> selectSacTestDriveSheet(@Param("param")Map<String,Object>param,Page<Map<String, Object>> page);
	  
	  /**
	   * 试乘试驾单详情查询
	   * @param param
	   * @return
	   */
	  public List<Map<String, Object>> selectSacTestDriveSheetDetail(@Param("param")Map<String,Object>param);
	  
	  
}
