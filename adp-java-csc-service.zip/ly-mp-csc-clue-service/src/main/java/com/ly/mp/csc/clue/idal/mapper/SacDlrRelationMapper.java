package com.ly.mp.csc.clue.idal.mapper;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.ly.mp.csc.clue.entities.SacDlrRelation;

/**
 * 网点关系映射
 * @author zhouhao
 * @date 2021/8/26 11:42
 */
public interface SacDlrRelationMapper extends BaseMapper<SacDlrRelation> {

	List<Map<String, Object>> selectByAll(IPage<Map<String, Object>> page, @Param("map") Map<String, Object> map);

	int insertSacDlrRelation(@Param("map") Map<String, Object> map);

	int updateByRelationId(@Param("updated")Map<String, Object> updated);

	int checkSacDlrRelation(@Param("param") Map<String, Object> param);

	//	List<Map<String, Object>> machDlrRelation(@Param("param") Map<String, Object> param);
	List<Map<String, Object>> machDlrRelation(@Param("channelCode")String channelCode, @Param("oldDlrCode")String oldDlrCode);

	/**
	 * 校验是否存在
	 *
	 * @param relationId 映射工作组ID
	 * @return int
	 */
	int checkDlrRelationExists(@Param("relationId") String relationId);
}