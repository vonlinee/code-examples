package com.ly.mp.csc.clue.idal.mapper;

import com.ly.mp.csc.clue.entities.OutboundConfig;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 商机外呼配置表 Mapper 接口
 * </p>
 *
 * @author ly-linliq
 * @since 2021-09-06
 */
public interface OutboundConfigMapper extends BaseMapper<OutboundConfig> {

      public int insertOutboundConfig(@Param("param")Map<String,Object>param);
	  
	  public int updateOutboundConfig(@Param("param")Map<String,Object>param);
	  
	  public List<Map<String,Object>> selectOutboundConfig(Page<Map<String, Object>> page,@Param("param") Map<String,Object> map);
	  
	  int checkRepeat(@Param("param") Map<String,Object> param);
	  int checkOutBoundExists(@Param("outboundConfigId") String outboundConfigId);
}
