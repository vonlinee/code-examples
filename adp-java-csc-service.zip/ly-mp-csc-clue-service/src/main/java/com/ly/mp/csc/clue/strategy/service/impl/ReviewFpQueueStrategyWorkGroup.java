package com.ly.mp.csc.clue.strategy.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ly.bucn.component.strategy.annotation.Strategy;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.csc.clue.entities.out.ReviewPersonQueneOut;
import com.ly.mp.csc.clue.service.ISacWorkGroupService;
import com.ly.mp.csc.clue.strategy.service.IReviewFpQueueStrategy;


/**
 * 根据工作组获取回访人员列表 值列表BUCN_PERSON_QUEUE
 * @author ly-shenyw
 *
 */
@Strategy(isDefault=false,names="reviewFpQueueStrategy2")
@Component
public class ReviewFpQueueStrategyWorkGroup implements IReviewFpQueueStrategy{
	
	@Autowired
	ISacWorkGroupService sacWorkGroupService;
	
	@Override
	public List<ReviewPersonQueneOut> queryPersonList(String dlrCode,String queueValueCode,String token){
		List<ReviewPersonQueneOut> returnList = new ArrayList<>();
		
		ParamPage<Map<String,Object>> mapPage = new ParamPage<Map<String,Object>>();
		mapPage.setPageIndex(-1);
		mapPage.setPageSize(-1);
		
		Map<String, Object> mapParam = new HashMap<>();
		mapParam.put("workGroupId", queueValueCode);
		mapPage.setParam(mapParam);
		ListResult<Map<String, Object>> listResult = sacWorkGroupService.queryListWorkGroupUserInfo(mapPage,token);
		if(listResult!=null && listResult.getRows()!=null && listResult.getRows().size()>0){
			for(int i=0;i<listResult.getRows().size();i++){
				ReviewPersonQueneOut info = new ReviewPersonQueneOut();
				info.setReviewPersonUserId(listResult.getRows().get(i).get("userId").toString());
				info.setReviewPersonName(listResult.getRows().get(i).get("empName").toString());
				returnList.add(info);
			}
		}
		return returnList;
	}

}
