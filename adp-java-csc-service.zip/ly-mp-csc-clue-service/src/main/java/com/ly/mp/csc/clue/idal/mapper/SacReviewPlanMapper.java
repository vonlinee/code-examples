package com.ly.mp.csc.clue.idal.mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.ly.mp.csc.clue.entities.SacReviewPlan;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface SacReviewPlanMapper extends BaseMapper<SacReviewPlan> {

    /**
     * com.ly.mp.csc.clue.idal.mapper.SacReviewPlanMapper
     * 回访计划设置查询
     * @param param 输入参数
     * @return java.util.List<com.ly.mp.csc.clue.entities.SacReviewPlan>
     * @author zhouhao
     * @date 2021/8/17 11:36
     */
    List<Map<String, Object>> selectByAll(IPage<Map<String, Object>> page, @Param("param") Map<String,Object> param);

    /**
     * com.ly.mp.csc.clue.idal.mapper.SacReviewPlanMapper
     * 回访计划设置重复校验
     * @param param 参数
     * @return int
     * @author zhouhao
     * @date 2021/8/17 11:39
     */
    int checkReviewPlanInfo(@Param("param") Map<String,Object> param);
    
    
    int checkReviewPlanExists(@Param("planId") String planId);
}