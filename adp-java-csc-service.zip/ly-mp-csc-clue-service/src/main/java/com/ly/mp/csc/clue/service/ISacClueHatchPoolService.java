package com.ly.mp.csc.clue.service;

import java.util.Map;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.entities.SacClueHatchPool;

/**
 * <p>
 * 总部线索孵化池表 服务类
 * </p>
 *
 * @author ly-linliq
 * @since 2021-10-26
 */
public interface ISacClueHatchPoolService extends IService<SacClueHatchPool> {

	/**
	 * 总部线索孵化池线索查询
	 * @param mapParam
	 * @return
	 */
	public ListResult<Map<String, Object>> sacClueHatchPoolQueryList(ParamPage<Map<String, Object>> mapParam);
	
	/**
	 * 总部线索孵化池线索保存
	 * @param mapParam
	 * @return
	 */
	public OptResult scaClueHatchPoolSave(Map<String, Object> mapParam);
	
	/**
	 * 总部线索孵化池线索激活
	 * @param mapParam
	 * @return
	 */
	public OptResult sacClueHatchPoolActivate(Map<String, Object> mapParam);
	
	/**
     * 回访表扩展字段转换
     * @param oldJson 原来保存的json
     * @param 新的要保存的map
     * @return
     */
	public Map<String, Object> transFiled(String oldJson,Map<String, Object> map,String tableName);
    
    public OptResult recycleClueHandle(Map<String, Object> map, String token);
}
