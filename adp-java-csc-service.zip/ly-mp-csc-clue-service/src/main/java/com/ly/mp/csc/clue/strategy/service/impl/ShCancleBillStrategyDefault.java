package com.ly.mp.csc.clue.strategy.service.impl;

import org.springframework.stereotype.Component;

import com.ly.bucn.component.strategy.annotation.Strategy;
import com.ly.mp.csc.clue.strategy.service.IShCancleBillStrategy;

@Strategy(isDefault=true,names="DEFAULT")
@Component
public class ShCancleBillStrategyDefault implements IShCancleBillStrategy{

	//单据校验
	@Override
	public void checkBill(String billCode,String token){
		System.out.println("ShCancleBillStrategyDefault.DEFAULT");
	}
}
