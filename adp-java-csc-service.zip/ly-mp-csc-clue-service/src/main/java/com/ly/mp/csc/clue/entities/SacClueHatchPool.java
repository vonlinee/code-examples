package com.ly.mp.csc.clue.entities;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;

/**
 * <p>
 * 总部线索孵化池表
 * </p>
 *
 * @author ly-linliq
 * @since 2021-10-29
 */
@TableName("t_sac_clue_hatch_pool")
public class SacClueHatchPool implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * ID
     */
    @TableId("HATCH_POOL_ID")
    private String hatchPoolId;

    /**
     * 店端线索ID
     */
    @TableField("CLUE_DLR_ID")
    private String clueDlrId;

    /**
     * 店端线索单号
     */
    @TableField("SERVER_ORDER")
    private String serverOrder;

    /**
     * 客户ID
     */
    @TableField("CUST_ID")
    private String custId;

    /**
     * 客户名称
     */
    @TableField("CUST_NAME")
    private String custName;

    /**
     * 联系号码
     */
    @TableField("PHONE")
    private String phone;

    /**
     * 性别编码
     */
    @TableField("GENDER_CODE")
    private String genderCode;

    /**
     * 性别名称
     */
    @TableField("GENDER_NAME")
    private String genderName;

    /**
     * 扩展字段1
     */
    @TableField("COLUMN1")
    private String column1;

    /**
     * 扩展字段2
     */
    @TableField("COLUMN2")
    private String column2;

    /**
     * 扩展字段3
     */
    @TableField("COLUMN3")
    private String column3;

    /**
     * 扩展字段4
     */
    @TableField("COLUMN4")
    private String column4;

    /**
     * 扩展字段5
     */
    @TableField("COLUMN5")
    private String column5;

    /**
     * 扩展字段6
     */
    @TableField("COLUMN6")
    private String column6;

    /**
     * 扩展字段7
     */
    @TableField("COLUMN7")
    private String column7;

    /**
     * 扩展字段8
     */
    @TableField("COLUMN8")
    private String column8;

    /**
     * 扩展字段9
     */
    @TableField("COLUMN9")
    private String column9;

    /**
     * 扩展字段10
     */
    @TableField("COLUMN10")
    private String column10;

    /**
     * 扩展字段11
     */
    @TableField("COLUMN11")
    private String column11;

    /**
     * 扩展字段12
     */
    @TableField("COLUMN12")
    private String column12;

    /**
     * 扩展字段13
     */
    @TableField("COLUMN13")
    private String column13;

    /**
     * 扩展字段14
     */
    @TableField("COLUMN14")
    private String column14;

    /**
     * 扩展字段15
     */
    @TableField("COLUMN15")
    private String column15;

    /**
     * 扩展字段16
     */
    @TableField("COLUMN16")
    private String column16;

    /**
     * 扩展字段17
     */
    @TableField("COLUMN17")
    private String column17;

    /**
     * 扩展字段18
     */
    @TableField("COLUMN18")
    private String column18;

    /**
     * 扩展字段19
     */
    @TableField("COLUMN19")
    private String column19;

    /**
     * 扩展字段20
     */
    @TableField("COLUMN20")
    private String column20;

    /**
     * 扩展字段21
     */
    @TableField("COLUMN21")
    private String column21;

    /**
     * 扩展字段22
     */
    @TableField("COLUMN22")
    private String column22;

    /**
     * 扩展字段23
     */
    @TableField("COLUMN23")
    private String column23;

    /**
     * 扩展字段24
     */
    @TableField("COLUMN24")
    private String column24;

    /**
     * 扩展字段25
     */
    @TableField("COLUMN25")
    private String column25;

    /**
     * 扩展字段26
     */
    @TableField("COLUMN26")
    private String column26;

    /**
     * 扩展字段27
     */
    @TableField("COLUMN27")
    private String column27;

    /**
     * 扩展字段28
     */
    @TableField("COLUMN28")
    private String column28;

    /**
     * 扩展字段29
     */
    @TableField("COLUMN29")
    private String column29;

    /**
     * 扩展字段30
     */
    @TableField("COLUMN30")
    private String column30;

    /**
     * JSON扩展字段
     */
    @TableField("EXTENDS_JSON")
    private String extendsJson;

    /**
     * 厂商标识ID
     */
    @TableField("OEM_ID")
    private String oemId;

    /**
     * 集团标识ID
     */
    @TableField("GROUP_ID")
    private String groupId;

    /**
     * 创建人ID
     */
    @TableField("CREATOR")
    private String creator;

    /**
     * 创建人
     */
    @TableField("CREATED_NAME")
    private String createdName;

    /**
     * 创建日期
     */
    @TableField("CREATED_DATE")
    private LocalDateTime createdDate;

    /**
     * 修改人ID
     */
    @TableField("MODIFIER")
    private String modifier;

    /**
     * 修改人
     */
    @TableField("MODIFY_NAME")
    private String modifyName;

    /**
     * 最后更新日期
     */
    @TableField("LAST_UPDATED_DATE")
    private LocalDateTime lastUpdatedDate;

    /**
     * 是否可用
     */
    @TableField("IS_ENABLE")
    private String isEnable;

    /**
     * 并发控制ID
     */
    @TableField("UPDATE_CONTROL_ID")
    private String updateControlId;

    public String getHatchPoolId() {
        return hatchPoolId;
    }

    public void setHatchPoolId(String hatchPoolId) {
        this.hatchPoolId = hatchPoolId;
    }
    public String getClueDlrId() {
        return clueDlrId;
    }

    public void setClueDlrId(String clueDlrId) {
        this.clueDlrId = clueDlrId;
    }
    public String getServerOrder() {
        return serverOrder;
    }

    public void setServerOrder(String serverOrder) {
        this.serverOrder = serverOrder;
    }
    public String getCustId() {
        return custId;
    }

    public void setCustId(String custId) {
        this.custId = custId;
    }
    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }
    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
    public String getGenderCode() {
        return genderCode;
    }

    public void setGenderCode(String genderCode) {
        this.genderCode = genderCode;
    }
    public String getGenderName() {
        return genderName;
    }

    public void setGenderName(String genderName) {
        this.genderName = genderName;
    }
    public String getColumn1() {
        return column1;
    }

    public void setColumn1(String column1) {
        this.column1 = column1;
    }
    public String getColumn2() {
        return column2;
    }

    public void setColumn2(String column2) {
        this.column2 = column2;
    }
    public String getColumn3() {
        return column3;
    }

    public void setColumn3(String column3) {
        this.column3 = column3;
    }
    public String getColumn4() {
        return column4;
    }

    public void setColumn4(String column4) {
        this.column4 = column4;
    }
    public String getColumn5() {
        return column5;
    }

    public void setColumn5(String column5) {
        this.column5 = column5;
    }
    public String getColumn6() {
        return column6;
    }

    public void setColumn6(String column6) {
        this.column6 = column6;
    }
    public String getColumn7() {
        return column7;
    }

    public void setColumn7(String column7) {
        this.column7 = column7;
    }
    public String getColumn8() {
        return column8;
    }

    public void setColumn8(String column8) {
        this.column8 = column8;
    }
    public String getColumn9() {
        return column9;
    }

    public void setColumn9(String column9) {
        this.column9 = column9;
    }
    public String getColumn10() {
        return column10;
    }

    public void setColumn10(String column10) {
        this.column10 = column10;
    }
    public String getColumn11() {
        return column11;
    }

    public void setColumn11(String column11) {
        this.column11 = column11;
    }
    public String getColumn12() {
        return column12;
    }

    public void setColumn12(String column12) {
        this.column12 = column12;
    }
    public String getColumn13() {
        return column13;
    }

    public void setColumn13(String column13) {
        this.column13 = column13;
    }
    public String getColumn14() {
        return column14;
    }

    public void setColumn14(String column14) {
        this.column14 = column14;
    }
    public String getColumn15() {
        return column15;
    }

    public void setColumn15(String column15) {
        this.column15 = column15;
    }
    public String getColumn16() {
        return column16;
    }

    public void setColumn16(String column16) {
        this.column16 = column16;
    }
    public String getColumn17() {
        return column17;
    }

    public void setColumn17(String column17) {
        this.column17 = column17;
    }
    public String getColumn18() {
        return column18;
    }

    public void setColumn18(String column18) {
        this.column18 = column18;
    }
    public String getColumn19() {
        return column19;
    }

    public void setColumn19(String column19) {
        this.column19 = column19;
    }
    public String getColumn20() {
        return column20;
    }

    public void setColumn20(String column20) {
        this.column20 = column20;
    }
    public String getColumn21() {
        return column21;
    }

    public void setColumn21(String column21) {
        this.column21 = column21;
    }
    public String getColumn22() {
        return column22;
    }

    public void setColumn22(String column22) {
        this.column22 = column22;
    }
    public String getColumn23() {
        return column23;
    }

    public void setColumn23(String column23) {
        this.column23 = column23;
    }
    public String getColumn24() {
        return column24;
    }

    public void setColumn24(String column24) {
        this.column24 = column24;
    }
    public String getColumn25() {
        return column25;
    }

    public void setColumn25(String column25) {
        this.column25 = column25;
    }
    public String getColumn26() {
        return column26;
    }

    public void setColumn26(String column26) {
        this.column26 = column26;
    }
    public String getColumn27() {
        return column27;
    }

    public void setColumn27(String column27) {
        this.column27 = column27;
    }
    public String getColumn28() {
        return column28;
    }

    public void setColumn28(String column28) {
        this.column28 = column28;
    }
    public String getColumn29() {
        return column29;
    }

    public void setColumn29(String column29) {
        this.column29 = column29;
    }
    public String getColumn30() {
        return column30;
    }

    public void setColumn30(String column30) {
        this.column30 = column30;
    }
    public String getExtendsJson() {
        return extendsJson;
    }

    public void setExtendsJson(String extendsJson) {
        this.extendsJson = extendsJson;
    }
    public String getOemId() {
        return oemId;
    }

    public void setOemId(String oemId) {
        this.oemId = oemId;
    }
    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }
    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }
    public String getCreatedName() {
        return createdName;
    }

    public void setCreatedName(String createdName) {
        this.createdName = createdName;
    }
    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }
    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier;
    }
    public String getModifyName() {
        return modifyName;
    }

    public void setModifyName(String modifyName) {
        this.modifyName = modifyName;
    }
    public LocalDateTime getLastUpdatedDate() {
        return lastUpdatedDate;
    }

    public void setLastUpdatedDate(LocalDateTime lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }
    public String getIsEnable() {
        return isEnable;
    }

    public void setIsEnable(String isEnable) {
        this.isEnable = isEnable;
    }
    public String getUpdateControlId() {
        return updateControlId;
    }

    public void setUpdateControlId(String updateControlId) {
        this.updateControlId = updateControlId;
    }

    @Override
    public String toString() {
        return "SacClueHatchPool{" +
        "hatchPoolId=" + hatchPoolId +
        ", clueDlrId=" + clueDlrId +
        ", serverOrder=" + serverOrder +
        ", custId=" + custId +
        ", custName=" + custName +
        ", phone=" + phone +
        ", genderCode=" + genderCode +
        ", genderName=" + genderName +
        ", column1=" + column1 +
        ", column2=" + column2 +
        ", column3=" + column3 +
        ", column4=" + column4 +
        ", column5=" + column5 +
        ", column6=" + column6 +
        ", column7=" + column7 +
        ", column8=" + column8 +
        ", column9=" + column9 +
        ", column10=" + column10 +
        ", column11=" + column11 +
        ", column12=" + column12 +
        ", column13=" + column13 +
        ", column14=" + column14 +
        ", column15=" + column15 +
        ", column16=" + column16 +
        ", column17=" + column17 +
        ", column18=" + column18 +
        ", column19=" + column19 +
        ", column20=" + column20 +
        ", column21=" + column21 +
        ", column22=" + column22 +
        ", column23=" + column23 +
        ", column24=" + column24 +
        ", column25=" + column25 +
        ", column26=" + column26 +
        ", column27=" + column27 +
        ", column28=" + column28 +
        ", column29=" + column29 +
        ", column30=" + column30 +
        ", extendsJson=" + extendsJson +
        ", oemId=" + oemId +
        ", groupId=" + groupId +
        ", creator=" + creator +
        ", createdName=" + createdName +
        ", createdDate=" + createdDate +
        ", modifier=" + modifier +
        ", modifyName=" + modifyName +
        ", lastUpdatedDate=" + lastUpdatedDate +
        ", isEnable=" + isEnable +
        ", updateControlId=" + updateControlId +
        "}";
    }
}
