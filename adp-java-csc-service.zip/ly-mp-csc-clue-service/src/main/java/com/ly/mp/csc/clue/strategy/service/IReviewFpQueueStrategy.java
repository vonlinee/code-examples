package com.ly.mp.csc.clue.strategy.service;

import java.util.List;

import com.ly.mp.csc.clue.entities.out.ReviewPersonQueneOut;

/**
 * 分配规则的人员队列策略  值列表BUCN_PERSON_QUEUE
 * 实现类的策略命名为：stategy+对应的队列类型编码，例如 stategy1
 * @author ly-shenyw
 *
 */
public interface IReviewFpQueueStrategy {
	
	/**
	 * 获取回访人员列表
	 * @param queueValueCode 队列值编码
	 * @return
	 */
	List<ReviewPersonQueneOut> queryPersonList(String dlrCode,String queueValueCode,String token);
}
