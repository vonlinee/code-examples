package com.ly.mp.csc.clue.controller;

import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.context.BusicenInvoker;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.service.IDlrClueReviewQueryService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * com.ly.mp.csc.clue.controller.SacReviewController 回访服务控制类
 * 
 * @author zhouhao、linliq
 */
@Api(value = "专营店线索回访服务", tags = { "专营店线索回访服务" })
@RestController
@RequestMapping(value = "/ly/sac/review/dlrclue", produces = { MediaType.APPLICATION_JSON_VALUE })
public class SacReviewDlrClueController {

	@Autowired
	IDlrClueReviewQueryService dlrClueReviewQueryService;

	@ApiOperation(value = "本人回访任务查询", notes = "本人回访任务查询")
	@RequestMapping(value = "/querymylist.do", method = RequestMethod.POST)
	public ListResult<Map<String, Object>> queryListMeReviewInfo(
			@RequestHeader(name = "authorization", required = false) String token,
			@RequestBody(required = false) ParamPage<Map<String, Object>> dataInfo) {
		return BusicenInvoker.doList(() -> dlrClueReviewQueryService.queryListMeReviewInfo(dataInfo, token)).result();
	}

	@ApiOperation(value = "本人回访任务导出", notes = "本人回访任务导出")
	@RequestMapping(value = "/exportmylist.do", method = RequestMethod.POST)
	public OptResult exportListMeReviewInfo(@RequestHeader(name = "authorization", required = false) String token,
			@RequestBody(required = false) ParamBase<Map<String, Object>> dataInfo, HttpServletResponse response) {
		return BusicenInvoker.doOpt(() -> dlrClueReviewQueryService.exportListMeReviewInfo(dataInfo, token, response)).result();
	}

	@ApiOperation(value = "本店回访任务查询", notes = "本店回访任务查询")
	@RequestMapping(value = "/querylistbydlr.do", method = RequestMethod.POST)
	public ListResult<Map<String, Object>> queryListByDlr(
			@RequestHeader(name = "authorization", required = false) String token,
			@RequestBody(required = false) ParamPage<Map<String, Object>> dataInfo) {
		return BusicenInvoker.doList(() -> dlrClueReviewQueryService.queryListByDlr(dataInfo, token)).result();
	}
	
	@ApiOperation(value = "本店回访任务导出", notes = "本店回访任务导出")
	@RequestMapping(value = "/exportdlrlist.do", method = RequestMethod.POST)
	public OptResult exportListDlrReviewInfo(@RequestHeader(name = "authorization", required = false) String token,
			@RequestBody(required = false) ParamBase<Map<String, Object>> dataInfo, HttpServletResponse response) {
		return BusicenInvoker.doOpt(() -> dlrClueReviewQueryService.exportListDlrReviewInfo(dataInfo, token, response)).result();
	}

	@ApiOperation(value = "回访记录查询", notes = "回访记录查询")
	@RequestMapping(value = "/queryreviewrecord.do", method = RequestMethod.POST)
	public ListResult<Map<String, Object>> queryReviewRecord(
			@RequestHeader(name = "authorization", required = false) String token,
			@RequestBody(required = false) ParamPage<Map<String, Object>> dataInfo) {
		return BusicenInvoker.doList(() -> dlrClueReviewQueryService.queryReviewRecord(dataInfo, token)).result();
	}

	@ApiOperation(value = "待审核任务查询", notes = "待审核任务查询")
	@RequestMapping(value = "/auditlist.do", method = RequestMethod.POST)
	public ListResult<Map<String, Object>> queryListAuditReviewInfo(
			@RequestHeader(name = "authorization", required = false) String token,
			@RequestBody(required = false) ParamPage<Map<String, Object>> dataInfo) {
		return BusicenInvoker.doList(() -> dlrClueReviewQueryService.queryListAuditReviewInfo(dataInfo, token)).result();
	}

	@ApiOperation(value = "回访审核记录查询", notes = "回访审核记录查询")
	@RequestMapping(value = "/auditrecordlist.do", method = RequestMethod.POST)
	public ListResult<Map<String, Object>> queryListAuditReviewRecordInfo(
			@RequestHeader(name = "authorization", required = false) String token,
			@RequestBody(required = false) ParamPage<Map<String, Object>> dataInfo) {
		return BusicenInvoker.doList(() -> dlrClueReviewQueryService.queryListAuditReviewRecordInfo(dataInfo, token)).result();
	}
	
	@ApiOperation(value = "本店成员待回访数查询", notes = "本店成员待回访数查询")
	@RequestMapping(value = "/queryuserreviewnum.do", method = RequestMethod.POST)
	public ListResult<Map<String, Object>> queryUserReviewNum(
			@RequestHeader(name = "authorization", required = false) String token,
			@RequestBody(required = false) ParamPage<Map<String, Object>> dataInfo) {
		return BusicenInvoker.doList(() -> dlrClueReviewQueryService.queryUserReviewNum(dataInfo, token)).result();
	}

}
