package com.ly.mp.csc.clue.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.csc.clue.entities.DbCarBrand;
import com.ly.mp.csc.clue.idal.mapper.SacDbCarBrandMapper;
import com.ly.mp.csc.clue.service.ISacDbCarBrandService;

/**
 * <p>
 * 车辆品牌 服务实现类
 * </p>
 *
 * @author ly-linliq
 * @since 2021-09-07
 */
@Service
public class SacDbCarBrandService extends ServiceImpl<SacDbCarBrandMapper, DbCarBrand> implements ISacDbCarBrandService {

	@Autowired
	SacDbCarBrandMapper sacDbCarBrandMapper;
	
	@Override
	public ListResult<Map<String, Object>> carBrandQuery(ParamPage<Map<String, Object>> mapParam) {
		ListResult<Map<String, Object>> result=new ListResult<Map<String,Object>>();
		try {
			int pageIndex=Integer.valueOf(mapParam.getPageIndex());
			int pageSize=Integer.valueOf(mapParam.getPageSize());
			Page<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);
			List<Map<String, Object>> list =sacDbCarBrandMapper.selectDbCarBrand(page, mapParam.getParam());
			page.setRecords(list);
			result= BusicenUtils.page2ListResult(page);
			
		} catch (Exception e) {
			log.error("carBrandQuery", e);
			throw e;
		}
		return result;
	}

}
