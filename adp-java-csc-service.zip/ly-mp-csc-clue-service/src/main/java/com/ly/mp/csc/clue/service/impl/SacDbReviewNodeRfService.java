package com.ly.mp.csc.clue.service.impl;

import com.ly.mp.csc.clue.entities.SacDbReviewNodeRf;
import com.ly.mp.csc.clue.helper.CacheDataFactory;
import com.ly.mp.csc.clue.idal.mapper.SacDbReviewNodeRfMapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ly.mp.csc.clue.service.ISacDbReviewNodeRfService;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.constant.UserBusiEntity;
import com.ly.mp.busi.base.context.BusicenContext;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.busi.base.handler.BusicenUtils.SOU;
import com.ly.mp.busi.base.handler.ResultHandler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.UUID;


/**
 * <p>
 * 回访业务节点关系表 服务实现类
 * </p>
 *
 * @author ly-busicen
 * @since 2021-09-10
 */
@Service
public class SacDbReviewNodeRfService extends ServiceImpl<SacDbReviewNodeRfMapper, SacDbReviewNodeRf> implements ISacDbReviewNodeRfService {

private Logger log = LoggerFactory.getLogger(SacDbReviewNodeRfService.class);
	
	@Autowired
	SacDbReviewNodeRfMapper sacDbReviewNodeRfMapper;
	@Autowired
	CacheDataFactory cacheDataFactory;

	/**
     * 回访节点查询
     * @param map 入参查询条件 
	 * @param token token
     * @return com.ly.mp.component.entities.ListResult<com.ly.mp.csc.clue.entities.out.ReviewAssignSetOut>
     * @author zhouhao
     * @date 2021/8/16 15:06
     */
    @Override
    public ListResult<Map<String,Object>> queryReviewNodeRfList(ParamPage<Map<String,Object>>map, String token){
        ListResult<Map<String,Object>> result = new ListResult<Map<String,Object>>();
        try {
            int pageIndex=map.getPageIndex();
            int pageSize=map.getPageSize();
            
            String overTimeSwitch = cacheDataFactory.querySysConfigValue("AUDIT_SWITCH", token);
            if(!StringHelper.IsEmptyOrNull(overTimeSwitch)){
            	map.getParam().put("overTimeSwitch", overTimeSwitch);
            }else{
            	map.getParam().put("overTimeSwitch", "1");
            }
            Page<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);
            List<Map<String, Object>> list = baseMapper.queryReviewNodeRfList(page, map.getParam());
            page.setRecords(list);
            result = BusicenUtils.page2ListResult(page);
        }catch (Exception e){
            e.printStackTrace();
            log.error("queryReviewNodeRfList:",e);
        }
        return result;
    }
    
	/**
	 * 根据主键判断插入或更新
	 * @param info
	 * @return
	 */
	@Override
	@Transactional
	public EntityResult<Map<String, Object>> sacDbReviewNodeRfSave(Map<String, Object> mapParam, String token){
		try {
			Boolean updateFlag = false;
		    if (!StringHelper.IsEmptyOrNull(mapParam.get("rfId"))) {
			    QueryWrapper<SacDbReviewNodeRf> wrapper = new QueryWrapper<>();
			    wrapper.lambda().eq(SacDbReviewNodeRf::getRfId, mapParam.get("rfId"));
		    	if (list(wrapper).size() > 0) {
		    		updateFlag = true;
				}
			}
			if(!updateFlag){
				//新增
				if (StringHelper.IsEmptyOrNull(mapParam.get("rfId"))) {
					//主键
					mapParam.put("rfId",UUID.randomUUID().toString());
				}
				BusicenUtils.invokeUserInfo(mapParam, SOU.Save,token);
				sacDbReviewNodeRfMapper.insertSacDbReviewNodeRf(mapParam);
			}else{
				//更新
				BusicenUtils.invokeUserInfo(mapParam, SOU.Update,"");
				sacDbReviewNodeRfMapper.updateSacDbReviewNodeRf(mapParam);
			}
			return ResultHandler.updateOk(mapParam);
		} catch (Exception e) {
			log.error("sacDbReviewNodeRfSave", e);
			throw e;
		} 
	}
	
}
