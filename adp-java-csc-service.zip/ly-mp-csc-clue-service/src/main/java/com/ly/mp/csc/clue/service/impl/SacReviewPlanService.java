package com.ly.mp.csc.clue.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegist;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegistor;
import com.ly.bucn.component.interceptor.annotation.Interceptor;
import com.ly.bucn.component.message.Message;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.constant.UserBusiEntity;
import com.ly.mp.busi.base.context.BusicenContext;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.busi.base.handler.OptResultBuilder;
import com.ly.mp.busicen.rule.field.IFireFieldRule;
import com.ly.mp.busicen.rule.field.execution.ValidResultCtn;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.entities.SacReviewPlan;
import com.ly.mp.csc.clue.helper.BusicenDbBaseUtils;
import com.ly.mp.csc.clue.idal.mapper.SacReviewPlanMapper;
import com.ly.mp.csc.clue.service.ISacReviewPlanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * com.ly.mp.csc.clue.service.impl.SacReviewPlanServiceImpl
 * 回访计划实现类
 * @author zhouhao
 * @date 2021/8/17 13:56
 * Date               Author          Version            Description
 *---------------------------------------------------------------------*
 * 2021/9/13 20:28:00     linliq           v1.0.0       解决工作组保存报错问题
 */
@Service
public class SacReviewPlanService extends ServiceImpl<SacReviewPlanMapper, SacReviewPlan> implements ISacReviewPlanService, InterceptorWrapperRegist {

    @Autowired
    Message message;
    @Autowired
    IFireFieldRule fireFieldRule;

    @Override
    public ListResult<Map<String, Object>> queryListReviewPlanInfo(ParamPage<Map<String, Object>> map,String token){
        ListResult<Map<String,Object>> result = new ListResult<Map<String,Object>>();
        //UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
        //回访计划统一由总部设置，不区分专营店
        //map.getParam().put("orgCode", userBusiEntity.getDlrCode());
        try {
            int pageIndex=map.getPageIndex();
            int pageSize=map.getPageSize();
            Page<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);
            List<Map<String, Object>> list = baseMapper.selectByAll(page, map.getParam());
            page.setRecords(list);
            result = BusicenUtils.page2ListResult(page);
        }catch (Exception e){
            e.printStackTrace();
            log.error("queryListReviewPlanInfo:",e);
            throw e;
        }
        return result;
    }

    @Override
    @Interceptor("csc_clue_savereviewplaninfo")
    public OptResult saveReviewPlanInfo(Map<String,Object> map , String token){
        try {
            SacReviewPlan vo = BusicenUtils.map2Object(map,SacReviewPlan.class);
            UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
            vo.setCreatedName(userBusiEntity.getEmpName());
            vo.setModifyName(userBusiEntity.getEmpName());
            vo.setOrgCode(userBusiEntity.getDlrCode());
            vo.setOrgName(userBusiEntity.getDlrName());
            BusicenDbBaseUtils.baseSaveById(vo,baseMapper,null,"",false,token);
            return OptResultBuilder.createOk().build();
        } catch (Exception e) {
            e.printStackTrace();
            log.error("csBuFiledConfigSaveById", e);
            throw e;
        }
    }

    @Override
    public OptResult deleteReviewPlanInfo(Map<String,Object> map , String token){
        try {
        	ValidResultCtn fireRule = fireFieldRule.fireRule(map, "csc-clue-review-check-0008", "maindata");
            String resMsg = fireRule.getNotValidMessage();
            if (!fireRule.isValid()){
                throw new BusicenException(resMsg);
            }
            String planId = map.get("planId").toString();
            baseMapper.deleteById(planId);
            return OptResultBuilder.createOk().build();
        } catch (Exception e) {
            e.printStackTrace();
            log.error("deleteReviewPlanInfo", e);
            throw e;
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    public void regist(InterceptorWrapperRegistor registor) {
        //切点编码要和切点表里面的保持一致
        registor.before("csc_clue_savereviewplaninfo_valid", (context, model)->{
            checkValidate((Map<String,Object>)context.data().getP()[0]);
        });
        registor.before("csc_clue_savereviewplaninfo_exit", (context, model)->{
            checkExits((Map<String,Object>)context.data().getP()[0]);
        });
        registor.before("csc_clue_savereviewplaninfo_repeat", (context, model)->{
            checkRepeat((Map<String,Object>)context.data().getP()[0]);
        });
        registor.after("csc_clue_savereviewplaninfo_msg", (context, model)->{
            checkAfter((Map<String,Object>)context.data().getP()[0]);
        });
    }
    
    public void checkExits(Map<String,Object> mapParam)
    {
    	try {
			if(!StringHelper.IsEmptyOrNull(mapParam.get("planId"))){
				int size = baseMapper.checkReviewPlanExists((String)mapParam.get("planId"));
				if (size == 0) {
					throw new BusicenException(message.get("CLUE-REVIEWASSIGN-29"));
				}
			}
		}catch(Exception ex)
		{
			throw ex;
		}
    }

    public void checkValidate(Map<String,Object> mapParam)
    {
        ValidResultCtn fireRule = fireFieldRule.fireRule(mapParam, "csc-clue-review-check-0003", "maindata");
        String resMsg = fireRule.getNotValidMessage();
        if (!fireRule.isValid()){
            throw new BusicenException(resMsg);
        }
    }

    public void checkRepeat(Map<String,Object> mapParam)
    {
    	if(baseMapper.checkReviewPlanInfo(mapParam)>=1){
            throw new BusicenException(message.get("CLUE-REVIEWASSIGN-16"));
        }
    }

    public void checkAfter(Map<String,Object> mapParam) {

    }

}
