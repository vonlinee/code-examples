package com.ly.mp.csc.clue.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ly.bucn.component.strategy.runtime.ChooseContext;
import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.context.BusicenInvoker;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.entities.out.ReviewPersonQueneOut;
import com.ly.mp.csc.clue.service.IClueReviewService;
import com.ly.mp.csc.clue.service.ISacReviewHisService;
import com.ly.mp.csc.clue.service.ISacReviewService;
import com.ly.mp.csc.clue.strategy.service.IReviewFpQueueStrategy;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * com.ly.mp.csc.clue.controller.SacReviewController 回访服务控制类
 * 
 * @author zhouhao、linliq
 */
@Api(value = "回访服务", tags = { "回访服务" })
@RestController
@RequestMapping(value = "/ly/sac/review", produces = { MediaType.APPLICATION_JSON_VALUE })
public class SacReviewController {

	@Autowired
	ISacReviewService sacReviewService;
	@Autowired
	ISacReviewHisService sacReviewHisService;
	@Autowired
	IClueReviewService clueReviewService;

	@ApiOperation(value = "test", notes = "test")
	@RequestMapping(value = "/test.do", method = RequestMethod.POST)
	public List<ReviewPersonQueneOut> test(@RequestHeader(name = "authorization", required = false) String token,
			@RequestBody(required = false) ParamPage<Map<String, Object>> dataInfo) {
		// 获取回访人员列表
		return ChooseContext.chooseBeanOrDefault("reviewFpQueueStrategy3", IReviewFpQueueStrategy.class)
				.queryPersonList("", "c32524f9-7d13-4934-b635-86d9f40c09c9", token);

	}

	@ApiOperation(value = "生成回访任务", notes = "生成回访任务")
	@RequestMapping(value = "/addtask.do", method = RequestMethod.POST)
	public EntityResult<Map<String, Object>> addtask(
			@RequestHeader(name = "authorization", required = false) String token,
			@RequestBody(required = false) ParamBase<Map<String, Object>> dataInfo) {
		return BusicenInvoker.doEntity(() -> sacReviewService.addTask(dataInfo.getParam(), token)).result();
	}

	@ApiOperation(value = "回访", notes = "回访")
	@RequestMapping(value = "/review.do", method = RequestMethod.POST)
	public EntityResult<Map<String, Object>> review(
			@RequestHeader(name = "authorization", required = false) String token,
			@RequestBody(required = false) ParamBase<Map<String, Object>> dataInfo) {
		return BusicenInvoker.doEntity(() -> clueReviewService.review(dataInfo.getParam(), token)).result();
	}
	
	@ApiOperation(value = "添加回访记录", notes = "添加回访记录")
	@RequestMapping(value = "/addReviewRecord.do", method = RequestMethod.POST)
	public EntityResult<Map<String, Object>> addReviewRecord(
			@RequestHeader(name = "authorization", required = false) String token,
			@RequestBody(required = false) ParamBase<Map<String, Object>> dataInfo) {
		return BusicenInvoker.doEntity(() -> sacReviewHisService.addReviewRecord(dataInfo.getParam(), token)).result();
	}

	@ApiOperation(value = "本人回访任务查询", notes = "本人回访任务查询")
	@RequestMapping(value = "/querymylist.do", method = RequestMethod.POST)
	public ListResult<Map<String, Object>> queryListMeReviewInfo(
			@RequestHeader(name = "authorization", required = false) String token,
			@RequestBody(required = false) ParamPage<Map<String, Object>> dataInfo) {
		return BusicenInvoker.doList(() -> sacReviewService.queryListMeReviewInfo(dataInfo, token)).result();
	}

	@ApiOperation(value = "本人回访任务导出", notes = "本人回访任务导出")
	@RequestMapping(value = "/exportmylist.do", method = RequestMethod.POST)
	public OptResult exportListMeReviewInfo(@RequestHeader(name = "authorization", required = false) String token,
			@RequestBody(required = false) ParamBase<Map<String, Object>> dataInfo, HttpServletResponse response) {
		return BusicenInvoker.doOpt(() -> sacReviewService.exportListMeReviewInfo(dataInfo, token, response)).result();
	}

	@ApiOperation(value = "本组回访任务查询", notes = "本组回访任务查询")
	@RequestMapping(value = "/querymygrouplist.do", method = RequestMethod.POST)
	public ListResult<Map<String, Object>> queryListGroupReviewInfo(
			@RequestHeader(name = "authorization", required = false) String token,
			@RequestBody(required = false) ParamPage<Map<String, Object>> dataInfo) {
		return BusicenInvoker.doList(() -> sacReviewService.queryListGroupReviewInfo(dataInfo, token)).result();
	}
	
	@ApiOperation(value = "回访详情查询", notes = "回访详情查询")
	@RequestMapping(value = "/reviewinfobyid.do", method = RequestMethod.POST)
	public ListResult<Map<String, Object>> queryReviewInfoById(
			@RequestHeader(name = "authorization", required = false) String token,
			@RequestBody(required = false) ParamPage<Map<String, Object>> dataInfo) {
		return BusicenInvoker.doList(() -> sacReviewService.queryReviewInfoById(dataInfo, token)).result();
	}

	@ApiOperation(value = "本组回访任务导出", notes = "本组回访任务导出")
	@RequestMapping(value = "/exportmygrouplist.do", method = RequestMethod.POST)
	public OptResult exportListGroupReviewInfo(@RequestHeader(name = "authorization", required = false) String token,
			@RequestBody(required = false) ParamBase<Map<String, Object>> dataInfo, HttpServletResponse response) {
		return BusicenInvoker.doOpt(() -> sacReviewService.exportListGroupReviewInfo(dataInfo, token, response))
				.result();
	}

	@ApiOperation(value = "待审核任务查询", notes = "待审核任务查询")
	@RequestMapping(value = "/auditlist.do", method = RequestMethod.POST)
	public ListResult<Map<String, Object>> queryListAuditReviewInfo(
			@RequestHeader(name = "authorization", required = false) String token,
			@RequestBody(required = false) ParamPage<Map<String, Object>> dataInfo) {
		return BusicenInvoker.doList(() -> sacReviewService.queryListAuditReviewInfo(dataInfo, token)).result();
	}

	@ApiOperation(value = "回访审核记录查询", notes = "回访审核记录查询")
	@RequestMapping(value = "/auditrecordlist.do", method = RequestMethod.POST)
	public ListResult<Map<String, Object>> queryListAuditReviewRecordInfo(
			@RequestHeader(name = "authorization", required = false) String token,
			@RequestBody(required = false) ParamPage<Map<String, Object>> dataInfo) {
		return BusicenInvoker.doList(() -> sacReviewService.queryListAuditReviewRecordInfo(dataInfo, token)).result();
	}

	@ApiOperation(value = "回访记录查询", notes = "回访记录查询")
	@RequestMapping(value = "/queryreviewrecord.do", method = RequestMethod.POST)
	public ListResult<Map<String, Object>> queryReviewRecord(
			@RequestHeader(name = "authorization", required = false) String token,
			@RequestBody(required = false) ParamPage<Map<String, Object>> dataInfo) {
		return BusicenInvoker.doList(() -> sacReviewService.queryReviewRecord(dataInfo, token)).result();
	}

	@ApiOperation(value = "回访任务分配", notes = "回访任务分配")
	@RequestMapping(value = "/fp.do", method = RequestMethod.POST)
	public OptResult reviewAssign(@RequestHeader(name = "authorization", required = false) String token,
			@RequestBody(required = true) ParamBase<Map<String, Object>> dataInfo) {
		dataInfo.getParam().put("article", "csc-clue-review-check-0007");
		return sacReviewService.reviewAssign(dataInfo.getParam(), token);
	}
	
	@ApiOperation(value = "回访任务分配--自动平均分配", notes = "回访任务分配--自动平均分配")
	@RequestMapping(value = "/autofp.do", method = RequestMethod.POST)
	public OptResult reviewAutoAssign(@RequestHeader(name = "authorization", required = false) String token,
			@RequestBody(required = true) ParamBase<Map<String, Object>> dataInfo) {
		return sacReviewService.reviewAutoAssign(dataInfo.getParam(), token);
	}

	@ApiOperation(value = "回访抢单", notes = "回访抢单")
	@RequestMapping(value = "/qiangdan.do", method = RequestMethod.POST)
	public EntityResult<Map<String, Object>> qiangdan(
			@RequestHeader(name = "authorization", required = false) String token,
			@RequestBody(required = false) ParamBase<Map<String, Object>> dataInfo) {
		return BusicenInvoker.doEntity(() -> sacReviewService.qiangdan(dataInfo.getParam(), token)).result();
	}
	
	@ApiOperation(value = "获取下次回访时间", notes = "获取下次回访时间")
	@RequestMapping(value = "/getnextreviewtime.do", method = RequestMethod.POST)
	public OptResult getNextReviewTime(@RequestHeader(name = "authorization", required = false) String token,
			@RequestBody(required = true) ParamBase<Map<String, Object>> dataInfo) {
		dataInfo.getParam().put("article", "csc-clue-review-check-0013");
		return BusicenInvoker.doOpt(()->sacReviewService.getNextReviewTime(dataInfo.getParam(), token)).result();
	}
	
}
