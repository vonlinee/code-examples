package com.ly.mp.csc.clue.idal.mapper;

import com.ly.mp.csc.clue.entities.DbCarColor;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 车身颜色 Mapper 接口
 * </p>
 *
 * @author ly-linliq
 * @since 2021-09-07
 */
public interface SacDbCarColorMapper extends BaseMapper<DbCarColor> {

      public List<Map<String,Object>> selectDbCarColor(Page<Map<String,Object>> page,@Param("param") Map<String,Object> mapParam);
}
