package com.ly.mp.csc.clue.strategy.service.impl;

import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ly.bucn.component.strategy.runtime.ChooseContext;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.csc.clue.strategy.service.IAddReviewStrategy;

/**
 * 新建回访策略工厂
 * @author ly-shenyw
 *
 */
@Component
public class AddReviewFactroy {

	@Value("${csc.clue.addreview.strategy:addReviewDefault}")
	private String reviewStrategy;
	
	public EntityResult<Map<String, Object>> addTask(Map<String, Object> map, String token){
		return ChooseContext.chooseBeanOrDefault(reviewStrategy, IAddReviewStrategy.class).addTask(map, token);
	}
	
}
