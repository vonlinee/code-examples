package com.ly.mp.csc.clue.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.constant.UserBusiEntity;
import com.ly.mp.busi.base.context.BusicenContext;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.busi.base.context.BusicenInvoker;
import com.ly.mp.busi.base.handler.OptResultBuilder;
import com.ly.mp.busi.base.handler.ResultHandler;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.otherservice.ICscSysOrgService;
import com.ly.mp.csc.clue.service.ISacClueInfoService;
import com.ly.mp.csc.clue.service.ISacClueInfoTemporaryService;
import com.ly.mp.csc.clue.service.ISacDbCarSeriesService;
import com.ly.mp.csc.clue.util.ClueFillInfoUtil;
import com.ly.mp.csc.clue.util.SendDlrUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Api(value = "总部商机", tags = { "总部商机" })
@RestController
@RequestMapping(value = "/ly/sac/clue")
public class SacClueInfoController {

	// private static Logger logger = LoggerFactory.getLogger(SacClueBaseInfoController.class);

	@Autowired ICscSysOrgService orgService;
	@Autowired ISacClueInfoService clueInfoService;
	@Autowired ISacDbCarSeriesService sacDbCarSeriesService;
	@Autowired ISacClueInfoTemporaryService clueInfoTemporaryService;

	@Autowired SendDlrUtil SendDlrUtil;
	@Autowired ClueFillInfoUtil clueFillInfoUtil;

	@ApiOperation(value="线索（总部）保存",notes="线索（总部）保存")
	@RequestMapping(value="/cluesave.do",method=RequestMethod.POST)
	public OptResult cluesave(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) ParamBase<Map<String, Object>> queryCondition) throws Exception{
		queryCondition.getParam().put("token", authentication);
		//		UserBusiEntity user = BusicenContext.getCurrentUserBusiInfo(authentication);
		return BusicenInvoker.doOpt(()->clueInfoService.saveMap(queryCondition, authentication)).result();
	}

	@ApiOperation(value="线索（总部）保存无token",notes="线索（总部）保存无token")
	@RequestMapping(value="/cluesavejob",method=RequestMethod.POST)
	public OptResult cluesavejob(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) ParamBase<Map<String, Object>> queryCondition) throws Exception{
		queryCondition.getParam().put("token", authentication);
		//		UserBusiEntity user = BusicenContext.getCurrentUserBusiInfo(authentication);
		return BusicenInvoker.doOpt(()->clueInfoService.saveMap(queryCondition, authentication)).result();
	}


	// TODO delete
	@ApiOperation(value="test",notes="test")
	@RequestMapping(value="/test.do",method=RequestMethod.POST)
	Object test(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) ParamPage<Map<String, Object>> queryCondition) throws Exception{
		return SendDlrUtil.getDlrMap((String)queryCondition.getParam().get("serverOrder"));
	}

	@ApiOperation(value="线索（总部）查询",notes="线索（总部）查询）")
	@RequestMapping(value="/cluebypage.do",method=RequestMethod.POST)
	public ListResult<Map<String, Object>> clueByPage(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) ParamPage<Map<String, Object>> queryCondition) throws Exception{
		Assert.notNull(queryCondition.getParam(), "参数param不能为空");
		queryCondition.getParam().put("token", authentication);
		return BusicenInvoker.doList(()->clueInfoService.findByPage(queryCondition)).result();
	}
	@ApiOperation(value="线索（总部）查询（电话号码不重复）",notes="线索（总部）查询（电话号码不重复）")
	@RequestMapping(value="/cluefinddistinctdatabypage.do",method=RequestMethod.POST)
	public ListResult<Map<String, Object>> clueFindDistinctDataByPage(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) ParamPage<Map<String, Object>> queryCondition) throws Exception{
		Assert.notNull(queryCondition.getParam(), "参数param不能为空");
		queryCondition.getParam().put("token", authentication);
		return BusicenInvoker.doList(()->clueInfoService.findDistinctDataByPage(queryCondition)).result();
	}
	@ApiOperation(value="线索（总部）获取详情",notes="线索（总部）获取详情）")
	@RequestMapping(value="/cluebyid.do",method=RequestMethod.POST)
	public EntityResult<Map<String, Object>> clueById(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) ParamBase<Map<String, Object>> queryCondition) throws Exception{
		return BusicenInvoker.doEntity(()->{
			Assert.notNull(queryCondition.getParam(), "参数param不能为空");
			queryCondition.getParam().put("token", authentication);
			String id = (String)queryCondition.getParam().get("id");
			String serverOrder = (String)queryCondition.getParam().get("serverOrder");
			if(StringUtils.isBlank(id) && StringUtils.isBlank(serverOrder)) {
				throw new BusicenException("id和serverOrder不能同时为空！");
			}
			return clueInfoService.findById(id, serverOrder);
		}).result();
	}

	@ApiOperation(value="线索（总部）导出",notes="线索（总部）导出）")
	@RequestMapping(value="/exportclue.do",method=RequestMethod.POST)
	public OptResult exportclue(@RequestHeader(name = "authorization", required = false) String token,
			@RequestBody(required = false) ParamBase<Map<String, Object>> dataInfo, HttpServletResponse response){
		return BusicenInvoker.doOpt(()->clueInfoService.exportclue(dataInfo, token, response)).result();
	}

	@ApiOperation(value = "总部商机导入", notes = "总部商机导入")
	@PostMapping(value = "/importcluefromexcel.do")
	ListResult<String> importClueFromExcel(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = true) MultipartFile uploadfile) {
		return BusicenInvoker.doList(() ->
		{
			ListResult<String> listResult = clueInfoTemporaryService.importFromExcel(uploadfile, authentication);
			return listResult;
		}).result();
	}

	@ApiOperation(value="导入总部商机表更新批量处理和处理状态",notes="导入总部商机表更新批量处理和处理状态")
	@RequestMapping(value="/tempclueupdatebatch",method=RequestMethod.POST)
	public OptResult tempClueUpdateBatch(int pageSize) throws Exception{
		return BusicenInvoker.doOpt(()->{
			clueInfoTemporaryService.tempClueUpdateBatch(pageSize);
			return ResultHandler.updateOk();
		}).result();
	}

	@ApiOperation(value="单条临时表数据导入总部商机表",notes="单条临时表数据导入总部商机表")
	@RequestMapping(value="/insertcluefromtemp",method=RequestMethod.POST)
	public OptResult insertClueFromTemp(@RequestBody(required = false) Map<String, Object> temporaryMap) throws Exception{
		return clueInfoTemporaryService.insertClueFromTemp(temporaryMap);
	}

	@ApiOperation(value="构造用户token信息(通过用户id)",notes="构造用户token信息(通过用户id)")
	@RequestMapping(value="/generateTokenByUserId",method=RequestMethod.POST)
	public EntityResult<UserBusiEntity> generateTokenByUserId(String userId) throws Exception{
		// 0fa92b00-5908-4b2d-a7fe-59d007c33e72	csr11910
		String token = orgService.generateTokenByUserId(userId);
		Assert.hasText(token, "生成token失败！");
		UserBusiEntity user = BusicenContext.getCurrentUserBusiInfo(token);
		return ResultHandler.updateOk(user);
	}

	@ApiOperation(value="总部商机导入查询",notes="总部商机导入查询")
	@RequestMapping(value= {"/cluetemporarybypage.do", "/cluetemporarybypage"},method=RequestMethod.POST)
	public ListResult<Map<String, Object>> clueTemporyByPage(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) ParamPage<Map<String, Object>> queryCondition) throws Exception{
		return BusicenInvoker.doList(()->clueInfoTemporaryService.findByPage(queryCondition)).result();
	}

	//	@ApiOperation(value = "根据id获取记录", notes = "根据id获取记录")
	//	@RequestMapping(value = "/getbyid.do", method = RequestMethod.POST)
	//	Object getById(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication, String id, String modelId)
	//			throws Exception {
	//		return BusicenInvoker.doo(() -> {
	//			return clueBaseInfoService.getById(id);
	//		}).result();
	//	}

	@ApiOperation(value = "根据ids删除记录", notes = "根据ids删除记录")
	@RequestMapping(value = "/deletebyids.do", method = RequestMethod.POST)
	Object deleteByIds(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication, String ids) throws Exception {
		return BusicenInvoker.doOpt(() -> {
			Assert.hasText(ids, "ids为空");
			String[] idArr = StringUtils.split(ids, ",");
			List<String> list = new ArrayList<>();
			for (String id : idArr) {
				if (StringUtils.isNotBlank(id)) {
					list.add(id);
				}
			}
			clueInfoService.removeByIds(list);
			return OptResultBuilder.createOk().build();
		}).result();
	}

	@ApiOperation(value="excel模板导出",notes="excel模板导出")
	@RequestMapping(value="/exceltemplateexport.do",method=RequestMethod.POST)
	public OptResult excelTemplateExport(@RequestHeader(name = "authorization", required = false) String token,
			@RequestBody(required = false) ParamBase<Map<String, String>> dataInfo, HttpServletResponse response){
		Assert.notNull(dataInfo.getParam(), "参数param不能为空");
		String pageCode = dataInfo.getParam().get("pageCode");
		Assert.hasText(pageCode, "参数param.pageCode不能为空");
		return clueInfoService.excelTemplateExport(response, pageCode, token);
	}

	@ApiOperation(value="商机填充信息",notes="商机填充信息")
	@RequestMapping(value="/cluefillinfo",method=RequestMethod.POST)
	public EntityResult<Map<String, Object>> clueFillInfo(@RequestHeader(name = "authorization", required = false) String token,
			@RequestBody(required = false) ParamBase<Map<String, String>> dataInfo, HttpServletResponse response){
		Map<String, Object> resultMap = new HashMap<String, Object>();

		resultMap.put("channelMap", clueFillInfoUtil.getChannelNameMap());

		// 意向级别编码
		resultMap.put("intenLevelMap", clueFillInfoUtil.getIntenLevelCodeNameMap());

		// 意向品牌编码
		resultMap.put("carBrandMap", clueFillInfoUtil.getCarBrandCodeNameMap());

		// 意向车系编码
		resultMap.put("carSeriesMap", clueFillInfoUtil.getCarSeriesCodeNameMap());

		// 意向车型编码
		resultMap.put("carTypeMap", clueFillInfoUtil.getCarTypeCodeNameMap());

		// 外观颜色编码
		resultMap.put("carColorMap", clueFillInfoUtil.getCarColorCodeNameMap());

		// 内饰颜色编码
		resultMap.put("carInColorMap", clueFillInfoUtil.getCarInColorCodeNameMap());


		// TODO 意向经销商编码
		Map<String, String> dlrMap = new HashMap<String, String>();
		// [dlrCode, dlrShortName]
		dlrMap.put("H2901", "广州风日");
		dlrMap.put("H2903", "广州华溢石槎");
		resultMap.put("dlrMap", clueFillInfoUtil.getDlrCodeNameMap());
		return ResultHandler.updateOk(resultMap);
	}

}
