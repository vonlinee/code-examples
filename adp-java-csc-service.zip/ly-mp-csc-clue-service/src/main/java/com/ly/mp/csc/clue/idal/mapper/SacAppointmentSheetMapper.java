package com.ly.mp.csc.clue.idal.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ly.mp.csc.clue.entities.SacAppointmentSheet;

/**
 * <p>
 * 试乘试驾预约单表 Mapper 接口
 * </p>
 *
 * @author ly-linliq
 * @since 2021-10-15
 */
public interface SacAppointmentSheetMapper extends BaseMapper<SacAppointmentSheet> {

	/**
	 * 试乘试驾预约单新增
	 * @param param
	 * @return
	 */
      public int insertSacAppointmentSheet(@Param("param")Map<String,Object>param);
	  
      /**
       * 试乘试驾预约单更新
       * @param param
       * @return
       */
	  public int updateSacAppointmentSheet(@Param("param")Map<String,Object>param);
	  
	  /**
	   * 查重
	   * @param param
	   * @return
	   */
	  public int checkRepeat(@Param("param")Map<String,Object>param);
	  /**
	   * 超长出库查询
	   * @param param
	   * @return
	   */
	  public int checkLongRepeat(@Param("param")Map<String,Object>param);
	 

	  /**
	   * 手机号查重
	   * @param param
	   * @return
	   */
	  public int checkPhoneRepeat(@Param("param")Map<String,Object>param);
	  
	  /**
	   * 试乘试驾预约单查询
	   * @param param
	   * @param page
	   * @return
	   */
	  public List<Map<String,Object>>selectSacAppointmentSheet(@Param("param")Map<String,Object>param,Page<Map<String, Object>> page);
	  
	  /**
	   * 试驾车容量查询
	   * @param param
	   * @param page
	   * @return
	   */
	  public List<Map<String,Object>>selectCarCapacity(@Param("param")Map<String,Object>param,Page<Map<String, Object>> page);
	  
	  /**
	   * 查询预约时间段有哪些
	   * @param param
	   * @return
	   */
	  public List<Map<String,Object>>selectCarCapacityTimeRange(@Param("param")Map<String,Object>param);
}
