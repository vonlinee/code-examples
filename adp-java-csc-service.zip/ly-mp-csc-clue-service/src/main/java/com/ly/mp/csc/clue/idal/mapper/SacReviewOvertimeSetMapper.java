package com.ly.mp.csc.clue.idal.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.ly.mp.csc.clue.entities.SacReviewOvertimeSet;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * com.ly.mp.csc.clue.idal.mapper.SacReviewOvertimeSetMapper
 * 回访超时规则设置表
 * @author zhouhao
 * @date 2021/8/18 15:30
 */
public interface SacReviewOvertimeSetMapper extends BaseMapper<SacReviewOvertimeSet> {

    /**
     * com.ly.mp.csc.clue.idal.mapper.SacReviewOvertimeSetMapper
     * 重复校验
     * @param map 输入参数
     * @return int
     * @author zhouhao
     * @date 2021/8/18 15:44
     */
    int checkReviewOvertime(@Param("param") Map<String,Object> map);

    /**
     * com.ly.mp.csc.clue.idal.mapper.SacReviewOvertimeSetMapper
     * 保存回访超时规则设置
     * @param param
     * @return int
     * @author zhouhao
     * @date 2021/8/18 15:56
     */
    int insertReviewOvertimeSet(@Param("param") Map<String,Object> element);

    /**
     * com.ly.mp.csc.clue.idal.mapper.SacReviewOvertimeSetMapper
     * 修改回访超时规则
     * @param param 输入参数
     * @return int
     * @author zhouhao
     * @date 2021/8/18 15:58
     */
    int updateBySetIdAndUpdateControlId(@Param("param")Map<String,Object> updated);

    /**
     * com.ly.mp.csc.clue.idal.mapper.SacReviewOvertimeSetMapper
     * 判断是新增还是修改
     * @param setId
     * @return java.lang.Integer
     * @author zhouhao
     * @date 2021/8/18 16:33
     */
    Integer countBySetId(@Param("setId")String setId);

    /**
     * com.ly.mp.csc.clue.idal.mapper.SacReviewOvertimeSetMapper
     * 回访超时规则查询
     * @param page 分页参数
     * @param map 输入参数
     * @return java.util.List<java.util.Map<java.lang.String,java.lang.Object>>
     * @author zhouhao
     * @date 2021/8/18 16:34
     */
    List<Map<String,Object>> queryListReviewOvertimeInfo(IPage<Map<String, Object>> page, @Param("param") Map<String,Object> map);
    
    /**
     * 获取匹配的超时规则
     * @param page
     * @param map
     * @return
     */
    List<Map<String,Object>> machOverTimeRule(@Param("param") Map<String,Object> map);
    
    /**
     * 计算超时时间
     * @param page
     * @param map
     * @return
     */
    List<Map<String,Object>> queryBillOverTime(@Param("param") Map<String,Object> map);
    
}