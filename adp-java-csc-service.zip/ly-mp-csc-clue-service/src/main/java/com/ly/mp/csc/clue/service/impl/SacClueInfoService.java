package com.ly.mp.csc.clue.service.impl;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegist;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegistor;
import com.ly.bucn.component.interceptor.annotation.Interceptor;
import com.ly.bucn.component.message.Message;
import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.constant.UserBusiEntity;
import com.ly.mp.busi.base.context.BusicenContext;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.busi.base.excel.ExcelData;
import com.ly.mp.busi.base.excel.ExcelDataBuilder;
import com.ly.mp.busi.base.excel.ExcelExportUtil;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.busi.base.handler.BusicenUtils.SOU;
import com.ly.mp.busi.base.handler.MapUtil;
import com.ly.mp.busi.base.handler.OptResultBuilder;
import com.ly.mp.busi.base.handler.ResultHandler;
import com.ly.mp.busicen.rule.field.article.IFieldArticle;
import com.ly.mp.busicen.rule.field.article.IFieldArticleContainer;
import com.ly.mp.busicen.rule.field.article.ext.FieldArticle;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.entities.SacClueInfo;
import com.ly.mp.csc.clue.idal.mapper.SacClueInfoMapper;
import com.ly.mp.csc.clue.otherservice.ICscSysBaseDataService;
import com.ly.mp.csc.clue.otherservice.ICscSysMetaService;
import com.ly.mp.csc.clue.service.IOutboundConfigService;
import com.ly.mp.csc.clue.service.IRemoveRepeatConfigService;
import com.ly.mp.csc.clue.service.ISacClueInfoService;
import com.ly.mp.csc.clue.service.ISacReviewService;
import com.ly.mp.csc.clue.util.CheckSendDlrCodeUtil;
import com.ly.mp.csc.clue.util.ExcelExport;
import com.ly.mp.csc.clue.util.FiledMappingUtil;
import com.ly.mp.csc.clue.util.ReviewUpdateClueUtil;
import com.ly.mp.csc.clue.util.SendDlrUtil;

/**
 * <p>
 * 总部线索表 服务实现类
 * </p>
 *
 * @author ly-busicen
 * @param <V>
 * @since 2021-08-20
 */
@Service
public class SacClueInfoService<V> extends ServiceImpl<SacClueInfoMapper, SacClueInfo>
implements ISacClueInfoService, InterceptorWrapperRegist {

	private Logger logger = LoggerFactory.getLogger(SacClueInfoService.class);

	@Autowired
	Message message;
	@Autowired
	IRemoveRepeatConfigService removeRepeatConfigService;
	@Autowired
	FiledMappingUtil filedMappingUtil;
	@Autowired
	ICscSysMetaService cscSysMetaService;
	@Autowired
	IOutboundConfigService outboundConfigService;
	@Autowired
	ICscSysBaseDataService baseDataService;
	@Autowired
	ISacReviewService sacReviewService;
	@Autowired SendDlrUtil sendDlrUtil;
	@Autowired CheckSendDlrCodeUtil checkSendDlrCodeUtil;

	@Override
	public ListResult<Map<String, Object>> findByPage(ParamPage<Map<String, Object>> paramPage) {
		ListResult<Map<String, Object>> result = new ListResult<Map<String, Object>>();
		try {
			Page<Map<String, Object>> page = new Page<Map<String, Object>>(paramPage.getPageIndex(),
					paramPage.getPageSize());
			Map<String, Object> param = paramPage.getParam();
			List<Map<String, Object>> list = null;
			// 历史表
			if(param != null && "1".equals(param.get("isHis"))) {
				list = this.baseMapper.selectHisByPage(page, param);
			} else {
				list = this.baseMapper.selectByPage(page, param);
			}
			page.setRecords(list);
			result = BusicenUtils.page2ListResult(page);
		} catch (Exception e) {
			logger.error("findByPage", e);
			throw e;
		}
		return result;
	}

	@Override
	public ListResult<Map<String, Object>> findDistinctDataByPage(ParamPage<Map<String, Object>> paramPage) {
		ListResult<Map<String, Object>> result = new ListResult<Map<String, Object>>();
		try {
			Page<Map<String, Object>> page = new Page<Map<String, Object>>(paramPage.getPageIndex(),
					paramPage.getPageSize());
			List<Map<String, Object>> list = this.baseMapper.selectDistinctDataByPage(page, paramPage.getParam());
			page.setRecords(list);
			result = BusicenUtils.page2ListResult(page);
		} catch (Exception e) {
			logger.error("findByPage", e);
			throw e;
		}
		return result;
	}

	@Override
	public EntityResult<Map<String, Object>> findById(String id, String serverOrder) {
		try {
			Map<String, Object> paramMap = new HashMap<>();
			paramMap.put("id", id);
			paramMap.put("serverOrder", serverOrder);
			Map<String, Object> clueMap = this.baseMapper.selectMapById(paramMap);
			if(clueMap == null) {
				// 查询历史表
				clueMap = this.baseMapper.selectHisById(paramMap);
			}
			return ResultHandler.updateOk(clueMap);
		} catch (Exception e) {
			logger.error("findByPage", e);
			throw e;
		}
	}

	private void setOrderCode(Map<String, Object> param, String dlrId, String token) {
		try {
			// 线索单号（总部）生成【线索编码】对应【单据类型】
			String billTypeId = "80006";
			ListResult<Map<String, Object>> generateOrderCode = baseDataService.generateOrderCode(dlrId, billTypeId,
					token);
			// ListResult<Map<String, Object>> generateOrderCode =
			// baseDataService.generateOrderCodeNoToken(dlrId, billTypeId);
			if ("1".equals(generateOrderCode.getResult())) {
				param.put("serverOrder", generateOrderCode.getMsg());
			} else {
				param.put("serverOrder", generateOrderCode());
				// throw new RuntimeException("调用生成【线索编码】出错！[result=" +
				// generateOrderCode.getResult() + ", msg=" + generateOrderCode.getMsg() + "]");
			}
		} catch (Exception e) {
			param.put("serverOrder", generateOrderCode());
		}
	}

	// 自定义生成单号
	private String generateOrderCode() {
		String serverTypeName = "SJ";
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		String newDate = sdf.format(new Date());
		String result = "";
		Random random = new Random();
		for (int i = 0; i < 3; i++) {
			result += random.nextInt(10);
		}
		return serverTypeName + newDate + result;
	}

	@Override
	public OptResult updateMap(Map<String, Object> param, String token) {
		OptResult optResult = new OptResult();
		String id = (String) param.get("id");
		Assert.hasText("主键不能为空", id);
		// 修改记录
		int result = this.baseMapper.updateSacClueInfo(param);
		if (result == 0) {
			optResult.setResult("0");
			optResult.setMsg(message.get("CLUE-BASE-02"));
		} else {
			optResult.setResult("1");
			optResult.setMsg(message.get("CLUE-BASE-01"));
		}
		return optResult;
	}

	@Override
	@Interceptor("csc_clue_base_save")
	@Transactional(rollbackFor = Exception.class)
	public OptResult saveMap(ParamBase<Map<String, Object>> clueParam, String token) {
		UserBusiEntity user = BusicenContext.getCurrentUserBusiInfo(token);
		// System.err.println("getUserID=" + user.getUserID() + ", userName=" +
		// user.getUserName() + ", orgName=" + user.getOrgName());
		Map<String, Object> param = clueParam.getParam();
		// 去掉空字符串
		MapUtil.removeNullValue(param);
		String id = (String) param.get("id");
		OptResult optResult = new OptResult();
		try {
			// 新增记录
			if (StringHelper.IsEmptyOrNull(id)) {
				param.put("updateOrSave", BusicenUtils.Save);
				param.put("id", StringHelper.GetGUID());
				param.put("isEnable", "1");

				// 设置默认值
				if (param.get("statusCode") == null) {
					param.put("statusCode", "1");
					param.put("statusName", "待分配");
				}
				BusicenUtils.invokeUserInfo(param, SOU.Save, token);
				try {
					// 生成线索单号：serverOrder
					setOrderCode(param, user.getDlrID(), token);
				} catch (Exception e) {
					e.printStackTrace();
					param.remove("id");
					optResult.setResult("0");
					throw BusicenException.create(e.getMessage() + ":" + user.getDlrID());
				}
				try {
					this.baseMapper.insertSacClueInfo(param);
					if (param.get("count") != null && Integer.valueOf(param.get("count").toString()) > 0) {
						optResult.setResult("1");
						optResult.setMsg(message.get("CLUE-BASE-05"));
						return optResult;
					}
				} catch (Exception e) {
					e.printStackTrace();
					param.remove("id");
					optResult.setResult("0");
					throw BusicenException.create(e.getMessage());
				}
			} else {
				param.put("updateOrSave", BusicenUtils.Update);
				param.put("lastUpdatedDate", LocalDateTime.now());
				param.put("modifier", user.getUserID());
				param.put("modifyName", user.getEmpName());
				// 修改记录
				int result = this.baseMapper.updateSacClueInfo(param);
				if (result == 0) {
					optResult.setResult("0");
					optResult.setMsg(message.get("CLUE-BASE-02"));
				} else {
					optResult.setResult("1");
					optResult.setMsg(message.get("CLUE-BASE-01"));
				}
				return optResult;
			}
		} catch (Exception e) {
			logger.error("saveMap", e);
			throw e;
		}
		return OptResultBuilder.createOk().build();
	}

	@SuppressWarnings("unchecked")
	@Override
	public void regist(InterceptorWrapperRegistor registor) {
		// 字段校验: 策略编码: bucn.fieldcheck 配置数据:
		// data:p[0].param,article:csc-clue-base-check-0001,type:maindata
		// 商机外呼配置校验
		registor.before("csc_clue_base_save_check_senddlr", (context, model) -> {
			ParamBase<Map<String, Object>> clueParam = (ParamBase<Map<String, Object>>) context.data().getP()[0];
			// UserBusiEntity user = (UserBusiEntity)context.data().getP()[1];
			Map<String, Object> param = clueParam.getParam();
			logger.debug("[statusCode={}]", param.get("statusCode"));
			String isOutBound = checkSendDlrCodeUtil.checkSendDlrCode(param);
			param.put("isOutBound", isOutBound);
			// 不需要外呼
			if("0".equals(isOutBound)) {
				param.put("statusCode", "4");
				param.put("statusName", "已派发");
				param.put("sendTime", Calendar.getInstance().getTime());
			}
		});
		// 查重
		registor.before("csc_clue_base_save_repeat", (context, model) -> {
			checkRepeat((ParamBase<Map<String, Object>>) context.data().getP()[0]);
		});
		// 生成回访任务
		registor.after("csc_clue_base_save_addreviewtask", (context, model) -> {
			ParamBase<Map<String, Object>> clueParam = (ParamBase<Map<String, Object>>) context.data().getP()[0];
			addreviewtask(clueParam);
		});

		// 下发专营店
		registor.after("csc_clue_base_save_basesenddlr", (context, model) -> {
			ParamBase<Map<String, Object>> clueParam = (ParamBase<Map<String, Object>>) context.data().getP()[0];
			Map<String, Object> param = clueParam.getParam();
			if(param == null) {
				return;
			}
			logger.debug("[statusCode={}]", param.get("statusCode"));
			// 不需要外呼
			if("0".equals(param.get("isOutBound"))) {
				String token = (String)param.get("token");
				Assert.hasText(token, "token不能为空");
				sendDlrUtil.send(param, token);
			}
		});
	}


	private void addreviewtask(ParamBase<Map<String, Object>> clueParam) {
		Map<String, Object> param = clueParam.getParam();
		if(param == null) {
			return;
		}
		// 不需要外呼
		if ("0".equals(param.get("isOutBound"))) {
			return ;
		}
		// 重复记录
		if(param.get("count") != null && Integer.valueOf(param.get("count").toString()) > 0) {
			return ;
		}
		// 不是新增记录 id为空表明新增失败
		if(param.get("id") == null || !BusicenUtils.Save.equals(param.get("updateOrSave"))) {
			return ;
		}
		//  生成回访任务
		String token = (String)param.get("token");
		Assert.hasText(token, "token不能为空");
		Map<String, Object> reviewMap = ReviewUpdateClueUtil.getReviewTaskParamFromClue(param, token);
		EntityResult<Map<String, Object>> addTask = sacReviewService.addTask(reviewMap, token);
		Map<String, Object> rows = addTask.getRows();
		if(rows == null || StringUtils.isBlank((String)rows.get("reviewId"))) {
			throw new BusicenException("生成回访任务失败！");
		}

		String id = param.get("id").toString();
		SacClueInfo vo = this.baseMapper.selectById(id);
		if(StringHelper.IsEmptyOrNull(vo.getReviewId())) {
			Map<String, Object> updateMap = new HashMap<>();
			updateMap.put("id", vo.getId());
			updateMap.put("reviewId", rows.get("reviewId"));
			updateMap.put("updateControlId", vo.getUpdateControlId());
			int updateFlag = this.baseMapper.updateSacClueInfo(updateMap);
			Assert.isTrue(updateFlag != 0, "回填回访Id失败");
		}
	}

	@SuppressWarnings("unchecked")
	private void checkRepeat(ParamBase<Map<String, Object>> mapParam) {
		try {
			ParamPage<Map<String, Object>> map = new ParamPage<Map<String, Object>>();
			String customSqlString = "";
			List<Map<String, Object>> noFieldMappingList = new ArrayList<Map<String, Object>>();
			List<String> jsonFieldMappingList = new ArrayList<String>();
			Map<String, Object> param = new HashMap<String, Object>();

			param.put("token", mapParam.getParam().get("token"));
			map.setPageIndex(1);
			map.setPageSize(-1);
			map.setParam(param);
			List<Map<String, Object>> list = removeRepeatConfigService.queryListRemoveRepeatConfig(map).getRows();
			// 初始化count为0
			int count = 0;
			// 当有线索去重规则时才走查重
			if (list.size() > 0) {
				Map<String, Object> configInfo = list.get(0);
				String columInfo = String.valueOf(configInfo.get("custom"));
				Map<String, Object> clueMap = mapParam.getParam();
				clueMap.put("checkPhone", configInfo.get("checkPhone"));
				clueMap.put("checkTime", configInfo.get("checkTime"));
				clueMap.put("checkTimeHorizon", configInfo.get("checkTimeHorizon"));
				// 自定义参数不为空时
				if (!StringHelper.IsEmptyOrNull(columInfo)) {
					// 处理参数
					List<Map<String, Object>> columnList = filedMappingUtil.customHandle(columInfo);
					// 查询字段映射情况
					Map<String, Object> info = new HashMap<String, Object>();
					info.put("sourceTableCode", "t_sac_clue_info");
					info.put("billType", "CLUE");
					info.put("businessType", "-1");
					info.put("columnList", columnList);
					Map<String, Object> fieldMap = filedMappingUtil.queryFieldMappingList(info);
					if (!StringHelper.IsEmptyOrNull(fieldMap.get("fieldMapping"))) {
						// 将有字段映射的参数、运算符、参数值拼接成sql
						customSqlString = filedMappingUtil
								.joinFieldMappingCustom((List<Map<String, Object>>) fieldMap.get("fieldMapping"));
					}
					if (!StringHelper.IsEmptyOrNull(fieldMap.get("field"))) {
						// 将没有字段映射的字段拼接成sql(字段名+运算符+值)
						noFieldMappingList = filedMappingUtil
								.joinNoFieldMappingCustom((List<Map<String, Object>>) fieldMap.get("field"));
					}
					if (!StringHelper.IsEmptyOrNull(fieldMap.get("jsonFieldMapping"))) {
						// 将字段映射类型为2的字段拼接成sql
						jsonFieldMappingList = filedMappingUtil.joinJsonFieldMappingCustom(
								(List<Map<String, Object>>) fieldMap.get("jsonFieldMapping"));
					}
					// 将字段映射类型为2的参数数组放进map中
					if (jsonFieldMappingList.size() > 0) {
						clueMap.put("jsonFieldMappingList", jsonFieldMappingList);
					}
					// 将没有字段映射的参数数组，将其放进map中
					if (noFieldMappingList.size() > 0) {
						clueMap.put("noFieldMappingList", noFieldMappingList);
					}
					// 将有字段映射的sql放进map中
					if (!StringHelper.IsEmptyOrNull(customSqlString)) {
						clueMap.put("customSqlString", customSqlString);
					}
					if (!StringHelper.IsEmptyOrNull(mapParam.getParam().get("id"))) {
						clueMap.put("id", String.valueOf(mapParam.getParam().get("id")));
					}
				}
				// 如果checkPhone为0且自定义参数为空的时候不走查重
				// 查重
				if ("1".equals(clueMap.get("checkPhone"))||!StringHelper.IsEmptyOrNull(columInfo)) {
					count = this.baseMapper.checkRepeat(clueMap);
				}
			}
			if (count > 0) {
				mapParam.getParam().put("count", count);
				mapParam.getParam().put("statusCode", "5");
				mapParam.getParam().put("statusName", "重复留资");
			} else {
				mapParam.getParam().put("count", 0);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			throw ex;
		}
		logger.debug("[statusCode={}]", mapParam.getParam().get("statusCode"));
	}

	/**
	 * 潜客单导出
	 */
	@Override
	@SuppressWarnings("unchecked")
	public OptResult exportclue(ParamBase<Map<String, Object>> dataInfo, String token, HttpServletResponse response) {

		try {
			String title = "潜客单管理";// 导出文件名称
			List<Map<String, Object>> columnList = (List<Map<String, Object>>) dataInfo.getParam().get("columnList");// 页面网格列列表
			if (columnList == null || columnList.size() == 0) {
				throw BusicenException.create(message.get("EXCEL-EXPORT-01"));
			}
			for (Map<String, Object> column : columnList) {
				column.replace("hidden", "true", "false");
			}
			// 先将结果查询出来
			dataInfo.getParam().put("token", token);
			ParamPage<Map<String, Object>> mapParamPage = new ParamPage<Map<String, Object>>();
			mapParamPage.setPageIndex(1);
			mapParamPage.setPageSize(-1);
			mapParamPage.setParam(dataInfo.getParam());
			ListResult<Map<String, Object>> listResult = findByPage(mapParamPage);
			List<Map<String, Object>> rows = listResult.getRows();

			// 导出excel
			ExcelExport export = new ExcelExport();
			export.excelExport(token, title, response, rows, columnList);

		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		return null;
	}


	@Autowired ICscSysMetaService metaService;
	@Autowired IFieldArticleContainer fieldArticleContainer;

	@Override
	public OptResult excelTemplateExport(HttpServletResponse response, String pageCode, String token) {
		HashMap<String, Object> fieldMap = new HashMap<>();
		fieldMap.put("oemCode", "1");
		fieldMap.put("brandCode", "1");
		//		List<IFieldArticle> articles = fieldArticleContainer.getArticles("csc-clue-base-temporary-check-0001maindata", fieldMap);
		List<IFieldArticle> articles = fieldArticleContainer.getArticles(pageCode + "maindata", fieldMap);
		List<String> requiredList = new ArrayList<>();
		for(IFieldArticle f: articles) {
			FieldArticle a = (FieldArticle)f;
			if(StringUtils.contains(a.getValidContent(), "notnull")) {
				requiredList.add(a.getColumn());
			}
		}

		String title = null;
		ListResult<Map<String, Object>> pageViewListResult = metaService.proConfigPageviewQueryByPage(token, pageCode);
		if("1".equals(pageViewListResult.getResult())) {
			List<Map<String, Object>> rows = pageViewListResult.getRows();
			if(rows != null && rows.size() == 1) {
				title = (String)rows.get(0).get("pageName");
				ListResult<Map<String, Object>> listResult = metaService.proConfigMappingQueryByPage(token, pageCode);
				if("1".equals(listResult.getResult())) {
					List<Map<String, Object>> newColumnList = listResult.getRows();
					try {
						// title = "导出文件名称";
						String[][] columns = new String[newColumnList.size()][3];
						for(int i = 0; i < newColumnList.size(); i++) {
							Map<String, Object> m = newColumnList.get(i);
							columns[i][0] = (String)m.get("filedCode");
							columns[i][1] = (String)m.get("mappingFiledCode");
							if(requiredList.contains(columns[i][0])) {
								columns[i][2] = "required";
							} else {
								columns[i][2] = "";
							}
						}
						List<Map<String, Object>> dataList = new ArrayList<Map<String, Object>>();
						ExcelData excelData = ExcelDataBuilder.create().title(title).columns(columns).data(dataList).build();
						ExcelExportUtil.export(excelData, response);
					} catch (Exception e) {
						throw new RuntimeException(e);
					}
				}
			}
		}
		return null;
	}
}
