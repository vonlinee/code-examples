package com.ly.mp.csc.clue.service.impl;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.adp.common.util.BaseSpecialDateUtils;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegist;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegistor;
import com.ly.bucn.component.interceptor.annotation.Interceptor;
import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.constant.UserBusiEntity;
import com.ly.mp.busi.base.context.BusicenContext;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.busi.base.handler.BusicenUtils.SOU;
import com.ly.mp.busi.base.handler.OptResultBuilder;
import com.ly.mp.busi.base.handler.ResultHandler;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.entities.SacTransferAudit;
import com.ly.mp.csc.clue.enums.ReviewAuditStatusEnum;
import com.ly.mp.csc.clue.enums.TransferAuditTypeEnum;
import com.ly.mp.csc.clue.idal.mapper.SacClueInfoDlrMapper;
import com.ly.mp.csc.clue.idal.mapper.SacReviewMapper;
import com.ly.mp.csc.clue.idal.mapper.SacTransferAuditMapper;
import com.ly.mp.csc.clue.otherservice.ICscSysOrgService;
import com.ly.mp.csc.clue.service.ISacClueInfoDlrService;
import com.ly.mp.csc.clue.service.ISacReviewService;
import com.ly.mp.csc.clue.service.ISacTransferAuditService;
import com.ly.mp.csc.clue.service.IXapiHandleService;


@Service
public class SacTransferAuditService<E> extends ServiceImpl<SacTransferAuditMapper, SacTransferAudit>
implements ISacTransferAuditService,InterceptorWrapperRegist {

	private static Logger log = LoggerFactory.getLogger(SacTransferAuditService.class);
	@Autowired SacTransferAuditMapper sacTransferAuditMapper;
	@Autowired SacClueInfoDlrMapper clueInfoDlrMapper;
	@Autowired ISacReviewService sacReviewService;
	@Autowired SacReviewMapper sacReviewMapper;


	@Override
	public EntityResult<Map<String, Object>> sacTransferAuditSave(Map<String, Object> mapParam, String token) {
		try {
			Boolean updateFlag = false;
			if (!StringHelper.IsEmptyOrNull(mapParam.get("auditId"))) {
				QueryWrapper<SacTransferAudit> wrapper = new QueryWrapper<>();
				wrapper.lambda().eq(SacTransferAudit::getAuditId, mapParam.get("auditId"));
				if (list(wrapper).size() > 0) {
					updateFlag = true;
				}
			}
			if (!updateFlag) {
				// 新增
				if (StringHelper.IsEmptyOrNull(mapParam.get("auditId"))) {
					// 主键
					mapParam.put("auditId", UUID.randomUUID().toString());
					mapParam.put("isEnable", "1");
				}
				BusicenUtils.invokeUserInfo(mapParam, SOU.Save, token);
				sacTransferAuditMapper.insertSacTransferAudit(mapParam);
			} else {
				// 更新
				BusicenUtils.invokeUserInfo(mapParam, SOU.Update, token);
				sacTransferAuditMapper.updateSacTransferAudit(mapParam);
			}
			QueryWrapper<SacTransferAudit> wrapper = new QueryWrapper<>();
			wrapper.lambda().eq(SacTransferAudit::getAuditId, mapParam.get("auditId"));
			return ResultHandler.updateOk(listMaps(wrapper).get(0));
		} catch (Exception e) {
			log.error("sacReviewSave", e);
			throw e;
		}
	}

	@Override
	public ListResult<Map<String, Object>> queryList(ParamPage<Map<String, Object>> map,String token){
		ListResult<Map<String,Object>> result = new ListResult<Map<String,Object>>();
		try {
			int pageIndex=map.getPageIndex();
			int pageSize=map.getPageSize();
			IPage<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);
			List<Map<String, Object>> list = baseMapper.selectByPage(page, map.getParam());
			page.setRecords(list);
			result = BusicenUtils.page2ListResult(page);
		}catch (Exception e){
			e.printStackTrace();
			log.error("queryListReviewPlanInfo:",e);
			throw e;
		}
		return result;
	}

	@Override
	public Map<String, Object> queryById(String auditId, String token){
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("auditId", auditId);
		IPage<Map<String, Object>> page = new Page<Map<String, Object>>(1, 1);
		List<Map<String, Object>> list = baseMapper.selectByPage(page, param);
		if(list.isEmpty()) {
			return null;
		}
		return list.get(0);
	}

	@Override
	@Transactional
	@Interceptor("sac_transfer_audit")
	public OptResult transferAudit(Map<String, Object> mapParam, String token) {
		BusicenUtils.invokeUserInfo(mapParam, SOU.Update, token);
		int updateFlg = sacTransferAuditMapper.updateSacTransferAudit(mapParam);
		if(updateFlg == 0) {
			throw BusicenException.create("审核失败");
		}
		return OptResultBuilder.createOk().build();
	}


	@SuppressWarnings("unchecked")
	@Override
	public void regist(InterceptorWrapperRegistor registor) {
		// 划转审核-数据检查和处理
		registor.before("sac_transfer_audit_check_and_deal", (context, model) -> {
			Map<String, Object> mapParam = (Map<String, Object>) context.data().getP()[0];
			String token = (String) context.data().getP()[1];

			String auditId = (String)mapParam.get("auditId");
			if(StringUtils.isBlank(auditId)) {
				throw BusicenException.create("审核ID不能为空！");
			}

			Map<String, Object> auditMap = this.queryById(auditId, token);
			if(auditMap == null) {
				throw BusicenException.create("该审核记录不存在！");
			}
			if(!"0".equals(auditMap.get("shStatus"))) {
				throw BusicenException.create("该记录已经审核过了，不允许重复审核");
			}
			mapParam.put("applyTypeCode", auditMap.get("applyTypeCode"));

			String shStatus = (String)mapParam.get("shStatus");
			if(StringUtils.isBlank(shStatus)) {
				throw BusicenException.create("审核状态编码不能为空！");
			}
			ReviewAuditStatusEnum statusEnum = ReviewAuditStatusEnum.fromString(shStatus);
			if(statusEnum == null) {
				throw BusicenException.create("不存在审核状态编码："  + shStatus);
			}

			mapParam.put("shStatus", statusEnum.getResult());
			mapParam.put("shStatusName", statusEnum.getMsg());
			String shDesc = (String)mapParam.get("shDesc");
			if(ReviewAuditStatusEnum.bh.equals(statusEnum)) { // 驳回
				if(StringUtils.isBlank(shDesc)) {
					throw BusicenException.create("驳回时，审核意见不能为空！");
				}
			}
			UserBusiEntity user = BusicenContext.getCurrentUserBusiInfo(token);
			if(user == null) {
				throw BusicenException.create("通过token获取用户失败！");
			}
			// 审核 相关信息
			mapParam.put("shPersonId", user.getUserID());
			mapParam.put("shPersonName", user.getEmpName());
			mapParam.put("shTime", LocalDateTime.now());
		});

		// 划转审核-调入店审核通过生成调出店审核
		//		registor.after("sac_transfer_audit_f_in_p_out", (context, model) -> {
		//			Map<String, Object> transferApplyMap = (Map<String, Object>) context.data().getP()[0];
		//			String token = (String) context.data().getP()[1];
		//			String shStatus = (String)transferApplyMap.get("shStatus");
		//			String applyTypeCode = (String)transferApplyMap.get("applyTypeCode");
		//
		//			if(ReviewAuditStatusEnum.ok.getResult().equals(shStatus)) { // 审核通过
		//				if(TransferAuditTypeEnum.inDlr.getResult().equals(applyTypeCode)) { // 调入店完成审核
		//					String auditId = (String)transferApplyMap.get("auditId");
		//					Map<String, Object> inAuditMap = this.queryById(auditId, token);
		//					inAuditMap.put("isEnable", "0");
		//					this.sacTransferAuditSave(inAuditMap, token);
		//
		//					// 生成调出店审核记录
		//					Map<String, Object> outAuditMap = new HashMap<>();
		//					outAuditMap.put("applyId", inAuditMap.get("applyId"));
		//					outAuditMap.put("shStatus", ReviewAuditStatusEnum.unAudit.getResult());
		//					outAuditMap.put("shStatusName", ReviewAuditStatusEnum.unAudit.getMsg());
		//					outAuditMap.put("applyTypeCode", TransferAuditTypeEnum.outDlr.getResult());
		//					outAuditMap.put("applyTypeName", TransferAuditTypeEnum.outDlr.getMsg());
		//					this.sacTransferAuditSave(outAuditMap, token);
		//				}
		//			}
		//		});

		// 划转审核-调出店审核通过更新店端线索
		registor.after("sac_transfer_audit_f_out_update_dlr_c", (context, model) -> {
			Map<String, Object> transferApplyMap = (Map<String, Object>) context.data().getP()[0];
			String token = (String) context.data().getP()[1];
			String shStatus = (String)transferApplyMap.get("shStatus");
			String applyTypeCode = (String)transferApplyMap.get("applyTypeCode");

			if(ReviewAuditStatusEnum.ok.getResult().equals(shStatus)) { // 审核通过
				if(TransferAuditTypeEnum.outDlr.getResult().equals(applyTypeCode)) { // 调出店完成审批
					String auditId = (String)transferApplyMap.get("auditId");
					Map<String, Object> auditMap = this.queryById(auditId, token);
					_dealDlrClue(auditMap, token);
				}
			}
		});
		// 划转审核-区域经理审核通过更新店端线索
		registor.after("sac_transfer_audit_f_m_update_dlr_c", (context, model) -> {
			Map<String, Object> transferApplyMap = (Map<String, Object>) context.data().getP()[0];
			String token = (String) context.data().getP()[1];
			String shStatus = (String)transferApplyMap.get("shStatus");
			String applyTypeCode = (String)transferApplyMap.get("applyTypeCode");

			if(ReviewAuditStatusEnum.ok.getResult().equals(shStatus)) { // 审核通过
				if(TransferAuditTypeEnum.areaManager.getResult().equals(applyTypeCode)) { // 区域经理审核
					String auditId = (String)transferApplyMap.get("auditId");
					Map<String, Object> auditMap = this.queryById(auditId, token);
					_dealDlrClue(auditMap, token);
				}
			}
		});
	}
	@Autowired 
	IXapiHandleService xapiHandleService;
	@Autowired ICscSysOrgService orgService;
	/**
	 * TODO 2021年12月24日
	 * 1、线索放入历史表 isEnable 0  备注：划转：划转到xx店
	 * 2、回访单放入历史表，回访内容写：划转到xx店
	 * 3、新建线索、回访单
	 * @param auditMap
	 * @param token
	 */
	private void _dealDlrClue(Map<String, Object> auditMap, String token) {
		String billCode = (String)auditMap.get("billCode");

		Map<String, Object> dlrClueMap = getDlrClueMap(billCode);
		if(dlrClueMap == null || StringHelper.IsEmptyOrNull(dlrClueMap.get("id"))) {
			throw BusicenException.create("不存在店端线索serverOrder=" + billCode);
		}
		dlrClueMap.put("isEnable", "0");
		OptResult updateMap = clueInfoDlrService.updateMap(dlrClueMap, token);
		if(!"1".equals(updateMap.getResult())) {
			throw BusicenException.create("更新店端线索失败！");
		}

		String clueId = (String)dlrClueMap.get("id");
		Map<String, Object> dlrClueXapiHandleMap = new HashMap<>();
		dlrClueXapiHandleMap.put("delSql", "delete from t_sac_clue_info_dlr  WHERE ID='" + clueId + "'");
		dlrClueXapiHandleMap.put("insertSql", "INSERT INTO  `t_sac_clue_info_dlr_his` (select * FROM t_sac_clue_info_dlr WHERE ID='" + clueId + "')");
		int insertDataFlag = xapiHandleService.insertData(dlrClueXapiHandleMap);
		if(insertDataFlag == 0) {
			throw BusicenException.create("插入店端线索历史记录失败！");
		}
		int delDataFlag = xapiHandleService.delData(dlrClueXapiHandleMap);
		if(delDataFlag == 0) {
			throw BusicenException.create("删除店端线索记录失败！");
		}

		String reviewId = (String)dlrClueMap.get("reviewId");
		Map<String, Object> reviewMap = getReviewByReviewId(reviewId);
		if(reviewId != null && reviewMap != null  && !StringHelper.IsEmptyOrNull(reviewMap.get("reviewId"))) {
			reviewMap.put("reviewDesc", "划转到" + auditMap.get("inDlrName") + "店");
			EntityResult<Map<String, Object>> entityResult = sacReviewService.sacReviewUpdate(reviewMap, token);
			if(!"1".equals(entityResult.getResult())) {
				throw BusicenException.create("更新回访信息失败！");
			}

			Map<String, Object> reviewXapiHandleMap = new HashMap<>();
			reviewXapiHandleMap.put("delSql", "delete from t_sac_review  WHERE REVIEW_ID='" + reviewId + "'");
			reviewXapiHandleMap.put("insertSql", "INSERT INTO  `t_sac_review_his` (select * FROM t_sac_review WHERE REVIEW_ID='" + reviewId + "')");
			int insertReviewDataFlag = xapiHandleService.insertData(reviewXapiHandleMap);
			if(insertReviewDataFlag == 0) {
				throw BusicenException.create("插入回访历史记录失败！");
			}
			int delReviewDataFlag = xapiHandleService.delData(reviewXapiHandleMap);
			if(delReviewDataFlag == 0) {
				throw BusicenException.create("删除回访记录失败！");
			}
		}

		String reviewPersonId = (String)auditMap.get("creator");

		dlrClueMap.put("dlrCode", auditMap.get("inDlrCode"));
		dlrClueMap.put("dlrShortName", auditMap.get("inDlrName"));
		dlrClueMap.put("reviewPersonId", reviewPersonId);
		dlrClueMap.put("reviewPersonName", auditMap.get("createdName"));
		// 计划回访时间 在当前时间加1天
		dlrClueMap.put("planReviewTime", LocalDateTime.now().plusDays(+1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
		dlrClueMap.put("isEnable", "1");
		dlrClueMap.remove("id");
		dlrClueMap.remove("reviewId");

		// 使用申请人生成token 然后用该token生成店端线索
		String reviewPersonToken = null;
		try {
			reviewPersonToken = orgService.generateTokenByUserId(reviewPersonId);
		} catch (Exception e) {
			throw BusicenException.create("通过userId(" + reviewPersonId + ")生成token失败");
		}
		if(StringHelper.IsEmptyOrNull(reviewPersonToken)) {
			throw BusicenException.create("token不能为空");
		}
		dlrClueMap.put("token", reviewPersonToken);
		ParamBase<Map<String, Object>> paramBase = new ParamBase<Map<String,Object>>();
		paramBase.setParam(dlrClueMap);
		EntityResult<Map<String, Object>> opt = clueInfoDlrService.saveMap(paramBase, reviewPersonToken);
		if(!"1".equals(opt.getResult())) {
			throw BusicenException.create("新增店端线索失败！");
		}
		// throw BusicenException.create("测试异常！");
	}

	@Autowired ISacClueInfoDlrService clueInfoDlrService;

	private Map<String, Object> getDlrClueMap(String serverOrder) {
		if (StringUtils.isBlank(serverOrder)) {
			return null;
		}
		Page<Map<String, Object>> page = new Page<Map<String, Object>>(1, Integer.MAX_VALUE);
		Map<String, Object> param = new HashMap<>();
		param.put("serverOrder", serverOrder);
		List<Map<String, Object>> list = clueInfoDlrMapper.selectByPage(page, param);
		if (list == null || list.size() ==0) {
			return null;
		}
		list.get(0).put("systemSource", "ADP-TRANSFER");
		list.get(0).put("creatorT", list.get(0).get("creator"));
		list.get(0).put("createdNameT", list.get(0).get("createdName"));
		list.get(0).put("createdDateT", BaseSpecialDateUtils.sysDate(list.get(0).get("createdDate").toString()));
		return list.get(0);
	}

	private Map<String, Object> getReviewByReviewId(String reviewId) {
		if (StringUtils.isBlank(reviewId)) {
			return null;
		}
		Page<Map<String, Object>> page = new Page<Map<String, Object>>(1, Integer.MAX_VALUE);
		Map<String, Object> param = new HashMap<>();
		param.put("reviewId", reviewId);
		List<Map<String, Object>> list = sacReviewMapper.queryReviewInfoById(page, param);
		if (list == null || list.size() ==0) {
			return null;
		}
		return list.get(0);
	}

}
