package com.ly.mp.csc.clue.service;

import com.ly.mp.csc.clue.entities.SacDbInnerConfig;
import com.baomidou.mybatisplus.extension.service.IService;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;

import java.util.Map;

/**
 * <p>
 * 内置配置表 服务类
 * </p>
 *
 * @author ly-busicen
 * @since 2021-10-26
 */
public interface ISacDbInnerConfigService extends IService<SacDbInnerConfig> {

	 /**
     * 配置列表查询
     * @param token token
     * @param map 输入参数
     * @return ListResult
     */
    ListResult<Map<String,Object>> queryConfigList(ParamPage<Map<String,Object>> map, String token);
    
	/**
	 * 根据主键判断插入或更新
	 * @param info
	 * @return
	 */
	EntityResult<Map<String, Object>> sacDbInnerConfigSave(Map<String, Object> mapParam, String token);
	
	/**
	 * 更新
	 * @param info
	 * @return
	 */
	EntityResult<Map<String, Object>> sacDbInnerConfigUpdate(Map<String, Object> mapParam, String token);
	
}
