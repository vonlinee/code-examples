package com.ly.mp.csc.clue.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegist;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegistor;
import com.ly.bucn.component.interceptor.annotation.Interceptor;
import com.ly.bucn.component.message.Message;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.busi.base.handler.BusicenUtils.SOU;
import com.ly.mp.busi.base.handler.OptResultBuilder;
import com.ly.mp.busicen.rule.field.IFireFieldRule;
import com.ly.mp.busicen.rule.field.execution.ValidResultCtn;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.entities.SacClueHatchPool;
import com.ly.mp.csc.clue.entities.SacClueInfoDlr;
import com.ly.mp.csc.clue.entities.in.FieldMappingIn;
import com.ly.mp.csc.clue.helper.CacheDataFactory;
import com.ly.mp.csc.clue.idal.mapper.SacClueHatchPoolHisMapper;
import com.ly.mp.csc.clue.idal.mapper.SacClueHatchPoolMapper;
import com.ly.mp.csc.clue.idal.mapper.SacClueInfoDlrMapper;
import com.ly.mp.csc.clue.service.ISacClueHatchPoolService;
import com.ly.mp.csc.clue.service.ISacFieldMappingConfigService;

/**
 * <p>
 * 总部线索孵化池表 服务实现类
 * </p>
 *
 * @author ly-linliq
 * @since 2021-10-26
 */
@Service
public class SacClueHatchPoolService extends ServiceImpl<SacClueHatchPoolMapper, SacClueHatchPool>
implements ISacClueHatchPoolService, InterceptorWrapperRegist {

	@Autowired
	SacClueHatchPoolMapper sacClueHatchPoolMapper;
	@Autowired
	SacClueInfoDlrMapper sacClueInfoDlrMapper;
	@Autowired
	ISacFieldMappingConfigService sacFieldMappingConfigService;
	@Autowired
	SacClueHatchPoolHisMapper sacClueHatchPoolHisMapper;
	@Autowired
	SacSystemConfigValueService sacSystemConfigValueService;
	@Autowired
	CacheDataFactory cacheDataFactory;
	@Autowired
	IFireFieldRule fireFieldRule;
	@Autowired
	Message message;

	@Override
	public ListResult<Map<String, Object>> sacClueHatchPoolQueryList(ParamPage<Map<String, Object>> mapParam) {
		ListResult<Map<String, Object>> result = new ListResult<Map<String, Object>>();
		try {
			Page<Map<String, Object>> page = new Page<Map<String, Object>>(mapParam.getPageIndex(),
					mapParam.getPageSize());
			List<Map<String, Object>> list = sacClueHatchPoolMapper.selectSacClueHatchPool(mapParam.getParam(), page);
			page.setRecords(list);
			result = BusicenUtils.page2ListResult(page);
		} catch (Exception e) {
			log.error("sacClueHatchPoolQueryList", e);
			throw e;
		}
		return result;
	}

	/**
	 * 线索孵化池线索保存 在保存的时候需要先将参数有映射的字段转换
	 */
	@Override
	@Interceptor("sac_clue_hatch_pool")
	public OptResult scaClueHatchPoolSave(Map<String, Object> mapParam) {
		try {
			String token = mapParam.get("token").toString();
			// 扩展字段转换
			String tableName = "t_sac_clue_hatch_pool";
			mapParam = transFiled(StringHelper.IsEmptyOrNull(mapParam.get("extendsJson")) ? null
					: mapParam.get("extendsJson").toString(), mapParam, tableName);
			if (StringHelper.IsEmptyOrNull(mapParam.get("hatchPoolId"))) {
				mapParam.put("hatchPoolId", StringHelper.GetGUID());
			}
			// 将线索信息存进线索孵化池表中
			BusicenUtils.invokeUserInfo(mapParam, SOU.Save, token);
			int count = sacClueHatchPoolMapper.insertSacClueHatchPool(mapParam);
			if (count == 0) {
				return OptResultBuilder.createFail().build();
			}
		} catch (Exception e) {
			log.error("scaClueHatchPoolSave", e);
			throw e;
		}
		return OptResultBuilder.createOk().build();
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	@Interceptor("sac_clue_hatch_pool_his")
	@SuppressWarnings("unchecked")
	public OptResult sacClueHatchPoolActivate(Map<String, Object> mapParam) {
		try {
			Map<String, Object> newMapParam = (Map<String, Object>) mapParam.get("clueInfo");
			// 先将该数据插入线索孵化池历史表
			String token = mapParam.get("token").toString();
			BusicenUtils.invokeUserInfo(newMapParam, SOU.Save, token);
			if (StringHelper.IsEmptyOrNull(newMapParam.get("hatchPoolHisId"))) {
				newMapParam.put("hatchPoolHisId", StringHelper.GetGUID());
			}
			if (sacClueHatchPoolHisMapper.insertSacClueHatchPoolHis(newMapParam) == 0) {
				return OptResultBuilder.createFail().setMsg(message.get("CLUE-HATCH-POOL-04")).build();
			}
			// 再将该数据从线索孵化池中删掉
			int count = sacClueHatchPoolMapper.deleteById(newMapParam.get("hatchPoolId").toString());
			if (count == 0) {
				return OptResultBuilder.createFail().setMsg(message.get("CLUE-HATCH-POOL-03")).build();
			}
		} catch (Exception e) {
			log.error("sacClueHatchPoolActivate", e);
			throw e;
		}
		return OptResultBuilder.createOk().build();
	}

	@Override
	@SuppressWarnings("unchecked")
	public void regist(InterceptorWrapperRegistor registor) {
		// 校验字段
		registor.before("sac_clue_hatch_pool_valid", (context, model) -> {
			checkPoolValidate((Map<String, Object>) context.data().getP()[0]);
		});
		registor.before("sac_clue_hatch_pool_exits", (context, model) -> {
			checkPoolExits((Map<String, Object>) context.data().getP()[0]);
		});
		registor.before("sac_clue_hatch_pool_his_valid", (context, model) -> {
			checkPoolHisValidate((Map<String, Object>) context.data().getP()[0]);
		});
		registor.before("sac_clue_hatch_pool_his_exits", (context, model) -> {
			checkPoolHisExits((Map<String, Object>) context.data().getP()[0]);
		});

	}

	/**
	 * 线索孵化池线索字段校验
	 *
	 * @param mapParam
	 */
	public void checkPoolValidate(Map<String, Object> mapParam) {
		ValidResultCtn fireRule = fireFieldRule.fireRule(mapParam, "sac-clue-hatch-pool-valid-check", "maindata");
		String resMsg = fireRule.getNotValidMessage();
		if (!fireRule.isValid()) {
			throw new BusicenException(resMsg);
		}
	}

	/**
	 * 查找店端线索id、店端线索单号是否存在
	 *
	 * @param mapParam
	 */
	public void checkPoolExits(Map<String, Object> mapParam) {
		try {
			QueryWrapper<SacClueInfoDlr> queryWrapper = new QueryWrapper<SacClueInfoDlr>();
			queryWrapper.eq("id", mapParam.get("clueDlrId")).eq("SERVER_ORDER", mapParam.get("serverOrder"));
			int count = sacClueInfoDlrMapper.selectCount(queryWrapper);
			if (count < 1) {
				throw new BusicenException(message.get("CLUE-HATCH-POOL-01"));
			}
		} catch (Exception e) {
			throw e;
		}
	}

	/**
	 * 线索孵化池历史线索激活字段校验
	 *
	 * @param mapParam
	 */
	public void checkPoolHisValidate(Map<String, Object> mapParam) {
		ValidResultCtn fireRule = fireFieldRule.fireRule(mapParam, "sac-clue-hatch-pool-his-valid-check", "maindata");
		String resMsg = fireRule.getNotValidMessage();
		if (!fireRule.isValid()) {
			throw new BusicenException(resMsg);
		}
	}

	/**
	 * 查找线索孵化池该线索是否存在
	 *
	 * @param mapParam
	 */
	public void checkPoolHisExits(Map<String, Object> mapParam) {
		//SacClueHatchPool sacClueHatchPool=BusicenUtils.map2Object(mapParam, SacClueHatchPool.class);
		SacClueHatchPool sacClueHatchPool = sacClueHatchPoolMapper.selectById(String.valueOf(mapParam.get("hatchPoolId")));
		if (sacClueHatchPool==null) {
			throw new BusicenException(message.get("CLUE-HATCH-POOL-02"));
		}
		mapParam.put("clueInfo", BusicenUtils.entityToMap(sacClueHatchPool));
	}

	/**
	 * 线索孵化池表扩展字段转换
	 *
	 * @param oldJson   原来保存的json
	 * @param 新的要保存的map
	 * @return
	 */
	@Override
	public Map<String, Object> transFiled(String oldJson, Map<String, Object> map, String tableName) {
		FieldMappingIn info = new FieldMappingIn();
		info.setSourceTableCode(tableName);
		if (!StringHelper.IsEmptyOrNull(map.get("billType"))) {
			info.setBillType(map.get("billType").toString());
		} else {
			info.setBillType("CLUE");
		}
		if (!StringHelper.IsEmptyOrNull(map.get("businessType"))) {
			info.setBusinessType(map.get("businessType").toString());
		} else {
			info.setBusinessType("-1");
		}
		info.setParam(map);
		info.setOldJson(oldJson);
		Map<String, Object> filedMap = sacFieldMappingConfigService.tranFieldToMap(info);
		if (filedMap != null && filedMap.size() > 0) {
			// 合并
			map.putAll(filedMap);
		}
		return map;
	}

	@Override
	public OptResult recycleClueHandle(Map<String, Object> map, String token) {
		// 如果审核通过则先查看系统配置：是否需要回收线索(CLUE_RECYCLE_SWITCH)
		String isRecycle = cacheDataFactory.querySysConfigValue("CLUE_RECYCLE_SWITCH", token);
		// 需要则回收线索到线索孵化池(厂商线索不回收，只回收店端的)
		if (!StringHelper.IsEmptyOrNull(isRecycle) && "1".equals(isRecycle) && "DLRCLUE".equals(map.get("billType"))) {
			// 根据店端线索单号查询线索
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("serverOrder", map.get("billCode"));
			Map<String, Object> dlrClueMap = sacClueInfoDlrMapper.selectMapById(paramMap);
			if(dlrClueMap==null) {
				throw new BusicenException("店端线索不存在");
			}
			// 参数设置
			dlrClueMap.put("clueDlrId", dlrClueMap.get("id"));
			dlrClueMap.put("token", token);
			OptResult result = this.scaClueHatchPoolSave(dlrClueMap);
			if ("0".equals(result.getResult())) {
				throw new BusicenException("店端线索回收失败");
			}
		}
		
		return null;
	}

}
