package com.ly.mp.csc.clue.service;

import java.util.Map;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.entities.SacTestDriveSheet;

/**
 * <p>
 * 试乘试驾单表 服务类
 * </p>
 *
 * @author ly-linliq
 * @since 2021-10-18
 */
public interface ISacTestDriveSheetService extends IService<SacTestDriveSheet> {

	/**
	 * 试乘试驾单查询
	 * @param mapParam
	 * @return
	 */
	public ListResult<Map<String, Object>> sacTestDriveSheetQueryList(ParamPage<Map<String, Object>>mapParam);
	
	public EntityResult<Map<String, Object>> sacTestDriveSheetQueryDetail(Map<String, Object> mapParam);
	
	/**
	 * 试乘试驾单开始/结束
	 * @param mapParam
	 * @return
	 */
	public OptResult sacTestDriveSheetStatus(Map<String, Object> mapParam);
	/**
	 * 试乘试驾单保存
	 * @param mapParam
	 * @return
	 */
	public OptResult sacTestDriveSheetSave(Map<String, Object> mapParam);
	
	/**
	 * 试乘试驾单保存(包含预约单)
	 * @param mapParam
	 * @return
	 */
	public OptResult sacTestDriveSheetAllSave(Map<String, Object> mapParam);
	
	/**
	 * 试乘试驾协议保存
	 * @param mapParam
	 * @return
	 */
	public OptResult sacTestDriveAgreementSave(Map<String, Object> mapParam);
	
}
