package com.ly.mp.csc.clue.mp;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.ly.bucn.component.ms.MsConsumerRegist;
import com.ly.bucn.component.ms.MsConsumerRegistor;
import com.ly.bucn.component.ms.entity.MsRegistProp;
import com.ly.mp.busicen.common.helper.SpringContextHolder;
import com.ly.mp.csc.clue.otherservice.ICscSysOrgService;
import com.ly.mp.csc.clue.service.ISacReviewService;

/**
 * 新建回访-消息队列-消费者
 * @author ly-shenyw
 *
 */
@Component
public class AddReviewMqConsumer implements MsConsumerRegist {

	@Autowired
	ICscSysOrgService orgService;
	
	//消息队列topic
	private final String topic="SacReviewService.addReview";
	
	//注册消费者
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public void regist(MsConsumerRegistor registor){
		registor.regist(topic, (t,m)->{
			Map<String, Object> param = (Map)JSON.parse(m);
			addReview(param);
		}, MsRegistProp.instance());
	}
	
	//调用新建回访方法
	public void addReview(Map<String, Object> map){
		String token = orgService.generateTokenByUserIdWithoutSuffix((String)map.get("userId"));
		
		SpringContextHolder.getBean(ISacReviewService.class).addTask(map, token);
	}
}
