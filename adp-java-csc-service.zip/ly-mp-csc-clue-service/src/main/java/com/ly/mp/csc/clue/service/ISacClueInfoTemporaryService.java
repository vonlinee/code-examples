package com.ly.mp.csc.clue.service;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.entities.SacClueInfoTemporary;

/**
 * <p>
 * 总店线索表临时表 服务类
 * </p>
 *
 * @author ly-busicen
 * @since 2021-08-19
 */
public interface ISacClueInfoTemporaryService extends IService<SacClueInfoTemporary> {

	/**
	 * 分页查询
	 * @param paramPage
	 * @return
	 */
	public ListResult<Map<String, Object>> findByPage(ParamPage<Map<String, Object>> paramPage);

	/**
	 *  单条临时表数据导入业务表
	 * @param temporaryMap
	 * @return
	 */
	public OptResult insertClueFromTemp(Map<String, Object> temporaryMap);
	public void tempClueUpdateBatch(int pageSize) ;
	/**
	 * 根据主键判断插入或更新
	 * @param info
	 * @return
	 */
	EntityResult<Map<String, Object>> sacClueInfoTemporarySave(Map<String, Object> mapParam, String token);

	/**
	 * 从Excel导入数据(总店商机表临时表)
	 * @param file
	 * @param user
	 * @return
	 */
	public ListResult<String> importFromExcel(MultipartFile file, String token) ;

	public String checkClueInfoTemporary(Map<String, Object> infoTemporary, List<Map<String, Object>> tranFieldMapList) ;


}
