package com.ly.mp.csc.clue.entities;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.time.LocalDateTime;

/**
    * 超时规则表
    */
@TableName(value = "t_sac_review_overtime_rule")
public class SacReviewOvertimeRule {
    /**
     * 规则ID
     */
    @TableId(value = "RULE_ID", type = IdType.INPUT)
    private String ruleId;

    /**
     * 规则名称
     */
    @TableField(value = "RULE_NAME")
    private String ruleName;

    /**
     * 规则说明
     */
    @TableField(value = "RULE_DESC")
    private String ruleDesc;

    /**
     * 所属组织
     */
    @TableField("ORG_CODE")
    private String orgCode;

    /**
     * 所属组织名称
     */
    @TableField("ORG_NAME")
    private String orgName;
    
    /**
     * 厂商标识ID
     */
    @TableField(value = "OEM_ID")
    private String oemId;

    /**
     * 集团标识ID
     */
    @TableField(value = "GROUP_ID")
    private String groupId;

    /**
     * 创建人ID
     */
    @TableField(value = "CREATOR")
    private String creator;

    /**
     * 创建人
     */
    @TableField(value = "CREATED_NAME")
    private String createdName;

    /**
     * 创建日期
     */
    @TableField(value = "CREATED_DATE")
    private LocalDateTime createdDate;

    /**
     * 修改人ID
     */
    @TableField(value = "MODIFIER")
    private String modifier;

    /**
     * 修改人
     */
    @TableField(value = "MODIFY_NAME")
    private String modifyName;

    /**
     * 最后更新日期
     */
    @TableField(value = "LAST_UPDATED_DATE")
    private LocalDateTime lastUpdatedDate;

    /**
     * 是否可用
     */
    @TableField(value = "IS_ENABLE")
    private String isEnable;

    /**
     * 并发控制ID
     */
    @TableField(value = "UPDATE_CONTROL_ID")
    private String updateControlId;

    /**
     * 获取规则ID
     *
     * @return RULE_ID - 规则ID
     */
    public String getRuleId() {
        return ruleId;
    }

    /**
     * 设置规则ID
     *
     * @param ruleId 规则ID
     */
    public void setRuleId(String ruleId) {
        this.ruleId = ruleId;
    }

    /**
     * 获取规则名称
     *
     * @return RULE_NAME - 规则名称
     */
    public String getRuleName() {
        return ruleName;
    }

    /**
     * 设置规则名称
     *
     * @param ruleName 规则名称
     */
    public void setRuleName(String ruleName) {
        this.ruleName = ruleName;
    }

    /**
     * 获取规则说明
     *
     * @return RULE_DESC - 规则说明
     */
    public String getRuleDesc() {
        return ruleDesc;
    }

    /**
     * 设置规则说明
     *
     * @param ruleDesc 规则说明
     */
    public void setRuleDesc(String ruleDesc) {
        this.ruleDesc = ruleDesc;
    }

    
    public String getOrgCode() {
		return orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	/**
     * 获取厂商标识ID
     *
     * @return OEM_ID - 厂商标识ID
     */
    public String getOemId() {
        return oemId;
    }

    /**
     * 设置厂商标识ID
     *
     * @param oemId 厂商标识ID
     */
    public void setOemId(String oemId) {
        this.oemId = oemId;
    }

    /**
     * 获取集团标识ID
     *
     * @return GROUP_ID - 集团标识ID
     */
    public String getGroupId() {
        return groupId;
    }

    /**
     * 设置集团标识ID
     *
     * @param groupId 集团标识ID
     */
    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    /**
     * 获取创建人ID
     *
     * @return CREATOR - 创建人ID
     */
    public String getCreator() {
        return creator;
    }

    /**
     * 设置创建人ID
     *
     * @param creator 创建人ID
     */
    public void setCreator(String creator) {
        this.creator = creator;
    }

    /**
     * 获取创建人
     *
     * @return CREATED_NAME - 创建人
     */
    public String getCreatedName() {
        return createdName;
    }

    /**
     * 设置创建人
     *
     * @param createdName 创建人
     */
    public void setCreatedName(String createdName) {
        this.createdName = createdName;
    }

    /**
     * 获取创建日期
     *
     * @return CREATED_DATE - 创建日期
     */
    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    /**
     * 设置创建日期
     *
     * @param createdDate 创建日期
     */
    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * 获取修改人ID
     *
     * @return MODIFIER - 修改人ID
     */
    public String getModifier() {
        return modifier;
    }

    /**
     * 设置修改人ID
     *
     * @param modifier 修改人ID
     */
    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    /**
     * 获取修改人
     *
     * @return MODIFY_NAME - 修改人
     */
    public String getModifyName() {
        return modifyName;
    }

    /**
     * 设置修改人
     *
     * @param modifyName 修改人
     */
    public void setModifyName(String modifyName) {
        this.modifyName = modifyName;
    }

    /**
     * 获取最后更新日期
     *
     * @return LAST_UPDATED_DATE - 最后更新日期
     */
    public LocalDateTime getLastUpdatedDate() {
        return lastUpdatedDate;
    }

    /**
     * 设置最后更新日期
     *
     * @param lastUpdatedDate 最后更新日期
     */
    public void setLastUpdatedDate(LocalDateTime lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }

    /**
     * 获取是否可用
     *
     * @return IS_ENABLE - 是否可用
     */
    public String getIsEnable() {
        return isEnable;
    }

    /**
     * 设置是否可用
     *
     * @param isEnable 是否可用
     */
    public void setIsEnable(String isEnable) {
        this.isEnable = isEnable;
    }

    /**
     * 获取并发控制ID
     *
     * @return UPDATE_CONTROL_ID - 并发控制ID
     */
    public String getUpdateControlId() {
        return updateControlId;
    }

    /**
     * 设置并发控制ID
     *
     * @param updateControlId 并发控制ID
     */
    public void setUpdateControlId(String updateControlId) {
        this.updateControlId = updateControlId;
    }

	@Override
	public String toString() {
		return "SacReviewOvertimeRule [ruleId=" + ruleId + ", ruleName=" + ruleName + ", ruleDesc=" + ruleDesc
				+ ", orgCode=" + orgCode + ", orgName=" + orgName + ", oemId=" + oemId + ", groupId=" + groupId
				+ ", creator=" + creator + ", createdName=" + createdName + ", createdDate=" + createdDate
				+ ", modifier=" + modifier + ", modifyName=" + modifyName + ", lastUpdatedDate=" + lastUpdatedDate
				+ ", isEnable=" + isEnable + ", updateControlId=" + updateControlId + "]";
	}

    
}