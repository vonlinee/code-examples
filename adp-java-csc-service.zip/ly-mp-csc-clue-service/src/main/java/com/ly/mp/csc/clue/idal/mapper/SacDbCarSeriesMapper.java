package com.ly.mp.csc.clue.idal.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ly.mp.csc.clue.entities.DbCarSeries;

/**
 * <p>
 * 车系 Mapper 接口
 * </p>
 *
 * @author ly-linliq
 * @since 2021-09-07
 */
public interface SacDbCarSeriesMapper extends BaseMapper<DbCarSeries>{

	public List<Map<String,Object>> selectDbCarSeries(Page<Map<String, Object>> page,@Param("param") Map<String,Object> map);
}
