package com.ly.mp.csc.clue.strategy.service.impl;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ly.bucn.component.strategy.annotation.Strategy;
import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.busi.base.handler.MapUtil;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.csc.clue.entities.SacClueInfoDlr;
import com.ly.mp.csc.clue.service.ISacClueInfoDlrService;
import com.ly.mp.csc.clue.strategy.service.IShCancleBillStrategy;

@Strategy(isDefault=false,names="dlrclue")
@Component
public class ShCancleBillStrategyDlrClue implements IShCancleBillStrategy{
	
	@Autowired
	ISacClueInfoDlrService sacClueInfoDlrService;
	
	//单据校验
	@Override
	public void checkBill(String billCode,String token){
		//获取店端线索信息
		QueryWrapper<SacClueInfoDlr> wrap1 = new QueryWrapper<>();
		wrap1.lambda().eq(SacClueInfoDlr::getServerOrder, billCode);
		SacClueInfoDlr clueInfoDlr = sacClueInfoDlrService.getOne(wrap1);
		if(clueInfoDlr==null){
			throw BusicenException.create("关联的线索不存在！");
		}
		clueInfoDlr.setStatusCode(null);
		clueInfoDlr.setStatusName(null);
		
		clueInfoDlr.setCreator(null);
		clueInfoDlr.setCreatedName(null);
		clueInfoDlr.setCreatedDate(null);
		clueInfoDlr.setModifier(null);
		clueInfoDlr.setModifyName(null);
		clueInfoDlr.setLastUpdatedDate(null);
		clueInfoDlr.setUpdateControlId(null);
		clueInfoDlr.setOemId(null);
		clueInfoDlr.setGroupId(null);
		clueInfoDlr.setFirstReviewTime(null);
		
		
		Map<String, Object> checkMap = MapUtil.entityToMap(clueInfoDlr);
		checkMap.put("token", token);
		//查重
		ParamBase<Map<String, Object>> mapParam = new ParamBase<>();
		mapParam.setParam(checkMap);
		EntityResult<Map<String, Object>> result = sacClueInfoDlrService.dlrClueCheckRepeat(mapParam);
		if("0".equals(result.getResult())){
			throw BusicenException.create(result.getMsg());
		}
		
	}
}
