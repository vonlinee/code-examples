package com.ly.mp.csc.clue.idal.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.ly.mp.csc.clue.entities.SacWorkGroup;
import com.ly.mp.csc.clue.entities.SacWorkGroupUser;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 工作组表 Mapper 接口
 * </p>
 *
 * @author ly-busicen
 * @since 2021-08-17
 */
public interface SacWorkGroupMapper extends BaseMapper<SacWorkGroup> {

	/**
	 * 插入
	 *
	 * @param mapParm
	 * @return
	 */
	public int insertSacWorkGroup(@Param("param") Map<String, Object> param);

	/**
	 * 更新
	 *
	 * @param mapParm
	 * @return
	 */
	public int updateSacWorkGroup(@Param("param") Map<String, Object> param);

	/**
	 * 校验是否重复
	 *
	 * @param mapParm 输入参数
	 * @return int
	 */
	int checkWorkGroupRepeat(@Param("param") Map<String, Object> param);


	/**
	 * 校验是否存在
	 *
	 * @param workGroupId 工作组ID
	 * @return int
	 */
	int checkWorkGroupExists(@Param("workGroupId") String workGroupId);

	/**
	 * 校验该成员是否已存在该工作组，不存在则新增；存在则不处理
	 *
	 * @param param 输入参数
	 * @return int
	 */
	int checkWorkGroupUserExists(@Param("param") Map<String, Object> param);

	/**
	 * 批量新增工作组人员
	 *
	 * @param list 人员信息集合
	 * @return int
	 */
	int insertListWorkGroupUser(@Param("list") List<SacWorkGroupUser> list);

	/**
	 * 查询工作组信息
	 *
	 * @param param 输入参数
	 * @param page  分页参数
	 * @return List
	 */
	List<Map<String, Object>> queryListWorkGroupInfo(IPage<Map<String, Object>> page, @Param("param") Map<String, Object> param);

	/**
	 * 设置工作组组长
	 *
	 * @param param 输入参数
	 * @return int
	 */
	int updateIsLeaderByWorkGroupIdAndWorkGroupUserId(@Param("param") Map<String, Object> param);

	/**
	 * 删除工作组人员
	 * @param param 输入参数
	 * @return int
	 */
	int deleteWorkGroupUser(@Param("param") Map<String, Object> param);

	/**
	 * 查询工作组人员
	 * @param param 输入参数
	 * @param page 分页参数
	 * @return List
	 */
	List<Map<String,Object>> queryListWorkGroupUserInfo (IPage<Map<String, Object>> page, @Param("param") Map<String, Object> param);

	//本组待办-查询本组所有员工列表
	List<Map<String, Object>> selectGroupUserList(@Param("param")Map<String, Object> paramMap);
	
	//获取本组员工待回访数列表
	List<Map<String, Object>> selectGroupUserReviewNum(IPage<Map<String, Object>> page, @Param("param") Map<String, Object> param);
}


