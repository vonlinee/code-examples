package com.ly.mp.csc.clue.service;

import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.entities.OutboundConfig;

import java.util.Map;

import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 商机外呼配置表 服务类
 * </p>
 *
 * @author ly-linliq
 * @since 2021-09-06
 */
public interface IOutboundConfigService extends IService<OutboundConfig> {

	/**
	* @Description: 商机外呼配置查询
	* @author: linliq
	* @date 2021/09/06 19:56:48
	* @param mapParam
	* @return
	 */
	ListResult<Map<String,Object>> queryListOutboundConfig(ParamPage<Map<String,Object>> mapParam);
	
	/**
	* @Description: 商机外呼配置保存
	* @author: linliq
	* @date 2021/09/06 19:57:01
	* @param mapParam
	* @return
	 */
	OptResult outboundConfigSave(Map<String,Object> mapParam);
}
