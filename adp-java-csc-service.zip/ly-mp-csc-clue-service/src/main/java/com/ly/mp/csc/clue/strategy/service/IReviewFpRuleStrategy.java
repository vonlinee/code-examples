package com.ly.mp.csc.clue.strategy.service;

import java.util.List;

import com.ly.mp.csc.clue.entities.out.ReviewFpResultOut;
import com.ly.mp.csc.clue.entities.out.ReviewPersonQueneOut;

/**
 * 分配规则策略接口
 * @author ly-shenyw
 *
 */
public interface IReviewFpRuleStrategy {
	
	/**
	 * 
	 * @param orgCode 组织编码
	 * @param personList 人员队列
	 * @param setId 分配规则设置ID
	 * @param planReviewTime 计划回访时间
	 * @param isFirstSelf 是否优先本人
	 * @return 返回匹配的分配人员信息
	 */
	ReviewFpResultOut handle(String orgCode, List<ReviewPersonQueneOut> personList,String setId,String planReviewTime);
}
