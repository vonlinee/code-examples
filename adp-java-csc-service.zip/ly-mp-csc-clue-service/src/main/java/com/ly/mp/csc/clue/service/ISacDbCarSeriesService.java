package com.ly.mp.csc.clue.service;

import java.util.Map;

import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.ListResult;

/**
 * <p>
 * 车系 服务类
 * </p>
 *
 * @author ly-linliq
 * @since 2021-09-07
 */
public interface ISacDbCarSeriesService {
	/**
	* @Description: 车系查询
	* @author: linliq
	* @date 2021/09/07 15:28:09
	* @param mapParam
	* @return
	 */
	public ListResult<Map<String,Object>> carSeriesQuery(ParamPage<Map<String, Object>> mapParam);

}
