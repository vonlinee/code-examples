package com.ly.mp.csc.clue.service;

import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.entities.SacReviewOvertimeSet;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;
import java.util.Map;

/**
 * com.ly.mp.csc.clue.service.ISacReviewOvertimeSetService
 * 回访超时规则接口类
 * @author zhouhao
 * @date 2021/8/18 16:25
 */
public interface ISacReviewOvertimeSetService extends IService<SacReviewOvertimeSet>{

    /**
     * com.ly.mp.csc.clue.service.ISacReviewOvertimeSetService
     * 回访超时规则保存
     * @param map 输入参数
     * @param token token
     * @return com.ly.mp.component.entities.OptResult
     * @author zhouhao
     * @date 2021/8/18 16:26
     */
    OptResult saveReviewOvertimeSetInfo(Map<String,Object> map, String token);

    /**
     * com.ly.mp.csc.clue.service.ISacReviewOvertimeSetService
     * 回访超时规则查询
     * @param map
     * @param token
     * @return com.ly.mp.component.entities.ListResult<java.util.Map<java.lang.String,java.lang.Object>>
     * @author zhouhao
     * @date 2021/8/18 16:37
     */
    ListResult<Map<String,Object>> queryListReviewOvertimeSetInfo(ParamPage<Map<String,Object>> map, String token);

    /**
     * 回访超时规则删除
     * @param map 输入参数
     * @param token token
     * @return OptResult
     */
    OptResult deleteReviewOvertimeSetInfo(Map<String,Object> map, String token);
    
    /**
     * 获取匹配的超时规则
     * @param map
     * @param token
     * @return
     */
    List<Map<String,Object>> machOverTimeRule(Map<String,Object> map, String token);
    
    /**
     * 计算超时时间
     * @param map
     * @param token
     * @return
     */
    List<Map<String,Object>> queryBillOverTime(Map<String,Object> map, String token);
}
