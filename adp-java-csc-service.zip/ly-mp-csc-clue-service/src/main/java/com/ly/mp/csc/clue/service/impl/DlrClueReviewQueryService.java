package com.ly.mp.csc.clue.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ly.bucn.component.message.Message;
import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.constant.UserBusiEntity;
import com.ly.mp.busi.base.context.BusicenContext;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.busicen.common.context.SwitchDbInvoke;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.entities.in.FieldMappingIn;
import com.ly.mp.csc.clue.idal.mapper.SacReviewDlrClueMapper;
import com.ly.mp.csc.clue.otherservice.ICscSysOrgService;
import com.ly.mp.csc.clue.service.IDlrClueReviewQueryService;
import com.ly.mp.csc.clue.service.ISacDbInnerConfigService;
import com.ly.mp.csc.clue.service.ISacFieldMappingConfigService;
import com.ly.mp.csc.clue.service.ISacReviewService;
import com.ly.mp.csc.clue.util.ExcelExport;

@Service
public class DlrClueReviewQueryService implements IDlrClueReviewQueryService{
	private Logger log = LoggerFactory.getLogger(DlrClueReviewQueryService.class);

	public static final String SUFFIX = "xlsx";

	@Autowired
	SacReviewDlrClueMapper sacReviewDlrClueMapper;
	@Autowired
	Message message;
	@Autowired
	ISacReviewService sacReviewService;
	@Autowired
	ISacDbInnerConfigService sacDbInnerConfigService;
	@Autowired
	ICscSysOrgService sysOrgService;
	@Autowired
	ISacFieldMappingConfigService sacFieldMappingConfigService;

	/**
	 * 本人待回访任务查询
	 *
	 * @param token token
	 * @param map   输入参数
	 * @return ListResult
	 */
	@Override
	public ListResult<Map<String, Object>> queryListMeReviewInfo(ParamPage<Map<String, Object>> map, String token) {
		try {

			int pageIndex = map.getPageIndex();
			int pageSize = map.getPageSize();
			UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
			map.getParam().put("userId", userBusiEntity.getUserID());
			map.getParam().put("orgCode", userBusiEntity.getDlrCode());
			Page<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);
			List<Map<String, Object>> list = sacReviewDlrClueMapper.queryListMeReviewInfo(page, map.getParam());
			for(int i=0;i<list.size();i++){
				Map<String, Object> infoMap = list.get(i);
				if(!StringHelper.IsEmptyOrNull(infoMap.get("extendsJson"))){
					infoMap.putAll(JSON.parseObject(infoMap.get("extendsJson").toString()));
				}
			}

			page.setRecords(list);
			return BusicenUtils.page2ListResult(page);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("queryListReviewAssignInfo:", e);
			throw e;
			// throw new BusicenException(message.get("CLUE-SYSTECONFIGVALUE-01"));
		}
	}

	/**
	 * 本店待回访任务查询
	 *
	 * @param token token
	 * @param map   输入参数
	 * @return ListResult
	 */
	@Override
	public ListResult<Map<String, Object>> queryListByDlr(ParamPage<Map<String, Object>> map, String token) {
		try {
			int pageIndex = map.getPageIndex();
			int pageSize = map.getPageSize();
			UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
			// 获取本店编码
			if(StringHelper.IsEmptyOrNull(map.getParam().get("orgCodeIn"))) {
				map.getParam().put("orgCode", userBusiEntity.getDlrCode());
			}

			StopWatch stopWatch = new StopWatch("本店待回访任务查询");
			stopWatch.start("task1: sacReviewDlrClueMapper.queryListByDlr");

			Page<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);
			List<Map<String, Object>> list = SwitchDbInvoke.invokeTidb(()->sacReviewDlrClueMapper.queryListByDlr(page, map.getParam()));
			stopWatch.stop();
			stopWatch.start("task2: extendsJson处理");
			for(int i=0;i<list.size();i++){
				Map<String, Object> infoMap = list.get(i);
				if(!StringHelper.IsEmptyOrNull(infoMap.get("extendsJson"))){
					infoMap.putAll(JSON.parseObject(infoMap.get("extendsJson").toString()));
				}
			}
			stopWatch.stop();
			System.out.println("本店待回访任务查询:" +stopWatch.getTotalTimeMillis() +"毫秒");//;

			page.setRecords(list);
			return BusicenUtils.page2ListResult(page);
		} catch (Exception e) {
			// e.printStackTrace();
			log.error("queryListByDlr:", e);
			throw e;
		}
	}

	/**
	 * 待审核任务查询
	 *
	 * @param token token
	 * @param map   输入参数
	 * @return ListResult
	 */
	@Override
	public ListResult<Map<String, Object>> queryListAuditReviewInfo(ParamPage<Map<String, Object>> map, String token) {
		try {
			int pageIndex = map.getPageIndex();
			int pageSize = map.getPageSize();
			UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
			map.getParam().put("orgCode", userBusiEntity.getDlrCode());
			map.getParam().put("shPersonId", userBusiEntity.getUserID());
			Page<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);
			List<Map<String, Object>> list = sacReviewDlrClueMapper.queryListAuditReviewInfo(page, map.getParam());
			for(int i=0;i<list.size();i++){
				Map<String, Object> infoMap = list.get(i);
				if(!StringHelper.IsEmptyOrNull(infoMap.get("extendsJson"))){
					infoMap.putAll(JSON.parseObject(infoMap.get("extendsJson").toString()));
				}
			}
			page.setRecords(list);
			return BusicenUtils.page2ListResult(page);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("queryListAuditReviewInfo:", e);
			throw e;
		}
	}

	/**
	 * 回访审核任务查询
	 *
	 * @param token token
	 * @param map   输入参数
	 * @return ListResult
	 */
	@Override
	public ListResult<Map<String, Object>> queryListAuditReviewRecordInfo(ParamPage<Map<String, Object>> map,
			String token) {
		try {
			int pageIndex = map.getPageIndex();
			int pageSize = map.getPageSize();
			UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
			map.getParam().put("orgCode", userBusiEntity.getDlrCode());
			map.getParam().put("personId", userBusiEntity.getUserID());
			Page<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);
			List<Map<String, Object>> list = sacReviewDlrClueMapper.queryListAuditReviewRecordInfo(page, map.getParam());
			for(int i=0;i<list.size();i++){
				Map<String, Object> infoMap = list.get(i);
				String extendsJson="";
				if(!StringHelper.IsEmptyOrNull(infoMap.get("extendsJson"))){
					infoMap.putAll(JSON.parseObject(infoMap.get("extendsJson").toString()));
					extendsJson=infoMap.get("extendsJson").toString();
				}
				unTransFiled(extendsJson,infoMap);
			}
			page.setRecords(list);
			return BusicenUtils.page2ListResult(page);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("queryListAuditReviewRecordInfo:", e);
			throw e;
		}
	}

	/**
	 * 回访记录查询
	 *
	 * @param token token
	 * @param map   输入参数
	 * @return ListResult
	 */
	@Override
	public ListResult<Map<String, Object>> queryReviewRecord(ParamPage<Map<String, Object>> map, String token) {
		try {
			if(StringHelper.IsEmptyOrNull(map.getParam().get("billCode"))) {
				throw new BusicenException(message.get("CLUE-REVIEW-RECODE-01"));
			}
			int pageIndex = map.getPageIndex();
			int pageSize = map.getPageSize();
			Page<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);
			List<Map<String, Object>> list = sacReviewDlrClueMapper.queryReviewRecord(page, map.getParam());
			page.setRecords(list);
			return BusicenUtils.page2ListResult(page);
		} catch (Exception e) {
			log.error("queryReviewRecord:", e);
			throw e;
		}
	}


	/**
	 * 本人待回访任务导出 @throws
	 */
	@SuppressWarnings("unchecked")
	@Override
	public OptResult exportListMeReviewInfo(ParamBase<Map<String, Object>> dataInfo, String token,
			HttpServletResponse response) {

		try {
			String title = "本人待回访任务";// 导出文件名称
			List<Map<String, Object>> columnList=(List<Map<String, Object>>) dataInfo.getParam().get("columnList");// 页面网格列列表
			if (columnList == null) {
				throw BusicenException.create(message.get("EXCEL-EXPORT-01"));
			}
			// 先将结果查询出来
			ParamPage<Map<String, Object>> mapParamPage = new ParamPage<Map<String, Object>>();
			mapParamPage.setPageIndex(1);
			mapParamPage.setPageSize(-1);
			mapParamPage.setParam(dataInfo.getParam());
			ListResult<Map<String, Object>> listResult = queryListMeReviewInfo(mapParamPage, token);
			List<Map<String, Object>> rows = listResult.getRows();
			// 导出excel
			ExcelExport export = new ExcelExport();
			export.excelExport(token, title, response, rows, columnList);

		} catch (Exception e) {
			e.printStackTrace();
			throw new BusicenException(e.getMessage());
		}
		return null;
	}

	/**
	 * 本店待回访任务导出
	 */
	@SuppressWarnings("unchecked")
	@Override
	public OptResult exportListDlrReviewInfo(ParamBase<Map<String, Object>> dataInfo, String token,
			HttpServletResponse response) {
		try {
			String title = "本店待回访任务";// 导出文件名称
			List<Map<String, Object>> columnList=(List<Map<String, Object>>) dataInfo.getParam().get("columnList");// 页面网格列列表
			if (columnList == null) {
				throw BusicenException.create(message.get("EXCEL-EXPORT-01"));
			}
			// 先将结果查询出来
			ParamPage<Map<String, Object>> mapParamPage = new ParamPage<Map<String, Object>>();
			mapParamPage.setPageIndex(1);
			mapParamPage.setPageSize(-1);
			mapParamPage.setParam(dataInfo.getParam());
			ListResult<Map<String, Object>> listResult = queryListByDlr(mapParamPage, token);
			List<Map<String, Object>> rows = listResult.getRows();
			// 导出excel
			ExcelExport export = new ExcelExport();
			export.excelExport(token, title, response, rows, columnList);

		} catch (Exception e) {
			e.printStackTrace();
			throw new BusicenException(e.getMessage());
		}
		return null;
	}

	/**
	 * 获取本店人员待回访数
	 * @param map
	 * @param token
	 * @return
	 */
	@Override
	public ListResult<Map<String, Object>> queryUserReviewNum(ParamPage<Map<String, Object>> map, String token) {
		try{

			UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
			//所属专营店编码
			map.getParam().put("dlrCode", userBusiEntity.getDlrCode());
			//获取岗位
			ParamPage<Map<String, Object>> map2 = new ParamPage<>();
			map2.setPageIndex(1);
			map2.setPageSize(1);
			Map<String, Object> confiParam = new HashMap<>();
			confiParam.put("configCode", "DLR_REVIEW_POSITION");
			map2.setParam(confiParam);
			ListResult<Map<String, Object>> configReuslt = sacDbInnerConfigService.queryConfigList(map2, token);
			if(configReuslt!=null && configReuslt.getRows()!=null && configReuslt.getRows().size()>0){
				map.getParam().put("positionCode", configReuslt.getRows().get(0).get("configValueCode").toString());

				//获取岗位员工列表
				ListResult<Map<String, Object>> listResult = sysOrgService.getEmpListByPosition(token,map);
				if(listResult!=null && listResult.getRows()!=null && listResult.getRows().size()>0){
					String userIdStr = listResult.getRows().stream()
							.filter(p->!StringHelper.IsEmptyOrNull(p.get("userId")))
							.map(p->p.get("userId").toString()).collect(Collectors.joining(","));

					//获取本店员工待办任务数
					ParamPage<Map<String, Object>> map3 = new ParamPage<Map<String, Object>>();
					map3.setPageIndex(-1);
					map3.setPageSize(-1);
					Map<String, Object> param = new HashMap<>();
					param.put("orgCode", userBusiEntity.getDlrCode());
					param.put("personIdList", String.join(",", userIdStr));
					map3.setParam(param);
					ListResult<Map<String, Object>> result3 = sacReviewService.queryTaskNumByPerson(map3, "");

					List<Map<String, Object>> returnList = new ArrayList<>();
					for(int i=0;i<listResult.getRows().size();i++){
						if(!StringHelper.IsEmptyOrNull(listResult.getRows().get(i).get("userId"))){
							String userId = listResult.getRows().get(i).get("userId").toString();
							Map<String, Object> info = new HashMap<>();
							info.put("userId", userId);
							info.put("empName", listResult.getRows().get(i).get("empName").toString());
							//获取待回访数
							if(result3!=null && result3.getRows()!=null && result3.getRows().size()>0){
								List<Map<String, Object>> fileList = result3.getRows().stream()
										.filter(s->userId.equals(s.get("reviewPersonId").toString()))
										.collect(Collectors.toList());
								if(fileList!=null && fileList.size()>0){
									info.put("taskNum", fileList.get(0).get("taskNum").toString());
								}
							}
							returnList.add(info);
						}
					}
					listResult.setRows(returnList);
					return listResult; 
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusicenException(e.getMessage());
		}
		return null;
	}

	/**
	 * 回访表扩展字段转换 反转
	 * 将数据库的字段转换为映射的参数字段
	 * @param oldJson   原来保存的json
	 * @param 新的要保存的map
	 * @return
	 */
	private Map<String, Object> unTransFiled(String oldJson, Map<String, Object> map) {
		FieldMappingIn info = new FieldMappingIn();
		info.setSourceTableCode("t_sac_review");
		info.setBillType(map.get("billType").toString());
		if (!StringHelper.IsEmptyOrNull(map.get("businessType"))) {
			info.setBusinessType(map.get("businessType").toString());
		} else {
			info.setBusinessType("-1");
		}
		info.setParam(map);
		info.setOldJson(oldJson);
		Map<String, Object> filedMap = sacFieldMappingConfigService.unTranFieldToMap(info);
		if (filedMap != null && filedMap.size() > 0) {
			// 合并
			map.putAll(filedMap);
		}
		return map;
	}


}
