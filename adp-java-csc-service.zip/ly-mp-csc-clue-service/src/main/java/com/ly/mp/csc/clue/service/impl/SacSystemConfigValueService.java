package com.ly.mp.csc.clue.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegist;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegistor;
import com.ly.bucn.component.interceptor.annotation.Interceptor;
import com.ly.bucn.component.message.Message;
import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.constant.UserBusiEntity;
import com.ly.mp.busi.base.context.BusicenContext;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.busi.base.handler.OptResultBuilder;
import com.ly.mp.busicen.rule.field.IFireFieldRule;
import com.ly.mp.busicen.rule.field.execution.ValidResultCtn;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.entities.SacSystemConfigValue;
import com.ly.mp.csc.clue.idal.mapper.SacSystemConfigValueMapper;
import com.ly.mp.csc.clue.service.ISacSystemConfigValueService;

/**
 * <p>
 * 工作组表 服务实现类
 * </p>
 *
 * @author zhouhao
 * @since 2021-08-17
 * Modification History:
 * Date               Author          Version            Description
 *---------------------------------------------------------------------*
 * 2021/9/7 14:28     linliq           v1.0.0            解决保存报错问题
 */
@Service
public class SacSystemConfigValueService extends ServiceImpl<SacSystemConfigValueMapper, SacSystemConfigValue> implements ISacSystemConfigValueService, InterceptorWrapperRegist {

	@Autowired
	Message message;
	@Autowired
	IFireFieldRule fireFieldRule;

	@Override
	@Interceptor("csc_clue_savesysteconfigvalueinfo")
	@Transactional(rollbackFor = Exception.class)
	public OptResult saveSysteConfigValueInfo(Map<String,Object> map, String token){
		try {
			Boolean updateFlag=false;
			//id不为空时判断新增还是修改
			if(!StringHelper.IsEmptyOrNull(map.get("configValueId"))) {
				if(baseMapper.selectById(map.get("configValueId").toString()) != null) {
					updateFlag=true;
				}
			}
			//保存组织信息
			UserBusiEntity userBusiEntity=BusicenContext.getCurrentUserBusiInfo(token);
			map.put("orgCode", userBusiEntity.getDlrCode());
			map.put("orgName", userBusiEntity.getDlrName());
			if(!updateFlag) {
				if(StringHelper.IsEmptyOrNull(map.get("isEnable"))) {
					map.put("isEnable", "1");
				}
				if(StringHelper.IsEmptyOrNull(map.get("configValueId"))) {
					map.put("configValueId", StringHelper.GetGUID());
				}
				BusicenUtils.invokeUserInfo(map, BusicenUtils.SOU.Save,token);
				if(!StringHelper.IsEmptyOrNull(map.get("configDesc"))) {
					baseMapper.updateByConfigId(map);
				}
				if(baseMapper.insertSystemConfigValue(map)==0){
					return OptResultBuilder.createFail().Msg(message.get("CLUE-SYSTECONFIGVALUE-03")).result("0").build();
				}
			}else {
				BusicenUtils.invokeUserInfo(map, BusicenUtils.SOU.Update,token);
				if(!StringHelper.IsEmptyOrNull(map.get("configDesc"))) {
					baseMapper.updateByConfigId(map);
				}
				if(baseMapper.updateByConfigValueIdAndUpdateControlId(map)==0){
					return OptResultBuilder.createFail().Msg(message.get("CLUE-SYSTECONFIGVALUE-03")).result("0").build();
				}
			}

		}catch (Exception e){
			e.printStackTrace();
			throw e;
		}
		return OptResultBuilder.createOk().build();
	}

	@Override
	@SuppressWarnings("unchecked")
	public void regist(InterceptorWrapperRegistor registor) {
		//切点编码要和切点表里面的保持一致
		registor.before("csc_clue_savesysteconfigvalueinfo_valid", (context, model)->{
			checkValidate((Map<String,Object>)context.data().getP()[0]);
		});
		registor.before("csc_clue_savesysteconfigvalueinfo_repeat", (context, model)->{
			checkRepeat((Map<String,Object>)context.data().getP()[0]);
		});
		registor.after("csc_clue_savesysteconfigvalueinfo_msg", (context, model)->{
			checkAfter((Map<String,Object>)context.data().getP()[0]);
		});
	}

	public void checkValidate(Map<String,Object> mapParam)
	{
		ValidResultCtn fireRule = fireFieldRule.fireRule(mapParam, "csc-clue-review-check-0004", "maindata");
		String resMsg = fireRule.getNotValidMessage();
		if (!fireRule.isValid()){
			throw new BusicenException(resMsg);
		}
	}

	public void checkRepeat(Map<String,Object> mapParam)
	{
		try {
			int size = baseMapper.countByConfigId((String)mapParam.get("configId"));
			if (size<1) {
				//判断系统配置是否存在
				throw new BusicenException(message.get("CLUE-REVIEWASSIGN-21"));
			}
			//        	int valueSize = baseMapper.countByConfigValueId((String)mapParam.get("configValueId"));
			//            if (valueSize<1) {
			//            	//判断系统配置值是否存在
			//            	throw new BusicenException(message.get("CLUE-REVIEWASSIGN-22"));
			//            }
		}catch(Exception ex)
		{
			throw ex;
			//throw new BusicenException(message.get("CLUE-SYSTECONFIGVALUE-01"));
		}
	}

	public void checkAfter(Map<String,Object> mapParam) {

	}

	/**
	 * 只是设置页面查询哪些可以配置的
	 */
	@Override
	public ListResult<Map<String,Object>> queryListSysteConfigValueInfo(ParamPage<Map<String,Object>> map, String token){
		ListResult<Map<String,Object>> result = new ListResult<Map<String,Object>>();
		UserBusiEntity userBusiEntity=BusicenContext.getCurrentUserBusiInfo(token);
		try {
			int pageIndex=map.getPageIndex();
			int pageSize=map.getPageSize();
			if("0".equals(userBusiEntity.getOrgType())){
				map.getParam().put("isPv", "1");
			}else{
				map.getParam().put("isPv", "0");
			}
			if(StringHelper.IsEmptyOrNull(map.getParam().get("orgCode"))){
				map.getParam().put("orgCode", userBusiEntity.getDlrCode());
			}
			Page<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);
			List<Map<String, Object>> list = baseMapper.selectByAll(page, map.getParam());
			page.setRecords(list);
			result = BusicenUtils.page2ListResult(page);
		}catch (Exception e){
			e.printStackTrace();
			log.error("queryListSysteConfigValueInfo:",e);
			throw e;
		}
		return result;
	}
	
	/**
	 * 根据配置编码获取配置信息
	 */
	@Override
	public ListResult<Map<String,Object>> selectByConfigCode(ParamPage<Map<String,Object>> map, String token){
		ListResult<Map<String,Object>> result = new ListResult<Map<String,Object>>();
		UserBusiEntity userBusiEntity=BusicenContext.getCurrentUserBusiInfo(token);
		try {
			int pageIndex=map.getPageIndex();
			int pageSize=map.getPageSize();
			if(StringHelper.IsEmptyOrNull(map.getParam().get("orgCode"))){
				map.getParam().put("orgCode", userBusiEntity.getDlrCode());
			}
			Page<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);
			List<Map<String, Object>> list = baseMapper.selectByConfigCode(page, map.getParam());
			page.setRecords(list);
			result = BusicenUtils.page2ListResult(page);
		}catch (Exception e){
			e.printStackTrace();
			log.error("selectByConfigCode:",e);
			throw e;
		}
		return result;
	}
	
	/**
     * 获取配置项信息
     * @param param
     * @return
     */
	@Override
	public List<Map<String,Object>> selectConfigInfo(Map<String, Object> param){
		return baseMapper.selectConfigInfo(param);
    }

	@Override
	public String getConfigValue(String configCode, String orgCode, String token) {
		ParamPage<Map<String, Object>> configMapPage = new ParamPage<Map<String, Object>>();
		configMapPage.setPageIndex(1);
		configMapPage.setPageSize(-1);
		Map<String, Object> config = new HashMap<String, Object>();
		config.put("configCode", configCode);
		config.put("orgCode", orgCode);
		configMapPage.setParam(config);
		List<Map<String, Object>> configList = selectByConfigCode(configMapPage, token).getRows();
		if (configList.size() > 0) {
			return configList.get(0).get("valueCode").toString();
		}
		return "";
	}
}
