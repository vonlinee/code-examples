package com.ly.mp.csc.clue.strategy.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ly.bucn.component.strategy.annotation.Strategy;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.csc.clue.entities.out.ReviewFpResultOut;
import com.ly.mp.csc.clue.entities.out.ReviewPersonQueneOut;
import com.ly.mp.csc.clue.service.ISacReviewFpSetService;
import com.ly.mp.csc.clue.strategy.service.IReviewFpRuleStrategy;

/**
 * 人员顺序分配，按照队列顺序分配，达到阀值后分配给下一个人
 * @author ly-shenyw
 *
 */
@Strategy(isDefault=false,names="personAsc")
@Component
public class ReviewFpRuleStrategyPersonAsc implements IReviewFpRuleStrategy{
	
	@Autowired
	ISacReviewFpSetService sacReviewFpSetService;
	
	/**
	 * 单个任务
	 * @param orgCode 组织编码
	 * @param personList 人员队列
	 * @param setId 分配规则设置ID
	 * @return 返回匹配的分配人员信息
	 */
	@Override
	public ReviewFpResultOut handle(String orgCode,List<ReviewPersonQueneOut> personList,String setId,String planReviewTime){
		
		//根据阀值获取分配人员
		ParamPage<Map<String, Object>> map = new ParamPage<Map<String, Object>>();
		map.setPageIndex(1);
		map.setPageSize(1);
		Map<String, Object> param = new HashMap<>();
		param.put("setId", setId);
		param.put("planReviewTime", planReviewTime);
		map.setParam(param);
		ListResult<Map<String, Object>> result = sacReviewFpSetService.queryReviewPersonBySetD(map, "");
		if(result!=null && result.getRows()!=null && result.getRows().size()>0){
			ReviewFpResultOut out = new ReviewFpResultOut();
			out.setReviewPersonUserId(result.getRows().get(0).get("personUserId").toString()); 
			out.setReviewPersonName(result.getRows().get(0).get("personName").toString()); 
			return out;
		}
		return null;
	}
}
