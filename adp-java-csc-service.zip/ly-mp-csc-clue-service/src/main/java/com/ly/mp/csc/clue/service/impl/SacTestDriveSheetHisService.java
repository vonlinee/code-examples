package com.ly.mp.csc.clue.service.impl;

import com.ly.mp.csc.clue.entities.SacTestDriveSheetHis;
import com.ly.mp.csc.clue.idal.mapper.SacTestDriveSheetHisMapper;
import com.ly.mp.csc.clue.service.ISacTestDriveSheetHisService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * 试乘试驾单表 服务实现类
 * </p>
 *
 * @author ly-linliq
 * @since 2021-12-13
 */
@Service
public class SacTestDriveSheetHisService extends ServiceImpl<SacTestDriveSheetHisMapper, SacTestDriveSheetHis> implements ISacTestDriveSheetHisService {

}
