package com.ly.mp.csc.clue.service;

import java.util.Map;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.entities.SacTransferAudit;

/**
 * 划转审核表 服务类
 * t_sac_transfer_audit
 * @author ly-zhengzc
 * @since 2021-12-10
 */
public interface ISacTransferAuditService extends IService<SacTransferAudit> {


	public OptResult transferAudit(Map<String, Object> mapParam, String token) ;


	public Map<String, Object> queryById(String auditId, String token);


	/**
	 * 保存记录
	 * @param mapParam
	 * @param token
	 * @return
	 */
	public EntityResult<Map<String, Object>> sacTransferAuditSave(Map<String, Object> mapParam, String token);
	/**
	 * 分页查询
	 * @param mapParam
	 * @param token
	 * @return
	 */
	public ListResult<Map<String, Object>> queryList(ParamPage<Map<String, Object>> map,String token);
}
