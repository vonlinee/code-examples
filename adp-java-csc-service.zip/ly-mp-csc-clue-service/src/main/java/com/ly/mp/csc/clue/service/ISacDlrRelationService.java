package com.ly.mp.csc.clue.service;

import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.entities.SacDlrRelation;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.Map;

public interface ISacDlrRelationService extends IService<SacDlrRelation>{

    OptResult saveDlrRelation (Map<String,Object> map, String token);

    OptResult deleteDlrRelation (Map<String,Object> map,String token);

    ListResult<Map<String,Object>> queryListDlrRelation(ParamPage<Map<String,Object>> map, String token);
}
