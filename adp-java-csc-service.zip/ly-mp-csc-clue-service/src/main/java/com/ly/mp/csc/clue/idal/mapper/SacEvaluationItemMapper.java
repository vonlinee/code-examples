package com.ly.mp.csc.clue.idal.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ly.mp.csc.clue.entities.SacEvaluationItem;

/**
 * <p>
 * 选择项表 Mapper 接口
 * </p>
 *
 * @author ly-linliq
 * @since 2021-10-14
 */
public interface SacEvaluationItemMapper extends BaseMapper<SacEvaluationItem> {

	/**
	 * 选择项查询
	 * @param param
	 * @param page
	 * @return
	 */
	  public List<Map<String,Object>> selectSacEvaluationItem(@Param("param")Map<String,Object>param,Page<Map<String, Object>> page);
      
	  /**
	   * 选择项新增
	   * @param param
	   * @return
	   */
	  public int insertSacEvaluationItem(@Param("param")Map<String,Object>param);
	  
	  /**
	   * 选择项修改
	   * @param param
	   * @return
	   */
	  public int updateSacEvaluationItem(@Param("param")Map<String,Object>param);
	  
	  /**
	   * 数据查重
	   * @param param
	   * @return
	   */
	  public int checkRepeat(@Param("param")Map<String,Object>param);
	  
}
