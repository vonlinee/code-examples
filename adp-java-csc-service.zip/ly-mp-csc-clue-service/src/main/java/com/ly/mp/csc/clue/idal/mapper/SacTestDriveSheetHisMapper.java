package com.ly.mp.csc.clue.idal.mapper;

import com.ly.mp.csc.clue.entities.SacTestDriveSheetHis;

import feign.Param;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import java.util.Map;

/**
 * <p>
 * 试乘试驾单表 Mapper 接口
 * </p>
 *
 * @author ly-linliq
 * @since 2021-12-13
 */
public interface SacTestDriveSheetHisMapper extends BaseMapper<SacTestDriveSheetHis> {

      public int insertSacTestDriveSheetHis(@Param("param")Map<String,Object>param);
	  
	  public int updateSacTestDriveSheetHis(@Param("param")Map<String,Object>param);
}
