package com.ly.mp.csc.clue.entities;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;

/**
 * <p>
 * 商机外呼配置表
 * </p>
 *
 * @author ly-linliq
 * @since 2021-09-06
 */
@TableName("t_sac_outbound_config")
public class OutboundConfig implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 配置id
     */
    @TableId("OUTBOUND_CONFIG_ID")
    private String outboundConfigId;

    /**
     * 一级信息来源编码
     */
    @TableField("INFO_CHAN_M_CODE")
    private String infoChanMCode;

    /**
     * 一级信息来源名称
     */
    @TableField("INFO_CHAN_M_NAME")
    private String infoChanMName;

    /**
     * 二级信息来源编码
     */
    @TableField("INFO_CHAN_D_CODE")
    private String infoChanDCode;

    /**
     * 二级信息来源名称
     */
    @TableField("INFO_CHAN_D_NAME")
    private String infoChanDName;

    /**
     * 三级信息来源编码
     */
    @TableField("INFO_CHAN_DD_CODE")
    private String infoChanDdCode;

    /**
     * 三级信息来源名称
     */
    @TableField("INFO_CHAN_DD_NAME")
    private String infoChanDdName;

    /**
     * 最低一级的信息来源编码
     */
    @TableField("CHANNEL_CODE")
    private String channelCode;

    /**
     * 最低一级的信息来源名称
     */
    @TableField("CHANNEL_NAME")
    private String channelName;

    /**
     * 厂商标识ID
     */
    @TableField("OEM_ID")
    private String oemId;

    /**
     * 集团标识ID
     */
    @TableField("GROUP_ID")
    private String groupId;

    /**
     * 创建人ID
     */
    @TableField("CREATOR")
    private String creator;

    /**
     * 创建人
     */
    @TableField("CREATED_NAME")
    private String createdName;

    /**
     * 创建日期
     */
    @TableField("CREATED_DATE")
    private LocalDateTime createdDate;

    /**
     * 修改人ID
     */
    @TableField("MODIFIER")
    private String modifier;

    /**
     * 修改人
     */
    @TableField("MODIFY_NAME")
    private String modifyName;

    /**
     * 最后更新日期
     */
    @TableField("LAST_UPDATED_DATE")
    private LocalDateTime lastUpdatedDate;

    /**
     * 是否可用
     */
    @TableField("IS_ENABLE")
    private String isEnable;

    /**
     * 是否外呼
     */
    @TableField("IS_OUTBOUND")
    private String isOutbound;

    /**
     * 并发控制ID
     */
    @TableField("UPDATE_CONTROL_ID")
    private String updateControlId;

    public String getOutboundConfigId() {
        return outboundConfigId;
    }

    public void setOutboundConfigId(String outboundConfigId) {
        this.outboundConfigId = outboundConfigId;
    }
    public String getInfoChanMCode() {
        return infoChanMCode;
    }

    public void setInfoChanMCode(String infoChanMCode) {
        this.infoChanMCode = infoChanMCode;
    }
    public String getInfoChanMName() {
        return infoChanMName;
    }

    public void setInfoChanMName(String infoChanMName) {
        this.infoChanMName = infoChanMName;
    }
    public String getInfoChanDCode() {
        return infoChanDCode;
    }

    public void setInfoChanDCode(String infoChanDCode) {
        this.infoChanDCode = infoChanDCode;
    }
    public String getInfoChanDName() {
        return infoChanDName;
    }

    public void setInfoChanDName(String infoChanDName) {
        this.infoChanDName = infoChanDName;
    }
    public String getInfoChanDdCode() {
        return infoChanDdCode;
    }

    public void setInfoChanDdCode(String infoChanDdCode) {
        this.infoChanDdCode = infoChanDdCode;
    }
    public String getInfoChanDdName() {
        return infoChanDdName;
    }

    public void setInfoChanDdName(String infoChanDdName) {
        this.infoChanDdName = infoChanDdName;
    }
    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }
    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }
    public String getOemId() {
        return oemId;
    }

    public void setOemId(String oemId) {
        this.oemId = oemId;
    }
    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }
    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }
    public String getCreatedName() {
        return createdName;
    }

    public void setCreatedName(String createdName) {
        this.createdName = createdName;
    }
    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }
    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier;
    }
    public String getModifyName() {
        return modifyName;
    }

    public void setModifyName(String modifyName) {
        this.modifyName = modifyName;
    }
    public LocalDateTime getLastUpdatedDate() {
        return lastUpdatedDate;
    }

    public void setLastUpdatedDate(LocalDateTime lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }
    public String getIsEnable() {
        return isEnable;
    }

    public void setIsEnable(String isEnable) {
        this.isEnable = isEnable;
    }
    public String getIsOutbound() {
        return isOutbound;
    }

    public void setIsOutbound(String isOutbound) {
        this.isOutbound = isOutbound;
    }
    public String getUpdateControlId() {
        return updateControlId;
    }

    public void setUpdateControlId(String updateControlId) {
        this.updateControlId = updateControlId;
    }

    @Override
    public String toString() {
        return "OutboundConfig{" +
        "outboundConfigId=" + outboundConfigId +
        ", infoChanMCode=" + infoChanMCode +
        ", infoChanMName=" + infoChanMName +
        ", infoChanDCode=" + infoChanDCode +
        ", infoChanDName=" + infoChanDName +
        ", infoChanDdCode=" + infoChanDdCode +
        ", infoChanDdName=" + infoChanDdName +
        ", channelCode=" + channelCode +
        ", channelName=" + channelName +
        ", oemId=" + oemId +
        ", groupId=" + groupId +
        ", creator=" + creator +
        ", createdName=" + createdName +
        ", createdDate=" + createdDate +
        ", modifier=" + modifier +
        ", modifyName=" + modifyName +
        ", lastUpdatedDate=" + lastUpdatedDate +
        ", isEnable=" + isEnable +
        ", isOutbound=" + isOutbound +
        ", updateControlId=" + updateControlId +
        "}";
    }
}
