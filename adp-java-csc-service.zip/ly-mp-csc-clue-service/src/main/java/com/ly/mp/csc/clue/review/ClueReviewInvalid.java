package com.ly.mp.csc.clue.review;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ly.bucn.component.interceptor.InterceptorWrapperRegist;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegistor;
import com.ly.bucn.component.interceptor.annotation.Interceptor;
import com.ly.bucn.component.strategy.annotation.Strategy;
import com.ly.mp.busicen.rule.field.IFireFieldRule;
import com.ly.mp.csc.clue.enums.ReviewAuditStatusEnum;
import com.ly.mp.csc.clue.enums.ReviewAuditTypeEnum;
import com.ly.mp.csc.clue.service.ISacReviewAuditService;

/**
 * 无效申请
 * @author ly-shenyw
 *
 */
@Strategy(isDefault=false,names="clueReviewInvalid")
@Service
public class ClueReviewInvalid extends AbstractClueReview implements InterceptorWrapperRegist{
	
	@Autowired
	IFireFieldRule fireFieldRule;
	@Autowired
	ISacReviewAuditService sacReviewAuditService;
	
	/**
	 * 前置操作
	 */
	@Override
	public void before(Map<String, Object> reviewMap,String token){
		//校验下发字段
		fireFieldRule.fireRuleExcpt(reviewMap, "csc-clue-review-invalid-check", "maindata");
		//校验是否存在未审核的记录
		checkAudit(reviewMap.get("reviewId").toString());
	}
	
	/**
	 * 其他操作
	 */
	@Override
	@Interceptor("csc_clue_review_invalid")
	public void handle(Map<String, Object> reviewMap,String token){
		//生成审核任务
		saveAudit(reviewMap,token);
	}
	
	/**
	 * 生成审核任务
	 * @param reviewMap
	 * @param token
	 */
	private void saveAudit(Map<String, Object> reviewMap,String token){
		Map<String, Object> param = new HashMap<>();
		param.put("reviewId", reviewMap.get("reviewId").toString());
		param.put("orgCode", reviewMap.get("orgCode").toString());
		param.put("orgName", reviewMap.get("orgName").toString());
		param.put("billCode", reviewMap.get("billCode").toString());
		param.put("applyTypeCode", ReviewAuditTypeEnum.invalid.getResult());
		param.put("applyTypeName", ReviewAuditTypeEnum.invalid.getMsg());
		param.put("applyDesc", reviewMap.get("reviewDesc").toString());
		param.put("shStatus", ReviewAuditStatusEnum.unAudit.getResult());
		param.put("shStatusName", ReviewAuditStatusEnum.unAudit.getMsg());
		//保存
		sacReviewAuditService.sacReviewAuditSave(param, token);
	}
	
	@Override
    public void regist(InterceptorWrapperRegistor registor) {

    }
}

