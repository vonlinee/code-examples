package com.ly.mp.csc.clue.service;

import java.util.Map;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.entities.SacTransferApply;

import javax.servlet.http.HttpServletResponse;

/**
 * 划转申请表 服务类
 * t_sac_transfer_apply
 * @author ly-zhengzc
 * @since 2021-12-14
 */
public interface ISacTransferApplyService extends IService<SacTransferApply> {
	/**
	 * 划转申请
	 * @param mapParam
	 * @param token
	 * @return
	 */
	public EntityResult<Map<String, Object>> transferApply(Map<String, Object> mapParam, String token);

	/**
	 * 划转申请单列表查询
	 * @param map
	 * @param token
	 * @return
	 */
	public ListResult<Map<String, Object>> queryApplyList(ParamPage<Map<String, Object>> map,String token);
	public ListResult<Map<String, Object>> queryAuditHisList(ParamPage<Map<String, Object>> map,String token) ;

	/**
	 * 审核任务列表查询
	 * @param map
	 * @param token
	 * @return
	 */
	public ListResult<Map<String, Object>> queryAuditList(ParamPage<Map<String, Object>> map,String token);

	/**
	 * 保存记录
	 * @param mapParam
	 * @param token
	 * @return
	 */
	public EntityResult<Map<String, Object>> sacTransferApplySave(Map<String, Object> mapParam, String token);
	/**
	 * 分页查询
	 * @param mapParam
	 * @param token
	 * @return
	 */
	public ListResult<Map<String, Object>> queryList(ParamPage<Map<String, Object>> map,String token);

	OptResult exportTransferapplydlrquery(ParamPage<Map<String, Object>> param, HttpServletResponse response, String authentication) throws Exception;
}
