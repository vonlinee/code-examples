package com.ly.mp.csc.clue.entities;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
/**
 * <p>
 * 去重规则配置表
 * </p>
 *
 * @author ly-linliq
 * @since 2021-09-03
 */
@TableName("t_sac_remove_repeat_config")
public class RemoveRepeatConfig implements Serializable {


    private static final long serialVersionUID = 1L;

    /**
     * 配置id
     */
    @TableId("CONFIG_ID")
    private String configId;

    /**
     * 是否校验手机号
     */
    @TableField("CHECK_PHONE")
    private String checkPhone;

    /**
     * 是否校验时间
     */
    @TableField("CHECK_TIME")
    private String checkTime;

    /**
     * 校验时间范围(天)
     */
    @TableField("CHECK_TIME_HORIZON")
    private Integer checkTimeHorizon;

    /**
     * 自定义参数,多个逗号分割
     */
    @TableField("CUSTOM")
    private String custom;

    /**
     * 厂商标识ID
     */
    @TableField("OEM_ID")
    private String oemId;

    /**
     * 集团标识ID
     */
    @TableField("GROUP_ID")
    private String groupId;

    /**
     * 创建人ID
     */
    @TableField("CREATOR")
    private String creator;

    /**
     * 创建人
     */
    @TableField("CREATED_NAME")
    private String createdName;

    /**
     * 创建日期
     */
    @TableField("CREATED_DATE")
    private LocalDateTime createdDate;

    /**
     * 修改人ID
     */
    @TableField("MODIFIER")
    private String modifier;

    /**
     * 修改人
     */
    @TableField("MODIFY_NAME")
    private String modifyName;

    /**
     * 最后更新日期
     */
    @TableField("LAST_UPDATED_DATE")
    private LocalDateTime lastUpdatedDate;

    /**
     * 是否可用
     */
    @TableField("IS_ENABLE")
    private String isEnable;
    
    /**
     * 组织编码
     */
    @TableField("ORG_CODE")
    private String orgCode;
    
    /**
     * 组织名称
     */
    @TableField("ORG_NAME")
    private String orgName;

    /**
     * 并发控制ID
     */
    @TableField("UPDATE_CONTROL_ID")
    private String updateControlId;

    public String getConfigId() {
        return configId;
    }

    public void setConfigId(String configId) {
        this.configId = configId;
    }
    public String getCheckPhone() {
        return checkPhone;
    }

    public void setCheckPhone(String checkPhone) {
        this.checkPhone = checkPhone;
    }
    public String getCheckTime() {
        return checkTime;
    }

    public void setCheckTime(String checkTime) {
        this.checkTime = checkTime;
    }
    public Integer getCheckTimeHorizon() {
        return checkTimeHorizon;
    }

    public void setCheckTimeHorizon(Integer checkTimeHorizon) {
        this.checkTimeHorizon = checkTimeHorizon;
    }
    public String getCustom() {
        return custom;
    }

    public void setCustom(String custom) {
        this.custom = custom;
    }
    public String getOemId() {
        return oemId;
    }

    public void setOemId(String oemId) {
        this.oemId = oemId;
    }
    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }
    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }
    public String getCreatedName() {
        return createdName;
    }

    public void setCreatedName(String createdName) {
        this.createdName = createdName;
    }
    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }
    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier;
    }
    public String getModifyName() {
        return modifyName;
    }

    public void setModifyName(String modifyName) {
        this.modifyName = modifyName;
    }
    public LocalDateTime getLastUpdatedDate() {
        return lastUpdatedDate;
    }

    public void setLastUpdatedDate(LocalDateTime lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }
    public String getIsEnable() {
        return isEnable;
    }

    public void setIsEnable(String isEnable) {
        this.isEnable = isEnable;
    }
    
    public String getOrgCode() {
        return orgCode;
    }

    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }
    
    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }
    
    public String getUpdateControlId() {
        return updateControlId;
    }

    public void setUpdateControlId(String updateControlId) {
        this.updateControlId = updateControlId;
    }

    @Override
    public String toString() {
        return "RemoveRepeatConfig{" +
        "configId=" + configId +
        ", checkPhone=" + checkPhone +
        ", checkTime=" + checkTime +
        ", checkTimeHorizon=" + checkTimeHorizon +
        ", custom=" + custom +
        ", oemId=" + oemId +
        ", groupId=" + groupId +
        ", creator=" + creator +
        ", createdName=" + createdName +
        ", createdDate=" + createdDate +
        ", modifier=" + modifier +
        ", modifyName=" + modifyName +
        ", lastUpdatedDate=" + lastUpdatedDate +
        ", isEnable=" + isEnable +
        ", orgName=" + orgName +
        ", orgCode=" + orgCode +
        ", updateControlId=" + updateControlId +
        "}";
    }
}
