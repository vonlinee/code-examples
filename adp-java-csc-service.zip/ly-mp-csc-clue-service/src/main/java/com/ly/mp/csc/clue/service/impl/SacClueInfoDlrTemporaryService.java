package com.ly.mp.csc.clue.service.impl;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;
import org.springframework.web.multipart.MultipartFile;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.bucn.component.interceptor.annotation.Interceptor;
import com.ly.bucn.component.message.Message;
import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.constant.UserBusiEntity;
import com.ly.mp.busi.base.context.BusicenContext;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.busi.base.handler.ResultHandler;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.entities.ClueDealStatusEnum;
import com.ly.mp.csc.clue.entities.SacClueInfoDlrTemporary;
import com.ly.mp.csc.clue.idal.mapper.SacChannelInfoMapper;
import com.ly.mp.csc.clue.idal.mapper.SacClueInfoDlrTemporaryMapper;
import com.ly.mp.csc.clue.otherservice.ICscSysBaseDataService;
import com.ly.mp.csc.clue.otherservice.ICscSysMetaService;
import com.ly.mp.csc.clue.otherservice.ICscSysOrgService;
import com.ly.mp.csc.clue.service.ISacClueInfoDlrService;
import com.ly.mp.csc.clue.service.ISacClueInfoDlrTemporaryService;
import com.ly.mp.csc.clue.service.ISacFieldMappingConfigService;
import com.ly.mp.csc.clue.util.ClueFillInfoUtil;
import com.ly.mp.csc.clue.util.ClueImportUtil;
import com.ly.mp.csc.clue.util.FieldMappingUtil;
import com.ly.mp.csc.clue.util.LookupValueUtil;


/**
 * <p>
 * 店端线索表临时表 服务实现类
 * </p>
 *
 * @author ly-busicen
 * @since 2021-08-20
 */
@Service
public class SacClueInfoDlrTemporaryService extends ServiceImpl<SacClueInfoDlrTemporaryMapper, SacClueInfoDlrTemporary> implements ISacClueInfoDlrTemporaryService {

	private Logger log = LoggerFactory.getLogger(SacClueInfoDlrTemporaryService.class);


	@Autowired Message message;
	@Autowired SacChannelInfoMapper channelInfoMapper;
	@Autowired SacClueInfoDlrTemporaryMapper sacClueInfoDlrTemporaryMapper;

	@Autowired LookupValueUtil lookupValueUtil;
	@Autowired ISacClueInfoDlrService sacClueInfoDlrService;
	@Autowired ISacClueInfoDlrTemporaryService clueInfoDlrTemporaryService;
	@Autowired ISacFieldMappingConfigService sacFieldMappingConfigService;

	@Autowired ICscSysOrgService orgService;
	@Autowired ICscSysMetaService cscSysMetaService;
	@Autowired ICscSysBaseDataService baseDataService;

	@Override
	public ListResult<Map<String, Object>> findByPage(ParamPage<Map<String, Object>> paramPage) {
		ListResult<Map<String, Object>> result=new ListResult<Map<String,Object>>();
		try {
			Page<Map<String, Object>> page = new Page<Map<String, Object>>(paramPage.getPageIndex(), paramPage.getPageSize());
			List<Map<String, Object>> list =this.baseMapper.selectByPage(page, paramPage.getParam());
			page.setRecords(list);
			result= BusicenUtils.page2ListResult(page);
		} catch (Exception e) {
			log.error("findByPage", e);
			throw e;
		}
		return result;
	}


	@Autowired ClueImportUtil clueImportUtil;
	@Autowired ClueFillInfoUtil clueFillInfoUtil;
	@Override
	@Transactional(rollbackFor = Exception.class)
	public ListResult<String> importFromExcel(MultipartFile file, String token) {
		// 错误Excel行列表
		List<String> errRowInfoList = new ArrayList<>();
		UserBusiEntity user = BusicenContext.getCurrentUserBusiInfo(token);
		// 校验excel文件类型
		ClueImportUtil.checkExtensionName(file.getOriginalFilename());
		try {
			ListResult<Map<String, Object>> configMappingListResult = cscSysMetaService.proConfigMappingQueryByPage(token, "clue_dlr_temporary_excel_import");
			if("0".equals(configMappingListResult.getResult())) {
				errRowInfoList.add(0 + "#获取Excel配置信息出错！" );
				return ClueImportUtil.listResult(errRowInfoList, "导入出错！");
			}

			InputStream is = file.getInputStream();
			Workbook hssfWorkbook = WorkbookFactory.create(is);
			Sheet sheet = hssfWorkbook.getSheetAt(0);
			// excel表头
			List<String> excelHeaderList = null;
			try {
				excelHeaderList = ClueImportUtil.getRowHeader(sheet, 0);
			} catch (Exception e) {
				errRowInfoList.add(0 + "#获取Excel表头出错！" );
				return ClueImportUtil.listResult(errRowInfoList, "导入出错！");
			}
			// 获取Excel表头的配置信息
			Map<String, Map<String, Object>> headerMappingMap = FieldMappingUtil.getHeaderMappingMap(configMappingListResult.getRows());
			List<Map<String, Object>> infoTemporaryList = ClueImportUtil.getInfoTemporaryList(sheet, excelHeaderList, headerMappingMap);

			Map<String, Map<String, String>> allLookupValueMap = null;
			Map<String, String> channelNameMap = null;
			Map<String, String> carSeriesNameCodeMap = null;
			try {
				// 获取值列表 为值列表【名称】转【值】做准备
				allLookupValueMap = lookupValueUtil.initClueLookupValue(token);
				channelNameMap = clueImportUtil.getChannelNameMap();
				carSeriesNameCodeMap = clueFillInfoUtil.getCarSeriesNameCodeMap();
			} catch (Exception e1) {
				e1.printStackTrace();
				errRowInfoList.add(0 + "#" + e1.getMessage());
				return ClueImportUtil.listResult(errRowInfoList);
			}
			String batchUuid = UUID.randomUUID().toString();
			for (int j = 0; j < infoTemporaryList.size(); j++) {
				try {
					Map<String, Object> infoTemporary = infoTemporaryList.get(j);
					BusicenUtils.invokeUserInfo(infoTemporary, BusicenUtils.Save, user, null);
					// Excel行数据转换成【临时表对象】
					infoTemporary.put("temporaryId", UUID.randomUUID().toString());
					infoTemporary.put("batchUuid", batchUuid);
					infoTemporary.put("dealStatusCode", ClueDealStatusEnum.WAITING.getCode());
					infoTemporary.put("dealStatus", ClueDealStatusEnum.WAITING.getDesc());
					infoTemporary.put("isEnable", "1");
					// 校验SacClueInfoTemporary
					String errInfo = clueInfoDlrTemporaryService.checkClueInfoTemporary(infoTemporary, infoTemporaryList);
					// 信息来源 填充信息
					errInfo += ClueImportUtil.fillChannelName(infoTemporary, channelNameMap);
					// 值列表 填充信息
					errInfo += ClueImportUtil.fillLookupValue(infoTemporary, allLookupValueMap);
					errInfo += ClueImportUtil.fillLookupValueDlrClueStatusName(infoTemporary, allLookupValueMap);
					// 填充车系编码
					errInfo += ClueImportUtil.fillCarSeriesCode(infoTemporary, carSeriesNameCodeMap);
					if(StringUtils.isNotBlank(errInfo)) {
						errRowInfoList.add(j + 1 + "# " + errInfo);
					}
				} catch (Exception e) {
					errRowInfoList.add(j + 1 + "# " + e.getMessage());
				}
			}
			// Excel的数据没有出错，导入临时表
			if(errRowInfoList.isEmpty()) {
				infoTemporaryList.forEach(mapParm->{
					BusicenUtils.invokeUserInfo(mapParm, BusicenUtils.SOU.Save,token);
					this.baseMapper.sacClueInfoDlrTemporaryInsert(mapParm);
				});
				return ClueImportUtil.listResult(errRowInfoList, message.get("CLUE-BASE-DLR-04"));
			} else {
				return ClueImportUtil.listResult(errRowInfoList, message.get("CLUE-BASE-DLR-06"));
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		} finally {
		}
	}

	@Override
	@Interceptor("csc_clue_dlr_temporary_importExcel")
	public String checkClueInfoTemporary(Map<String, Object> infoTemporary, List<Map<String, Object>> tranFieldMapList) {
		String errInfo = "";
		Set<String> infoKeyset = infoTemporary.keySet();
		if(infoKeyset.contains("phone")) {
			try {
				String phone = (String)infoTemporary.get("phone");
				// 校验Excel中电话号码是否存在重复
				long countExcelPhone = 0;
				// 校验数据库中电话号码是否存在重复
				int countDBPhone = 0;
				if(StringUtils.isNotBlank(phone)) {
					countExcelPhone = tranFieldMapList.stream().filter(item -> (phone !=null && phone.equals(item.get("phone")))).count();
					//countDBPhone = clueInfoService.checkRepeat(phone, null);
				}
				ClueImportUtil.checkPhone(phone, "电话号码", countExcelPhone, countDBPhone);
			} catch (Exception e) {
				errInfo += e.getMessage() + ", ";
			}
		}

		//		if(infoKeyset.contains("phoneBackup")) {
		//			try {
		//				String phoneBackup = (String)infoTemporary.get("phoneBackup");
		//				// 校验Excel中电话号码是否存在重复
		//				long countExcelPhone = 0;
		//				// 校验数据库中电话号码是否存在重复
		//				int countDBPhone = 0;
		//				if(StringUtils.isNotBlank(phoneBackup)) {
		//					countExcelPhone = tranFieldMapList.stream().filter(item -> (phoneBackup !=null && phoneBackup.equals(item.get("phoneBackup")))).count();
		//					//countDBPhone = clueInfoService.checkRepeat(null, phoneBackup);
		//				}
		//
		//				ClueImportUtil.checkPhone(phoneBackup, "备用电话号码", countExcelPhone, countDBPhone);
		//			} catch (Exception e) {
		//				errInfo += e.getMessage() + ", ";
		//			}
		//		}
		return errInfo;
	}

	OptResult _updateFailInfo(SacClueInfoDlrTemporary entity, String errMessage) {
		entity.setDealStatusCode(ClueDealStatusEnum.FAIL.getCode());
		entity.setDealStatus(ClueDealStatusEnum.FAIL.getDesc());
		entity.setErrMessage(errMessage);
		this.updateById(entity);
		return ResultHandler.updateOk();
	}
	@Override
	public void tempClueDlrUpdateBatch(int pageSize) {
		Page<Map<String, Object>> page = new Page<Map<String, Object>>(1, pageSize);
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("dealStatusCode", ClueDealStatusEnum.WAITING.getCode()); // 待处理
		List<Map<String, Object>> list =this.baseMapper.selectByPage(page, paramMap);
		String batchUuid = StringHelper.GetGUID();
		list.forEach(m->{
			Map<String, Object> newMap = new HashMap<>();
			newMap.put("dealStatusCode",ClueDealStatusEnum.DEALING.getCode());// 处理中
			newMap.put("dealStatus",ClueDealStatusEnum.DEALING.getDesc());// 处理中
			newMap.put("batchUuid", batchUuid);
			newMap.put("temporaryId", m.get("temporaryId"));
			newMap.put("updateControlId", m.get("updateControlId"));
			sacClueInfoDlrTemporaryMapper.sacClueInfoDlrTemporaryUpdate(newMap);
		});
	}


	@Override
	public OptResult insertClueDlrFromTemp(Map<String, Object> temporaryMap) {
		String temporaryId = (String)temporaryMap.get("temporaryId");
		String userId = (String)temporaryMap.get("creator");
		Assert.hasText(temporaryId, "temporaryId不能为空");


		SacClueInfoDlrTemporary entity = new SacClueInfoDlrTemporary();
		entity.setTemporaryId((String)temporaryMap.get("temporaryId"));

		if(StringHelper.IsEmptyOrNull(userId)) {
			return _updateFailInfo(entity, "creator不能为空");
		}

		log.info("importJob-userId={}", userId);
		String token = null;
		String tokenMsg = "token=不能为空";
		try {
			token = orgService.generateTokenByUserId(userId);
		} catch (Exception e) {
			tokenMsg =  "通过userId生成token失败:" + e.getMessage();
		}
		if(StringHelper.IsEmptyOrNull(token)) {
			return _updateFailInfo(entity, tokenMsg);
		}

		Map<String, Object> tarMap = new HashMap<>();
		tarMap.putAll(temporaryMap);
		tarMap.remove("id");
		tarMap.put("token", token);
		ParamBase<Map<String, Object>> clueParam = new ParamBase<>();
		clueParam.setParam(tarMap);

		EntityResult<Map<String, Object>> clueOptResult = null;
		String clueAddErrMsg = null;
		try {
			clueOptResult = sacClueInfoDlrService.saveMap(clueParam, token);
			if("0".equals(clueOptResult.getResult())) {
				clueAddErrMsg = clueOptResult.getMsg();
			}
		} catch (Exception e) {
			// TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			clueAddErrMsg = e.getMessage();
		}
		if(!StringHelper.IsEmptyOrNull(clueAddErrMsg)) {
			return _updateFailInfo(entity, "创建线索失败:" + clueAddErrMsg);
		}
		entity.setDealStatusCode(ClueDealStatusEnum.SUCCESS.getCode());
		entity.setDealStatus(ClueDealStatusEnum.SUCCESS.getDesc());
		this.updateById(entity);
		return ResultHandler.updateOk();
	}

}
