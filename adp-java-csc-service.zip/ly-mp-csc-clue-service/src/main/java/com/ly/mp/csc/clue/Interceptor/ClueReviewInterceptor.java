package com.ly.mp.csc.clue.Interceptor;

import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegist;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegistor;
import com.ly.mp.csc.clue.idal.mapper.SacClueInfoMapper;
import com.ly.mp.csc.clue.service.ISacClueInfoService;

/**
 * 总部商机回访后置
 * @author ly-shenyw
 *
 */
@Service
public class ClueReviewInterceptor implements InterceptorWrapperRegist {

	@Autowired
	ISacClueInfoService clueInfoService;
	@Autowired
	SacClueInfoMapper clueInfoMapper;

	private List<Map<String, Object>> queryClue(String billCode){
		Page<Map<String, Object>> page = new Page<Map<String, Object>>(1, 1);
		Map<String, Object> param = new HashMap<>();
		param.put("serverOrder", billCode);
		return clueInfoMapper.selectByPage(page, param);
	}

	//csc_clue_review_save后置
	private void updateClueInfoSave(Map<String, Object> reviewParam,String token){
		//单据类型
		String billType = (String) reviewParam.get("billType");
		if("CLUE".equals(billType)){
			String billCode = (String) reviewParam.get("billCode");
			Page<Map<String, Object>> page = new Page<Map<String, Object>>(1, 1);
			Map<String, Object> param = new HashMap<>();
			param.put("serverOrder", billCode);
			List<Map<String, Object>> list = clueInfoMapper.selectByPage(page, param);
			if (list != null && !list.isEmpty()) {
				Map<String, Object> clueMap = list.get(0);
				Calendar curCal = Calendar.getInstance();

				if (clueMap.get("firstReviewTime") == null) {
					clueMap.put("firstReviewTime", curCal.getTime());
				}
				clueMap.put("lastReviewTime", curCal.getTime());

				clueMap.put("statusCode", "2");
				clueMap.put("statusName", "待回访");
				clueInfoService.updateMap(clueMap, token);
			}
		}
	}
	public void updateClueInfo(Map<String, Object> reviewParam) {
		String token = (String) reviewParam.get("token");
		String nodeCode = (String) reviewParam.get("nodeCode");
		// 不做处理
		if ("New".equals(nodeCode)) {
			return;
		}

		// 对应clue表的serverOrder
		String billCode = (String) reviewParam.get("billCode");
		if (StringUtils.isNotBlank(billCode)) {
			Page<Map<String, Object>> page = new Page<Map<String, Object>>(1, 1);
			Map<String, Object> param = new HashMap<>();
			param.put("serverOrder", billCode);
			List<Map<String, Object>> list = clueInfoMapper.selectByPage(page, param);
			if (list != null && !list.isEmpty()) {
				Map<String, Object> clueMap = list.get(0);
				Calendar curCal = Calendar.getInstance();

				if (clueMap.get("firstReviewTime") == null) {
					clueMap.put("firstReviewTime", curCal.getTime());
				}
				clueMap.put("lastReviewTime", curCal.getTime());

				/*
				 * 商机状态：1 待分配 2 待回访 3 待派发 4 已派发 5 重复留资 6 派发失败 7 战败申请 8 失控申请 9 无效申请 10 战败 11 失控
				 * 12 无效线索 13 关闭
				 */
				// 继续跟进
				if ("Save".equals(nodeCode)) {
					clueMap.put("statusCode", "2");
					clueMap.put("statusName", "待回访");
				}
				// 下发专营店
				if ("Send".equals(nodeCode)) {
					clueMap.put("statusCode", "4");
					clueMap.put("statusName", "已派发");
					clueMap.put("sendDlrCode", reviewParam.get("sendDlrCode"));
					clueMap.put("sendDlrShortName", reviewParam.get("sendDlrShortName"));
					clueMap.put("sendTime", curCal.getTime());
				}

				// 战败申请
				if ("Defeat".equals(nodeCode)) {
					clueMap.put("statusCode", "7");
					clueMap.put("statusName", "战败申请");
				}
				// 失控申请
				if ("Notctrl".equals(nodeCode)) {
					clueMap.put("statusCode", "8");
					clueMap.put("statusName", "失控申请");
				}
				// 无效申请
				if ("Invalid".equals(nodeCode)) {
					clueMap.put("statusCode", "9");
					clueMap.put("statusName", "无效申请");
				}
				// 战败
				if ("Defeated".equals(nodeCode)) {
					clueMap.put("statusCode", "10");
					clueMap.put("statusName", "战败");
				}
				// 失控
				if ("Notctrled".equals(nodeCode)) {
					clueMap.put("statusCode", "11");
					clueMap.put("statusName", "失控");
				}
				// 无效
				if ("Invalided".equals(nodeCode)) {
					clueMap.put("statusCode", "12");
					clueMap.put("statusName", "无效线索");
				}
				// 结束回访
				if ("End".equals(nodeCode)) {
					clueMap.put("statusCode", "13");
					clueMap.put("statusName", "待回访");
				}

				// clueMap.put("token", token);
				clueInfoService.updateMap(clueMap, token);
			}
		}

	}

	@SuppressWarnings("unchecked")
	@Override
	public void regist(InterceptorWrapperRegistor registor) {
		// 字段校验: 策略编码: bucn.fieldcheck 配置数据:
		// data:p[0].param,article:csc-clue-base-check-0001,type:maindata

		// 生成回访任务
		/*
		registor.after("csc_clue_base_save_addreviewtask", (context, model) -> {
			ParamBase<Map<String, Object>> clueParam = (ParamBase<Map<String, Object>>) context.data().getP()[0];
			if("1".equals(clueParam.getParam().get("isOutBound"))) {
				Map<String, Object> param = clueParam.getParam();
				// 如果 插入成功 则 生成回访任务
				if (param.get("id") != null && BusicenUtils.Save.equals(param.get("updateOrSave"))
						&& Integer.valueOf(param.get("count").toString()) == 0) {
					String token = param.get("token").toString();
					Map<String, Object> reviewMap = getReviewTaskParam(param, token);
					EntityResult<Map<String, Object>> addTask = sacReviewService.addTask(reviewMap, token);
					Map<String, Object> rows = addTask.getRows();
					// 回填回访Id
					param.put("reviewId", rows.get("reviewId"));
					this.baseMapper.updateSacClueInfo(param);
				}
			}
		});
		 */
	}
}
