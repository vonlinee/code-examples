package com.ly.mp.csc.clue.entities;

import java.time.LocalDateTime;

/**
    * 回访分配设置人员阀值表
    */
public class SacReviewFpSetD {
    /**
    * 明细ID
    */
    private String id;

    /**
    * 设置ID
    */
    private String setId;

    /**
    * 人员用户ID
    */
    private String personUserId;

    /**
    * 人员名称
    */
    private String personName;

    /**
    * 顺序
    */
    private String orderNo;

    /**
    * 阀值
    */
    private String maxNum;

    /**
    * 厂商标识ID
    */
    private String oemId;

    /**
    * 集团标识ID
    */
    private String groupId;

    /**
    * 创建人ID
    */
    private String creator;

    /**
    * 创建人
    */
    private String createdName;

    /**
    * 创建日期
    */
    private LocalDateTime createdDate;

    /**
    * 修改人ID
    */
    private String modifier;

    /**
    * 修改人
    */
    private String modifyName;

    /**
    * 最后更新日期
    */
    private LocalDateTime lastUpdatedDate;

    /**
    * 是否可用
    */
    private String isEnable;

    /**
    * 并发控制ID
    */
    private String updateControlId;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSetId() {
        return setId;
    }

    public void setSetId(String setId) {
        this.setId = setId;
    }

    public String getPersonUserId() {
        return personUserId;
    }

    public void setPersonUserId(String personUserId) {
        this.personUserId = personUserId;
    }

    public String getPersonName() {
        return personName;
    }

    public void setPersonName(String personName) {
        this.personName = personName;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getMaxNum() {
        return maxNum;
    }

    public void setMaxNum(String maxNum) {
        this.maxNum = maxNum;
    }

    public String getOemId() {
        return oemId;
    }

    public void setOemId(String oemId) {
        this.oemId = oemId;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public String getCreatedName() {
        return createdName;
    }

    public void setCreatedName(String createdName) {
        this.createdName = createdName;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    public String getModifyName() {
        return modifyName;
    }

    public void setModifyName(String modifyName) {
        this.modifyName = modifyName;
    }

    public LocalDateTime getLastUpdatedDate() {
        return lastUpdatedDate;
    }

    public void setLastUpdatedDate(LocalDateTime lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }

    public String getIsEnable() {
        return isEnable;
    }

    public void setIsEnable(String isEnable) {
        this.isEnable = isEnable;
    }

    public String getUpdateControlId() {
        return updateControlId;
    }

    public void setUpdateControlId(String updateControlId) {
        this.updateControlId = updateControlId;
    }
}