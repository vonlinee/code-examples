package com.ly.mp.csc.clue.service.impl;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.busi.base.handler.BusicenUtils.SOU;
import com.ly.mp.busi.base.handler.ResultHandler;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.entities.SacDbInnerConfig;
import com.ly.mp.csc.clue.idal.mapper.SacDbInnerConfigMapper;
import com.ly.mp.csc.clue.service.ISacDbInnerConfigService;


/**
 * <p>
 * 内置配置表 服务实现类
 * </p>
 *
 * @author ly-busicen
 * @since 2021-10-26
 */
@Service
public class SacDbInnerConfigService extends ServiceImpl<SacDbInnerConfigMapper, SacDbInnerConfig> implements ISacDbInnerConfigService {

private Logger log = LoggerFactory.getLogger(SacDbInnerConfigService.class);
	
	@Autowired
	SacDbInnerConfigMapper sacDbInnerConfigMapper;

	/**
	 * 获取配置列表
	 * 
	 * @param token token
	 * @param map   输入参数
	 * @return ListResult
	 */
	@Override
	public ListResult<Map<String, Object>> queryConfigList(ParamPage<Map<String, Object>> map, String token) {
		try {

			int pageIndex = map.getPageIndex();
			int pageSize = map.getPageSize();
			Page<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);
			List<Map<String, Object>> list = baseMapper.queryConfigList(page, map.getParam());
			page.setRecords(list);
			return BusicenUtils.page2ListResult(page);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("queryConfigList:", e);
			throw e;
		}
	}
	
	/**
	 * 根据主键判断插入或更新
	 * @param info
	 * @return
	 */
	@Override
	@Transactional
	public EntityResult<Map<String, Object>> sacDbInnerConfigSave(Map<String, Object> mapParam, String token){
		try {
			Boolean updateFlag = false;
		    if (!StringHelper.IsEmptyOrNull(mapParam.get("configId"))) {
			    QueryWrapper<SacDbInnerConfig> wrapper = new QueryWrapper<>();
			    wrapper.lambda().eq(SacDbInnerConfig::getConfigId, mapParam.get("configId"));
		    	if (list(wrapper).size() > 0) {
		    		updateFlag = true;
				}
			}
			if(!updateFlag){
				//新增
				if (StringHelper.IsEmptyOrNull(mapParam.get("configId"))) {
					//主键
					mapParam.put("configId",UUID.randomUUID().toString());
				}
				BusicenUtils.invokeUserInfo(mapParam, SOU.Save,token);
				sacDbInnerConfigMapper.insertSacDbInnerConfig(mapParam);
			}else{
				//更新
				BusicenUtils.invokeUserInfo(mapParam, SOU.Update,token);
				sacDbInnerConfigMapper.updateSacDbInnerConfig(mapParam);
			}
			return ResultHandler.updateOk(mapParam);
		} catch (Exception e) {
			log.error("sacDbInnerConfigSave", e);
			throw e;
		} 
	}
	
	/**
	 * 更新
	 * @param info
	 * @return
	 */
	@Override
	@Transactional
	public EntityResult<Map<String, Object>> sacDbInnerConfigUpdate(Map<String, Object> mapParam, String token){
		try {
			//invokeUserInfo会把updateControlId更新掉
			String updateControlId = !StringHelper.IsEmptyOrNull(mapParam.get("updateControlId"))?mapParam.get("updateControlId").toString():"";
			//更新
			BusicenUtils.invokeUserInfo(mapParam, SOU.Update,token);
			if(!StringHelper.IsEmptyOrNull(updateControlId)){
				mapParam.put("updateControlId", updateControlId);
			}
			int rows = sacDbInnerConfigMapper.updateSacDbInnerConfig(mapParam);
			if(rows<=0){
				throw BusicenException.create("并发操作，请重试");
			}
			return ResultHandler.updateOk(mapParam);
		} catch (Exception e) {
			log.error("sacDbInnerConfigUpdate", e);
			throw e;
		} 
	}
	
}
