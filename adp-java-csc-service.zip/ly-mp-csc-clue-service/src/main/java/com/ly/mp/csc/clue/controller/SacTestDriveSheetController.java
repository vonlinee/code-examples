package com.ly.mp.csc.clue.controller;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.context.BusicenInvoker;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.service.ISacTestDriveSheetService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * <p>
 * 试乘试驾单表 前端控制器
 * </p>
 *
 * @author ly-linliq
 * @since 2021-10-18
 */
@Api(value = "试乘试驾单管理", tags = { "试乘试驾单管理" })
@RestController
@RequestMapping("/ly/sac/sactestdrivesheet")
public class SacTestDriveSheetController {

	@Autowired
	ISacTestDriveSheetService sacTestDriveSheetService;

	@ApiOperation(value = "试乘试驾单列表查询", notes = "试乘试驾单列表查询")
	@RequestMapping(value = "/sactestdrivesheetquerylist.do", method = RequestMethod.POST)
	public ListResult<Map<String, Object>> sacTestDriveSheetQueryList(
			@RequestHeader(name = "authorization", required = false) String authentication,
			@RequestBody(required = false) ParamPage<Map<String, Object>> mapParam) {
		mapParam.getParam().put("token", authentication);
		return BusicenInvoker.doList(() -> sacTestDriveSheetService.sacTestDriveSheetQueryList(mapParam)).result();
	}

	@ApiOperation(value = "试乘试驾单详情查询", notes = "试乘试驾单详情查询")
	@RequestMapping(value = "/sactestdrivesheetquerydetail.do", method = RequestMethod.POST)
	public EntityResult<Map<String, Object>> sacTestDriveSheetQueryDetail(
			@RequestHeader(name = "authorization", required = false) String authentication,
			@RequestBody(required = false) ParamBase<Map<String, Object>> mapParam) {
		mapParam.getParam().put("token", authentication);
		return BusicenInvoker.doEntity(() -> sacTestDriveSheetService.sacTestDriveSheetQueryDetail(mapParam.getParam()))
				.result();
	}

	@ApiOperation(value = "试乘试驾单开始", notes = "试乘试驾单开始")
	@RequestMapping(value = "/sactestdrivesheetstart.do", method = RequestMethod.POST)
	public OptResult sacTestDriveSheetStart(
			@RequestHeader(name = "authorization", required = false) String authentication,
			@RequestBody(required = false) ParamBase<Map<String, Object>> mapParam) {
		mapParam.getParam().put("token", authentication);
		mapParam.getParam().put("testStatus", "1");
		mapParam.getParam().put("startTime",
				LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
		return BusicenInvoker.doOpt(() -> sacTestDriveSheetService.sacTestDriveSheetStatus(mapParam.getParam()))
				.result();
	}

	@ApiOperation(value = "试乘试驾单结束", notes = "试乘试驾单结束")
	@RequestMapping(value = "/sactestdrivesheetend.do", method = RequestMethod.POST)
	public OptResult sacTestDriveSheetEnd(
			@RequestHeader(name = "authorization", required = false) String authentication,
			@RequestBody(required = false) ParamBase<Map<String, Object>> mapParam) {
		mapParam.getParam().put("token", authentication);
		mapParam.getParam().put("testStatus", "2");
		mapParam.getParam().put("endTime",
				LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
		return BusicenInvoker.doOpt(() -> sacTestDriveSheetService.sacTestDriveSheetStatus(mapParam.getParam()))
				.result();
	}

	@ApiOperation(value = "试乘试驾单保存", notes = "试乘试驾单保存")
	@RequestMapping(value = "/sactestdrivesheetsave.do", method = RequestMethod.POST)
	public OptResult sacTestDriveSheetSave(
			@RequestHeader(name = "authorization", required = false) String authentication,
			@RequestBody(required = false) ParamBase<Map<String, Object>> mapParam) {
		mapParam.getParam().put("token", authentication);
		return BusicenInvoker.doOpt(() -> sacTestDriveSheetService.sacTestDriveSheetSave(mapParam.getParam())).result();
	}

	@ApiOperation(value = "试乘试驾协议保存", notes = "试乘试驾协议保存")
	@RequestMapping(value = "/sactestdriveagreementsave.do", method = RequestMethod.POST)
	public OptResult sacTestDriveAgreementSave(
			@RequestHeader(name = "authorization", required = false) String authentication,
			@RequestBody(required = false) ParamBase<Map<String, Object>> mapParam) {
		mapParam.getParam().put("token", authentication);
		return BusicenInvoker.doOpt(() -> sacTestDriveSheetService.sacTestDriveAgreementSave(mapParam.getParam()))
				.result();
	}

	@ApiOperation(value = "试乘试驾协议查询", notes = "试乘试驾协议查询")
	@RequestMapping(value = "/sactestdriveagreementquerylist.do", method = RequestMethod.POST)
	public ListResult<Map<String, Object>> sacTestDriveAgreementQueryList(
			@RequestHeader(name = "authorization", required = false) String authentication,
			@RequestBody(required = false) ParamPage<Map<String, Object>> mapParam) {
		mapParam.getParam().put("token", authentication);
		mapParam.getParam().put("isAgreement", true);
		return BusicenInvoker.doList(() -> sacTestDriveSheetService.sacTestDriveSheetQueryList(mapParam)).result();
	}
	
	@ApiOperation(value = "试乘试驾单保存(包含预约单)", notes = "试乘试驾单保存(包含预约单)")
	@RequestMapping(value = "/sactestdrivesheetallsave.do", method = RequestMethod.POST)
	public OptResult sacTestDriveSheetAllSave(
			@RequestHeader(name = "authorization", required = false) String authentication,
			@RequestBody(required = false) ParamBase<Map<String, Object>> mapParam) {
		mapParam.getParam().put("token", authentication);
		return BusicenInvoker.doOpt(() -> sacTestDriveSheetService.sacTestDriveSheetAllSave(mapParam.getParam())).result();
	}
}
