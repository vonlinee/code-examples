package com.ly.mp.csc.clue.entities;


import java.io.Serializable;
import java.time.LocalDateTime;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
/**
 * 划转审核表
 * t_sac_transfer_audit
 * @author ly-zhengzc
 * @since 2021-12-14
 */
@TableName(value = "t_sac_transfer_audit")
public class SacTransferAudit implements Serializable {
	private static final long serialVersionUID = 1L;

	/** 审核ID */
	@TableId("AUDIT_ID")
	private String auditId;

	/** 申请ID */
	@TableField("APPLY_ID")
	private String applyId;

	/** 审核类型编码 */
	@TableField("APPLY_TYPE_CODE")
	private String applyTypeCode;

	/** 审核类型名称 */
	@TableField("APPLY_TYPE_NAME")
	private String applyTypeName;

	/** 审核人员用户ID */
	@TableField("SH_PERSON_ID")
	private String shPersonId;

	/** 审核人员名称 */
	@TableField("SH_PERSON_NAME")
	private String shPersonName;

	/** 审核意见 */
	@TableField("SH_DESC")
	private String shDesc;

	/** 审核时间 */
	@TableField("SH_TIME")
	private LocalDateTime shTime;

	/** 审核状态编码 */
	@TableField("SH_STATUS")
	private String shStatus;

	/** 审核状态名称 */
	@TableField("SH_STATUS_NAME")
	private String shStatusName;

	/** 扩展字段1 */
	@TableField("COLUMN1")
	private String column1;

	/** 扩展字段2 */
	@TableField("COLUMN2")
	private String column2;

	/** 扩展字段3 */
	@TableField("COLUMN3")
	private String column3;

	/** 扩展字段4 */
	@TableField("COLUMN4")
	private String column4;

	/** 扩展字段5 */
	@TableField("COLUMN5")
	private String column5;

	/** JSON扩展字段 */
	@TableField("EXTENDS_JSON")
	private String extendsJson;

	/** 厂商标识ID */
	@TableField("OEM_ID")
	private String oemId;

	/** 集团标识ID */
	@TableField("GROUP_ID")
	private String groupId;

	/** 创建人ID */
	@TableField("CREATOR")
	private String creator;

	/** 创建人 */
	@TableField("CREATED_NAME")
	private String createdName;

	/** 创建日期 */
	@TableField("CREATED_DATE")
	private LocalDateTime createdDate;

	/** 修改人ID */
	@TableField("MODIFIER")
	private String modifier;

	/** 修改人 */
	@TableField("MODIFY_NAME")
	private String modifyName;

	/** 最后更新日期 */
	@TableField("LAST_UPDATED_DATE")
	private LocalDateTime lastUpdatedDate;

	/** 是否可用 */
	@TableField("IS_ENABLE")
	private String isEnable;

	/** 并发控制ID */
	@TableField("UPDATE_CONTROL_ID")
	private String updateControlId;

	public String getAuditId() {
		return auditId;
	}

	public String getApplyId() {
		return applyId;
	}

	public String getApplyTypeCode() {
		return applyTypeCode;
	}

	public String getApplyTypeName() {
		return applyTypeName;
	}

	public String getShPersonId() {
		return shPersonId;
	}

	public String getShPersonName() {
		return shPersonName;
	}

	public String getShDesc() {
		return shDesc;
	}

	public LocalDateTime getShTime() {
		return shTime;
	}

	public String getShStatus() {
		return shStatus;
	}

	public String getShStatusName() {
		return shStatusName;
	}

	public String getColumn1() {
		return column1;
	}

	public String getColumn2() {
		return column2;
	}

	public String getColumn3() {
		return column3;
	}

	public String getColumn4() {
		return column4;
	}

	public String getColumn5() {
		return column5;
	}

	public String getExtendsJson() {
		return extendsJson;
	}

	public String getOemId() {
		return oemId;
	}

	public String getGroupId() {
		return groupId;
	}

	public String getCreator() {
		return creator;
	}

	public String getCreatedName() {
		return createdName;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public String getModifier() {
		return modifier;
	}

	public String getModifyName() {
		return modifyName;
	}

	public LocalDateTime getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public String getIsEnable() {
		return isEnable;
	}

	public String getUpdateControlId() {
		return updateControlId;
	}

	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}

	public void setApplyId(String applyId) {
		this.applyId = applyId;
	}

	public void setApplyTypeCode(String applyTypeCode) {
		this.applyTypeCode = applyTypeCode;
	}

	public void setApplyTypeName(String applyTypeName) {
		this.applyTypeName = applyTypeName;
	}

	public void setShPersonId(String shPersonId) {
		this.shPersonId = shPersonId;
	}

	public void setShPersonName(String shPersonName) {
		this.shPersonName = shPersonName;
	}

	public void setShDesc(String shDesc) {
		this.shDesc = shDesc;
	}

	public void setShTime(LocalDateTime shTime) {
		this.shTime = shTime;
	}

	public void setShStatus(String shStatus) {
		this.shStatus = shStatus;
	}

	public void setShStatusName(String shStatusName) {
		this.shStatusName = shStatusName;
	}

	public void setColumn1(String column1) {
		this.column1 = column1;
	}

	public void setColumn2(String column2) {
		this.column2 = column2;
	}

	public void setColumn3(String column3) {
		this.column3 = column3;
	}

	public void setColumn4(String column4) {
		this.column4 = column4;
	}

	public void setColumn5(String column5) {
		this.column5 = column5;
	}

	public void setExtendsJson(String extendsJson) {
		this.extendsJson = extendsJson;
	}

	public void setOemId(String oemId) {
		this.oemId = oemId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public void setCreatedName(String createdName) {
		this.createdName = createdName;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public void setModifier(String modifier) {
		this.modifier = modifier;
	}

	public void setModifyName(String modifyName) {
		this.modifyName = modifyName;
	}

	public void setLastUpdatedDate(LocalDateTime lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public void setIsEnable(String isEnable) {
		this.isEnable = isEnable;
	}

	public void setUpdateControlId(String updateControlId) {
		this.updateControlId = updateControlId;
	}

}
