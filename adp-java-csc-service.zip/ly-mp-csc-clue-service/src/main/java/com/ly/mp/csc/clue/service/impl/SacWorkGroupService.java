package com.ly.mp.csc.clue.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegist;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegistor;
import com.ly.bucn.component.interceptor.annotation.Interceptor;
import com.ly.bucn.component.message.Message;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.constant.UserBusiEntity;
import com.ly.mp.busi.base.context.BusicenContext;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.busi.base.handler.BusicenUtils.SOU;
import com.ly.mp.busi.base.handler.OptResultBuilder;
import com.ly.mp.busi.base.handler.ResultHandler;
import com.ly.mp.busicen.rule.field.IFireFieldRule;
import com.ly.mp.busicen.rule.field.execution.ValidResultCtn;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.entities.SacWorkGroup;
import com.ly.mp.csc.clue.entities.SacWorkGroupUser;
import com.ly.mp.csc.clue.idal.mapper.SacWorkGroupMapper;
import com.ly.mp.csc.clue.idal.mapper.SacWorkGroupUserMapper;
import com.ly.mp.csc.clue.service.ISacWorkGroupService;


/**
 * <p>
 * 工作组表 服务实现类
 * </p>
 *
 * @author zhouhao
 * @since 2021-08-17
 * Modification History:
 * Date               Author          Version            Description
 *---------------------------------------------------------------------*
 * 2021/9/7 14:28     linliq           v1.0.0       解决工作组保存报错问题
 */
@Service
public class SacWorkGroupService extends ServiceImpl<SacWorkGroupMapper, SacWorkGroup> implements ISacWorkGroupService, InterceptorWrapperRegist {

	private final Logger log = LoggerFactory.getLogger(SacWorkGroupService.class);
	
	@Autowired
	SacWorkGroupMapper sacWorkGroupMapper;
	@Autowired
	SacWorkGroupUserMapper sacWorkGroupUserMapper;
    @Autowired
    Message message;
    @Autowired
    IFireFieldRule fireFieldRule;

	/**
	 * 根据主键判断插入或更新
	 * @param mapParam
	 * @return
	 */
	@Override
	@Transactional(rollbackFor = Exception.class)
	public EntityResult<Map<String, Object>> sacWorkGroupSave(Map<String, Object> mapParam, String token){
		try {
			UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
			
			boolean updateFlag = false;
		    if (!StringHelper.IsEmptyOrNull(mapParam.get("workGroupId"))) {
			    QueryWrapper<SacWorkGroup> wrapper = new QueryWrapper<>();
			    wrapper.lambda().eq(SacWorkGroup::getWorkGroupId, mapParam.get("workGroupId"));
		    	if (list(wrapper).size() > 0) {
		    		updateFlag = true;
				}
			}
			if(!updateFlag){
				//新增
				if (StringHelper.IsEmptyOrNull(mapParam.get("workGroupId"))) {
					//主键
					mapParam.put("workGroupId",UUID.randomUUID().toString());
				}
				//专营店编码
				mapParam.put("dlrCode", userBusiEntity.getDlrCode());
				BusicenUtils.invokeUserInfo(mapParam, SOU.Save,token);
				sacWorkGroupMapper.insertSacWorkGroup(mapParam);
			}else{
				//更新
				BusicenUtils.invokeUserInfo(mapParam, SOU.Update,"");
				sacWorkGroupMapper.updateSacWorkGroup(mapParam);
			}
			return ResultHandler.updateOk(mapParam);
		} catch (Exception e) {
			log.error("sacWorkGroupSave", e);
			throw e;
		} 
	}

    @SuppressWarnings("unchecked")
	@Override
    public void regist(InterceptorWrapperRegistor registor) {
        //切点编码要和切点表里面的保持一致
        registor.before("csc_group_saveworkgroupinfo_valid", (context, model)->{
            checkValidate((Map<String,Object>)context.data().getP()[0]);
        });
		registor.before("csc_group_saveleader_valid", (context, model)->{
			checkValidate((Map<String,Object>)context.data().getP()[0]);
		});
		registor.before("csc_group_saveleader_exits", (context, model)->{
			checkLeaderExits((Map<String,Object>)context.data().getP()[0]);
		});
		registor.before("csc_group_deleteworkgroupuserinfo_valid", (context, model)->{
			checkValidate((Map<String,Object>)context.data().getP()[0]);
		});
        registor.before("csc_group_saveworkgroupinfo_repeat", (context, model)->{
            checkRepeat((Map<String,Object>)context.data().getP()[0],(String)context.data().getP()[1]);
            
        });
        registor.before("csc_group_saveworkgroupinfo_check", (context, model)->{
            checkExists((Map<String,Object>)context.data().getP()[0]);
        });
        registor.before("csc_group_saveworkgroupinfo_checkgroupuser", (context, model)->{
			checkWorkGroupUserExists((Map<String,Object>)context.data().getP()[0],(String)context.data().getP()[1]);
        });
        registor.after("csc_group_saveworkgroupinfo_msg", (context, model)->{
            checkAfter((Map<String,Object>)context.data().getP()[0]);
        });
    }
    
	/**
	 * 设置组长时校验工作组成员是否存在
	 * @param mapParam 输入参数
	 */
	public void checkLeaderExits(Map<String,Object> mapParam){
		try {
			int size = baseMapper.checkWorkGroupUserExists(mapParam);
			if (size == 0) {
				throw new BusicenException(message.get("CLUE-REVIEWASSIGN-29"));
			}
		}catch(Exception ex)
		{
			throw ex;
		}
	}
    
	/**
	 * 校验工作组是否存在
	 * @param mapParam 输入参数
	 */
	public void checkExists(Map<String,Object> mapParam){
		try {
			boolean updateFlag = false;
			if(!StringHelper.IsEmptyOrNull(mapParam.get("workGroupId"))){
				int size = baseMapper.checkWorkGroupExists((String)mapParam.get("workGroupId"));
				if (size > 0) {
					updateFlag = true;
				}else {
                	throw new BusicenException(message.get("CLUE-REVIEWASSIGN-29"));
                }
			}
			mapParam.put("updateFlag",updateFlag);
		}catch(Exception ex)
		{
			throw ex;
		}
	}

	/**
	 * 工作组新增非空校验
	 * @param mapParam 输入参数
	 */
    public void checkValidate(Map<String,Object> mapParam){
    	String article = (String)mapParam.get("article");
        ValidResultCtn fireRule = fireFieldRule.fireRule(mapParam, article, "maindata");
        String resMsg = fireRule.getNotValidMessage();
        if (!fireRule.isValid()){
            throw new BusicenException(resMsg);
        }
    }

	/**
	 * 校验工作组是否重复
	 * @param mapParam 输入参数
	 */
	public void checkRepeat(Map<String,Object> mapParam,String token){
		UserBusiEntity userBusiEntity=BusicenContext.getCurrentUserBusiInfo(token);
		mapParam.put("dlrCode", userBusiEntity.getDlrCode());
		int check = baseMapper.checkWorkGroupRepeat(mapParam);
		if(check>=1){
			throw new BusicenException(message.get("CLUE-REVIEWASSIGN-13"));
		}
	}

	/**
	 * 判断该成员是否已存在该工作组,不存在则新增,存在则不处理。
	 * @param mapParam
	 * @param token
	 */
	@SuppressWarnings("unchecked")
	public void checkWorkGroupUserExists(Map<String,Object> mapParam,String token){
		try {
			List<Map<String,Object>> empList = new ArrayList<>();
			boolean updateFlag = (boolean)mapParam.get("updateFlag");
			List<Map<String,Object>> list = (List<Map<String,Object>>)mapParam.get("empList");
			//工作组新增时
			if(!updateFlag){
				//主键
				mapParam.put("workGroupId",StringHelper.GetGUID());
				String workGroupId = (String)mapParam.get("workGroupId");
				//若list不为空
				if(!StringHelper.IsEmptyOrNull(list)){
					mapParam.remove("empList");
					for (Map<String,Object> emp:list) {
					    if(!StringHelper.IsEmptyOrNull(emp.get("empName"))) {
                            emp.put("workGroupId", workGroupId);
                            BusicenUtils.invokeUserInfo(emp, SOU.Save, token);
                            emp.put("workGroupUserId", StringHelper.GetGUID());
                            emp.put("isEnable", "1");
                            emp.put("isLeader", "0");
                            empList.add(emp);
                        }
					}
					mapParam.put("empList",empList);
				}
			}else {
				//工作组修改时
				String workGroupId = (String)mapParam.get("workGroupId");
				//判断该成员是否已存在该工作组，不存在则新增；存在则不处理
				if(!StringHelper.IsEmptyOrNull(list)){
					for (Map<String,Object> emp:list) {
					    if(!StringHelper.IsEmptyOrNull(emp.get("empName"))) {
                            emp.put("workGroupId", workGroupId);
                            if (baseMapper.checkWorkGroupUserExists(emp) == 0) {
                                BusicenUtils.invokeUserInfo(emp, SOU.Save, token);
                                emp.put("workGroupUserId", StringHelper.GetGUID());
                                emp.put("isEnable", "1");
                                emp.put("isLeader", "0");
                                empList.add(emp);
                            }
                        }
					}
					mapParam.put("empList",empList);
				}
			}
		}catch (Exception e){
		    e.printStackTrace();
		    throw e;
			//throw new BusicenException(message.get("CLUE-WORKGROUP-04"));
		}
	}

	public void checkAfter(Map<String,Object> mapParam) {

	}

	/**
	 * 保存工作组和工作组人员信息
	 * @param map 输入参数 csc-clue-group-check-0001
	 * @param token token
	 * @return OptResult
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(rollbackFor = Exception.class)
    @Interceptor("csc_group_saveworkgroupinfo")
    public OptResult saveWorkGroupInfo(Map<String, Object> map,String token){
		UserBusiEntity userBusiEntity=BusicenContext.getCurrentUserBusiInfo(token);
	    try {
	    	//判断新增修改
			boolean updateFlag = (boolean)map.get("updateFlag");
			if(!updateFlag){
				BusicenUtils.invokeUserInfo(map, BusicenUtils.SOU.Save,token);
				map.remove("createdName");
				map.remove("modifyName");
				map.put("createdName", userBusiEntity.getEmpName());
				map.put("modifyName", userBusiEntity.getEmpName());
				map.put("dlrCode", userBusiEntity.getDlrCode());
				if(baseMapper.insertSacWorkGroup(map)==0){
					return OptResultBuilder.createFail().Msg(message.get("CLUE-WORKGROUP-02")).result("0").build();
				}
			}else{
				BusicenUtils.invokeUserInfo(map, BusicenUtils.SOU.Update,token);
				String updateControlId = (String)map.get("updateControlId");
				map.remove("modifyName");
				map.put("modifyName", userBusiEntity.getEmpName());
				map.put("updateControlId",updateControlId);
				if(baseMapper.updateSacWorkGroup(map)==0){
					return OptResultBuilder.createFail().Msg(message.get("CLUE-WORKGROUP-03")).result("0").build();
				}
			}
			//工作组人员信息集合
			List<Map<String,Object>> list = (List<Map<String,Object>>)map.get("empList");
			if(!StringHelper.IsEmptyOrNull(list)){
				List<SacWorkGroupUser> listVo = new ArrayList<>();
				for (Map<String,Object> emp:list) {
					//校验工作组成员字段
					ValidResultCtn fireRule = fireFieldRule.fireRule(emp, "csc-clue-group-check-0004", "maindata");
			        String resMsg = fireRule.getNotValidMessage();
			        if (!fireRule.isValid()){
			            throw new BusicenException(resMsg);
			        }
					SacWorkGroupUser vo = BusicenUtils.map2Object(emp, SacWorkGroupUser.class);
					if(StringHelper.IsEmptyOrNull(vo.getWorkGroupId())){
						continue;
					}
					listVo.add(vo);
				}
				//保存人员信息
				if(listVo.size()>0){
					
					if(baseMapper.insertListWorkGroupUser(listVo)==0){
						throw new BusicenException(message.get("CLUE-WORKGROUP-05"));
					}
				}
			}
        }catch (Exception e){
            e.printStackTrace();
            log.error("saveWorkGroupInfo:",e);
            throw e;
            //throw new BusicenException(message.get("CLUE-SYSTECONFIGVALUE-01"));
        }
	    return OptResultBuilder.createOk().build();
    }

	/**
	 * 查询工作组信息
	 * @param map 输入参数
	 * @param token token
	 * @return ListResult
	 */
	@Override
	public ListResult<Map<String,Object>> queryListWorkGroupInfo(ParamPage<Map<String,Object>> map, String token){
		try {
			UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
			
			int pageIndex=map.getPageIndex();
			int pageSize=map.getPageSize();
			Page<Map<String, Object>> page = new Page<>(pageIndex, pageSize);
			map.getParam().put("dlrCode", userBusiEntity.getDlrCode());
			List<Map<String, Object>> list = baseMapper.queryListWorkGroupInfo(page, map.getParam());
			page.setRecords(list);
			return BusicenUtils.page2ListResult(page);
		}catch (Exception e){
			e.printStackTrace();
			log.error("queryListWorkGroupInfo:",e);
			throw e;
			//throw new BusicenException(message.get("CLUE-SYSTECONFIGVALUE-01"));
		}
	}

	/**
	 * 查询工作组人员信息
	 * @param map 输入参数
	 * @param token token
	 * @return ListResult
	 */
	@Override
	public ListResult<Map<String,Object>> queryListWorkGroupUserInfo(ParamPage<Map<String,Object>> map, String token){
		try {
			if(StringHelper.IsEmptyOrNull(map.getParam().get("workGroupId"))) {
				throw new BusicenException("工作组ID不能为空");
			}
			int pageIndex=map.getPageIndex();
			int pageSize=map.getPageSize();
			Page<Map<String, Object>> page = new Page<>(pageIndex, pageSize);
			List<Map<String, Object>> list = baseMapper.queryListWorkGroupUserInfo(page, map.getParam());
			page.setRecords(list);
			return BusicenUtils.page2ListResult(page);
		}catch (Exception e){
			e.printStackTrace();
			log.error("queryListWorkGroupUserInfo:",e);
			throw e;
			//throw new BusicenException(message.get("CLUE-SYSTECONFIGVALUE-01"));
		}
	}

	/**
	 * 工作组设置组长
	 * @param map 输入参数  csc-clue-group-check-0002
	 * @return OptResult
	 */
	@Override
	@Interceptor("csc_group_saveleader")
	public OptResult saveLeader(Map<String,Object> map,String token){
		try {
			map.put("isLeader","0");
			BusicenUtils.invokeUserInfo(map, SOU.Update,token);
			if(baseMapper.updateIsLeaderByWorkGroupIdAndWorkGroupUserId(map)==0){
				throw new BusicenException(message.get("CLUE-REVIEWASSIGN-17"));
			}
			map.put("isLeader","1");
			if(baseMapper.updateIsLeaderByWorkGroupIdAndWorkGroupUserId(map)==0){
				throw new BusicenException(message.get("CLUE-REVIEWASSIGN-17"));
			}
		}catch (Exception e){
			e.printStackTrace();
			log.error("queryListReviewAssignInfo:",e);
			throw e;
			//throw new BusicenException(message.get("CLUE-SYSTECONFIGVALUE-01"));
		}
		return OptResultBuilder.createOk().build();
	}

	/**
	 * 删除成员
	 * @param map 输入参数 csc-clue-group-check-0003
	 * @return OptResult
	 */
	@Override
	@SuppressWarnings("unchecked")
	@Interceptor("csc_group_deleteworkgroupuserinfo")
	public OptResult deleteWorkGroupUserInfo(Map<String,Object> map){
		try {
			List<String> list=new ArrayList<String>();
			list=(List<String>) map.get("workGroupUserId");
			for(int i=0;i<list.size();i++) {
				if(StringHelper.IsEmptyOrNull(list.get(i))) {
					throw new BusicenException(message.get("CLUE-WORKGROUP-07"));
				}
			}
			if(list.size()<1) {
				throw new BusicenException(message.get("CLUE-WORKGROUP-07"));
			}
			baseMapper.deleteWorkGroupUser(map);
		}catch (Exception e){
			e.printStackTrace();
			log.error("queryListReviewAssignInfo:",e);
			throw e;
			//throw new BusicenException(message.get("CLUE-SYSTECONFIGVALUE-01"));
		}
		return OptResultBuilder.createOk().build();
	}
	
	//查询本组所有人员用户列表,逗号分割
	//isLeader:1则查本人是组长的所在组的成员，0则不过是不是组长都查出来
	@Override
	public String selectGroupUserList(String empId,String isLeader){
		Map<String,Object> param = new HashMap<>();
		param.put("empId",empId);
		param.put("isLeader",isLeader);
		List<Map<String, Object>>  list = sacWorkGroupMapper.selectGroupUserList(param);
		//过滤数组中为null的对象
		list.removeAll(Collections.singleton(null));
		if(list !=null && list.size()>0){
			return list.get(0).get("userIdList").toString();
		}
		return "";
	}
	
	/**
	 * 获取本组员工待回访数列表
	 * @param map 输入参数
	 * @param token token
	 * @return ListResult
	 */
	@Override
	public ListResult<Map<String,Object>> selectGroupUserReviewNum(ParamPage<Map<String,Object>> map, String token){
		try {

			UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
	
			map.getParam().put("empId", userBusiEntity.getEmpID());
			
			int pageIndex=map.getPageIndex();
			int pageSize=map.getPageSize();
			Page<Map<String, Object>> page = new Page<>(pageIndex, pageSize);
			List<Map<String, Object>> list = baseMapper.selectGroupUserReviewNum(page, map.getParam());
			page.setRecords(list);
			return BusicenUtils.page2ListResult(page);
		}catch (Exception e){
			e.printStackTrace();
			log.error("selectGroupUserReviewNum:",e);
			throw e;
			//throw new BusicenException(message.get("CLUE-SYSTECONFIGVALUE-01"));
		}
	}
}

