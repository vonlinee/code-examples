package com.ly.mp.csc.clue.strategy.service.impl;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.ly.bucn.component.strategy.annotation.Strategy;
import com.ly.mp.busicen.common.helper.SpringContextHolder;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.csc.clue.service.ISacReviewService;
import com.ly.mp.csc.clue.strategy.service.IAddReviewStrategy;

/**
 * 新建回访-默认策略，实时调用
 * @author ly-shenyw
 *
 */
@Strategy(isDefault=true,names="addReviewDefault")
@Component
public class AddReviewStrategyDefault implements IAddReviewStrategy {
	//新建回访单
	public EntityResult<Map<String, Object>> addTask(Map<String, Object> map, String token){
		return SpringContextHolder.getBean(ISacReviewService.class).addTask(map, token);
	}
}
