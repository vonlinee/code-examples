package com.ly.mp.csc.clue.idal.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.ly.mp.csc.clue.entities.SacReviewOvertimeRule;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * com.ly.mp.csc.clue.idal.mapper.SacReviewOvertimeRuleMapper
 * 超期规则数据持久化
 *
 * @author zhouhao
 * @date 2021/8/17 14:07
 */
public interface SacReviewOvertimeRuleMapper extends BaseMapper<SacReviewOvertimeRule> {

    /**
     * com.ly.mp.csc.clue.idal.mapper.SacReviewOvertimeRuleMapper
     * 超期规则查询
     *
     * @param paraMap 输入参数
     * @return java.util.List<java.util.Map < java.lang.String, java.lang.Object>>
     * @author zhouhao
     * @date 2021/8/17 14:20
     */
    List<Map<String, Object>> selectByAll(IPage<Map<String, Object>> page, @Param("paraMap") Map<String, Object> paraMap);

    /**
     * com.ly.mp.csc.clue.idal.mapper.SacReviewOvertimeRuleMapper
     * 超期规则重复校验
     *
     * @param paraMap 输入参数
     * @return int 是否重复
     * @author zhouhao
     * @date 2021/8/17 14:20
     */
    int checkReviewOverTime(@Param("paraMap") Map<String, Object> paraMap);

    /**
     * 新增超期规则明细
     * @param map 输入参数
     * @return int
     */
    int insertReviewOverTimed(@Param("map") Map<String, Object> map);


    /**
     * 超期规则明细查询
     * @param page 分页参数
     * @param param 输入参数
     * @return List
     */
    List<Map<String, Object>> queryListRuleD(IPage<Map<String, Object>> page,@Param("param") Map<String, Object> param);

    int checkReviewOverTimed(@Param("param") Map<String, Object> param);

    int updateReviewOvertimeRuled(@Param("map") Map<String, Object> map);

    int deleteRuledInfo(String id);
    
    int checkReviewOvertimeRuleExists(@Param("ruleId") String ruleId);
    int checkReviewOvertimeRuleDExits(@Param("id") String id);
    
    int deleteByRuled (@Param("ruleId") String ruleId);
}