package com.ly.mp.csc.clue.controller;

import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.context.BusicenInvoker;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.service.ISacDlrRelationService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * com.ly.mp.csc.clue.controller.SacDlrRelationController
 * 网点关系映射服务控制类
 * @author zhouhao
 * @date 2021/8/18 16:18
 */
@Api(value = "网点关系映射服务", tags = { "网点关系映射服务" })
@RestController
@RequestMapping(value = "/ly/sac/dlrrelation", produces = { MediaType.APPLICATION_JSON_VALUE })
public class SacDlrRelationController {
	//注入服务
	@Autowired
	ISacDlrRelationService sacDlrRelationService;
	
	@ApiOperation(value="网点关系映射查询", notes="网点关系映射查询")
	@RequestMapping(value = "/querylist.do", method = RequestMethod.POST)
	public ListResult<Map<String,Object>> queryListReviewOvertimeSetInfo(
			@RequestHeader(name = "authorization",required = false) String token,
			@RequestBody(required = false) ParamPage<Map<String,Object>> dataInfo){
		return BusicenInvoker.doList(()->sacDlrRelationService.queryListDlrRelation(dataInfo,token)).result();
	}
	
		
	@ApiOperation(value="网点关系映射保存", notes="网点关系映射保存")
	@RequestMapping(value = "/save.do", method = RequestMethod.POST)
	public OptResult saveReviewOvertimeSetInfo(
			@RequestHeader(name = "authorization",required = false) String token,
			@RequestBody(required = true) ParamBase<Map<String, Object>> dataInfo){
		return BusicenInvoker.doOpt(()->sacDlrRelationService.saveDlrRelation(dataInfo.getParam(), token)).result();
	}

	@ApiOperation(value="网点关系映射删除", notes="网点关系映射删除")
	@RequestMapping(value = "/delete.do", method = RequestMethod.POST)
	public OptResult deleteReviewOvertimeSetInfo(
			@RequestHeader(name = "authorization",required = false) String token,
			@RequestBody(required = true) ParamBase<Map<String, Object>> dataInfo){
		return BusicenInvoker.doOpt(()->sacDlrRelationService.deleteDlrRelation(dataInfo.getParam(), token)).result();
	}
}

