package com.ly.mp.csc.clue.service;

import com.ly.mp.csc.clue.entities.SacDbReviewNodeRf;
import com.baomidou.mybatisplus.extension.service.IService;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;

import java.util.Map;

/**
 * <p>
 * 回访业务节点关系表 服务类
 * </p>
 *
 * @author ly-busicen
 * @since 2021-09-10
 */
public interface ISacDbReviewNodeRfService extends IService<SacDbReviewNodeRf> {

	/**
     * 回访分配设置查询
     * @param map 入参查询条件
	 * @param token token
     * @return com.ly.mp.component.entities.ListResult<com.ly.mp.csc.clue.entities.out.ReviewAssignSetOut>
     * @author zhouhao
     * @date 2021/8/16 15:06
     */
    ListResult<Map<String,Object>> queryReviewNodeRfList(ParamPage<Map<String,Object>>map, String token);
	
	/**
	 * 根据主键判断插入或更新
	 * @param info
	 * @return
	 */
	EntityResult<Map<String, Object>> sacDbReviewNodeRfSave(Map<String, Object> mapParam, String token);
	
}
