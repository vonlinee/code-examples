package com.ly.mp.csc.clue.service.impl;

import com.ly.mp.csc.clue.entities.SacDbReviewNode;
import com.ly.mp.csc.clue.idal.mapper.SacDbReviewNodeMapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ly.mp.csc.clue.service.ISacDbReviewNodeService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.busi.base.handler.BusicenUtils.SOU;
import com.ly.mp.busi.base.handler.ResultHandler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;
import java.util.UUID;


/**
 * <p>
 * 回访节点表 服务实现类
 * </p>
 *
 * @author ly-busicen
 * @since 2021-09-10
 */
@Service
public class SacDbReviewNodeService extends ServiceImpl<SacDbReviewNodeMapper, SacDbReviewNode> implements ISacDbReviewNodeService {

private Logger log = LoggerFactory.getLogger(SacDbReviewNodeService.class);
	
	@Autowired
	SacDbReviewNodeMapper sacDbReviewNodeMapper;

	/**
	 * 根据主键判断插入或更新
	 * @param info
	 * @return
	 */
	@Override
	@Transactional
	public EntityResult<Map<String, Object>> sacDbReviewNodeSave(Map<String, Object> mapParam, String token){
		try {
			Boolean updateFlag = false;
		    if (!StringHelper.IsEmptyOrNull(mapParam.get("nodeId"))) {
			    QueryWrapper<SacDbReviewNode> wrapper = new QueryWrapper<>();
			    wrapper.lambda().eq(SacDbReviewNode::getNodeId, mapParam.get("nodeId"));
		    	if (list(wrapper).size() > 0) {
		    		updateFlag = true;
				}
			}
			if(!updateFlag){
				//新增
				if (StringHelper.IsEmptyOrNull(mapParam.get("nodeId"))) {
					//主键
					mapParam.put("nodeId",UUID.randomUUID().toString());
				}
				BusicenUtils.invokeUserInfo(mapParam, SOU.Save,token);
				sacDbReviewNodeMapper.insertSacDbReviewNode(mapParam);
			}else{
				//更新
				BusicenUtils.invokeUserInfo(mapParam, SOU.Update,"");
				sacDbReviewNodeMapper.updateSacDbReviewNode(mapParam);
			}
			return ResultHandler.updateOk(mapParam);
		} catch (Exception e) {
			log.error("sacDbReviewNodeSave", e);
			throw e;
		} 
	}
	
}
