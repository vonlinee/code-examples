package com.ly.mp.csc.clue.idal.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.ly.mp.csc.clue.entities.SacSystemConfigValue;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface SacSystemConfigValueMapper extends BaseMapper<SacSystemConfigValue> {

    /**
     * com.ly.mp.csc.clue.idal.mapper.SacSystemConfigValueMapper
     * 新增系统配置值
     * @param element 输入参数
     * @return int
     * @author zhouhao
     * @date 2021/8/18 14:55
     */
    int insertSystemConfigValue(@Param("element")Map<String,Object> element);
    

    /**
     * com.ly.mp.csc.clue.idal.mapper.SacSystemConfigValueMapper
     * 修改系统配置值
     * @param element 输入参数
     * @return int
     * @author zhouhao
     * @date 2021/8/18 14:55
     */
    int updateByConfigValueIdAndUpdateControlId(@Param("updated")Map<String,Object> element);

    /**
     * com.ly.mp.csc.clue.idal.mapper.SacSystemConfigValueMapper
     * 校验
     * @param configValueId 主键ID
     * @return java.lang.Integer
     * @author zhouhao
     * @date 2021/8/18 14:56
     */
    Integer countByConfigValueId(@Param("configValueId")String configValueId);
    
    
    Integer countByConfigId(@Param("configId")String configId);

    /**
     * com.ly.mp.csc.clue.idal.mapper.SacSystemConfigValueMapper
     * 系统配置值查询
     * @param param 输入参数
     * @return java.util.List<java.util.Map<java.lang.String,java.lang.Object>
     * @author zhouhao
     * @date 2021/8/18 15:08
     */
    List<Map<String,Object>> selectByAll(IPage<Map<String, Object>> page, @Param("param")Map<String,Object> param);
    
    /**
     * 根据编码获取配置
     * @param page
     * @param param
     * @return
     */
    List<Map<String,Object>> selectByConfigCode(IPage<Map<String, Object>> page, @Param("param")Map<String,Object> param);
    
    /**
     * 获取配置项信息
     * @param param
     * @return
     */
    List<Map<String,Object>> selectConfigInfo(@Param("param")Map<String,Object> param);

    int updateByConfigId(@Param("map") Map<String,Object> map);
}