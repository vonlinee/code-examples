package com.ly.mp.csc.clue.service;

import java.util.Map;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.entities.SacChannelInfo;

/**
 * 渠道信息服务类
 * @author zhouhao
 */
public interface ISacChannelInfoService extends IService<SacChannelInfo>{

	/**
	 * 渠道信息查询（树形结构）
	 * @param map 输入参数
	 * @param token token
	 * @return ListResult
	 */
	ListResult<Map<String,Object>> queryListChannelInfo(ParamPage<Map<String,Object>> map, String token);

	/**
	 * @Description 渠道信息管理查询
	 * @param map
	 * @param token
	 * @return
	 */
	ListResult<Map<String,Object>> queryListChannel(ParamPage<Map<String,Object>> map, String token);

	/**
	 * 渠道信息保存
	 * @param map 输入参数
	 * @param token token
	 * @return OptResult
	 */
	OptResult saveChannelInfo(Map<String,Object> map, String token);
	
	/**
	 * 渠道信息关系查下，根据渠道名称向上找渠道列表
	 * @param mapParam
	 * @param token
	 * @return
	 */
	ListResult<Map<String, Object>> queryChannelLinkByName(ParamPage<Map<String, Object>> mapParam, String token);
}
