package com.ly.mp.csc.clue.strategy.service.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONObject;
import com.ly.bucn.component.ms.MsContextSimple;
import com.ly.bucn.component.strategy.annotation.Strategy;
import com.ly.mp.busi.base.constant.UserBusiEntity;
import com.ly.mp.busi.base.context.BusicenContext;
import com.ly.mp.busi.base.handler.EntityResultBuilder;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.csc.clue.strategy.service.IAddReviewStrategy;

/**
 * 新建回访-消息队列-生产者
 * @author ly-shenyw
 *
 */
@Strategy(isDefault=false,names="addReviewMq")
@Component
public class AddReviewStrategyMq implements IAddReviewStrategy {
	
	//消息队列topic
	private final String topic="SacReviewService.addReview";
	
	@Autowired
	MsContextSimple msContextSimple;
	
	//新建回访单
	public EntityResult<Map<String, Object>> addTask(Map<String, Object> map, String token){
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("reviewId", UUID.randomUUID().toString());
		
		UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
		map.put("userId", userBusiEntity.getUserID());
		msContextSimple.send(topic, JSONObject.toJSONString(map));
		return EntityResultBuilder.<Map<String, Object>>creatOk().rows(resultMap).build();
	}
}
