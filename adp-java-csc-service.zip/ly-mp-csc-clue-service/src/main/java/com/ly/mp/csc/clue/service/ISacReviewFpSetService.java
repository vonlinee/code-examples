package com.ly.mp.csc.clue.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.entities.SacReviewFpSet;

import java.util.List;
import java.util.Map;

/**
 * com.ly.mp.csc.clue.service.SacReviewFpSetService
 * 回访分配服务接口类
 * @author zhouhao
 * @date 2021/8/16 14:31
 */
public interface ISacReviewFpSetService  extends IService<SacReviewFpSet> {

    /**
     * com.ly.mp.csc.clue.service.SacReviewFpSetDService
     * 回访分配设置查询
     * @param map 入参查询条件
	 * @param token token
     * @return com.ly.mp.component.entities.ListResult<com.ly.mp.csc.clue.entities.out.ReviewAssignSetOut>
     * @author zhouhao
     * @date 2021/8/16 15:06
     */
    ListResult<Map<String,Object>> queryListReviewAssignInfo(ParamPage<Map<String,Object>> map, String token);

    /**
     * com.ly.mp.csc.clue.service.ISacReviewFpSetDService
     * 回访分配设置
     * @param map 输入参数
     * @param token token
     * @return com.ly.mp.component.entities.OptResult
     * @author zhouhao
     * @date 2021/8/16 18:03
     */
    OptResult saveReviewAssignInfo(Map<String,Object> map, String token);

    /**
     * com.ly.mp.csc.clue.service.ISacReviewFpSetDService
     * 分配规则查询
     * @param map 输入参数
     * @param token token
     * @return com.ly.mp.component.entities.ListResult<java.util.Map<java.lang.String,java.lang.Object>>
     * @author zhouhao
     * @date 2021/8/17 10:35
     */
    ListResult<Map<String,Object>> queryListReviewRuleInfo(ParamPage<Map<String,Object>> map, String token);

    /**
     * 分配规则删除
     * @param map 输入参数
     * @param token token
     * @return OptResult
     */
    OptResult deleteReviewAssignInfo(Map<String,Object> map, String token);
    
    /**
     * 获取匹配的分配规则
     * @param param
     * @return
     */
    List<Map<String, Object>> machReviewFpRule(Map<String,Object> map, String token);
    
    /**
     * 获取人员阀值列表及当前回访数
     * @param map
     * @param token
     * @return
     */
    ListResult<Map<String, Object>> queryReviewPersonBySetD(ParamPage<Map<String,Object>> map, String token);
    
    /**
     * 获取阀值列表
     * @param map
     * @param token
     * @return
     */
    ListResult<Map<String, Object>> queryReviewFpSetD(ParamPage<Map<String,Object>> map, String token);
    
    /**
     * 获取队列中的人员列表及阀值
     * @param map
     * @param token
     * @return
     */
    ListResult<Map<String, Object>> queryFpPersonList(ParamPage<Map<String,Object>> map, String token);
}
