package com.ly.mp.csc.clue.entities;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;

/**
 * <p>
 * 试驾车表
 * </p>
 *
 * @author ly-linliq
 * @since 2021-12-08
 */
@TableName("t_sac_demo_car")
public class SacDemoCar implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 所属专营店编码
     */
    @TableField("DLR_CODE")
    private String dlrCode;

    /**
     * 试驾车ID
     */
    @TableId("CAR_ID")
    private String carId;

    /**
     * 所属专营店名称
     */
    @TableField("DLR_NAME")
    private String dlrName;

    /**
     * 车牌号
     */
    @TableField("PLATE_NUMBER")
    private String plateNumber;

    /**
     * 车型名称
     */
    @TableField("SMALL_CAR_TYPE_CN")
    private String smallCarTypeCn;

    /**
     * 车型编码
     */
    @TableField("SMALL_CAR_TYPE_CODE")
    private String smallCarTypeCode;

    /**
     * 试驾车状态
     */
    @TableField("CAR_STATUS_CODE")
    private String carStatusCode;

    /**
     * 试驾车状态中文名
     */
    @TableField("CAR_STATUS_NAME")
    private String carStatusName;

    /**
     * VIN(车架号)
     */
    @TableField("CAR_VIN")
    private String carVin;

    /**
     * 行驶里程
     */
    @TableField("ROAD_HAUL")
    private Double roadHaul;

    /**
     * 登记时间
     */
    @TableField("REGISTRATION_TIME")
    private LocalDateTime registrationTime;

    /**
     * 退役时间
     */
    @TableField("RETIRED_TIME")
    private LocalDateTime retiredTime;

    /**
     * 备注
     */
    @TableField("REMARK")
    private String remark;

    /**
     * 车辆状态(是否可用)
     */
    @TableField("IS_ENABLE")
    private String isEnable;

    /**
     * 厂商标识ID
     */
    @TableField("OEM_ID")
    private String oemId;

    /**
     * 集团标识ID
     */
    @TableField("GROUP_ID")
    private String groupId;

    /**
     * 创建人ID
     */
    @TableField("CREATOR")
    private String creator;

    /**
     * 创建人
     */
    @TableField("CREATED_NAME")
    private String createdName;

    /**
     * 创建日期
     */
    @TableField("CREATED_DATE")
    private LocalDateTime createdDate;

    /**
     * 修改人ID
     */
    @TableField("MODIFIER")
    private String modifier;

    /**
     * 修改人
     */
    @TableField("MODIFY_NAME")
    private String modifyName;

    /**
     * 最后更新日期
     */
    @TableField("LAST_UPDATED_DATE")
    private LocalDateTime lastUpdatedDate;

    /**
     * 并发控制ID
     */
    @TableField("UPDATE_CONTROL_ID")
    private String updateControlId;

    /**
     * 扩展字段1
     */
    @TableField("COLUMN1")
    private String column1;

    /**
     * 扩展字段2
     */
    @TableField("COLUMN2")
    private String column2;

    /**
     * 扩展字段3
     */
    @TableField("COLUMN3")
    private String column3;

    /**
     * 扩展字段4
     */
    @TableField("COLUMN4")
    private String column4;

    /**
     * 扩展字段5
     */
    @TableField("COLUMN5")
    private String column5;

    /**
     * 扩展字段6
     */
    @TableField("COLUMN6")
    private String column6;

    /**
     * 扩展字段7
     */
    @TableField("COLUMN7")
    private String column7;

    /**
     * 扩展字段8
     */
    @TableField("COLUMN8")
    private String column8;

    /**
     * 扩展字段9
     */
    @TableField("COLUMN9")
    private String column9;

    /**
     * 扩展字段10
     */
    @TableField("COLUMN10")
    private String column10;

    public String getDlrCode() {
        return dlrCode;
    }

    public void setDlrCode(String dlrCode) {
        this.dlrCode = dlrCode;
    }
    public String getCarId() {
        return carId;
    }

    public void setCarId(String carId) {
        this.carId = carId;
    }
    public String getDlrName() {
        return dlrName;
    }

    public void setDlrName(String dlrName) {
        this.dlrName = dlrName;
    }
    public String getPlateNumber() {
        return plateNumber;
    }

    public void setPlateNumber(String plateNumber) {
        this.plateNumber = plateNumber;
    }
    public String getSmallCarTypeCn() {
        return smallCarTypeCn;
    }

    public void setSmallCarTypeCn(String smallCarTypeCn) {
        this.smallCarTypeCn = smallCarTypeCn;
    }
    public String getSmallCarTypeCode() {
        return smallCarTypeCode;
    }

    public void setSmallCarTypeCode(String smallCarTypeCode) {
        this.smallCarTypeCode = smallCarTypeCode;
    }
    public String getCarStatusCode() {
        return carStatusCode;
    }

    public void setCarStatusCode(String carStatusCode) {
        this.carStatusCode = carStatusCode;
    }
    public String getCarStatusName() {
        return carStatusName;
    }

    public void setCarStatusName(String carStatusName) {
        this.carStatusName = carStatusName;
    }
    public String getCarVin() {
        return carVin;
    }

    public void setCarVin(String carVin) {
        this.carVin = carVin;
    }
    public Double getRoadHaul() {
        return roadHaul;
    }

    public void setRoadHaul(Double roadHaul) {
        this.roadHaul = roadHaul;
    }
    public LocalDateTime getRegistrationTime() {
        return registrationTime;
    }

    public void setRegistrationTime(LocalDateTime registrationTime) {
        this.registrationTime = registrationTime;
    }
    public LocalDateTime getRetiredTime() {
        return retiredTime;
    }

    public void setRetiredTime(LocalDateTime retiredTime) {
        this.retiredTime = retiredTime;
    }
    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
    public String getIsEnable() {
        return isEnable;
    }

    public void setIsEnable(String isEnable) {
        this.isEnable = isEnable;
    }
    public String getOemId() {
        return oemId;
    }

    public void setOemId(String oemId) {
        this.oemId = oemId;
    }
    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }
    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }
    public String getCreatedName() {
        return createdName;
    }

    public void setCreatedName(String createdName) {
        this.createdName = createdName;
    }
    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }
    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier;
    }
    public String getModifyName() {
        return modifyName;
    }

    public void setModifyName(String modifyName) {
        this.modifyName = modifyName;
    }
    public LocalDateTime getLastUpdatedDate() {
        return lastUpdatedDate;
    }

    public void setLastUpdatedDate(LocalDateTime lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }
    public String getUpdateControlId() {
        return updateControlId;
    }

    public void setUpdateControlId(String updateControlId) {
        this.updateControlId = updateControlId;
    }
    public String getColumn1() {
        return column1;
    }

    public void setColumn1(String column1) {
        this.column1 = column1;
    }
    public String getColumn2() {
        return column2;
    }

    public void setColumn2(String column2) {
        this.column2 = column2;
    }
    public String getColumn3() {
        return column3;
    }

    public void setColumn3(String column3) {
        this.column3 = column3;
    }
    public String getColumn4() {
        return column4;
    }

    public void setColumn4(String column4) {
        this.column4 = column4;
    }
    public String getColumn5() {
        return column5;
    }

    public void setColumn5(String column5) {
        this.column5 = column5;
    }
    public String getColumn6() {
        return column6;
    }

    public void setColumn6(String column6) {
        this.column6 = column6;
    }
    public String getColumn7() {
        return column7;
    }

    public void setColumn7(String column7) {
        this.column7 = column7;
    }
    public String getColumn8() {
        return column8;
    }

    public void setColumn8(String column8) {
        this.column8 = column8;
    }
    public String getColumn9() {
        return column9;
    }

    public void setColumn9(String column9) {
        this.column9 = column9;
    }
    public String getColumn10() {
        return column10;
    }

    public void setColumn10(String column10) {
        this.column10 = column10;
    }

    @Override
    public String toString() {
        return "SacDemoCar{" +
        "dlrCode=" + dlrCode +
        ", carId=" + carId +
        ", dlrName=" + dlrName +
        ", plateNumber=" + plateNumber +
        ", smallCarTypeCn=" + smallCarTypeCn +
        ", smallCarTypeCode=" + smallCarTypeCode +
        ", carStatusCode=" + carStatusCode +
        ", carStatusName=" + carStatusName +
        ", carVin=" + carVin +
        ", roadHaul=" + roadHaul +
        ", registrationTime=" + registrationTime +
        ", retiredTime=" + retiredTime +
        ", remark=" + remark +
        ", isEnable=" + isEnable +
        ", oemId=" + oemId +
        ", groupId=" + groupId +
        ", creator=" + creator +
        ", createdName=" + createdName +
        ", createdDate=" + createdDate +
        ", modifier=" + modifier +
        ", modifyName=" + modifyName +
        ", lastUpdatedDate=" + lastUpdatedDate +
        ", updateControlId=" + updateControlId +
        ", column1=" + column1 +
        ", column2=" + column2 +
        ", column3=" + column3 +
        ", column4=" + column4 +
        ", column5=" + column5 +
        ", column6=" + column6 +
        ", column7=" + column7 +
        ", column8=" + column8 +
        ", column9=" + column9 +
        ", column10=" + column10 +
        "}";
    }
}
