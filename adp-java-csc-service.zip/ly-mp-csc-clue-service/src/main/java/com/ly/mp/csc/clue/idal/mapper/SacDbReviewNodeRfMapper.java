package com.ly.mp.csc.clue.idal.mapper;

import com.ly.mp.csc.clue.entities.SacDbReviewNodeRf;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;

import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 回访业务节点关系表 Mapper 接口
 * </p>
 *
 * @author ly-busicen
 * @since 2021-09-10
 */
public interface SacDbReviewNodeRfMapper extends BaseMapper<SacDbReviewNodeRf> {

	/**
    * 获取节点关系列表
    * @param page
    * @param param
    * @return
    */
    List<Map<String, Object>> queryReviewNodeRfList(IPage<Map<String, Object>> page, @Param("param") Map<String, Object> param);
	    
	/**
	 * 插入
	 * @param mapParm
	 * @return
	 */
	public int insertSacDbReviewNodeRf(@Param("param")Map<String, Object> mapParm);
	
	/**
	 * 更新
	 * @param mapParm
	 * @return
	 */
	public int updateSacDbReviewNodeRf(@Param("param")Map<String, Object> mapParm);
}
