package com.ly.mp.csc.clue.service.impl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StopWatch;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegist;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegistor;
import com.ly.bucn.component.interceptor.annotation.Interceptor;
import com.ly.bucn.component.message.Message;
import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.constant.UserBusiEntity;
import com.ly.mp.busi.base.context.BusicenContext;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.busi.base.handler.BusicenUtils.SOU;
import com.ly.mp.busi.base.handler.MapUtil;
import com.ly.mp.busi.base.handler.OptResultBuilder;
import com.ly.mp.busi.base.handler.ResultHandler;
import com.ly.mp.busicen.common.context.SwitchDbInvoke;
import com.ly.mp.busicen.rule.field.FireFieldRule;
import com.ly.mp.busicen.rule.field.IFireFieldRule;
import com.ly.mp.busicen.rule.field.execution.ValidResultCtn;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.entities.SacAppointmentSheet;
import com.ly.mp.csc.clue.entities.SacTestDriveSheet;
import com.ly.mp.csc.clue.helper.CacheDataFactory;
import com.ly.mp.csc.clue.idal.mapper.SacAppointmentSheetMapper;
import com.ly.mp.csc.clue.idal.mapper.SacDemoCarMapper;
import com.ly.mp.csc.clue.idal.mapper.SacTestDriveSheetMapper;
import com.ly.mp.csc.clue.otherservice.ICscSysBaseDataService;
import com.ly.mp.csc.clue.service.ISacAppointmentSheetService;
import com.ly.mp.csc.clue.service.ISacDbInnerConfigService;

/**
 * <p>
 * 试乘试驾预约单表 服务实现类
 * </p>
 *
 * @author ly-linliq
 * @since 2021-10-15
 */
@Service
public class SacAppointmentSheetService extends ServiceImpl<SacAppointmentSheetMapper, SacAppointmentSheet>
		implements ISacAppointmentSheetService, InterceptorWrapperRegist {

	private Logger log = LoggerFactory.getLogger(SacAppointmentSheetService.class);
	@Autowired
	SacAppointmentSheetMapper sacAppointmentSheetMapper;
	@Autowired
	SacTestDriveSheetMapper sacTestDriveSheetMapper;
	@Autowired
	SacTestDriveSheetService sacTestDriveSheetService;
	@Autowired
	SacClueInfoDlrService sacClueInfoDlrService;
	@Autowired
	CacheDataFactory cacheDataFactory;
	@Autowired
	SacDemoCarMapper sacDemoCarMapper;
	@Autowired
	ISacDbInnerConfigService sacDbInnerConfigService;
	@Autowired
	ICscSysBaseDataService cscSysBaseDataService;
	@Autowired
	ICscSysBaseDataService baseDataService;
	@Autowired
	IFireFieldRule fireFieldRule;
	@Autowired
	Message message;
	/**
	 * 试乘试驾预约单查询
	 */
	@Override
	public ListResult<Map<String, Object>> appointmentSheetQueryList(ParamPage<Map<String, Object>> mapParam) {
		ListResult<Map<String, Object>> result = new ListResult<Map<String, Object>>();
		try {
			// 去掉空字符串
			MapUtil.removeNullValue(mapParam.getParam());
			//字段校验
			ValidResultCtn fireRule = fireFieldRule.fireRule(mapParam.getParam(), "csc-clue-appointment-sheet-check1",
					"maindata");
			String resMsg = fireRule.getNotValidMessage();
			if (!fireRule.isValid()) {
				throw new BusicenException(resMsg);
			}
			// 默认查询没有被取消的试乘试驾单
			if (StringHelper.IsEmptyOrNull(mapParam.getParam().get("isEnable"))) {
				mapParam.getParam().put("isEnable", "1");
			}
			String token = mapParam.getParam().get("token").toString();
			// 根据token获取当前用户信息
			UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
			mapParam.getParam().put("dlrCode", userBusiEntity.getDlrCode());
			Page<Map<String, Object>> page = new Page<Map<String, Object>>(mapParam.getPageIndex(),
					mapParam.getPageSize());

			List<Map<String, Object>> list = sacAppointmentSheetMapper.selectSacAppointmentSheet(mapParam.getParam(),
					page);
			page.setRecords(list);
			result = BusicenUtils.page2ListResult(page);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("appointmentSheetQueryList", e);
			throw e;
		}
		return result;

	}

	/**
	 * 试乘试驾预约单保存
	 */
	@Override
	@Interceptor("csc_clue_appointment_sheet")
	@Transactional(rollbackFor = Exception.class)
	public EntityResult<Map<String, Object>> appointmentSheetSave(Map<String, Object> mapParam) {
		StopWatch stopWatch = new StopWatch("试乘试驾预约单");
		
		String token = String.valueOf(mapParam.get("token"));
		try {
			// 判断新增还是修改
			Boolean updateFlag = false;
			if (!StringHelper.IsEmptyOrNull(mapParam.get("updateFlag"))) {
				updateFlag = (Boolean) mapParam.get("updateFlag");
			}
			// 新增
			if (!updateFlag) {
				if (StringHelper.IsEmptyOrNull(mapParam.get("appointmentId"))) {
					mapParam.put("appointmentId", StringHelper.GetGUID());
				}
				if (StringHelper.IsEmptyOrNull(mapParam.get("customerSex"))) {
					mapParam.put("customerSex", "1");
				}
				if (StringHelper.IsEmptyOrNull(mapParam.get("isEnable"))) {
					mapParam.put("isEnable", "1");
				}
				if (StringHelper.IsEmptyOrNull(mapParam.get("appointmentChannel"))) {
					mapParam.put("appointmentChannel", "0");
				}
				if (StringHelper.IsEmptyOrNull(mapParam.get("isTestDrive"))) {
					mapParam.put("isTestDrive", "0");
				}
				// 生成预约时间
				String appointmentTime = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format(LocalDateTime.now());
				mapParam.put("appointmentTime", appointmentTime);
				stopWatch.start("单号生成");
				// 单号生成
				setOrderCode(mapParam);
				stopWatch.stop();
				
				stopWatch.start("插入预约单");
				BusicenUtils.invokeUserInfo(mapParam, SOU.Save, token);
				sacAppointmentSheetMapper.insertSacAppointmentSheet(mapParam);
				stopWatch.stop();
			} else {
				BusicenUtils.invokeUserInfo(mapParam, SOU.Update, token);
				sacAppointmentSheetMapper.updateSacAppointmentSheet(mapParam);
			}
			Page<Map<String, Object>> page = new Page<Map<String, Object>>(1,-1);
			stopWatch.start("返回数据");
			List<Map<String, Object>> list = sacAppointmentSheetMapper.selectSacAppointmentSheet(mapParam,page);
			stopWatch.stop();
			System.out.println("试乘试驾预约单:" +stopWatch.prettyPrint() +"毫秒");//;
			System.out.println("试乘试驾预约单:" +stopWatch.getTotalTimeMillis() +"毫秒");//;
			return ResultHandler.updateOk(list.get(0));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("appointmentSheetSave", e);
			throw e;
		}
	}

	private void setOrderCode(Map<String, Object> mapParam) {
		try {
			// 试乘试驾预约单单号生成
			String billTypeId = "bucn_yy_no";
			String dlrId = mapParam.get("dlrId").toString();
			String token = String.valueOf(mapParam.get("token"));
			ListResult<Map<String, Object>> generateOrderCode = baseDataService.generateOrderCode(dlrId, billTypeId,
					token);
			// 调用服务成功则直接获取单号，不成功则调用自定义单号生成方法
			if ("1".equals(generateOrderCode.getResult())) {
				mapParam.put("appointmentOrderNo", generateOrderCode.getMsg());
			} else {
				throw BusicenException.create("调用生成【试驾预约单单号】出错！[result=" + generateOrderCode.getResult() + ", msg="
						+ generateOrderCode.getMsg() + "]");
			}
			
		} catch (Exception e) {
			throw e;
		}
	}

	/**
	 * 试驾车容量查询
	 */
	@Override
	@Interceptor("csc_clue_drive_capacity")
	public ListResult<Map<String, Object>> sacTestDriveCapacityQueryList(ParamPage<Map<String, Object>> mapParam) {
		ListResult<Map<String, Object>> result = new ListResult<Map<String, Object>>();

		try {
			result = (ListResult<Map<String, Object>>) mapParam.getParam().get("result");
		} catch (Exception e) {
			e.printStackTrace();
			log.error("sacTestDriveCapacityQueryList", e);
			throw e;
		}
		return result;
	}

	/**
	 * 试乘试驾单取消
	 */
	@Override
	@Interceptor("csc_clue_appointment_sheet_cancel")
	@Transactional(rollbackFor = Exception.class)
	public OptResult appointmentSheetCancel(Map<String, Object> mapParam) {
		try {
			String token = mapParam.get("token").toString();
			BusicenUtils.invokeUserInfo(mapParam, SOU.Update, token);
			mapParam.put("isEnable", "0");
			int result = sacAppointmentSheetMapper.updateSacAppointmentSheet(mapParam);
			if (result == 0) {
				return OptResultBuilder.createFail().build();
			}
		} catch (Exception e) {
			log.error("appointmentSheetCancel", e);
			throw e;
		}
		return OptResultBuilder.createOk().build();
	}

	/**
	 * 前后置方法
	 * 
	 * @param registor
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void regist(InterceptorWrapperRegistor registor) {
		// 校验字段
		registor.before("csc_clue_appointment_sheet_valid", (context, model) -> {
			checkValidate((Map<String, Object>) context.data().getP()[0]);
		});
		// 检查时间
		registor.before("csc_clue_appointment_sheet_check_time", (context, model) -> {
			StopWatch stopWatch = new StopWatch("检查预约时间是否合法");
			stopWatch.start("开始");
			checkTime((Map<String, Object>) context.data().getP()[0]);
			stopWatch.stop();
			System.out.println("查预约时间是否合法:" +stopWatch.prettyPrint() +"毫秒");//;
			System.out.println("查预约时间是否合法:" +stopWatch.getTotalTimeMillis() +"毫秒");//;
		});
		// 新增主键是否已存在查重
		registor.before("csc_clue_appointment_sheet_repeat", (context, model) -> {
			StopWatch stopWatch = new StopWatch("新增主键是否已存在查重");
			stopWatch.start("开始");
			checkRepeat((Map<String, Object>) context.data().getP()[0]);
			stopWatch.stop();
			System.out.println("新增主键是否已存在查重:" +stopWatch.prettyPrint() +"毫秒");//;
			System.out.println("新增主键是否已存在查重:" +stopWatch.getTotalTimeMillis() +"毫秒");//;
		});
		// 预约人数阈值检验,已达到阈值则不能再预约
		registor.before("csc_clue_appointment_sheet_threshold", (context, model) -> {
			StopWatch stopWatch = new StopWatch("预约人数阈值检验");
			stopWatch.start("开始");
			checkThresholdValue((Map<String, Object>) context.data().getP()[0]);
			stopWatch.stop();
			System.out.println("预约人数阈值检验:" +stopWatch.prettyPrint() +"毫秒");//;
			System.out.println("预约人数阈值检验:" +stopWatch.getTotalTimeMillis() +"毫秒");//;
		});
		// 判断客户是否存在，不存在则新增一条线索
		registor.before("csc_clue_appointment_sheet_customer", (context, model) -> {
			checkCustomerClue((Map<String, Object>) context.data().getP()[0]);
		});
		// 预约单取消字段校验
		registor.before("csc_clue_appointment_sheet_cancel_valid", (context, model) -> {
			checkAppointmentCancelValidate((Map<String, Object>) context.data().getP()[0]);
		});
		// 预约单校验是否存在、是否可以取消
		registor.before("csc_clue_appointment_sheet_cancel_exits", (context, model) -> {
			checkAppointmentIdExits((Map<String, Object>) context.data().getP()[0]);
		});
		// 取消预约单后，删除试乘试驾单信息
		registor.after("csc_clue_appointment_sheet_cancel_sheet", (context, model) -> {
			deleteTestDriveSheet((Map<String, Object>) context.data().getP()[0]);
		});
		// 容量查询前后置方法
		registor.before("csc_clue_drive_capacity_check", (context, model) -> {
			checkCapacityValidate((ParamPage<Map<String, Object>>) context.data().getP()[0]);
		});
		// 容量查询实现
		registor.before("csc_clue_drive_capacity_query", (context, model) -> {
			checkCapacityquery((ParamPage<Map<String, Object>>) context.data().getP()[0]);
		});

	}

	public void checkCapacityValidate(ParamPage<Map<String, Object>> mapParam) {
		// 必填字段校验
		ValidResultCtn fireRule = fireFieldRule.fireRule(mapParam.getParam(), "csc-clue-capacity-check", "maindata");
		String resMsg = fireRule.getNotValidMessage();
		if (!fireRule.isValid()) {
			throw new BusicenException(resMsg);
		}
	}

	public void checkCapacityquery(ParamPage<Map<String, Object>> mapParam) {
		Supplier<ListResult<Map<String, Object>>> supplier = ()->{
			ListResult<Map<String, Object>> result = new ListResult<Map<String, Object>>();
			try {
				String token = mapParam.getParam().get("token").toString();
				UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
				mapParam.getParam().put("dlrCode", userBusiEntity.getDlrCode());
				// 查询系统配置中的试乘试驾预约时间开关，APPOINTMENT_SWITCH
				String configValue = cacheDataFactory.querySysConfigValue("APPOINTMENT_SWITCH", token);

				// 默认可以预约当前时间段
				boolean isCan = true;
				if (!StringHelper.IsEmptyOrNull(configValue)) {
					// valueCode=0，不能预约当前时间段
					if ("0".equals(configValue)) {
						isCan = false;
					}
				}
				mapParam.getParam().put("isCan", isCan);
				// 首先先查询时间段
				List<Map<String, Object>> timeRangeList = sacAppointmentSheetMapper
						.selectCarCapacityTimeRange(mapParam.getParam());
				// 拼接查询条件
				String condition = "";
				for (Map<String, Object> map : timeRangeList) {
					condition = condition + ",MAX(IF(TT.CONFIG_VALUE_CODE = '" + map.get("configValueCode").toString()
							+ "', TT.CAPACITY_STATUS, NULL)) AS '" + map.get("configValueCode").toString() + "'";
				}
				mapParam.getParam().put("condition", condition);
				// 先查询
				Page<Map<String, Object>> page = new Page<Map<String, Object>>(mapParam.getPageIndex(),
						mapParam.getPageSize());
				List<Map<String, Object>> list = sacAppointmentSheetMapper.selectCarCapacity(mapParam.getParam(), page);
				page.setRecords(list);
				result = BusicenUtils.page2ListResult(page);
				// 将结果添加到mapParam
				mapParam.getParam().put("result", result);
				return result;
			} catch (Exception e) {
				e.printStackTrace();
				log.error("sacTestDriveCapacityQueryListBefore", e);
				throw e;
			}
		};
		 SwitchDbInvoke.invokeTidb(supplier);
		
	}

	/**
	 * 字段校验
	 * 
	 * @param mapParam
	 */
	public void checkValidate(Map<String, Object> mapParam) {
		// 通用字段校验
		ValidResultCtn fireRule = fireFieldRule.fireRule(mapParam, "csc-clue-appointment-sheet-check", "maindata");
		String resMsg = fireRule.getNotValidMessage();
		if (!fireRule.isValid()) {
			throw new BusicenException(resMsg);
		}
		// 普通试乘试驾时，字段校验
		if ("0".equals(mapParam.get("testType")) || "1".equals(mapParam.get("testType"))) {
			fireRule = fireFieldRule.fireRule(mapParam, "csc-clue-appointment-check-nomal", "maindata");
			resMsg = fireRule.getNotValidMessage();
		} else {
			// 深度试驾时，字段校验
			fireRule = fireFieldRule.fireRule(mapParam, "csc-clue-appointment-check-deep", "maindata");
			resMsg = fireRule.getNotValidMessage();
		}
		if (!fireRule.isValid()) {
			throw new BusicenException(resMsg);
		}
	}

	/**
	 * 检查预约时间是否合法
	 * 
	 * @param mapParam
	 * @throws Exception
	 */
	public void checkTime(Map<String, Object> mapParam) {
		try {
			Calendar date = Calendar.getInstance();
			// 普通试乘试驾时间校验
			if ("0".equals(mapParam.get("testType")) || "1".equals(mapParam.get("testType"))) {
				// 判断时间是否与内置表的时间一致，若是不符合则抛异常(appointmentTestTime)
//				Map<String, Object> param = new HashMap<String, Object>();
//				param.put("configValueCode", mapParam.get("appointmentTestTime"));
//				param.put("configCode", "DRIVE_TIME");
//				ParamPage<Map<String, Object>> paramPage = new ParamPage<Map<String, Object>>();
//				paramPage.setPageIndex(1);
//				paramPage.setPageSize(-1);
//				paramPage.setParam(param);
//				List<Map<String, Object>> result = sacDbInnerConfigService
//						.queryConfigList(paramPage, mapParam.get("token").toString()).getRows();
//
//				if (result.size() == 0) {
//					throw new BusicenException(message.get("APPOINTMENT-SHEET-05"));
//				}
				// 新增试乘试驾预约单的时候，验证预约时间是否合理
				// 判断日期是否是今天开始往后的
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
				String dateString = simpleDateFormat.format(date.getTime());
				if (simpleDateFormat.parse(dateString).after(simpleDateFormat.parse(mapParam.get("appointmentTestDate").toString()))) {
					throw new BusicenException(message.get("APPOINTMENT-SHEET-06"));
				}
				// 如果选择今天的日期，那时间段的开始时间只能大于当前的时间了
				if (simpleDateFormat.parse(dateString).equals(simpleDateFormat.parse(mapParam.get("appointmentTestDate").toString()))) {
					// 查询系统配置中的试乘试驾预约时间开关，APPOINTMENT_SWITCH
					String configValue = cacheDataFactory.querySysConfigValue("APPOINTMENT_SWITCH", String.valueOf(mapParam.get("token")));

					// 默认可以预约当前时间段
					boolean isCan = true;
					if (!StringHelper.IsEmptyOrNull(configValue)) {
						// valueCode=0，不能预约当前时间段
						if ("0".equals(configValue)) {
							isCan = false;
						}
					}
					//格式化
					DateFormat df = new SimpleDateFormat("HH:mm:ss");
					//获取当前时分
					int currentHour = date.get(Calendar.HOUR_OF_DAY);
					int currentMinute=date.get(Calendar.MINUTE);
					//当前时间
					Date currentTime=df.parse(currentHour+":"+currentMinute+":00");
					//预约时间段开始时间
					String startTime=mapParam.get("appointmentTestTime").toString().split("-")[0]+":00";
					Date appointStartTime=df.parse(startTime);
					//预约时间段结束时间
					String endTime=mapParam.get("appointmentTestTime").toString().split("-")[1]+":00";
					Date appointEndTime=df.parse(endTime);
					//当前时间不能大于等于时间段的开始时间
					if(currentTime.getTime()>=appointEndTime.getTime()) {
						throw new BusicenException(message.get("APPOINTMENT-SHEET-07"));
					}
					//如果不可以预约当前时间段,则当前时间要不在时间段内
					if (!isCan&&currentTime.getTime()>=appointStartTime.getTime()&&currentTime.getTime()<=appointEndTime.getTime()) {
						throw new BusicenException(message.get("APPOINTMENT-SHEET-17"));
					}
				}
			} else {
				// 深度试驾时间判断
				// 当前时间大于预约开始时间，抛异常
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				String dateString = simpleDateFormat.format(date.getTime());
				if (simpleDateFormat.parse(dateString).after(simpleDateFormat.parse(mapParam.get("appointmentStartTime").toString()))) {
					throw new BusicenException(message.get("APPOINTMENT-SHEET-11"));
				}
				// 开始时间大于等于结束时间，抛异常
				if (simpleDateFormat.parse(mapParam.get("appointmentStartTime").toString()).after(simpleDateFormat.parse(mapParam.get("appointmentEndTime").toString()))
						||simpleDateFormat.parse(mapParam.get("appointmentStartTime").toString()).equals(simpleDateFormat.parse(mapParam.get("appointmentEndTime").toString()))) {
					throw new BusicenException(message.get("APPOINTMENT-SHEET-12"));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusicenException(e.getMessage());
		}
	}

	/**
	 * 查重
	 * 
	 * @param mapParam
	 */
	public void checkRepeat(Map<String, Object> mapParam) {
		try {
			// 普通试乘试驾拼接开始时间与结束时间
			if ("0".equals(mapParam.get("testType")) || "1".equals(mapParam.get("testType"))) {
				String[] timeStrings = String.valueOf(mapParam.get("appointmentTestTime")).split("-");
				String appointmentStartTime = String.valueOf(mapParam.get("appointmentTestDate")) + " " + timeStrings[0]
						+ ":00";
				String appointmentEndTime = String.valueOf(mapParam.get("appointmentTestDate")) + " " + timeStrings[1]
						+ ":00";
				mapParam.put("appointmentStartTime", appointmentStartTime);
				mapParam.put("appointmentEndTime", appointmentEndTime);
			} else {
				mapParam.put("appointmentTestDate", "");
				mapParam.put("appointmentTestTime", "");
			}
			// 判断是新增还是修改
			Boolean updateFlag = false;
			if (!StringHelper.IsEmptyOrNull(mapParam.get("appointmentId"))) {
				// 数据库查询是否存在此id
				QueryWrapper<SacAppointmentSheet> queryWrapper = new QueryWrapper<SacAppointmentSheet>();
				queryWrapper.eq("APPOINTMENT_ID", mapParam.get("appointmentId"));
				List<SacAppointmentSheet> list = baseMapper.selectList(queryWrapper);
				if (list.size() > 0) {
					updateFlag = true;
					// 当该试乘试驾单已经开始试乘试驾了就不能修改了
					if ("1".equals(list.get(0).getIsTestDrive())) {
						throw new BusicenException(message.get("APPOINTMENT-SHEET-13"));
					}
					// 已经过期的试乘试驾预约单不能修改(跟进时不限制)
					Calendar date = Calendar.getInstance();
					SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					String dateString = simpleDateFormat.format(date.getTime());
					if (simpleDateFormat.parse(dateString).after(simpleDateFormat.parse(list.get(0).getAppointmentStartTime()))
							&&"0".equals(mapParam.get("isFollow"))) {
						throw new BusicenException(message.get("APPOINTMENT-SHEET-14"));
					}
				}
			}

			//查询用户所属专营店信息
			String token = String.valueOf(mapParam.get("token"));
			UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
			mapParam.put("dlrCode", userBusiEntity.getDlrCode());
			mapParam.put("dlrName", userBusiEntity.getDlrName());
			mapParam.put("dlrId", userBusiEntity.getDlrID());
			mapParam.put("reviewPersonId", userBusiEntity.getUserID());
			mapParam.put("reviewPersonName", userBusiEntity.getUserName());
			// 客户预约单查重:根据电话、预约试乘试驾日期、预约试乘试驾时间段、专营店编码查重
			// 普通试乘试驾查重
			int plateNumberCount = 0;
			mapParam.put("isCheckRepeak", true);
			mapParam.put("updateFlag", updateFlag);
			plateNumberCount = sacAppointmentSheetMapper.checkRepeat(mapParam);

			if (plateNumberCount > 0) {
				throw new BusicenException(message.get("APPOINTMENT-SHEET-01"));
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusicenException(e.getMessage());
		}
	}

	/**
	 * 判断线索是否存在，不存在则新建线索
	 * 
	 * @param mapParam
	 */
	public void checkCustomerClue(Map<String, Object> mapParam) {
		StopWatch stopWatch = new StopWatch("试乘试驾判断线索是否存在");
		
		try {
            Boolean updateFlag = (Boolean) mapParam.get("updateFlag");
            //新增时，需要判断线索是否存在
            if(!updateFlag) {
            	stopWatch.start("dlrClueCheckRepeat");
            	
            	ParamBase<Map<String, Object>> mapParamBase = new ParamBase<Map<String, Object>>();
    			Map<String, Object> param = new HashMap<String, Object>();
    			param.put("phone", mapParam.get("customerPhone"));
    			param.put("token", String.valueOf(mapParam.get("token")));
    			mapParamBase.setParam(param);
    			// 先查询线索是否存在，存在则存线索单号与顾客id
    			Map<String, Object> clue = (Map<String, Object>) sacClueInfoDlrService.dlrClueCheckRepeat(mapParamBase).getRows();
    			stopWatch.stop();
    			
    			Map<String, Object> dlrClue = new HashMap<String, Object>();
    			// 不存在则新增线索,map为空时并没有分配内存，所以不能对其put操作
    			if (clue == null) {
    				// 根据token获取用户信息
    				String token = mapParam.get("token").toString();
    				// 根据token获取当前用户信息
    				UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
    				ParamBase<Map<String, Object>> newParamBase = new ParamBase<Map<String, Object>>();
    				Map<String, Object> newParam = new HashMap<String, Object>();
    				newParam.put("custName", mapParam.get("customerName"));
    				newParam.put("phone", mapParam.get("customerPhone"));
    				newParam.put("token", mapParam.get("token"));
    				if (!StringHelper.IsEmptyOrNull(mapParam.get("intenLevelCode"))) {
    					newParam.put("intenLevelCode", mapParam.get("intenLevelCode"));
    					newParam.put("intenLevelName", mapParam.get("intenLevelName"));
    				}
    				newParam.put("intenCarTypeCode", mapParam.get("smallCarTypeCode"));
    				newParam.put("intenCarTypeName", mapParam.get("smallCarTypeName"));
    				newParam.put("infoChanMCode", "dlr.build");
    				newParam.put("infoChanMName", "门店自建");
    				newParam.put("channelCode", "dlr.build");
    				newParam.put("channelName", "门店自建");
    				newParam.put("businessHeatCode", mapParam.get("businessHeatCode"));
    				newParam.put("businessHeatName", mapParam.get("businessHeatName"));
    				newParam.put("planBuyDateName", mapParam.get("planBuyDateName"));
    				newParam.put("planBuyDate", mapParam.get("planBuyDate"));
//    				newParam.put("reviewPersonId", mapParam.get("reviewPersonId"));
//    				newParam.put("reviewPersonName", mapParam.get("reviewPersonName"));
    				newParam.put("genderCode", mapParam.get("customerSexCode"));
    				newParam.put("genderName", mapParam.get("customerSexName"));
    				newParam.put("reviewPersonId", userBusiEntity.getUserID());
    				newParam.put("reviewPersonName", userBusiEntity.getEmpName());
    				newParam.put("planReviewTime", LocalDateTime.now().plusDays(+1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
    				newParamBase.setParam(newParam);
    				
    				stopWatch.start("新建线索");
    				
    				// 新建线索
    				sacClueInfoDlrService.saveMap(newParamBase, String.valueOf(mapParam.get("token")));
    				
    				stopWatch.stop();
    				
    				dlrClue.put("serverOrder", newParamBase.getParam().get("serverOrder"));
    				dlrClue.put("custId", newParamBase.getParam().get("custId"));
    				dlrClue.put("intenLevelCode", newParamBase.getParam().get("intenLevelCode"));
    				dlrClue.put("intenLevelName", newParamBase.getParam().get("intenLevelName"));
    			} else {
    				dlrClue.put("serverOrder", clue.get("serverOrder"));
    				dlrClue.put("custId", clue.get("custId"));
    				dlrClue.put("intenLevelCode", clue.get("intenLevelCode"));
    				dlrClue.put("intenLevelName", clue.get("intenLevelName"));
    			}
    			// 获取客户信息
    			mapParam.put("dlrClueOrderNo", dlrClue.get("serverOrder"));
    			mapParam.put("customerId", dlrClue.get("custId"));
    			mapParam.put("intenLevelCode", dlrClue.get("intenLevelCode"));
    			mapParam.put("intenLevelName", dlrClue.get("intenLevelName"));
            }
            //不管新增还是修改，性别都能修改
            if(!StringHelper.IsEmptyOrNull(mapParam.get("customerSexCode"))) {
            	mapParam.put("customerSex", mapParam.get("customerSexCode"));
            }
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		System.out.println("试乘试驾判断线索是否存在:" +stopWatch.prettyPrint() +"毫秒");//;
		System.out.println("试乘试驾判断线索是否存在:" +stopWatch.getTotalTimeMillis() +"毫秒");//;
	}

	/**
	 * 预约人数阈值校验
	 * 
	 * @param mapParam
	 */
	public void checkThresholdValue(Map<String, Object> mapParam) {
		try {
			String token=String.valueOf(mapParam.get("token"));
			// 查询系统配置中的试乘试驾预约人数阈值设置，DRIVE_NUM_SWITCH
			String configValue="1";
			configValue = cacheDataFactory.querySysConfigValue("DRIVE_NUM_SWITCH", token);
			// 查询到配置时，做校验(排除更换门店情况)
			if (!StringHelper.IsEmptyOrNull(configValue)) {
				// 获取阈值
				int threshold = Integer.valueOf(configValue);
				// 查找同一时间这辆车已经被预约了多少人
				mapParam.put("isCheckRepeak", false);
				int testCount = sacAppointmentSheetMapper.checkRepeat(mapParam);
				if (testCount >= threshold) {
					throw new BusicenException(message.get("APPOINTMENT-SHEET-16"));
				}
				//查看这辆车这段时间内有没有被超长出库
				int longCount=sacAppointmentSheetMapper.checkLongRepeat(mapParam);
				if(longCount>0) {
					throw new BusicenException("该车辆这段时间被超长出库，不能预约");
				}
				
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void checkAppointmentCancelValidate(Map<String, Object> mapParam) {
		ValidResultCtn fireRule = fireFieldRule.fireRule(mapParam, "csc-clue-appointment-cancel-check", "maindata");
		String resMsg = fireRule.getNotValidMessage();
		if (!fireRule.isValid()) {
			throw new BusicenException(resMsg);
		}
	}

	public void checkAppointmentIdExits(Map<String, Object> mapParam) {
		try {
			String token = mapParam.get("token").toString();
			UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
			QueryWrapper<SacAppointmentSheet> queryWrapper = new QueryWrapper<SacAppointmentSheet>();
			queryWrapper.eq("APPOINTMENT_ID", mapParam.get("appointmentId")).eq("DLR_CODE",
					userBusiEntity.getDlrCode());
			// 判断主键是否存在
			List<SacAppointmentSheet> list = sacAppointmentSheetMapper.selectList(queryWrapper);
			if (list.size() == 0) {
				throw new BusicenException(message.get("APPOINTMENT-SHEET-08"));
			}
			// 已开始或已完成试驾的不能取消预约单
			if ("1".equals(list.get(0).getIsTestDrive())) {
				throw new BusicenException(message.get("APPOINTMENT-SHEET-09"));
			}
			// 已经过期的试乘试驾预约单不能修改（当前时间大于等于预约单的开始时间）
			Calendar date = Calendar.getInstance();
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String dateString = simpleDateFormat.format(date.getTime());
			if (simpleDateFormat.parse(dateString)
					.after(simpleDateFormat.parse(list.get(0).getAppointmentStartTime()))) {
				throw new BusicenException(message.get("APPOINTMENT-SHEET-10"));
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusicenException(e.getMessage());
		}
	}

	/**
	 * 取消预约单后删除试乘试驾单(若试驾单存在的话)
	 * 
	 * @param mapParam
	 */
	public void deleteTestDriveSheet(Map<String, Object> mapParam) {
		try {
			Map<String, Object> newParam=new HashMap<String, Object>();
			newParam.put("APPOINTMENT_ID", mapParam.get("appointmentId"));
			//根据预约单id查询试驾单
			List<SacTestDriveSheet> list=sacTestDriveSheetMapper.selectByMap(newParam);
			//若存在就将对应的试驾单改为不可用状态
			if(list.size()>0) {
				String token = mapParam.get("token").toString();
				// 删除试乘试驾单
				mapParam.put("isEnable", "0");
				mapParam.put("testDriveSheetId", list.get(0).getTestDriveSheetId());
				BusicenUtils.invokeUserInfo(mapParam, SOU.Update, token);
				sacTestDriveSheetMapper.updateSacTestDriveSheet(mapParam);
			}
		} catch (Exception e) {
			throw e;
		}
	}
}
