package com.ly.mp.csc.clue.service;
import java.util.Map;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.csc.clue.entities.RemoveRepeatConfig;

/**
 * <p>
 * 去重规则配置表 服务类
 * </p>
 *
 * @author ly-linliq
 * @since 2021-09-03
 */
public interface IRemoveRepeatConfigService extends IService<RemoveRepeatConfig> {

	/**
	* @Description: 潜客去重规则配置查询
	* @author: linliq
	* @date 2021/09/06 14:51:40
	* @param map
	* @return
	 */
	ListResult<Map<String,Object>> queryListRemoveRepeatConfig(ParamPage<Map<String,Object>> mapParam);
	
	/**
	* @Description: 潜客去重规则配置保存
	* @author: linliq
	* @date 2021/09/06 15:06:53
	* @param mapParam
	* @return
	 */
	EntityResult<Map<String, Object>> repeatRuleConfigSave(Map<String,Object> mapParam);
	
	
	
}