package com.ly.mp.csc.clue.controller;


import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.context.BusicenInvoker;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.service.ISacAppointmentSheetService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * <p>
 * 试乘试驾预约单表 前端控制器
 * </p>
 *
 * @author ly-linliq
 * @since 2021-10-15
 */
@Api(value = "试乘试驾预约单管理",tags = {"试乘试驾预约单管理"})
@RestController
@RequestMapping("/ly/sac/sacappointmentsheet")
public class SacAppointmentSheetController {
	
	@Autowired
	ISacAppointmentSheetService sacAppointmentSheetService;
	
	@ApiOperation(value = "试乘试驾预约单查询", notes = "试乘试驾预约单查询")
	@RequestMapping(value = "/appointmentsheetquerylist.do", method = RequestMethod.POST)
	public ListResult<Map<String, Object>> appointmentSheetQueryList(
			@RequestHeader(name = "authorization", required = false) String authentication,
			@RequestBody(required = false) ParamPage<Map<String, Object>> mapParam){
		mapParam.getParam().put("token", authentication);
		return BusicenInvoker.doList(()->sacAppointmentSheetService.appointmentSheetQueryList(mapParam)).result();
	}

	@ApiOperation(value = "试乘试驾预约单保存", notes = "试乘试驾预约单保存")
	@RequestMapping(value = "/appointmentsheetsave.do", method = RequestMethod.POST)
	public EntityResult<Map<String, Object>> appointmentSheetSave(@RequestHeader(name = "authorization", required = false) String authentication,
			@RequestBody(required = false) ParamBase<Map<String, Object>> mapParam) {
		mapParam.getParam().put("token", authentication);
		return BusicenInvoker.doEntity(() -> sacAppointmentSheetService.appointmentSheetSave(mapParam.getParam())).result();
	}
	
	@ApiOperation(value = "试乘试驾预约单取消", notes = "试乘试驾预约单取消")
	@RequestMapping(value = "/appointmentsheetcancel.do", method = RequestMethod.POST)
	public OptResult appointmentSheetCance(@RequestHeader(name = "authorization", required = false) String authentication,
			@RequestBody(required = false) ParamBase<Map<String, Object>> mapParam) {
		mapParam.getParam().put("token", authentication);
		return BusicenInvoker.doOpt(() -> sacAppointmentSheetService.appointmentSheetCancel(mapParam.getParam())).result();
	}
	
	
	@ApiOperation(value = "试乘试驾容量查询", notes = "试乘试驾容量查询")
	@RequestMapping(value = "/sactestdrivecapacityquerylist.do", method = RequestMethod.POST)
	public ListResult<Map<String, Object>> sacTestDriveCapacityQueryList(
			@RequestHeader(name = "authorization", required = false) String authentication,
			@RequestBody(required = false) ParamPage<Map<String, Object>> mapParam){
		mapParam.getParam().put("token", authentication);
		return BusicenInvoker.doList(()->sacAppointmentSheetService.sacTestDriveCapacityQueryList(mapParam)).result();
	}
}
