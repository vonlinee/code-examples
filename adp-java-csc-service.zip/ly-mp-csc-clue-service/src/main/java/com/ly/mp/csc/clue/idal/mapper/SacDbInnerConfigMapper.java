package com.ly.mp.csc.clue.idal.mapper;

import com.ly.mp.csc.clue.entities.SacDbInnerConfig;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;

import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 内置配置表 Mapper 接口
 * </p>
 *
 * @author ly-busicen
 * @since 2021-10-26
 */
public interface SacDbInnerConfigMapper extends BaseMapper<SacDbInnerConfig> {

	/**
     * 获取配置列表
     * @param page 分页参数
     * @param param 输入参数
     * @return List
     */
    List<Map<String, Object>> queryConfigList(IPage<Map<String, Object>> page, @Param("param")Map<String, Object> param);
    
	/**
	 * 插入
	 * @param mapParm
	 * @return
	 */
	public int insertSacDbInnerConfig(@Param("param")Map<String, Object> mapParm);
	
	/**
	 * 更新
	 * @param mapParm
	 * @return
	 */
	public int updateSacDbInnerConfig(@Param("param")Map<String, Object> mapParm);
}
