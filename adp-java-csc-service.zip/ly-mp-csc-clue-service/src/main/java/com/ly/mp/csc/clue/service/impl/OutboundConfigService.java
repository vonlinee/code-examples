package com.ly.mp.csc.clue.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegist;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegistor;
import com.ly.bucn.component.interceptor.annotation.Interceptor;
import com.ly.bucn.component.message.Message;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.busi.base.handler.BusicenUtils.SOU;
import com.ly.mp.busicen.rule.field.IFireFieldRule;
import com.ly.mp.busicen.rule.field.execution.ValidResultCtn;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.entities.OutboundConfig;
import com.ly.mp.csc.clue.idal.mapper.OutboundConfigMapper;
import com.ly.mp.csc.clue.service.IOutboundConfigService;

/**
 * <p>
 * 商机外呼配置表 服务实现类
 * </p>
 *
 * @author ly-linliq
 * @since 2021-09-06
 */
@Service
public class OutboundConfigService extends ServiceImpl<OutboundConfigMapper, OutboundConfig> implements IOutboundConfigService, InterceptorWrapperRegist {

	@Autowired
	OutboundConfigMapper outboundConfigMapper;
	@Autowired
	Message message;
	@Autowired
    IFireFieldRule fireFieldRule;
	
	@Override
	public ListResult<Map<String, Object>> queryListOutboundConfig(ParamPage<Map<String, Object>> mapParam) {
		ListResult<Map<String, Object>> result=new ListResult<Map<String,Object>>();
		try {
			int pageIndex=Integer.valueOf(mapParam.getPageIndex());
			int pageSize=Integer.valueOf(mapParam.getPageSize());

			Page<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);
			List<Map<String, Object>> list =outboundConfigMapper.selectOutboundConfig(page, mapParam.getParam());
			page.setRecords(list);
			result= BusicenUtils.page2ListResult(page);
		} catch (Exception e) {
			log.error("queryListOutboundConfig", e);
			throw e;
		}
		return result;
	}

	@Override
	@Interceptor("csc_clue_saveoutboundconfig")
	public OptResult outboundConfigSave(Map<String, Object> mapParam) {
		OptResult optResult=new OptResult();
		String token =String.valueOf(mapParam.get("token"));
		try {
			boolean updateFlag=(boolean) mapParam.get("updateFlag");
			//判断新增还是修改
			if(!updateFlag) {
				if(StringHelper.IsEmptyOrNull(mapParam.get("isEnable"))) {
					mapParam.put("isEnable", "1");
				}
				if(StringHelper.IsEmptyOrNull(mapParam.get("isOutbound"))) {
					mapParam.put("isOutbound", "1");
				}
				//生成主键
				mapParam.put("outboundConfigId", StringHelper.GetGUID());
				BusicenUtils.invokeUserInfo(mapParam, SOU.Save,token);
				int result=outboundConfigMapper.insertOutboundConfig(mapParam);
				if(result==0) {
					optResult.setMsg(message.get("OUTBOUND-CONFIG-01"));
					optResult.setResult("0");
				}else {
					optResult.setMsg(message.get("OUTBOUND-CONFIG-02"));
					optResult.setResult("1");
				}
			}else {
				BusicenUtils.invokeUserInfo(mapParam, SOU.Update,token);
				int result=outboundConfigMapper.updateOutboundConfig(mapParam);
				if(result==0) {
					optResult.setMsg(message.get("OUTBOUND-CONFIG-03"));
					optResult.setResult("0");
				}else {
					optResult.setMsg(message.get("OUTBOUND-CONFIG-04"));
					optResult.setResult("1");
				}
			}
		} catch (Exception e) {
			log.error("repeatRuleConfigSave",e);
			throw e;
			//throw new BusicenException(message.get("CLUE-SYSTECONFIGVALUE-01"));
		}
		return optResult;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void regist(InterceptorWrapperRegistor registor) {
		 registor.before("csc_clue_saveoutboundconfig_valid", (context, model)->{
	            checkValidate((Map<String,Object>)context.data().getP()[0]);
	        });
		 registor.before("csc_clue_saveoutboundconfig_exits", (context, model)->{
	            checkExits((Map<String,Object>)context.data().getP()[0]);
	        });
		 registor.before("csc_clue_saveoutboundconfig_repeat", (context, model)->{
	            checkRepeat((Map<String,Object>)context.data().getP()[0]);
	        });
	}
	
	 public void checkValidate(Map<String,Object> mapParam){
	        ValidResultCtn fireRule = fireFieldRule.fireRule(mapParam, "csc1001002", "maindata");
	        String resMsg = fireRule.getNotValidMessage();
	        if (!fireRule.isValid()){
	            throw new BusicenException(resMsg);
	        }
	    }
	 //判断主键是否存在
	 public void checkExits(Map<String,Object> mapParam){
		 try {
				boolean updateFlag = false;
				if(!StringHelper.IsEmptyOrNull(mapParam.get("outboundConfigId"))){
					int size = baseMapper.checkOutBoundExists((String)mapParam.get("outboundConfigId"));
					if (size > 0) {
						updateFlag = true;
					}else {
	                	throw new BusicenException(message.get("CLUE-REVIEWASSIGN-29"));
	                }
				}
				mapParam.put("updateFlag",updateFlag);
			}catch(Exception ex)
			{
				throw ex;
			}
	    }

	 public void checkRepeat(Map<String,Object> mapParam){
	        int check = outboundConfigMapper.checkRepeat(mapParam);
	        if(check>=1){
	            throw new BusicenException(message.get("CLUE-REVIEWASSIGN-11"));
	        }
	    }

}
