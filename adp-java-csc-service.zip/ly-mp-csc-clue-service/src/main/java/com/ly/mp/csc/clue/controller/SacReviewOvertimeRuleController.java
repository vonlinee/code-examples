package com.ly.mp.csc.clue.controller;

import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.context.BusicenInvoker;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.service.ISacReviewOvertimeRuleService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * com.ly.mp.csc.clue.controller.SacReviewOvertimeRuleController
 * 超期规则服务控制类
 * @author zhouhao
 * @date 2021/8/16 15:18
 */
@Api(value = "超时规则服务", tags = { "超时规则服务" })
@RestController
@RequestMapping(value = "/ly/sac/reviewovertimerule", produces = { MediaType.APPLICATION_JSON_VALUE })
public class SacReviewOvertimeRuleController {
	//注入服务
	@Autowired
	ISacReviewOvertimeRuleService sacReviewOvertimeRuleService;
	
	@ApiOperation(value="超时规则查询", notes="超时规则查询")
	@RequestMapping(value = "/querylist.do", method = RequestMethod.POST)
	public ListResult<Map<String,Object>> queryListReviewOvertimeRuleInfo(
			@RequestHeader(name = "authorization",required = false) String token,
			@RequestBody(required = false) ParamPage<Map<String,Object>> dataInfo){
		return BusicenInvoker.doList(()->sacReviewOvertimeRuleService.queryListReviewOvertimeRuleInfo(dataInfo,token)).result();
	}

	@ApiOperation(value="超时规则明细查询", notes="超时规则明细查询")
	@RequestMapping(value = "/querylistruled.do", method = RequestMethod.POST)
	public ListResult<Map<String,Object>> queryListReviewOvertimeRuleDInfo(
			@RequestHeader(name = "authorization",required = false) String token,
			@RequestBody(required = false) ParamPage<Map<String,Object>> dataInfo){
		dataInfo.getParam().put("token", token);
		return BusicenInvoker.doList(()->sacReviewOvertimeRuleService.queryListReviewOvertimeRuleDInfo(dataInfo)).result();
	}

	@ApiOperation(value="超时规则明细保存", notes="超时规则明细保存")
	@RequestMapping(value = "/saveruled.do", method = RequestMethod.POST)
	public OptResult saveReviewOvertimeRuleDInfo(
			@RequestHeader(name = "authorization",required = false) String token,
			@RequestBody(required = true)ParamBase<Map<String,Object>> dataInfo){
		return BusicenInvoker.doOpt(()->sacReviewOvertimeRuleService.saveReviewOvertimeRuleDInfo(dataInfo.getParam(), token)).result();
	}
	
	@ApiOperation(value="超时规则明细删除", notes="超时规则明细删除")
	@RequestMapping(value = "/deleteruled.do", method = RequestMethod.POST)
	public OptResult deleteReviewOvertimeRuleDInfo(
			@RequestHeader(name = "authorization",required = false) String token,
			@RequestBody(required = true)ParamBase<Map<String,Object>> dataInfo){
		return BusicenInvoker.doOpt(()->sacReviewOvertimeRuleService.deleteReviewOvertimeRuleDInfo(dataInfo.getParam(), token)).result();
	}

		
	@ApiOperation(value="超时规则保存", notes="超时规则设置保存")
	@RequestMapping(value = "/save.do", method = RequestMethod.POST)
	public OptResult saveReviewOvertimeRuleInfo(
			@RequestHeader(name = "authorization",required = false) String token,
			@RequestBody(required = true)ParamBase<Map<String,Object>> dataInfo){
		return BusicenInvoker.doOpt(()->sacReviewOvertimeRuleService.saveReviewOvertimeRuleInfo(dataInfo.getParam(), token)).result();
	}

	@ApiOperation(value="超时规则删除", notes="超时规则设置删除")
	@RequestMapping(value = "/delete.do", method = RequestMethod.POST)
	public OptResult deleteReviewOvertimeRuleInfo(
			@RequestHeader(name = "authorization",required = false) String token,
			@RequestBody(required = true) ParamBase<Map<String, Object>> dataInfo){
		return BusicenInvoker.doOpt(()->sacReviewOvertimeRuleService.deleteReviewOvertimeRuleInfo(dataInfo.getParam(), token)).result();
	}
}
