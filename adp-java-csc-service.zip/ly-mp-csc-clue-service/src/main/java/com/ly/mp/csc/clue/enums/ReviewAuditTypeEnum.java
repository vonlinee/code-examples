package com.ly.mp.csc.clue.enums;

/**
 * 回访审核类型 值列表BUCN_SH_TYPE
 * @author ly-shenyw
 *
 */
public enum ReviewAuditTypeEnum {
	/**
	 * 战败申请
	 */
	defeat("1","战败申请"),
	
	/**
	 * 失控申请
	 */
	notctrl("2","失控申请"),
	
	/**
	 * 无效申请
	 */
	invalid("3","无效申请");
	
	private String result;
	private String msg;
	
	private ReviewAuditTypeEnum(String result, String msg) {
		this.result = result;
		this.msg = msg;
	}

	public String getResult() {
		return result;
	}

	public String getMsg() {
		return msg;
	}
	
	//根据result获取枚举
	public static ReviewAuditTypeEnum fromString(String code) {
        for (ReviewAuditTypeEnum b : ReviewAuditTypeEnum.values()) {
            if (b.getResult().equalsIgnoreCase(code)) {
                return b;
            }
        }
        return null;
	}
}

