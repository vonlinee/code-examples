package com.ly.mp.csc.clue.entities;


import java.io.Serializable;
import java.time.LocalDateTime;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
/**
 * 划转申请表
 * t_sac_transfer_apply
 * @author ly-zhengzc
 * @since 2021-12-14
 */
@TableName(value = "t_sac_transfer_apply")
public class SacTransferApply implements Serializable {
	private static final long serialVersionUID = 1L;

	/** 申请ID */
	@TableId("APPLY_ID")
	private String applyId;

	/** 业务单号 */
	@TableField("BILL_CODE")
	private String billCode;

	/** 客户ID */
	@TableField("CUST_ID")
	private String custId;

	/** 客户名称 */
	@TableField("CUST_NAME")
	private String custName;

	/** 联系号码 */
	@TableField("PHONE")
	private String phone;

	/** 调出门店编码 */
	@TableField("OUT_DLR_CODE")
	private String outDlrCode;

	/** 调出门店名称 */
	@TableField("OUT_DLR_NAME")
	private String outDlrName;

	/** 调入门店编码 */
	@TableField("IN_DLR_CODE")
	private String inDlrCode;

	/** 调入门店名称 */
	@TableField("IN_DLR_NAME")
	private String inDlrName;

	/** 申请原因 */
	@TableField("APPLY_DESC")
	private String applyDesc;

	/** 扩展字段1 */
	@TableField("COLUMN1")
	private String column1;

	/** 扩展字段2 */
	@TableField("COLUMN2")
	private String column2;

	/** 扩展字段3 */
	@TableField("COLUMN3")
	private String column3;

	/** 扩展字段4 */
	@TableField("COLUMN4")
	private String column4;

	/** 扩展字段5 */
	@TableField("COLUMN5")
	private String column5;

	/** 扩展字段6 */
	@TableField("COLUMN6")
	private String column6;

	/** 扩展字段7 */
	@TableField("COLUMN7")
	private String column7;

	/** 扩展字段8 */
	@TableField("COLUMN8")
	private String column8;

	/** 扩展字段9 */
	@TableField("COLUMN9")
	private String column9;

	/** 扩展字段10 */
	@TableField("COLUMN10")
	private String column10;

	/** JSON扩展字段 */
	@TableField("EXTENDS_JSON")
	private String extendsJson;

	/** 厂商标识ID */
	@TableField("OEM_ID")
	private String oemId;

	/** 集团标识ID */
	@TableField("GROUP_ID")
	private String groupId;

	/** 创建人ID */
	@TableField("CREATOR")
	private String creator;

	/** 创建人 */
	@TableField("CREATED_NAME")
	private String createdName;

	/** 创建日期 */
	@TableField("CREATED_DATE")
	private LocalDateTime createdDate;

	/** 修改人ID */
	@TableField("MODIFIER")
	private String modifier;

	/** 修改人 */
	@TableField("MODIFY_NAME")
	private String modifyName;

	/** 最后更新日期 */
	@TableField("LAST_UPDATED_DATE")
	private LocalDateTime lastUpdatedDate;

	/** 是否可用 */
	@TableField("IS_ENABLE")
	private String isEnable;

	/** 并发控制ID */
	@TableField("UPDATE_CONTROL_ID")
	private String updateControlId;

	public String getApplyId() {
		return applyId;
	}

	public String getBillCode() {
		return billCode;
	}

	public String getCustId() {
		return custId;
	}

	public String getCustName() {
		return custName;
	}

	public String getPhone() {
		return phone;
	}

	public String getOutDlrCode() {
		return outDlrCode;
	}

	public String getOutDlrName() {
		return outDlrName;
	}

	public String getInDlrCode() {
		return inDlrCode;
	}

	public String getInDlrName() {
		return inDlrName;
	}

	public String getApplyDesc() {
		return applyDesc;
	}

	public String getColumn1() {
		return column1;
	}

	public String getColumn2() {
		return column2;
	}

	public String getColumn3() {
		return column3;
	}

	public String getColumn4() {
		return column4;
	}

	public String getColumn5() {
		return column5;
	}

	public String getColumn6() {
		return column6;
	}

	public String getColumn7() {
		return column7;
	}

	public String getColumn8() {
		return column8;
	}

	public String getColumn9() {
		return column9;
	}

	public String getColumn10() {
		return column10;
	}

	public String getExtendsJson() {
		return extendsJson;
	}

	public String getOemId() {
		return oemId;
	}

	public String getGroupId() {
		return groupId;
	}

	public String getCreator() {
		return creator;
	}

	public String getCreatedName() {
		return createdName;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public String getModifier() {
		return modifier;
	}

	public String getModifyName() {
		return modifyName;
	}

	public LocalDateTime getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public String getIsEnable() {
		return isEnable;
	}

	public String getUpdateControlId() {
		return updateControlId;
	}

	public void setApplyId(String applyId) {
		this.applyId = applyId;
	}

	public void setBillCode(String billCode) {
		this.billCode = billCode;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public void setOutDlrCode(String outDlrCode) {
		this.outDlrCode = outDlrCode;
	}

	public void setOutDlrName(String outDlrName) {
		this.outDlrName = outDlrName;
	}

	public void setInDlrCode(String inDlrCode) {
		this.inDlrCode = inDlrCode;
	}

	public void setInDlrName(String inDlrName) {
		this.inDlrName = inDlrName;
	}

	public void setApplyDesc(String applyDesc) {
		this.applyDesc = applyDesc;
	}

	public void setColumn1(String column1) {
		this.column1 = column1;
	}

	public void setColumn2(String column2) {
		this.column2 = column2;
	}

	public void setColumn3(String column3) {
		this.column3 = column3;
	}

	public void setColumn4(String column4) {
		this.column4 = column4;
	}

	public void setColumn5(String column5) {
		this.column5 = column5;
	}

	public void setColumn6(String column6) {
		this.column6 = column6;
	}

	public void setColumn7(String column7) {
		this.column7 = column7;
	}

	public void setColumn8(String column8) {
		this.column8 = column8;
	}

	public void setColumn9(String column9) {
		this.column9 = column9;
	}

	public void setColumn10(String column10) {
		this.column10 = column10;
	}

	public void setExtendsJson(String extendsJson) {
		this.extendsJson = extendsJson;
	}

	public void setOemId(String oemId) {
		this.oemId = oemId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public void setCreatedName(String createdName) {
		this.createdName = createdName;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public void setModifier(String modifier) {
		this.modifier = modifier;
	}

	public void setModifyName(String modifyName) {
		this.modifyName = modifyName;
	}

	public void setLastUpdatedDate(LocalDateTime lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public void setIsEnable(String isEnable) {
		this.isEnable = isEnable;
	}

	public void setUpdateControlId(String updateControlId) {
		this.updateControlId = updateControlId;
	}

}
