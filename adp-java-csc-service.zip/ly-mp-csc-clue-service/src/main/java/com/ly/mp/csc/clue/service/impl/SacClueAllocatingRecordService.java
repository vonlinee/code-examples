package com.ly.mp.csc.clue.service.impl;

import java.util.List;
import java.util.Map;

import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busicen.common.constant.UserBusiEntity;
import com.ly.mp.busicen.common.context.BusicenContext;
import com.ly.mp.busicen.common.context.BusicenException;
import com.ly.mp.busicen.common.handler.ResultHandler;
import com.ly.mp.busicen.common.util.BusicenUtils;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.entities.SacClueAllocatingRecord;
import com.ly.mp.csc.clue.idal.mapper.SacClueAllocatingRecordMapper;
import com.ly.mp.csc.clue.service.ISacClueAllocatingRecordService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
//import io.seata.spring.annotation.GlobalTransactional;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;


/**
 * <p>
 * 线索分配记录表 服务实现类
 * </p>
 *
 * @author CaiYunXiang
 * @since 2022-05-24
 */
@Service
public class SacClueAllocatingRecordService extends ServiceImpl<SacClueAllocatingRecordMapper, SacClueAllocatingRecord> implements ISacClueAllocatingRecordService {

private Logger log = LoggerFactory.getLogger(SacClueAllocatingRecordService.class);
	
	@Autowired
	SacClueAllocatingRecordMapper sacClueAllocatingRecordMapper;
	
	
	/**
	 * 分页查询
	 */
	@Override
	public ListResult<Map<String, Object>> sacClueAllocatingRecordFindInfo(ParamPage<Map<String, Object>> dataInfo, String token){
		ListResult<Map<String, Object>> result = new ListResult<>();
		Map<String, Object> param = dataInfo.getParam();
		try {
			IPage<Map<String, Object>> page = new Page<>(dataInfo.getPageIndex(), dataInfo.getPageSize());
			List<Map<String, Object>> list = sacClueAllocatingRecordMapper.querySacClueAllocatingRecord(page, param);
			page.setRecords(list);
			result = ResultHandler.queryOk(page,list);

		} catch (Exception e) {
			log.error("sacClueAllocatingRecordFindInfo异常", e);
			//抛出RuntimeException，事务才会回滚
			throw new RuntimeException(e.getMessage());
		}
		return result;
	}
	
	
	/**
	 * 根据主键判断插入或更新
	 * @param info
	 * @return
	 */
	@Override
	@Transactional
	//@GlobalTransactional(name="sacClueAllocatingRecordSave")
	public OptResult sacClueAllocatingRecordSaveInfo(ParamBase<Map<String, Object>> dataInfo, String token){
		Map<String, Object> param = dataInfo.getParam();
		OptResult result = new OptResult();
		try {
			int sacClueAllocatingRecordI=0;
			UserBusiEntity entity = BusicenContext.getCurrentUserBusiInfo(token);
			//this.transFiled((String) null, dataInfo);
			if(dataInfo!=null) {
				//BusicenUtils.invokeUserInfo(dataInfo, SOU.Save, token);
				sacClueAllocatingRecordI = sacClueAllocatingRecordMapper.createSacClueAllocatingRecord(param,entity);
			}else {
				//BusicenUtils.invokeUserInfo(dataInfo, SOU.Update, token);
				sacClueAllocatingRecordI = sacClueAllocatingRecordMapper.updateSacClueAllocatingRecord(param);
			}
			if (sacClueAllocatingRecordI < 1) {
				throw BusicenException.create("线索分配记录表维护失败！");
			}
			result=ResultHandler.updateOk();
		} catch (Exception e) {
			log.error("sacClueAllocatingRecordSave", e);
			throw e;
		}
		return result;
	}
}
