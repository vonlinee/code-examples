package com.ly.mp.csc.clue.service;

import com.ly.mp.csc.clue.entities.SacTestDriveSheetHis;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 试乘试驾单表 服务类
 * </p>
 *
 * @author ly-linliq
 * @since 2021-12-13
 */
public interface ISacTestDriveSheetHisService extends IService<SacTestDriveSheetHis> {

}
