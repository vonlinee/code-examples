package com.ly.mp.csc.clue.entities;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.time.LocalDateTime;

/**
    * 渠道信息表
    */
@TableName(value = "t_sac_channel_info")
public class SacChannelInfo {
    /**
     * ID
     */
    @TableId(value = "ID", type = IdType.INPUT)
    private String id;

    /**
     * 渠道编码
     */
    @TableField(value = "CHANNEL_CODE")
    private String channelCode;

    /**
     * 父渠道编码
     */
    @TableField(value = "PARENT_CHANNEL_CODE")
    private String parentChannelCode;

    /**
     * 渠道名称
     */
    @TableField(value = "CHANNEL_NAME")
    private String channelName;

    /**
     * 渠道级别编码
     */
    @TableField(value = "CHANNEL_LEVEL_CODE")
    private String channelLevelCode;

    /**
     * 渠道级别名称
     */
    @TableField(value = "CHANNEL_LEVEL_NAME")
    private String channelLevelName;

    /**
     * 所属层级
     */
    @TableField(value = "LEVEL_CODE")
    private String levelCode;

    /**
     * 厂商标识ID
     */
    @TableField(value = "OEM_ID")
    private String oemId;

    /**
     * 集团标识ID
     */
    @TableField(value = "GROUP_ID")
    private String groupId;

    /**
     * 创建人ID
     */
    @TableField(value = "CREATOR")
    private String creator;

    /**
     * 创建人
     */
    @TableField(value = "CREATED_NAME")
    private String createdName;

    /**
     * 创建日期
     */
    @TableField(value = "CREATED_DATE")
    private LocalDateTime createdDate;

    /**
     * 修改人ID
     */
    @TableField(value = "MODIFIER")
    private String modifier;

    /**
     * 修改人
     */
    @TableField(value = "MODIFY_NAME")
    private String modifyName;

    /**
     * 最后更新日期
     */
    @TableField(value = "LAST_UPDATED_DATE")
    private LocalDateTime lastUpdatedDate;

    /**
     * 是否可用
     */
    @TableField(value = "IS_ENABLE")
    private String isEnable;

    /**
     * 并发控制ID
     */
    @TableField(value = "UPDATE_CONTROL_ID")
    private String updateControlId;

    /**
     * 获取ID
     *
     * @return ID - ID
     */
    public String getId() {
        return id;
    }

    /**
     * 设置ID
     *
     * @param id ID
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * 获取渠道编码
     *
     * @return CHANNEL_CODE - 渠道编码
     */
    public String getChannelCode() {
        return channelCode;
    }

    /**
     * 设置渠道编码
     *
     * @param channelCode 渠道编码
     */
    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    /**
     * 获取父渠道编码
     *
     * @return PARENT_CHANNEL_CODE - 父渠道编码
     */
    public String getParentChannelCode() {
        return parentChannelCode;
    }

    /**
     * 设置父渠道编码
     *
     * @param parentChannelCode 父渠道编码
     */
    public void setParentChannelCode(String parentChannelCode) {
        this.parentChannelCode = parentChannelCode;
    }

    /**
     * 获取渠道名称
     *
     * @return CHANNEL_NAME - 渠道名称
     */
    public String getChannelName() {
        return channelName;
    }

    /**
     * 设置渠道名称
     *
     * @param channelName 渠道名称
     */
    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    /**
     * 获取渠道级别编码
     *
     * @return CHANNEL_LEVEL_CODE - 渠道级别编码
     */
    public String getChannelLevelCode() {
        return channelLevelCode;
    }

    /**
     * 设置渠道级别编码
     *
     * @param channelLevelCode 渠道级别编码
     */
    public void setChannelLevelCode(String channelLevelCode) {
        this.channelLevelCode = channelLevelCode;
    }

    /**
     * 获取渠道级别名称
     *
     * @return CHANNEL_LEVEL_NAME - 渠道级别名称
     */
    public String getChannelLevelName() {
        return channelLevelName;
    }

    /**
     * 设置渠道级别名称
     *
     * @param channelLevelName 渠道级别名称
     */
    public void setChannelLevelName(String channelLevelName) {
        this.channelLevelName = channelLevelName;
    }

    /**
     * 获取所属层级
     *
     * @return LEVEL_CODE - 所属层级
     */
    public String getLevelCode() {
        return levelCode;
    }

    /**
     * 设置所属层级
     *
     * @param levelCode 所属层级
     */
    public void setLevelCode(String levelCode) {
        this.levelCode = levelCode;
    }

    /**
     * 获取厂商标识ID
     *
     * @return OEM_ID - 厂商标识ID
     */
    public String getOemId() {
        return oemId;
    }

    /**
     * 设置厂商标识ID
     *
     * @param oemId 厂商标识ID
     */
    public void setOemId(String oemId) {
        this.oemId = oemId;
    }

    /**
     * 获取集团标识ID
     *
     * @return GROUP_ID - 集团标识ID
     */
    public String getGroupId() {
        return groupId;
    }

    /**
     * 设置集团标识ID
     *
     * @param groupId 集团标识ID
     */
    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    /**
     * 获取创建人ID
     *
     * @return CREATOR - 创建人ID
     */
    public String getCreator() {
        return creator;
    }

    /**
     * 设置创建人ID
     *
     * @param creator 创建人ID
     */
    public void setCreator(String creator) {
        this.creator = creator;
    }

    /**
     * 获取创建人
     *
     * @return CREATED_NAME - 创建人
     */
    public String getCreatedName() {
        return createdName;
    }

    /**
     * 设置创建人
     *
     * @param createdName 创建人
     */
    public void setCreatedName(String createdName) {
        this.createdName = createdName;
    }

    /**
     * 获取创建日期
     *
     * @return CREATED_DATE - 创建日期
     */
    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    /**
     * 设置创建日期
     *
     * @param createdDate 创建日期
     */
    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * 获取修改人ID
     *
     * @return MODIFIER - 修改人ID
     */
    public String getModifier() {
        return modifier;
    }

    /**
     * 设置修改人ID
     *
     * @param modifier 修改人ID
     */
    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    /**
     * 获取修改人
     *
     * @return MODIFY_NAME - 修改人
     */
    public String getModifyName() {
        return modifyName;
    }

    /**
     * 设置修改人
     *
     * @param modifyName 修改人
     */
    public void setModifyName(String modifyName) {
        this.modifyName = modifyName;
    }

    /**
     * 获取最后更新日期
     *
     * @return LAST_UPDATED_DATE - 最后更新日期
     */
    public LocalDateTime getLastUpdatedDate() {
        return lastUpdatedDate;
    }

    /**
     * 设置最后更新日期
     *
     * @param lastUpdatedDate 最后更新日期
     */
    public void setLastUpdatedDate(LocalDateTime lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }

    /**
     * 获取是否可用
     *
     * @return IS_ENABLE - 是否可用
     */
    public String getIsEnable() {
        return isEnable;
    }

    /**
     * 设置是否可用
     *
     * @param isEnable 是否可用
     */
    public void setIsEnable(String isEnable) {
        this.isEnable = isEnable;
    }

    /**
     * 获取并发控制ID
     *
     * @return UPDATE_CONTROL_ID - 并发控制ID
     */
    public String getUpdateControlId() {
        return updateControlId;
    }

    /**
     * 设置并发控制ID
     *
     * @param updateControlId 并发控制ID
     */
    public void setUpdateControlId(String updateControlId) {
        this.updateControlId = updateControlId;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", channelCode=").append(channelCode);
        sb.append(", parentChannelCode=").append(parentChannelCode);
        sb.append(", channelName=").append(channelName);
        sb.append(", channelLevelCode=").append(channelLevelCode);
        sb.append(", channelLevelName=").append(channelLevelName);
        sb.append(", levelCode=").append(levelCode);
        sb.append(", oemId=").append(oemId);
        sb.append(", groupId=").append(groupId);
        sb.append(", creator=").append(creator);
        sb.append(", createdName=").append(createdName);
        sb.append(", createdDate=").append(createdDate);
        sb.append(", modifier=").append(modifier);
        sb.append(", modifyName=").append(modifyName);
        sb.append(", lastUpdatedDate=").append(lastUpdatedDate);
        sb.append(", isEnable=").append(isEnable);
        sb.append(", updateControlId=").append(updateControlId);
        sb.append("]");
        return sb.toString();
    }
}