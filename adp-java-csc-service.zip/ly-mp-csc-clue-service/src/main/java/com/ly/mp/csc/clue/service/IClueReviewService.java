package com.ly.mp.csc.clue.service;

import java.util.Map;

import com.ly.mp.component.entities.EntityResult;

public interface IClueReviewService {
	EntityResult<Map<String, Object>> review(Map<String, Object> reviewMap,String token);
}
