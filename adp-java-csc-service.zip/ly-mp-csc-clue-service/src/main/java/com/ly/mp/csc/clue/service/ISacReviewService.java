package com.ly.mp.csc.clue.service;

import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.entities.SacReview;


/**
 * com.ly.mp.csc.clue.service.ISacReviewService
 * 回访任务接口类
 * @author zhouhao
 * @date 2021/8/20 10:07
 */
public interface ISacReviewService extends IService<SacReview>{

	/**
     * 生成回访任务
     * @param map
     * @param token
     * @return
     */
    EntityResult<Map<String,Object>> addTask(Map<String,Object> map,String token);
    
    /**
     * 计算超时时间
     * @param type 1首次回访，2二次回访
     * @param map{orgCode,billType,businessType,channelCode,planReviewTime}
     * @param token
     * @return
     */
    String queryOverTime(String type, Map<String, Object> map,String token);
    
    /**
     * 回访表扩展字段转换
     * @param oldJson 原来保存的json
     * @param 新的要保存的map
     * @return
     */
    Map<String, Object> transFiled(String oldJson,Map<String, Object> map);
    
    /**
     * 本人待回访任务查询
     * @param token token
     * @param map 输入参数
     * @return ListResult
     */
    ListResult<Map<String,Object>> queryListMeReviewInfo(ParamPage<Map<String,Object>> map, String token);

    /**
     * 本人待回访任务导出
     * @param resopnse
     */
    OptResult exportListMeReviewInfo(ParamBase<Map<String,Object>> dataInfo, String token,HttpServletResponse response);
   
    /**
     * 本组待回访任务查询
     * @param token token
     * @param map 输入参数
     * @return ListResult
     */
    ListResult<Map<String,Object>> queryListGroupReviewInfo(ParamPage<Map<String,Object>> map, String token);
    
    
    /**
     * 本组待回访任务导出
     * @param dataInfo
     * @param token
     * @param response
     * @return
     */
    OptResult exportListGroupReviewInfo(ParamBase<Map<String,Object>> dataInfo, String token,HttpServletResponse response);
    /**
     * 待审核任务查询
     * @param token token
     * @param map 输入参数
     * @return ListResult
     */
    ListResult<Map<String,Object>> queryListAuditReviewInfo(ParamPage<Map<String,Object>> map, String token);

    /**
     * 回访审核任务查询
     * @param token token
     * @param map 输入参数
     * @return ListResult
     */
    ListResult<Map<String,Object>> queryListAuditReviewRecordInfo(ParamPage<Map<String,Object>> map, String token);

    /**
     * 获取当天人员的回访任务数 按任务数量顺序排
     * @param page 分页参数
     * @param param 输入参数
     * @return List
     */
    ListResult<Map<String, Object>> queryTaskNumByPerson(ParamPage<Map<String, Object>> map, String token);
    
    /**
     * 回访记录查询
     * @param token token
     * @param map 输入参数
     * @return ListResult
     */
    ListResult<Map<String,Object>> queryReviewRecord(ParamPage<Map<String,Object>> map, String token);
    
    /**
	 * 回访详情查询
	 *
	 * @param token token
	 * @param map   输入参数
	 * @return ListResult
	 */
	ListResult<Map<String, Object>> queryReviewInfoById(ParamPage<Map<String, Object>> map,String token); 
	
    /**
     * 回访任务分配
     * @param map 输入参数
     * @param token token
     * @return OptResult
     */
    OptResult reviewAssign(Map<String,Object> map, String token);
    
    /**
	 * 自动平均分配
	 * @param map
	 * @param token
	 * @return
	 */
	OptResult reviewAutoAssign(Map<String, Object> map, String token);
	
    /**
	 * 回访抢单
	 * @param reviewMap
	 * @param token
	 */
    EntityResult<Map<String, Object>> qiangdan(Map<String, Object> reviewMap,String token);
	
    /**
	 * 根据主键判断插入或更新
	 * @param info
	 * @return
	 */
	EntityResult<Map<String, Object>> sacReviewSave(Map<String, Object> mapParam, String token);
	
	/**
	 * 更新回访表
	 * @param info
	 * @return
	 */
	EntityResult<Map<String, Object>> sacReviewUpdate(Map<String, Object> mapParam, String token);
	
	/**
	 * 获取下次回访时间
	 * @param map
	 * @param token
	 * @return
	 */
	OptResult getNextReviewTime (Map<String,Object> map, String token);
	
}
