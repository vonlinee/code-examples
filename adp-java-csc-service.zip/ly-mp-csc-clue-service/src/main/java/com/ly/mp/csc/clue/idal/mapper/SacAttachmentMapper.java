package com.ly.mp.csc.clue.idal.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ly.mp.csc.clue.entities.SacAttachment;


/**
 * 附件表 Mapper接口
 * t_sac_attachment
 * @author ly-zhengzc
 * @since 2021-12-9
 */
public interface SacAttachmentMapper extends BaseMapper<SacAttachment> {

	/**
	 * 插入
	 * @param mapParm
	 * @return
	 */
	public int insertSacAttachment(@Param("param")Map<String, Object> mapParm);
	/**
	 * 更新
	 * @param mapParm
	 * @return
	 */
	public int updateSacAttachment(@Param("param")Map<String, Object> mapParm);
	/**
	 * 分页查询
	 * @param page
	 * @param param
	 * @return
	 */
	List<Map<String, Object>> selectByPage(Page<Map<String, Object>> page, @Param("param")Map<String, Object> param);

}
