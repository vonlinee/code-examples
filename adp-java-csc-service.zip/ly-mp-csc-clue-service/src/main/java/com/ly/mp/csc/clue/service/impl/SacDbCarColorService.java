package com.ly.mp.csc.clue.service.impl;


import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.csc.clue.entities.DbCarColor;
import com.ly.mp.csc.clue.idal.mapper.SacDbCarColorMapper;
import com.ly.mp.csc.clue.service.ISacDbCarColorService;

/**
 * <p>
 * 车身颜色 服务实现类
 * </p>
 *
 * @author ly-linliq
 * @since 2021-09-07
 */
@Service
@Transactional
public class SacDbCarColorService extends ServiceImpl<SacDbCarColorMapper, DbCarColor> implements ISacDbCarColorService {

	@Autowired
	SacDbCarColorMapper sacDbCarColorMapper;
	
	@Override
	public ListResult<Map<String, Object>> carColorQuery(ParamPage<Map<String, Object>> mapParam) {
		ListResult<Map<String, Object>> result=new ListResult<Map<String,Object>>();
		try {
			int pageIndex=Integer.valueOf(mapParam.getPageIndex());
			int pageSize=Integer.valueOf(mapParam.getPageSize());
			Page<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);
			List<Map<String, Object>> list =sacDbCarColorMapper.selectDbCarColor(page, mapParam.getParam());
			page.setRecords(list);
			result= BusicenUtils.page2ListResult(page);
			
		} catch (Exception e) {
			log.error("carColorQuery", e);
			throw e;
		}
		return result;
	}
}
