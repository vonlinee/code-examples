package com.ly.mp.csc.clue.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.busi.base.handler.BusicenUtils.SOU;
import com.ly.mp.busi.base.handler.ResultHandler;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.entities.SacFieldMappingConfig;
import com.ly.mp.csc.clue.entities.in.FieldMappingIn;
import com.ly.mp.csc.clue.entities.out.FieldMappingOut;
import com.ly.mp.csc.clue.idal.mapper.SacFieldMappingConfigMapper;
import com.ly.mp.csc.clue.service.ISacFieldMappingConfigService;

/**
 * <p>
 * 扩展字段配置表 服务实现类
 * </p>
 *
 * @author ly-busicen
 * @since 2021-08-17
 */
@Service
public class SacFieldMappingConfigService extends ServiceImpl<SacFieldMappingConfigMapper, SacFieldMappingConfig>
implements ISacFieldMappingConfigService {

	private Logger log = LoggerFactory.getLogger(SacFieldMappingConfigService.class);

	@Autowired
	SacFieldMappingConfigMapper sacFieldMappingConfigMapper;

	/**
	 * 根据输入参数，返回数据库对应的字段
	 */
	@Override
	public FieldMappingOut tranField(FieldMappingIn info) {
		// 校验参数
		checkParam(info);
		FieldMappingOut outInfo = new FieldMappingOut();
		Map<String, Object> targetMap = new HashMap<>();

		if (info.getParam() != null && info.getParam().size() > 0) {
			Map<String, Object> paramMap = info.getParam();
			JSONObject columnJson = new JSONObject();
			//先获取原来保存的json
			if(!StringHelper.IsEmptyOrNull(info.getOldJson())){
				JSONObject oldJson = JSON.parseObject(info.getOldJson());
				columnJson.putAll(oldJson);
			}
			// 获取配置的映射字段信息
			QueryWrapper<SacFieldMappingConfig> wraper = new QueryWrapper<>();
			wraper.lambda().eq(SacFieldMappingConfig::getSourceTableCode, info.getSourceTableCode());
			wraper.lambda().eq(SacFieldMappingConfig::getBillType, info.getBillType());
			//-1或传入的businessType
			wraper.lambda().and(cs->cs.eq(SacFieldMappingConfig::getBusinessType, info.getBusinessType()).or().eq(SacFieldMappingConfig::getBusinessType, "-1"));
			wraper.lambda().eq(SacFieldMappingConfig::getIsEnable, "1");
			List<SacFieldMappingConfig> list = sacFieldMappingConfigMapper.selectList(wraper);

			for (int i = 0; i < list.size(); i++) {
				if (paramMap.containsKey(list.get(i).getMappingFiledCode())) {
					if ("1".equals(list.get(i).getFiledType())) {
						// 处理普通映射字段
						targetMap.put(list.get(i).getFiledCode(), paramMap.get(list.get(i).getMappingFiledCode()));
					} else if ("2".equals(list.get(i).getFiledType())) {
						// 处理json字段
						columnJson.put(list.get(i).getFiledCode(), paramMap.get(list.get(i).getMappingFiledCode()));
					}
				}
			}
			outInfo.setTargetFields(targetMap);
			outInfo.setTargetJson(columnJson.toJSONString());
		}
		return outInfo;
	}
	
	/**
	 * 根据输入参数，返回数据库对应的字段 json字段不处理
	 */
	//@Override
	public FieldMappingOut unTranField(FieldMappingIn info) {
		// 校验参数
		checkParam(info);
		FieldMappingOut outInfo = new FieldMappingOut();
		Map<String, Object> targetMap = new HashMap<>();

		if (info.getParam() != null && info.getParam().size() > 0) {
			Map<String, Object> paramMap = info.getParam();

			// 获取配置的映射字段信息
			QueryWrapper<SacFieldMappingConfig> wraper = new QueryWrapper<>();
			wraper.lambda().eq(SacFieldMappingConfig::getSourceTableCode, info.getSourceTableCode());
			wraper.lambda().eq(SacFieldMappingConfig::getBillType, info.getBillType());
			//-1或传入的businessType
			wraper.lambda().and(cs->cs.eq(SacFieldMappingConfig::getBusinessType, info.getBusinessType()).or().eq(SacFieldMappingConfig::getBusinessType, "-1"));
			wraper.lambda().eq(SacFieldMappingConfig::getIsEnable, "1");
			List<SacFieldMappingConfig> list = sacFieldMappingConfigMapper.selectList(wraper);

			for (int i = 0; i < list.size(); i++) {
				if (paramMap.containsKey(list.get(i).getFiledCode())) {
					if ("1".equals(list.get(i).getFiledType())) {
						// 处理普通映射字段
						targetMap.put(list.get(i).getMappingFiledCode(), paramMap.get(list.get(i).getFiledCode()));
					}
				}
			}
			outInfo.setTargetFields(targetMap);
		}
		return outInfo;
	}
	
	/**
	 * 将参数转换为数据库字段
	 * 字段转换后返回MAP 返回的json字段对应键值 为extendsJson
	 * @param info
	 * @return 
	 */
	@Override
	public Map<String, Object> tranFieldToMap(FieldMappingIn info) {
		Map<String, Object> returnMap = new HashMap<>();
		
		FieldMappingOut fieldOut = tranField(info);
		//获取转换的普通字段
		Map<String, Object> filedMap = fieldOut.getTargetFields();
		if(filedMap!=null && filedMap.size()>0){
			returnMap.putAll(filedMap);
		}
		//获取转换的JSON字段
		String jsonFile = fieldOut.getTargetJson();
		if(!StringHelper.IsEmptyOrNull(jsonFile)){
			returnMap.put("extendsJson", jsonFile);
		}
		
		return returnMap;
	}
	
	/**
	 * 反转：将数据库字段转换为映射的参数字段
	 * 字段转换后返回MAP
	 * @param info
	 * @return 
	 */
	@Override
	public Map<String, Object> unTranFieldToMap(FieldMappingIn info) {
		Map<String, Object> returnMap = new HashMap<>();
		
		FieldMappingOut fieldOut = unTranField(info);
		//获取转换的普通字段
		Map<String, Object> filedMap = fieldOut.getTargetFields();
		if(filedMap!=null && filedMap.size()>0){
			returnMap.putAll(filedMap);
		}
		//获取转换的JSON字段
		String jsonFile = info.getOldJson();
		if(!StringHelper.IsEmptyOrNull(jsonFile)){
			returnMap.putAll(JSON.parseObject(jsonFile));
		}
		
		return returnMap;
	}
	
	/**
	 * 字段转换后返回MAP 返回的json字段对应键值 为extendsJson
	 * @param info
	 * @return 
	 */
	
	@Override
	public EntityResult<Map<String, Object>> tranFieldToMapTest(Map<String, Object> param) {
		try{
			FieldMappingIn info = new FieldMappingIn();
			info.setSourceTableCode(param.get("sourceTableCode").toString());
			info.setBillType(param.get("billType").toString());
			if(!StringHelper.IsEmptyOrNull(param.get("businessType"))){
				info.setBusinessType(param.get("businessType").toString());
			}else{
				info.setBusinessType("-1");
			}
			info.setParam(param);
			if(!StringHelper.IsEmptyOrNull(param.get("oldJson"))){
				info.setOldJson(param.get("oldJson").toString());
			}
			//获取转换的普通字段
			Map<String, Object> filedMap = tranFieldToMap(info);
			
			return ResultHandler.updateOk(filedMap);
		}catch (Exception e) {
			throw e;
		}
	}

	@Override
	public List<SacFieldMappingConfig> getList(FieldMappingIn info) {
		// 校验参数
		checkParam(info);
		// 获取配置的映射字段信息
		QueryWrapper<SacFieldMappingConfig> wraper = new QueryWrapper<>();
		wraper.lambda().eq(SacFieldMappingConfig::getSourceTableCode, info.getSourceTableCode());
		wraper.lambda().eq(SacFieldMappingConfig::getBillType, info.getBillType());
		wraper.lambda().eq(SacFieldMappingConfig::getBusinessType, info.getBusinessType());
		wraper.lambda().eq(SacFieldMappingConfig::getIsEnable, "1");
		List<SacFieldMappingConfig> list = sacFieldMappingConfigMapper.selectList(wraper);
		return list;
	}

	// 校验参数
	private void checkParam(FieldMappingIn info) {
		if (StringHelper.IsEmptyOrNull(info.getSourceTableCode())) {
			throw new BusicenException("源表编码不能为空");
		}
		if (StringHelper.IsEmptyOrNull(info.getBillType())) {
			throw new BusicenException("单据类型不能为空");
		}
		if (StringHelper.IsEmptyOrNull(info.getBusinessType())) {
			throw new BusicenException("业务类型不能为空");
		}
	}

	/**
	 * 根据主键判断插入或更新
	 *
	 * @param info
	 * @return
	 */
	@Override
	@Transactional
	public EntityResult<Map<String, Object>> sacFieldMappingConfigSave(Map<String, Object> mapParam, String token) {
		try {
			Boolean updateFlag = false;
			if (!StringHelper.IsEmptyOrNull(mapParam.get("id"))) {
				QueryWrapper<SacFieldMappingConfig> wrapper = new QueryWrapper<>();
				wrapper.lambda().eq(SacFieldMappingConfig::getId, mapParam.get("id"));
				if (list(wrapper).size() > 0) {
					updateFlag = true;
				}
			}
			if (!updateFlag) {
				// 新增
				if (StringHelper.IsEmptyOrNull(mapParam.get("id"))) {
					// 主键
					mapParam.put("id", UUID.randomUUID().toString());
				}
				BusicenUtils.invokeUserInfo(mapParam, SOU.Save, token);
				sacFieldMappingConfigMapper.insertSacFieldMappingConfig(mapParam);
			} else {
				// 更新
				BusicenUtils.invokeUserInfo(mapParam, SOU.Update, "");
				sacFieldMappingConfigMapper.updateSacFieldMappingConfig(mapParam);
			}
			return ResultHandler.updateOk(mapParam);
		} catch (Exception e) {
			log.error("sacFieldMappingConfigSave", e);
			throw e;
		}
	}

	public List<SacFieldMappingConfig> getFieldMappingList(String sourceTableCode, String billType, String businessType) {
		FieldMappingIn info = new FieldMappingIn();
		info.setSourceTableCode(sourceTableCode);
		info.setBillType(billType);
		info.setBusinessType(businessType);
		List<SacFieldMappingConfig> list = getList(info);
		return list;
	}

}
