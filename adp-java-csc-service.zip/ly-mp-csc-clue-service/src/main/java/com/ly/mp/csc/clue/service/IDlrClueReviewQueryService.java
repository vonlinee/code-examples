package com.ly.mp.csc.clue.service;

import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;

/**
 * 回访查询-DLRCLUE
 * 针对专营店线索回访查询
 * @author ly-shenyw
 *
 */
public interface IDlrClueReviewQueryService {
    
    /**
     * 本人待回访任务查询
     * @param token token
     * @param map 输入参数
     * @return ListResult
     */
    ListResult<Map<String,Object>> queryListMeReviewInfo(ParamPage<Map<String,Object>> map, String token);

    /**
     * 本人待回访任务导出
     * @param resopnse
     */
    OptResult exportListMeReviewInfo(ParamBase<Map<String,Object>> dataInfo, String token,HttpServletResponse response);

    /**
     * 本店待回访任务查询
     * @param token token
     * @param map 输入参数
     * @return ListResult
     */
    ListResult<Map<String,Object>> queryListByDlr(ParamPage<Map<String,Object>> map, String token);
    
    /**
     * 本店待回访任务导出
     * @param dataInfo
     * @param token
     * @param response
     * @return
     */
    OptResult exportListDlrReviewInfo(ParamBase<Map<String,Object>> dataInfo, String token,HttpServletResponse response);

    /**
     * 待审核任务查询
     * @param token token
     * @param map 输入参数
     * @return ListResult
     */
    ListResult<Map<String,Object>> queryListAuditReviewInfo(ParamPage<Map<String,Object>> map, String token);

    /**
     * 回访审核任务查询
     * @param token token
     * @param map 输入参数
     * @return ListResult
     */
    ListResult<Map<String,Object>> queryListAuditReviewRecordInfo(ParamPage<Map<String,Object>> map, String token);

    /**
     * 回访记录查询
     * @param token token
     * @param map 输入参数
     * @return ListResult
     */
    ListResult<Map<String,Object>> queryReviewRecord(ParamPage<Map<String,Object>> map, String token);
    
    /**
	 * 获取本店人员待回访数
	 * @param map
	 * @param token
	 * @return
	 */
	ListResult<Map<String, Object>> queryUserReviewNum(ParamPage<Map<String, Object>> map, String token);

}

