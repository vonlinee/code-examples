package com.ly.mp.csc.clue.idal.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.ly.mp.csc.clue.entities.SacTransferAudit;


/**
 * 划转审核表 Mapper接口
 * t_sac_transfer_audit
 * @author ly-zhengzc
 * @since 2021-12-10
 */
public interface SacTransferAuditMapper extends BaseMapper<SacTransferAudit> {

	/**
	 * 插入
	 * @param mapParm
	 * @return
	 */
	public int insertSacTransferAudit(@Param("param")Map<String, Object> mapParm);
	/**
	 * 更新
	 * @param mapParm
	 * @return
	 */
	public int updateSacTransferAudit(@Param("param")Map<String, Object> mapParm);
	/**
	 * 分页查询
	 * @param page
	 * @param param
	 * @return
	 */
	List<Map<String, Object>> selectByPage(IPage<Map<String, Object>> page, @Param("param")Map<String, Object> param);
}
