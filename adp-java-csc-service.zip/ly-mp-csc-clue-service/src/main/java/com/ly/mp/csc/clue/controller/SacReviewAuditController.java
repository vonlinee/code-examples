package com.ly.mp.csc.clue.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.busi.base.context.BusicenInvoker;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.service.ISacReviewAuditService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * com.ly.mp.csc.clue.controller.SacReviewAssignSetController
 * 回访审核服务控制类
 * @author zhouhao
 */
@Api(value = "回访审核服务", tags = { "回访审核服务" })
@RestController
@RequestMapping(value = "/ly/sac/reviewaudit", produces = { MediaType.APPLICATION_JSON_VALUE })
public class SacReviewAuditController {
	//注入服务
	@Autowired
	ISacReviewAuditService sacReviewAuditService;

	@ApiOperation(value="回访审核", notes="回访审核")
	@RequestMapping(value = "/audit.do", method = RequestMethod.POST)
	public OptResult saveReviewAssignInfo(
		@RequestHeader(name = "authorization",required = false) String token,
		@RequestBody(required = true) ParamBase<Map<String,Object>> dataInfo){
		dataInfo.getParam().put("article","csc-clue-review-check-0006");
		return BusicenInvoker.doOpt(() ->sacReviewAuditService.reviewAudit(dataInfo.getParam(), token)).result();
	}
	
	@ApiOperation(value="回访批量审核", notes="回访批量审核")
	@RequestMapping(value = "/auditbanch.do", method = RequestMethod.POST)
	public OptResult reviewAuditBanch(
		@RequestHeader(name = "authorization",required = false) String token,
		@RequestBody(required = true) ParamBase<Map<String,Object>> dataInfo){
		return BusicenInvoker.doOpt(() ->sacReviewAuditService.reviewAuditBanch(dataInfo.getParam(), token)).result();
	}
	
	@ApiOperation(value="回访审核撤回", notes="回访审核撤回")
	@RequestMapping(value = "/shenheCancle.do", method = RequestMethod.POST)
	public OptResult shenheCancle(
		@RequestHeader(name = "authorization",required = false) String token,
		@RequestBody(required = true) ParamBase<Map<String,Object>> dataInfo){
		return BusicenInvoker.doOpt(() ->sacReviewAuditService.shenheCancle(dataInfo.getParam(), token)).result();
	}
}
