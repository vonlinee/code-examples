package com.ly.mp.csc.clue.idal.mapper;


import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ly.mp.busicen.common.constant.UserBusiEntity;
import com.ly.mp.csc.clue.entities.SacClueAllocatingRecord;
import org.apache.ibatis.annotations.Param;
import com.baomidou.mybatisplus.core.metadata.IPage;

/**
 * <p>
 * 线索分配记录表 Mapper 接口
 * </p>
 *
 * @author CaiYunXiang
 * @since 2022-05-24
 */
public interface SacClueAllocatingRecordMapper extends BaseMapper<SacClueAllocatingRecord> {
	//线索分配记录表 信息查询
	List <Map<String, Object>> querySacClueAllocatingRecord(IPage<Map<String, Object>> page,@Param("param")Map <String, Object> paramMap);
	//线索分配记录表 信息新增
	int createSacClueAllocatingRecord (@Param("param") Map <String, Object> paramMap, @Param("entity") UserBusiEntity entity);
	//线索分配记录表 信息更新
	int updateSacClueAllocatingRecord (@Param("param") Map <String, Object> paramMap);
	//线索分配记录表 信息删除
	int deleteSacClueAllocatingRecord (@Param("param") Map <String, Object> paramMap);
}
