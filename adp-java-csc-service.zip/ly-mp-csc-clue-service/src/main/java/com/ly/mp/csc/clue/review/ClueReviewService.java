package com.ly.mp.csc.clue.review;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegist;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegistor;
import com.ly.bucn.component.interceptor.annotation.Interceptor;
import com.ly.bucn.component.strategy.runtime.ChooseContext;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.busicen.rule.field.IFireFieldRule;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.entities.SacReview;
import com.ly.mp.csc.clue.service.IClueReviewService;
import com.ly.mp.csc.clue.service.ISacDbReviewNodeRfService;
import com.ly.mp.csc.clue.service.ISacReviewService;

@Service
public class ClueReviewService implements IClueReviewService, InterceptorWrapperRegist{

	@Autowired
	ISacReviewService sacReviewService;
	@Autowired
	ISacDbReviewNodeRfService sacDbReviewNodeRfService;
	@Autowired
	IFireFieldRule fireFieldRule;
	
	/**
	 * 回访
	 * @param reviewMap
	 * @param token
	 */
	@Interceptor("csc_clue_review")
	@Override
	 @Transactional(rollbackFor=Exception.class)
	public EntityResult<Map<String, Object>> review(Map<String, Object> reviewMap,String token){
		try{
			//去掉空字符串
			//MapUtil.removeNullValue(reviewMap);
			//上次回访时间
			if(StringHelper.IsEmptyOrNull(reviewMap.get("lastReviewTime"))){
				reviewMap.put("lastReviewTime", LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
			}
			//获取回访单信息并赋值
			queryReviewInfo(reviewMap,token);
			//获取节点信息并赋值
			queryNodeInfo(reviewMap, token);
			//执行策略--根据场景码执行
			EntityResult<Map<String, Object>> result =  ChooseContext.chooseBeanOrDefault(String.format("clueReview%s", reviewMap.get("nodeCode").toString()), AbstractClueReview.class).review(reviewMap, token);
			return result;
		}catch (Exception e) {
			e.printStackTrace();
			throw BusicenException.create(e.getMessage());
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
    public void regist(InterceptorWrapperRegistor registor) {
        //回访前置：回访通用参数校验
        registor.before("csc_clue_review_common_check", (context, model)->{
        	reviewCheck((Map<String,Object>)context.data().getP()[0]);
        });
        
      	//回访后置
        registor.after("csc_clue_review_after", (context, model)->{
            reviewAfter((Map<String,Object>)context.data().getP()[0],(String)context.data().getP()[1]);
        });

    }

	/**
	 * 回访前置：回访通用参数校验
	 * @param reviewMap
	 */
	private void reviewCheck(Map<String, Object> reviewMap){
		fireFieldRule.fireRuleExcpt(reviewMap, "csc-clue-review-common-check", "maindata");
	}
	
	/**
	 * 回访后置
	 * @param mapParam
	 */
	public void reviewAfter(Map<String,Object> mapParam,String token) {

    }
	
	/**
	 * 获取回访单信息，并赋值
	 * @param reviewMap
	 * @param token
	 * @return
	 */
	private SacReview queryReviewInfo(Map<String, Object> reviewMap,String token){
		QueryWrapper<SacReview> query1 = new QueryWrapper<>();
		query1.lambda().eq(SacReview::getReviewId, reviewMap.get("reviewId").toString());
		SacReview reviewInfo = sacReviewService.getOne(query1);
		if(reviewInfo==null){
			throw BusicenException.create("该回访单不存在!");
		}else if(!reviewInfo.getUpdateControlId().equals(reviewMap.get("updateControlId").toString())){
			throw BusicenException.create("请刷新列表后重试!");
		}
		//参数赋值 计算超时，扩展字段用
//		reviewMap.put("orgCode", reviewInfo.getOrgCode());
//		reviewMap.put("orgName", reviewInfo.getOrgName());
		//Cai
		if(StringHelper.IsEmptyOrNull(reviewMap.get("orgCode")) || StringHelper.IsEmptyOrNull(reviewMap.get("orgName"))) {
			reviewMap.put("orgCode", reviewInfo.getOrgCode());
			reviewMap.put("orgName", reviewInfo.getOrgName());
		}
		reviewMap.put("billType", reviewInfo.getBillType());
		reviewMap.put("businessType", reviewInfo.getBusinessType());
		reviewMap.put("billCode", reviewInfo.getBillCode());
//		if(!StringHelper.IsEmptyOrNull(reviewInfo.getChannelCode())){
//			reviewMap.put("channelCode", reviewInfo.getChannelCode());
//			reviewMap.put("channelName", reviewInfo.getChannelName());
//		}
		reviewMap.put("oldJsonStr", reviewInfo.getExtendsJson());

		return reviewInfo;
	}
	
	/**
	 * 获取节点信息 ，并赋值
	 * @param reviewMap
	 * @param token
	 * @return
	 */
	private Map<String, Object> queryNodeInfo(Map<String, Object> reviewMap,String token){
		ParamPage<Map<String, Object>> map = new ParamPage<>();
		map.setPageIndex(1);
		map.setPageSize(1);
		Map<String,Object> param = new HashMap<>();
		param.put("billType", reviewMap.get("billType").toString());
		if(!StringHelper.IsEmptyOrNull(reviewMap.get("businessType"))){
			param.put("businessType", reviewMap.get("businessType").toString());
		}
		param.put("nodeCode", reviewMap.get("nodeCode").toString());
		map.setParam(param);
		ListResult<Map<String, Object>> result = sacDbReviewNodeRfService.queryReviewNodeRfList(map, token);
		if(result!=null && result.getRows()!=null && result.getRows().size()>0){
			//参数赋值
			reviewMap.put("nodeName", result.getRows().get(0).get("nodeName").toString());
			reviewMap.put("reviewStatus", result.getRows().get(0).get("statusCode").toString());
			reviewMap.put("reviewStatusName", result.getRows().get(0).get("statusName").toString());
			
			return result.getRows().get(0);
		}else{
			throw BusicenException.create("非法的场景码:"+reviewMap.get("nodeCode").toString());
		}
		
	}
	
}
