package com.ly.mp.csc.clue.controller;

import java.util.Arrays;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.context.BusicenInvoker;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.service.ISacAttachmentService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Api(value = "附件管理", tags = { "附件管理" })
@RestController
@RequestMapping(value = "/ly/sac/sacattachment")
public class SacAttachmentController {

	@Autowired ISacAttachmentService sacAttachmentService;

	@ApiOperation(value="附件上传",notes="附件上传")
	@RequestMapping(value="/attachmentadd.do",method=RequestMethod.POST)
	public EntityResult<Map<String, Object>> sacAttachmentAdd(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) ParamBase<Map<String, Object>> queryCondition) throws Exception{
		queryCondition.getParam().put("token", authentication);
		return BusicenInvoker.doEntity(()->sacAttachmentService.sacAttachmentAdd(queryCondition.getParam(), authentication)).result();
	}

	@ApiOperation(value="附件查询",notes="附件查询）")
	@RequestMapping(value="/attachmentquery.do",method=RequestMethod.POST)
	public ListResult<Map<String, Object>> attachmentQuery(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) ParamPage<Map<String, Object>> queryCondition) throws Exception{
		return BusicenInvoker.doList(()->{
			Assert.notNull(queryCondition.getParam(), "参数param不能为空");
			String billIds = (String)queryCondition.getParam().get("billIds");
			if(!StringHelper.IsEmptyOrNull(billIds)) {
				queryCondition.getParam().put("billIdList", Arrays.asList(StringUtils.split(billIds, ",")));
			}
			queryCondition.getParam().put("isEnable", "1");
			return sacAttachmentService.sacAttachmentQueryList(queryCondition, authentication);
		}).result();
	}

	@ApiOperation(value="附件删除",notes="附件删除")
	@RequestMapping(value="/attachmentdelete.do",method=RequestMethod.POST)
	public EntityResult<Map<String, Object>> sacAttachmentDelete(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) ParamBase<Map<String, Object>> queryCondition) throws Exception{
		queryCondition.getParam().put("token", authentication);
		return BusicenInvoker.doEntity(()->sacAttachmentService.sacAttachmentDelete(queryCondition.getParam(), authentication)).result();
	}
}
