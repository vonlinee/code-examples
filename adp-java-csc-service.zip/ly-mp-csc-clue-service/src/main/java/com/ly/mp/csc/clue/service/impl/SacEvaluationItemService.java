package com.ly.mp.csc.clue.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegist;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegistor;
import com.ly.bucn.component.interceptor.annotation.Interceptor;
import com.ly.bucn.component.message.Message;
import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.constant.UserBusiEntity;
import com.ly.mp.busi.base.context.BusicenContext;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.busi.base.handler.BusicenUtils.SOU;
import com.ly.mp.busi.base.handler.MapUtil;
import com.ly.mp.busi.base.handler.OptResultBuilder;
import com.ly.mp.busicen.rule.field.FireFieldRule;
import com.ly.mp.busicen.rule.field.execution.ValidResultCtn;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.entities.SacEvaluationItem;
import com.ly.mp.csc.clue.idal.mapper.SacEvaluationItemMapper;
import com.ly.mp.csc.clue.service.ISacEvaluationItemService;

/**
 * <p>
 * 选择项表 服务实现类
 * </p>
 *
 * @author ly-linliq
 * @since 2021-10-14
 */
@Service
public class SacEvaluationItemService extends ServiceImpl<SacEvaluationItemMapper, SacEvaluationItem>
		implements ISacEvaluationItemService, InterceptorWrapperRegist {

	@Autowired
	SacEvaluationItemMapper sacEvaluationItemMapper;
	@Autowired
	FireFieldRule fireFieldRule;
	@Autowired
	Message message;

	/**
	 * 选择项查询
	 */
	@Override
	public ListResult<Map<String, Object>> evaluationItemQueryList(ParamPage<Map<String, Object>> mapParam,
			String token) {
		ListResult<Map<String, Object>> result = new ListResult<Map<String, Object>>();
		try {
			ValidResultCtn fireRule = fireFieldRule.fireRule(mapParam.getParam(), "csc-clue-evaluation-item-check1", "maindata");
			String resMsg = fireRule.getNotValidMessage();
			if (!fireRule.isValid()) {
				throw new BusicenException(resMsg);
			}
			// 去掉空字符串
			MapUtil.removeNullValue(mapParam.getParam());
			if(StringHelper.IsEmptyOrNull(mapParam.getParam().get("dlrCode"))) {
				// 根据token获取当前用户信息
				UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
				mapParam.getParam().put("dlrCode", userBusiEntity.getDlrCode());
				mapParam.getParam().put("dlrName", userBusiEntity.getDlrName());
			}
			Page<Map<String, Object>> page = new Page<Map<String, Object>>(mapParam.getPageIndex(),
					mapParam.getPageSize());

			List<Map<String, Object>> list = sacEvaluationItemMapper.selectSacEvaluationItem(mapParam.getParam(), page);
			page.setRecords(list);
			result = BusicenUtils.page2ListResult(page);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("evaluationItemQueryList", e);
			throw e;
		}
		return result;
	}

	/**
	 * 选择项保存
	 */
	@Override
	@Interceptor("csc_clue_evaluation_item")
	public OptResult evaluationItemSave(ParamBase<Map<String, Object>> mapParam) {
		OptResult optResult=new OptResult();
		String token =String.valueOf(mapParam.getParam().get("token"));
		try {
			// 去掉空字符串
			MapUtil.removeNullValue(mapParam.getParam());
			Boolean updateFlag = false;
			if (!StringHelper.IsEmptyOrNull(mapParam.getParam().get("updateFlag"))) {
				updateFlag = (Boolean) mapParam.getParam().get("updateFlag");
			}
			// 新增
			if (!updateFlag) {
				if (StringHelper.IsEmptyOrNull(mapParam.getParam().get("evaluationItemId"))) {
					mapParam.getParam().put("evaluationItemId", StringHelper.GetGUID());
				}
				BusicenUtils.invokeUserInfo(mapParam.getParam(), SOU.Save, token);
				int result= sacEvaluationItemMapper.insertSacEvaluationItem(mapParam.getParam());
				if(result==0) {
					optResult.setMsg(message.get("EVALUATION-ITEM-02"));
					optResult.setResult("0");
					return optResult;
				}

			} else {
				// 修改
				BusicenUtils.invokeUserInfo(mapParam.getParam(), SOU.Update, token);
				int result=sacEvaluationItemMapper.updateSacEvaluationItem(mapParam.getParam());
				if(result==0) {
					optResult.setMsg(message.get("EVALUATION-ITEM-03"));
					optResult.setResult("0");
					return optResult;
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			log.error("DemoCarSave", e);
			throw e;
		}
		return OptResultBuilder.createOk().build();
	}

	/**
	 * 前后置方法
	 * 
	 * @param registor
	 */
	@Override
	@SuppressWarnings("unchecked")
	public void regist(InterceptorWrapperRegistor registor) {
		// 校验字段
		registor.before("csc_clue_evaluation_item_valid", (context, model) -> {
			checkValidate((ParamBase<Map<String, Object>>) context.data().getP()[0]);
		});
		// 校验是新增还是修改并查重
		registor.before("csc_clue_evaluation_item_repeat", (context, model) -> {
			checkRepeat((ParamBase<Map<String, Object>>) context.data().getP()[0]);
		});
	}

	/**
	 * 字段校验
	 * 
	 * @param mapParam
	 */
	public void checkValidate(ParamBase<Map<String, Object>> mapParam) {
		ValidResultCtn fireRule = fireFieldRule.fireRule(mapParam.getParam(), "csc-clue-evaluation-item-check", "maindata");
		String resMsg = fireRule.getNotValidMessage();
		if (!fireRule.isValid()) {
			throw new BusicenException(resMsg);
		}
	}

	/**
	 * 判断是否修改及查重
	 * 
	 * @param mapParam
	 */
	public void checkRepeat(ParamBase<Map<String, Object>> mapParam) {
		try {
			String token =String.valueOf(mapParam.getParam().get("token"));
			UserBusiEntity userBusiEntity=BusicenContext.getCurrentUserBusiInfo(token);
			// 判断是新增还是修改
			Boolean updateFlag = false;
			if (!StringHelper.IsEmptyOrNull(mapParam.getParam().get("evaluationItemId"))) {
				// 数据库查询是否存在此id
				QueryWrapper<SacEvaluationItem> queryWrapper = new QueryWrapper<SacEvaluationItem>();
				queryWrapper.eq("EVALUATION_ITEM_ID", mapParam.getParam().get("evaluationItemId"));
				int count = baseMapper.selectCount(queryWrapper);
				if (count > 0) {
					updateFlag = true;
				}
			}
			mapParam.getParam().put("updateFlag", updateFlag);
			mapParam.getParam().put("dlrCode", userBusiEntity.getDlrCode());
			mapParam.getParam().put("dlrName", userBusiEntity.getDlrName());
			// 查重
			int plateNumberCount = sacEvaluationItemMapper.checkRepeat(mapParam.getParam());
			if (plateNumberCount > 0) {
				throw new BusicenException(message.get("EVALUATION-ITEM-01"));
			}
			
		} catch (Exception e) {
			throw e;
		}
	}
}
