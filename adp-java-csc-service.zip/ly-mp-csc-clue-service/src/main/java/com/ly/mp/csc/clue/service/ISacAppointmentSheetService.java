package com.ly.mp.csc.clue.service;

import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.entities.SacAppointmentSheet;

import java.util.Map;

import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 试乘试驾预约单表 服务类
 * </p>
 *
 * @author ly-linliq
 * @since 2021-10-15
 */
public interface ISacAppointmentSheetService extends IService<SacAppointmentSheet> {
	
	/**
	 * 试乘试驾预约单查询
	 * @param mapParam
	 * @return
	 */
	public ListResult<Map<String, Object>> appointmentSheetQueryList(ParamPage<Map<String, Object>>mapParam);
	
	/**
	 * 试乘试驾预约单保存
	 * @param mapParam
	 * @return
	 */
	public EntityResult<Map<String, Object>> appointmentSheetSave(Map<String, Object> mapParam);
	
	/**
	 * 试乘试驾单取消
	 * @param mapParam
	 * @return
	 */
	public OptResult appointmentSheetCancel(Map<String, Object> mapParam);
	
	/**
	 * 试驾车容量查询
	 * @param mapParam
	 * @return
	 */
	public ListResult<Map<String, Object>> sacTestDriveCapacityQueryList(ParamPage<Map<String, Object>>mapParam);

}
