package com.ly.mp.csc.clue.util;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import com.ly.mp.busi.base.constant.UserBusiEntity;
import com.ly.mp.busi.base.context.BusicenContext;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.enums.ReviewAssignStatusEnum;
import com.ly.mp.csc.clue.enums.ReviewNodeEnum;

@Component
public class ReviewUpdateClueUtil {

	/**
	 * 更新总部商机Map
	 * @param clueMap
	 * @param reviewParam
	 * @param token
	 * @return
	 */
	public static boolean needUpdateClue(Map<String, Object> clueMap, Map<String, Object> reviewParam, String token) {
		boolean needUpdate = false; // 默认不需要更新
		String nodeCode = (String) reviewParam.get("nodeCode");
		String assignStatus = (String) reviewParam.get("assignStatus");
		if(clueMap == null || StringUtils.isBlank(nodeCode)) {
			return needUpdate;
		}
		// 把回访的字段覆盖总部商机字段
		cover(clueMap, reviewParam, "sendDlrCode");
		cover(clueMap, reviewParam, "sendDlrShortName");
		commonCover(clueMap, reviewParam);

		String reviewId = (String)reviewParam.get("reviewId");
		if(StringUtils.isNotBlank(reviewId)) {
			clueMap.put("reviewId", reviewId);
		}
		Calendar curCal = Calendar.getInstance();
		if (StringHelper.IsEmptyOrNull(clueMap.get("firstReviewTime"))) {
			clueMap.put("firstReviewTime", curCal.getTime());
		}
		if (StringHelper.IsEmptyOrNull(reviewParam.get("lastReviewTime"))) {
			clueMap.put("lastReviewTime", curCal.getTime());
		}



		/*
		 * 商机状态：1 待分配 2 待回访 3 待派发 4 已派发 5 重复留资
		 * 6 派发失败 7 战败申请 8 失控申请 9 无效申请 10 战败
		 * 11 失控 12 无效线索 13 关闭
		 */
		if (ReviewNodeEnum.New.getResult().equals(nodeCode)) {
			if(reviewParam.get("assignTime") != null) { // 自动分配
				clueMap.put("statusCode", "2");
				clueMap.put("statusName", "待回访");
				clueMap.put("assignTime", reviewParam.get("assignTime"));
			} else {
				// 其他情况 不做处理
				return needUpdate;
			}
		} else if (ReviewNodeEnum.Save.getResult().equals(nodeCode)) {// 继续跟进
			if(ReviewAssignStatusEnum.assignEd.getResult().equals(assignStatus)) {// 回访状态：已分配
				clueMap.put("statusCode", "2");
				clueMap.put("statusName", "待回访");
			}
		} else if (ReviewNodeEnum.Send.getResult().equals(nodeCode)) {// 下发专营店
			clueMap.put("statusCode", "4");
			clueMap.put("statusName", "已派发");
			clueMap.put("sendDlrCode", reviewParam.get("sendDlrCode"));
			clueMap.put("sendDlrShortName", reviewParam.get("sendDlrShortName"));
			clueMap.put("sendTime", curCal.getTime());
		} else if (ReviewNodeEnum.Defeat.getResult().equals(nodeCode)) {// 战败申请
			clueMap.put("statusCode", "7");
			clueMap.put("statusName", "战败申请");
		} else if (ReviewNodeEnum.Notctrl.getResult().equals(nodeCode)) {// 失控申请
			clueMap.put("statusCode", "8");
			clueMap.put("statusName", "失控申请");
		} else if (ReviewNodeEnum.Invalid.getResult().equals(nodeCode)) {// 无效申请
			clueMap.put("statusCode", "9");
			clueMap.put("statusName", "无效申请");
		} else if (ReviewNodeEnum.Undefeat.getResult().equals(nodeCode) ||
				ReviewNodeEnum.Unnotctrl.getResult().equals(nodeCode) ||
				ReviewNodeEnum.Uninvalid.getResult().equals(nodeCode)
				) {// 战败申请驳回、失控申请驳回、无效申请驳回
			if(ReviewAssignStatusEnum.assignEd.getResult().equals(assignStatus)) {// 回访状态：已分配
				clueMap.put("statusCode", "2");
				clueMap.put("statusName", "待回访");
			} else if(ReviewAssignStatusEnum.unAssign.getResult().equals(assignStatus)) {// 回访状态：待分配
				clueMap.put("statusCode", "1");
				clueMap.put("statusName", "待分配");
			}
		} else if (ReviewNodeEnum.Defeated.getResult().equals(nodeCode)) {// 战败
			clueMap.put("statusCode", "10");
			clueMap.put("statusName", "战败");
		} else if (ReviewNodeEnum.Notctrled.getResult().equals(nodeCode)) {// 失控
			clueMap.put("statusCode", "11");
			clueMap.put("statusName", "失控");
		} else if (ReviewNodeEnum.Invalided.getResult().equals(nodeCode)) {// 无效
			clueMap.put("statusCode", "12");
			clueMap.put("statusName", "无效线索");
		} else if (ReviewNodeEnum.End.getResult().equals(nodeCode)) {// 结束回访
			clueMap.put("statusCode", "13");
			clueMap.put("statusName", "关闭");
		}
		return true;
	}

	private static void commonCover(Map<String, Object> clueMap, Map<String, Object> reviewParam) {
		cover(clueMap, reviewParam, "reviewPersonName");
		cover(clueMap, reviewParam, "reviewPersonId");
		cover(clueMap, reviewParam, "lastReviewTime");

		cover(clueMap, reviewParam, "genderCode", "gender");
		cover(clueMap, reviewParam, "genderName");

		cover(clueMap, reviewParam, "infoChanMCode");
		cover(clueMap, reviewParam, "infoChanMName");
		cover(clueMap, reviewParam, "infoChanDCode");
		cover(clueMap, reviewParam, "infoChanDName");
		cover(clueMap, reviewParam, "infoChanDdCode");
		cover(clueMap, reviewParam, "infoChanDdName");
		cover(clueMap, reviewParam, "channelCode");
		cover(clueMap, reviewParam, "channelName");

		cover(clueMap, reviewParam, "custName");
		cover(clueMap, reviewParam, "phone");
		cover(clueMap, reviewParam, "phoneBack");
		cover(clueMap, reviewParam, "nodeCode");
		cover(clueMap, reviewParam, "nodeName");
		cover(clueMap, reviewParam, "sendTime");

		cover(clueMap, reviewParam, "intenLevelCode");
		cover(clueMap, reviewParam, "intenLevelName");
		cover(clueMap, reviewParam, "intenBrandCode");
		cover(clueMap, reviewParam, "intenBrandName");
		cover(clueMap, reviewParam, "intenSeriesCode");
		cover(clueMap, reviewParam, "intenSeriesName");
		cover(clueMap, reviewParam, "intenCarTypeCode");
		cover(clueMap, reviewParam, "intenCarTypeName");

		cover(clueMap, reviewParam, "remark");
		cover(clueMap, reviewParam, "illustration");

		cover(clueMap, reviewParam, "planBuyDateName");
		cover(clueMap, reviewParam, "planBuyDate");
		cover(clueMap, reviewParam, "testDriveDateName");
		cover(clueMap, reviewParam, "testDriveDate");
		cover(clueMap, reviewParam, "businessHeatName");
		cover(clueMap, reviewParam, "businessHeatCode");
		cover(clueMap, reviewParam, "carPurchaseBudget");

	}

	private static void cover(Map<String, Object> clueMap, Map<String, Object> reviewParam, String key) {
		clueMap.put(key, reviewParam.get(key));
	}
	private static void cover(Map<String, Object> clueMap, Map<String, Object> reviewParam, String key1, String key2) {
		clueMap.put(key1, reviewParam.get(key2));
	}

	/**
	 * 更新店端线索Map
	 * @param clueMap
	 * @param reviewParam
	 * @param token
	 * @return
	 */
	public static boolean needUpdateDlrClue(Map<String, Object> clueMap, Map<String, Object> reviewParam, String token) {
		boolean needUpdate = false; // 默认不需要更新
		String nodeCode = (String) reviewParam.get("nodeCode");
		String assignStatus = (String) reviewParam.get("assignStatus");
		if(clueMap == null || StringUtils.isBlank(nodeCode)) {
			return needUpdate;
		}
		// 把回访的字段覆盖店端线索字段 经销商编码
		cover(clueMap, reviewParam, "dlrCode");
		cover(clueMap, reviewParam, "dlrShortName");
		commonCover(clueMap, reviewParam);

		String reviewId = (String)reviewParam.get("reviewId");
		if(StringUtils.isNotBlank(reviewId)) {
			clueMap.put("reviewId", reviewId);
		}
		Calendar curCal = Calendar.getInstance();
		if (StringHelper.IsEmptyOrNull(clueMap.get("firstReviewTime"))) {
			clueMap.put("firstReviewTime", curCal.getTime());
		}
		if (StringHelper.IsEmptyOrNull(reviewParam.get("lastReviewTime"))) {
			clueMap.put("lastReviewTime", curCal.getTime());
		}

		/*
		 * 线索状态：1 待分配 2 待回访  5 重复留资
		 * 7 战败申请 8 失控申请 9 无效申请 10 战败
		 * 11 失控 12 无效线索 13关闭  14 预约到店
		 */
		if (ReviewNodeEnum.New.getResult().equals(nodeCode)) {
			if(reviewParam.get("assignTime") != null) { // 自动分配
				clueMap.put("statusCode", "2");
				clueMap.put("statusName", "待回访");
				clueMap.put("assignTime", reviewParam.get("assignTime"));
				// 新建不写firstReviewTime
				clueMap.remove("firstReviewTime");
				clueMap.remove("lastReviewTime");
			} else {
				// 其他情况 不做处理
				return needUpdate;
			}
		} else if (ReviewNodeEnum.Save.getResult().equals(nodeCode)) {// 继续跟进
			if(ReviewAssignStatusEnum.unAssign.getResult().equals(assignStatus)) {// 回访状态：待分配
				clueMap.put("statusCode", "1");
				clueMap.put("statusName", "待分配");
			}else{
				clueMap.put("statusCode", "2");
				clueMap.put("statusName", "待回访");
			}
		} else if (ReviewNodeEnum.Defeat.getResult().equals(nodeCode)) {// 战败申请
			clueMap.put("statusCode", "7");
			clueMap.put("statusName", "战败申请");
		} else if (ReviewNodeEnum.Notctrl.getResult().equals(nodeCode)) {// 失控申请
			clueMap.put("statusCode", "8");
			clueMap.put("statusName", "失控申请");
		} else if (ReviewNodeEnum.Invalid.getResult().equals(nodeCode)) {// 无效申请
			clueMap.put("statusCode", "9");
			clueMap.put("statusName", "无效申请");
		} else if (ReviewNodeEnum.Undefeat.getResult().equals(nodeCode) ||
				ReviewNodeEnum.Unnotctrl.getResult().equals(nodeCode) ||
				ReviewNodeEnum.Uninvalid.getResult().equals(nodeCode)
				) {// 战败申请驳回、失控申请驳回、无效申请驳回
			if(ReviewAssignStatusEnum.assignEd.getResult().equals(assignStatus)) {// 回访状态：已分配
				clueMap.put("statusCode", "2");
				clueMap.put("statusName", "待回访");
			} else if(ReviewAssignStatusEnum.unAssign.getResult().equals(assignStatus)) {// 回访状态：待分配
				clueMap.put("statusCode", "1");
				clueMap.put("statusName", "待分配");
			}
		} else if (ReviewNodeEnum.Defeated.getResult().equals(nodeCode)) {// 战败
			clueMap.put("statusCode", "10");
			clueMap.put("statusName", "战败");
		} else if (ReviewNodeEnum.Notctrled.getResult().equals(nodeCode)) {// 失控
			clueMap.put("statusCode", "11");
			clueMap.put("statusName", "失控");
		} else if (ReviewNodeEnum.Invalided.getResult().equals(nodeCode)) {// 无效
			clueMap.put("statusCode", "12");
			clueMap.put("statusName", "无效线索");
		} else if (ReviewNodeEnum.Come.getResult().equals(nodeCode)) {// 预约到店
			clueMap.put("statusCode", "14");
			clueMap.put("statusName", "预约到店");
		} else if (ReviewNodeEnum.End.getResult().equals(nodeCode)) {// 结束回访
			clueMap.put("statusCode", "13");
			clueMap.put("statusName", "关闭");
		}
		// Cai
		clueMap.put("provinceCode", reviewParam.get("provinceCode"));
		clueMap.put("provinceName", reviewParam.get("provinceName"));
		clueMap.put("cityCode", reviewParam.get("cityCode"));
		clueMap.put("cityName", reviewParam.get("cityName"));
		clueMap.put("countyCode", reviewParam.get("countyCode"));
		clueMap.put("countyName", reviewParam.get("countyName"));
		clueMap.put("dlrCode", reviewParam.get("orgCode"));
		clueMap.put("dlrShortName", reviewParam.get("orgName"));
		return true;
	}

	public static Map<String, Object> getReviewTaskParamFromClue(Map<String, Object> clueInfoMap, String token) {
		Map<String, Object> reviewMap = _getReviewTaskParamCommon(clueInfoMap, token);
		reviewMap.put("billType", "CLUE");
		reviewMap.put("billTypeName", "商机");

		String sendDlrCode = (String)clueInfoMap.get("sendDlrCode");
		String sendDlrShortName = (String)clueInfoMap.get("sendDlrShortName");
		if(!StringHelper.IsEmptyOrNull(sendDlrCode) && !StringHelper.IsEmptyOrNull(sendDlrCode)) {
			reviewMap.put("orgCode", sendDlrCode);
			reviewMap.put("orgName", sendDlrShortName);
		} else {
			UserBusiEntity user = BusicenContext.getCurrentUserBusiInfo(token);
			Assert.hasText(user.getDlrCode(),"当前用户的信息没有dlrCode");
			Assert.hasText(user.getDlrName(),"当前用户的信息没有dlrName");
			reviewMap.put("orgCode", user.getDlrCode());
			reviewMap.put("orgName", user.getDlrName());
		}
		return reviewMap;
	}
	public static Map<String, Object> getReviewTaskParamFromClueDlr(Map<String, Object> clueInfoMap, String token) {
		Map<String, Object> reviewMap = _getReviewTaskParamCommon(clueInfoMap, token);
		reviewMap.put("billType", "DLRCLUE");
		reviewMap.put("billTypeName", "线索");

		String dlrCode = (String)clueInfoMap.get("dlrCode");
		String dlrShortName = (String)clueInfoMap.get("dlrShortName");
		if(!StringHelper.IsEmptyOrNull(dlrCode) && !StringHelper.IsEmptyOrNull(dlrShortName)) {
			reviewMap.put("orgCode", dlrCode);
			reviewMap.put("orgName", dlrShortName);
		} else {
			UserBusiEntity user = BusicenContext.getCurrentUserBusiInfo(token);
			Assert.hasText(user.getDlrCode(),"当前用户的信息没有dlrCode");
			Assert.hasText(user.getDlrName(),"当前用户的信息没有dlrName");
			reviewMap.put("orgCode", user.getDlrCode());
			reviewMap.put("orgName", user.getDlrName());
		}
		return reviewMap;
	}

	private static Map<String, Object> _getReviewTaskParamCommon(Map<String, Object> clueInfoMap, String token) {
		Map<String, Object> reviewMap = new HashMap<String, Object>();
		reviewMap.putAll(clueInfoMap);
		reviewMap.put("infoChanMCode", clueInfoMap.get("infoChanMCode"));
		reviewMap.put("infoChanMName", clueInfoMap.get("infoChanMName"));
		reviewMap.put("infoChanDCode", clueInfoMap.get("infoChanDCode"));
		reviewMap.put("infoChanDName", clueInfoMap.get("infoChanDName"));
		reviewMap.put("infoChanDdCode", clueInfoMap.get("infoChanDdCode"));
		reviewMap.put("infoChanDdName", clueInfoMap.get("infoChanDdName"));
		reviewMap.put("channelCode", clueInfoMap.get("channelCode"));
		reviewMap.put("channelName", clueInfoMap.get("channelName"));
		reviewMap.put("billCode", clueInfoMap.get("serverOrder"));
		if(clueInfoMap.get("custId") == null) {
			reviewMap.put("custId", StringHelper.GetGUID());
		} else {
			reviewMap.put("custId", clueInfoMap.get("custId"));
		}
		reviewMap.put("custName", clueInfoMap.get("custName"));
		reviewMap.put("phone", clueInfoMap.get("phone"));
		reviewMap.put("gender", clueInfoMap.get("genderCode")); // 性别编码
		reviewMap.put("genderName", clueInfoMap.get("genderName"));
		reviewMap.put("interCarSerise", clueInfoMap.get("intenSeriesName")); // 意向车系名称
		return reviewMap;
	}

}
