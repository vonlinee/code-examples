package com.ly.mp.csc.clue.service;

import java.util.Map;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.entities.SacDemoCar;

/**
 * <p>
 * 试驾车表 服务类
 * </p>
 *
 * @author ly-linliq
 * @since 2021-10-14
 */
public interface ISacDemoCarService extends IService<SacDemoCar> {
	/**
	 * 试驾车查询
	 * @param mapParam
	 * @author ly-linliq
	 * @return
	 */
	public ListResult<Map<String, Object>> demoCarQueryList(ParamPage<Map<String, Object>> mapParam);
	/**
	 * 试驾车保存
	 * @param mapParam
	 * @author ly-linliq
	 * @return
	 */
	public OptResult demoCarSave(ParamBase<Map<String, Object>> mapParam);
}
