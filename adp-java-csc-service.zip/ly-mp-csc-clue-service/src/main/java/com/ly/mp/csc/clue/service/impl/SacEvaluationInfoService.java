package com.ly.mp.csc.clue.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegist;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegistor;
import com.ly.bucn.component.interceptor.annotation.Interceptor;
import com.ly.bucn.component.message.Message;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.constant.UserBusiEntity;
import com.ly.mp.busi.base.context.BusicenContext;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.busi.base.handler.MapUtil;
import com.ly.mp.busi.base.handler.OptResultBuilder;
import com.ly.mp.busi.base.handler.BusicenUtils.SOU;
import com.ly.mp.busicen.rule.field.FireFieldRule;
import com.ly.mp.busicen.rule.field.execution.ValidResultCtn;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.entities.SacEvaluationInfo;
import com.ly.mp.csc.clue.idal.mapper.SacEvaluationInfoMapper;
import com.ly.mp.csc.clue.idal.mapper.SacEvaluationItemMapper;
import com.ly.mp.csc.clue.idal.mapper.SacTestDriveSheetMapper;
import com.ly.mp.csc.clue.service.ISacEvaluationInfoService;

/**
 * <p>
 * 试乘试驾评价表 服务实现类
 * </p>
 *
 * @author ly-linliq
 * @since 2021-10-19
 */
@Service
public class SacEvaluationInfoService extends ServiceImpl<SacEvaluationInfoMapper, SacEvaluationInfo>
		implements ISacEvaluationInfoService, InterceptorWrapperRegist {

	@Autowired
	SacEvaluationInfoMapper sacEvaluationInfoMapper;
	@Autowired
	SacEvaluationItemMapper sacEvaluationItemMapper;
	@Autowired
	SacTestDriveSheetMapper sacTestDriveSheetMapper;
	@Autowired
	FireFieldRule fireFieldRule;
	@Autowired
	Message message;

	/**
	 * 试乘试驾评价查询
	 */
	@Override
	public ListResult<Map<String, Object>> sacEvaluationInfoQueryList(ParamPage<Map<String, Object>> mapParam) {
		ListResult<Map<String, Object>> result = new ListResult<Map<String, Object>>();
		try {
			// 去掉空字符串
			MapUtil.removeNullValue(mapParam.getParam());
			// 字段检验
			ValidResultCtn fireRule = fireFieldRule.fireRule(mapParam.getParam(), "csc-clue-ecaluation-info-find-check",
					"maindata");
			String resMsg = fireRule.getNotValidMessage();
			if (!fireRule.isValid()) {
				throw new BusicenException(resMsg);
			}
			String token = mapParam.getParam().get("token").toString();
			// 根据token获取当前用户信息
			UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
			mapParam.getParam().put("dlrCode", userBusiEntity.getDlrCode());
			mapParam.getParam().put("dlrName", userBusiEntity.getDlrName());
			Page<Map<String, Object>> page = new Page<Map<String, Object>>(mapParam.getPageIndex(),
					mapParam.getPageSize());

			List<Map<String, Object>> list = sacEvaluationInfoMapper.selectSacEvaluationInfo(mapParam.getParam(), page);
			// 对查询结果进行处理
			// 查找评论类型，并计算平均分
			List<Map<String, Object>> evaluationTypeList = sacEvaluationInfoMapper
					.selectEvaluationType(mapParam.getParam());
			List<Map<String, Object>> evaluationList = new ArrayList<Map<String, Object>>();
			if (evaluationTypeList.size() > 0) {
				for (Map<String, Object> item : evaluationTypeList) {
					Map<String, Object> evaluation = new HashMap<String, Object>();
					List<Map<String, Object>> evaluationItemList = new ArrayList<Map<String, Object>>();
					int sumScore = 0;
					double avgScore = 0.0;
					for (Map<String, Object> map : list) {
						// 查找该评论类型的子评论项
						if (map.get("evaluationType").equals(item.get("evaluationType"))) {
							sumScore += Integer.valueOf(map.get("evaluationScore").toString());
							Map<String, Object> mapIteMap = new HashMap<String, Object>();
							mapIteMap.put("evaluationItem", map.get("evaluationItem"));
							mapIteMap.put("evaluationScore", map.get("evaluationScore"));
							mapIteMap.put("evaluationInfoId", map.get("evaluationInfoId"));
							evaluationItemList.add(mapIteMap);
						}
					}
					avgScore = (sumScore * 1.00) / evaluationItemList.size();
					double newAvgScore=0.0;
					if(avgScore>0) {
						// 处理平均分数，保留一位小数点
						BigDecimal bigDecimal = new BigDecimal(avgScore);
						newAvgScore= bigDecimal.setScale(1, BigDecimal.ROUND_HALF_UP).doubleValue();
					}
					evaluation.put("dlrCode", item.get("dlrCode"));
					evaluation.put("dlrName", item.get("dlrName"));
					evaluation.put("evaluationType", item.get("evaluationType"));
					evaluation.put("testDriveSheetId", item.get("testDriveSheetId"));
					evaluation.put("evaluationItemList", evaluationItemList);
					evaluation.put("avgScore", newAvgScore);
					evaluation.put("oemId", item.get("oemId"));
					evaluation.put("groupId", item.get("groupId"));
					evaluation.put("creator", item.get("creator"));
					evaluation.put("createdName", item.get("createdName"));
					evaluation.put("createdDate", item.get("createdDate"));
					evaluation.put("MODIFIER", item.get("MODIFIER"));
					evaluation.put("modifyName", item.get("modifyName"));
					evaluation.put("lastUpdatedDate", item.get("lastUpdatedDate"));
					evaluation.put("isEnable", item.get("isEnable"));
					evaluation.put("updateControlId", item.get("updateControlId"));
					evaluationList.add(evaluation);
				}
				
			}
			page.setRecords(evaluationList);
			result = BusicenUtils.page2ListResult(page);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("sacEvaluationInfoQueryList", e);
			throw e;
		}
		return result;
	}

	/**
	 * 试乘试驾评价保存
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Interceptor("csc_clue_ecaluation_info")
	@Transactional
	public OptResult sacEvaluationInfoSave(Map<String, Object> mapParam) {
		OptResult optResult = new OptResult();
		String token = String.valueOf(mapParam.get("token"));
		UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
		try {
			// 将专营店该试驾单评价全删除
			UpdateWrapper<SacEvaluationInfo> updateWrapper = new UpdateWrapper<SacEvaluationInfo>();
			updateWrapper.eq("TEST_DRIVE_SHEET_ID", mapParam.get("testDriveSheetId")).eq("DLR_CODE",
					userBusiEntity.getDlrCode());
			sacEvaluationInfoMapper.delete(updateWrapper);
			// 再将最新的评价插入评价表
			List<Map<String, Object>> evaluationList = (List<Map<String, Object>>) mapParam.get("evaluationList");
			for (Map<String, Object> evaluation : evaluationList) {
				if(!StringHelper.IsEmptyOrNull(mapParam.get("dlrCode"))){
					evaluation.put("dlrCode", mapParam.get("dlrCode"));
					evaluation.put("dlrName", mapParam.get("dlrName"));
				}else {
					evaluation.put("dlrCode", userBusiEntity.getDlrCode());
					evaluation.put("dlrName", userBusiEntity.getDlrName());
				}
				evaluation.put("testDriveSheetId", mapParam.get("testDriveSheetId"));
				if (StringHelper.IsEmptyOrNull(evaluation.get("evaluationInfoId"))) {
					evaluation.put("evaluationInfoId", StringHelper.GetGUID());
				}
				if (StringHelper.IsEmptyOrNull(evaluation.get("isEnable"))) {
					evaluation.put("isEnable", "1");
				}
				BusicenUtils.invokeUserInfo(evaluation, SOU.Save, token);
				int result = sacEvaluationInfoMapper.insertSacEvaluationInfo(evaluation);
				if (result == 0) {
					optResult.setMsg(message.get("EVALUATION-INFO-01", evaluation.get("evaluationItem")));
					optResult.setResult("0");
					return optResult;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("sacEvaluationInfoSave", e);
			throw e;
		}
		return OptResultBuilder.createOk().build();
	}

	@Override
	@SuppressWarnings("unchecked")
	public void regist(InterceptorWrapperRegistor registor) {
		// 校验字段
		registor.before("csc_clue_ecaluation_info_valid", (context, model) -> {
			checkValidate((Map<String, Object>) context.data().getP()[0]);
		});
		// 校验是新增还是修改并查重
		registor.before("csc_clue_ecaluation_info_repeat", (context, model) -> {
			checkRepeat((Map<String, Object>) context.data().getP()[0]);
		});

	}

	@SuppressWarnings("unchecked")
	public void checkValidate(Map<String, Object> mapParam) {
		ValidResultCtn fireRule = fireFieldRule.fireRule(mapParam, "csc-clue-ecaluation-info-check", "maindata");
		String resMsg = fireRule.getNotValidMessage();
		if (!fireRule.isValid()) {
			throw new BusicenException(resMsg);
		}
		// 判断试驾单是否存在
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("testDriveSheetId", mapParam.get("testDriveSheetId"));
		Page<Map<String, Object>> page = new Page<Map<String, Object>>(1, -1);
		List<Map<String, Object>> list = sacTestDriveSheetMapper.selectSacTestDriveSheet(map, page);
		if (list.size() <= 0) {
			throw new BusicenException(message.get("EVALUATION-INFO-02"));
		}
		// 获取评价数组
		List<Map<String, Object>> evaluationList = (List<Map<String, Object>>) mapParam.get("evaluationList");
		// 如果评价项列表为空则抛异常
		if (evaluationList.size() == 0) {
			throw new BusicenException(message.get("EVALUATION-INFO-03"));
		}
		// 评价数组字段校验
		for (Map<String, Object> evaluation : evaluationList) {
			ValidResultCtn evaluationListFireRule = fireFieldRule.fireRule(evaluation,
					"csc-clue-ecaluationlist-info-check", "maindata");
			String resMsg1 = evaluationListFireRule.getNotValidMessage();
			if (!evaluationListFireRule.isValid()) {
				throw new BusicenException(resMsg1);
			}
//			if(Integer.valueOf(evaluation.get("evaluationScore").toString())<1) {
//				throw new BusicenException("请打1-5的分数");
//			}
		}
	}

	public void checkRepeat(Map<String, Object> mapParam) {
	}
}
