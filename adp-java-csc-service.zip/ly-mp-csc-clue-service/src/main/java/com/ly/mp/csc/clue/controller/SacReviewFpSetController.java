package com.ly.mp.csc.clue.controller;

import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.context.BusicenInvoker;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.service.ISacReviewFpSetService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * com.ly.mp.csc.clue.controller.SacReviewAssignSetController
 * 回访分配设置控制类
 * @author zhouhao
 * @date 2021/8/16 15:18
 */
@Api(value = "回访分配服务", tags = { "回访分配服务" })
@RestController
@RequestMapping(value = "/ly/sac/reviewfpset", produces = { MediaType.APPLICATION_JSON_VALUE })
public class SacReviewFpSetController {
	//注入服务
	@Autowired
	ISacReviewFpSetService sacReviewFpSetService;
	
	@ApiOperation(value="回访分配设置查询", notes="回访分配设置查询")
	@RequestMapping(value = "/querylist.do", method = RequestMethod.POST)
	public ListResult<Map<String,Object>> queryListReviewAssignInfo(
			@RequestHeader(name = "authorization",required = false) String token,
			@RequestBody(required = false) ParamPage<Map<String,Object>> dataInfo){
		dataInfo.getParam().put("token",token);
		return BusicenInvoker.doList(()->sacReviewFpSetService.queryListReviewAssignInfo( dataInfo, token)).result();
	}
	
		
	@ApiOperation(value="回访分配设置保存", notes="回访分配设置保存")
	@RequestMapping(value = "/save.do", method = RequestMethod.POST)
	public OptResult saveReviewAssignInfo(
		@RequestHeader(name = "authorization",required = false) String token,
		@RequestBody(required = true) ParamBase<Map<String,Object>> dataInfo){
		return BusicenInvoker.doOpt(()->sacReviewFpSetService.saveReviewAssignInfo(dataInfo.getParam(), token)).result();
	}

	@ApiOperation(value="回访分配设置删除", notes="回访分配设置删除")
	@RequestMapping(value = "/delete.do", method = RequestMethod.POST)
	public OptResult deleteReviewAssignInfo(
			@RequestHeader(name = "authorization",required = false) String token,
			@RequestBody(required = true) ParamBase<Map<String,Object>> dataInfo){
		return BusicenInvoker.doOpt(()->sacReviewFpSetService.deleteReviewAssignInfo(dataInfo.getParam(), token)).result();
	}

	@ApiOperation(value="分配规则查询", notes="分配规则查询")
	@RequestMapping(value = "/querylistreviewrule.do", method = RequestMethod.POST)
	public ListResult<Map<String,Object>> queryListReviewRuleInfo(
			@RequestHeader(name = "authorization",required = false) String token,
			@RequestBody(required = false) ParamPage<Map<String,Object>> dataInfo){
		return BusicenInvoker.doList(()->sacReviewFpSetService.queryListReviewRuleInfo( dataInfo, token)).result();
	}
	
	@ApiOperation(value="获取队列中的人员列表及阀值", notes="获取队列中的人员列表及阀值")
	@RequestMapping(value = "/queryfppersonlist.do", method = RequestMethod.POST)
	public ListResult<Map<String,Object>> queryFpPersonList(
			@RequestHeader(name = "authorization",required = false) String token,
			@RequestBody(required = false) ParamPage<Map<String,Object>> dataInfo){
		return BusicenInvoker.doList(()->sacReviewFpSetService.queryFpPersonList( dataInfo, token)).result();
	}
}
