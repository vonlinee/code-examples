package com.ly.mp.csc.clue.service;

import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.entities.SacClueInfoDlr;

/**
 * <p>
 * 店端线索表 服务类
 * </p>
 *
 * @author ly-busicen
 * @since 2021-08-20
 */
public interface ISacClueInfoDlrService extends IService<SacClueInfoDlr> {
	/**
	 * 店端线索重复检查，返回0表示没有重复
	 * @param mapParam
	 * @return
	 */
	public int checkRepeat(ParamBase<Map<String, Object>> mapParam) ;
	public EntityResult<Map<String, Object>> dlrClueCheckRepeat(ParamBase<Map<String, Object>> mapParam) ;
	/**
	 * 店端线索保存
	 * @param clueParam
	 * @return
	 */
	public EntityResult<Map<String, Object>> saveMap(ParamBase<Map<String, Object>> clueParam, String token);
	public OptResult updateMap(Map<String, Object> param, String token) ;

	/**
	 * 店端线索分页查询
	 * @param paramPage
	 * @return
	 */
	public ListResult<Map<String, Object>> findByPage(ParamPage<Map<String, Object>> paramPage) ;

	public EntityResult<Map<String, Object>> findById(String id, String serverOrder) ;

	/**
	 * 店端线索导出
	 * @param mapParam
	 * @param token
	 * @param response
	 * @return
	 */
	public OptResult exportDlrClue(Map<String, Object> mapParam, String token,HttpServletResponse response);

}
