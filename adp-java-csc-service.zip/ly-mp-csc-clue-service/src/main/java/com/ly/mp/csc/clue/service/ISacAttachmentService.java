package com.ly.mp.csc.clue.service;

import java.util.Map;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.csc.clue.entities.SacAttachment;

/**
 * 附件表 服务类
 * t_sac_attachment
 * @author ly-zhengzc
 * @since 2021-12-9
 */
public interface ISacAttachmentService extends IService<SacAttachment> {


	public EntityResult<Map<String, Object>> sacAttachmentAdd(Map<String, Object> mapParam, String token);
	/**
	 * 保存记录
	 * @param mapParam
	 * @param token
	 * @return
	 */
	public EntityResult<Map<String, Object>> sacAttachmentSave(Map<String, Object> mapParam, String token);
	/**
	 * 分页查询
	 * @param mapParam
	 * @param token
	 * @return
	 */
	public ListResult<Map<String, Object>> sacAttachmentQueryList(ParamPage<Map<String, Object>> map,String token);

	public EntityResult<Map<String, Object>> sacAttachmentDelete(Map<String, Object> mapParam, String token);
}
