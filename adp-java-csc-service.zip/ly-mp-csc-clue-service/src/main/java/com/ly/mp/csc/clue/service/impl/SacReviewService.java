package com.ly.mp.csc.clue.service.impl;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.IntSummaryStatistics;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletResponse;

import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.ly.mp.csc.clue.entities.SacClueInfoDlr;
import com.ly.mp.csc.clue.service.*;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StopWatch;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.bucn.component.interceptor.InterceptorDataContext;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegist;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegistor;
import com.ly.bucn.component.interceptor.annotation.Interceptor;
import com.ly.bucn.component.message.Message;
import com.ly.bucn.component.ms.MsContext;
import com.ly.bucn.component.ms.MsContextSimple;
import com.ly.bucn.component.mybatis.MybatisContext;
import com.ly.bucn.component.strategy.runtime.ChooseContext;
import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.constant.UserBusiEntity;
import com.ly.mp.busi.base.context.BusicenContext;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.busi.base.handler.BusicenUtils.SOU;
import com.ly.mp.busi.base.handler.MapUtil;
import com.ly.mp.busi.base.handler.OptResultBuilder;
import com.ly.mp.busi.base.handler.ResultHandler;
import com.ly.mp.busicen.rule.field.IFireFieldRule;
import com.ly.mp.busicen.rule.field.execution.ValidResultCtn;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.entities.SacReview;
import com.ly.mp.csc.clue.entities.in.FieldMappingIn;
import com.ly.mp.csc.clue.entities.out.ReviewFpResultOut;
import com.ly.mp.csc.clue.entities.out.ReviewPersonQueneOut;
import com.ly.mp.csc.clue.enums.ReviewAssignStatusEnum;
import com.ly.mp.csc.clue.enums.ReviewAuditStatusEnum;
import com.ly.mp.csc.clue.enums.ReviewAuditTypeEnum;
import com.ly.mp.csc.clue.enums.ReviewNodeEnum;
import com.ly.mp.csc.clue.enums.ReviewStatusEnum;
import com.ly.mp.csc.clue.helper.CacheDataFactory;
import com.ly.mp.csc.clue.idal.mapper.SacClueInfoDlrMapper;
import com.ly.mp.csc.clue.idal.mapper.SacClueInfoMapper;
import com.ly.mp.csc.clue.idal.mapper.SacReviewMapper;
import com.ly.mp.csc.clue.otherservice.ICscSysMetaService;
import com.ly.mp.csc.clue.strategy.service.IReviewFpQueueStrategy;
import com.ly.mp.csc.clue.strategy.service.IReviewFpRuleStrategy;
import com.ly.mp.csc.clue.util.ExcelExport;
import com.ly.mp.csc.clue.util.ReviewUpdateClueUtil;

/**
 * com.ly.mp.csc.clue.service.impl.SacReviewService 回访任务实现类
 *
 * @author zhouhao
 * @date 2021/8/20 9:46
 */
@Service
public class SacReviewService extends ServiceImpl<SacReviewMapper, SacReview>
implements ISacReviewService, InterceptorWrapperRegist {

	private Logger logger = LoggerFactory.getLogger(SacReviewService.class);

	public static final String SUFFIX = "xlsx";

	@Autowired
	SacReviewMapper sacReviewMapper;
	@Autowired
	Executor asyncTaskExecutor;
	@Autowired
	Message message;
	@Autowired
	IFireFieldRule fireFieldRule;
	@Autowired
	CacheDataFactory cacheDataFactory;
	@Autowired
	ISacReviewFpSetService sacReviewFpSetService;
	@Autowired
	ISacFieldMappingConfigService sacFieldMappingConfigService;
	@Autowired
	ISacReviewOvertimeSetService sacReviewOvertimeSetService;
	@Autowired
	ISacReviewPlanService sacReviewPlanService;
	@Autowired
	ISacClueInfoDlrService sacClueInfoDlrService;
	@Autowired
	ICscSysMetaService cscSysMetaService;

	@Autowired
	MybatisContext mybatisContext;

	/**
	 * 生成回访任务
	 *
	 * @param map
	 * @param token
	 * @return
	 */
	@Override
	@Interceptor("csc_clue_review_addtask")
	@Transactional(rollbackFor = Exception.class)
	public EntityResult<Map<String, Object>> addTask(Map<String, Object> map, String token) {
		StopWatch stopWatch = new StopWatch("生成回访任务");
		
		try {
			// String orgCode = map.get("orgCode").toString();
			// 首次回访为待回访
			map.put("reviewStatus", ReviewStatusEnum.unreview.getResult());
			map.put("reviewStatusName", ReviewStatusEnum.unreview.getMsg());
			map.put("nodeCode", "New");
			map.put("nodeName", "新建回访单");

			if(!StringHelper.IsEmptyOrNull(map.get("factComeTime"))){
				map.put("isCome", "1");
			}else{
				map.put("isCome", "0");
			}

			// 没指定回访人员，则根据分配规则取回访人员
			if (StringHelper.IsEmptyOrNull(map.get("reviewPersonId"))) {
				stopWatch.start("根据分配规则取回访人员");
				
				ReviewFpResultOut personOut = queryFpPerson(map, token);
				stopWatch.stop();
				
				if (personOut != null) {
					map.put("reviewPersonId", personOut.getReviewPersonUserId());
					map.put("reviewPersonName", personOut.getReviewPersonName());
					// 设为已分配
					map.put("assignStatus", ReviewAssignStatusEnum.assignEd.getResult());
					map.put("assignStatusName", ReviewAssignStatusEnum.assignEd.getMsg());
					map.put("assignTime",
							LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
				} else {
					// 设为未分配
					map.put("assignStatus", ReviewAssignStatusEnum.unAssign.getResult());
					map.put("assignStatusName", ReviewAssignStatusEnum.unAssign.getMsg());
				}
			} else {
				// 设为已分配
				map.put("assignStatus", ReviewAssignStatusEnum.assignEd.getResult());
				map.put("assignStatusName", ReviewAssignStatusEnum.assignEd.getMsg());
				map.put("assignTime", LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
			}
			stopWatch.start("计算超时时间 ");
			// 计算超时时间 首次回访
			String overTime = queryOverTime("1", map, token);
			stopWatch.stop();
			if (!StringHelper.IsEmptyOrNull(overTime)) {
				map.put("overReviewTime", overTime);
			}
			stopWatch.start("扩展字段转换 ");
			// 扩展字段转换
			transFiled(null, map);
			stopWatch.stop();
			
			stopWatch.start("保存回访任务表 ");
			// 保存回访任务表
			EntityResult<Map<String, Object>>  result = sacReviewSave(map, token);
			stopWatch.stop();
			System.out.println("生成回访任务:" +stopWatch.prettyPrint() +"毫秒");//;
			System.out.println("生成回访任务:" +stopWatch.getTotalTimeMillis() +"毫秒");//;
			
			return result;
			
		} catch (Exception e) {
			e.printStackTrace();
			log.error("addTask:", e);
			throw e;
			// throw new BusicenException(message.get("CLUE-REVIEW-ADDTASK-01"));
		}
	}

	// 根据分配规则获取回访人员
	private ReviewFpResultOut queryFpPerson(Map<String, Object> map, String token) {
		String orgCode = map.get("orgCode").toString();
		// 获取自动分配开关 1开启，0关闭
		String autoFpSwitch = cacheDataFactory.querySysConfigValue("AUTO_FP_SWITCH", token);
		if (!StringHelper.IsEmptyOrNull(autoFpSwitch) && "1".equals(autoFpSwitch)) {
			// 获取回访分配规则设置
			List<Map<String, Object>> fpRuleList = sacReviewFpSetService.machReviewFpRule(map, token);
			if (fpRuleList != null && fpRuleList.size() > 0) {
				// 回访人员队列策略
				String queueStategy = String.format("reviewFpQueueStrategy%s",
						fpRuleList.get(0).get("personQueueCode").toString());
				// 回访人员队列值
				String queueValueCode = fpRuleList.get(0).get("personQueueValueCode").toString();
				// 分配规则设置ID
				String setId = fpRuleList.get(0).get("setId").toString();
				// 分配规则编码
				String ruleCode = fpRuleList.get(0).get("ruleCode").toString();
				//是否本人优先
				String isFirstSelf = fpRuleList.get(0).get("isFirstSelf").toString();

				// 获取回访人员列表
				List<ReviewPersonQueneOut> personList = ChooseContext
						.chooseBeanOrDefault(queueStategy, IReviewFpQueueStrategy.class)
						.queryPersonList(orgCode, queueValueCode, token);
				//优先本人
				if("1".equals(isFirstSelf)){
					UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
					long haveSelf = personList.stream().filter(p->userBusiEntity.getUserID().equals(p.getReviewPersonUserId())).count();
					if(haveSelf>0){
						ReviewFpResultOut out = new ReviewFpResultOut();
						out.setReviewPersonUserId(userBusiEntity.getUserID());
						out.setReviewPersonName(userBusiEntity.getEmpName());
						return out;
					}
				}
				// 调用分配规则获取回访人员
				String planReviewTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
				if (!StringHelper.IsEmptyOrNull(map.get("planReviewTime"))) {
					planReviewTime = map.get("planReviewTime").toString();
				}
				return ChooseContext.chooseBeanOrDefault(ruleCode, IReviewFpRuleStrategy.class).handle(orgCode,
						personList, setId, planReviewTime);
			}
		}

		return null;
	}

	/**
	 * 计算超时时间
	 *
	 * @param type                                                          1首次回访，2二次回访
	 * @param map{orgCode,billType,businessType,channelCode,planReviewTime}
	 * @param token
	 * @return
	 */
	@Override
	public String queryOverTime(String type, Map<String, Object> map, String token) {
		StopWatch stopWatch = new StopWatch("计算超时时间");
		
		String orgCode = map.get("orgCode").toString();
		stopWatch.start("获取开关");
		// 获取超时开关 1开启，0关闭
		String overTimeSwitch = cacheDataFactory.querySysConfigValue("OVERTIME_SWITCH", token);
		stopWatch.stop();
		
		if (!StringHelper.IsEmptyOrNull(overTimeSwitch) && "1".equals(overTimeSwitch)) {
			stopWatch.start("获取规则");
			// 获取超时规则
			List<Map<String, Object>> overRuleList = sacReviewOvertimeSetService.machOverTimeRule(map, token);
			stopWatch.stop();
			
			if (overRuleList != null && overRuleList.size() > 0) {
				
				if (!StringHelper.IsEmptyOrNull(overRuleList.get(0).get("firstRuleId"))) {
					Map<String, Object> overTimeParam = new HashMap<>();
					// 1首次回访，2二次回访
					if ("1".equals(type)) {
						overTimeParam.put("ruleId", overRuleList.get(0).get("firstRuleId").toString());
					} else if ("2".equals(type)) {
						overTimeParam.put("ruleId", overRuleList.get(0).get("secRuleId").toString());
					}
					// 计划回访时间
					if (!StringHelper.IsEmptyOrNull(map.get("planReviewTime"))) {
						overTimeParam.put("planReviewTime", map.get("planReviewTime").toString());
					} else {
						overTimeParam.put("planReviewTime",
								LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
					}
					stopWatch.start("queryBillOverTime");
					List<Map<String, Object>> overTimeList = sacReviewOvertimeSetService
							.queryBillOverTime(overTimeParam, token);
					stopWatch.stop();
					if (overTimeList != null && overTimeList.size() > 0) {
						return overTimeList.get(0).get("overTime").toString();
					}
				}
			}
		}
		System.out.println("计算超时时间:" +stopWatch.prettyPrint() +"毫秒");//;
		System.out.println("计算超时时间:" +stopWatch.getTotalTimeMillis() +"毫秒");//;
		return null;
	}

	/**
	 * 回访表扩展字段转换
	 * 将参数转换为数据库的字段
	 * @param oldJson   原来保存的json
	 * @param 新的要保存的map
	 * @return
	 */
	@Override
	public Map<String, Object> transFiled(String oldJson, Map<String, Object> map) {
		FieldMappingIn info = new FieldMappingIn();
		info.setSourceTableCode("t_sac_review");
		info.setBillType(map.get("billType").toString());
		if (!StringHelper.IsEmptyOrNull(map.get("businessType"))) {
			info.setBusinessType(map.get("businessType").toString());
		} else {
			info.setBusinessType("-1");
		}
		info.setParam(map);
		info.setOldJson(oldJson);
		Map<String, Object> filedMap = sacFieldMappingConfigService.tranFieldToMap(info);
		if (filedMap != null && filedMap.size() > 0) {
			// 合并
			map.putAll(filedMap);
		}
		return map;
	}

	/**
	 * 回访表扩展字段转换 反转
	 * 将数据库的字段转换为映射的参数字段
	 * @param oldJson   原来保存的json
	 * @param 新的要保存的map
	 * @return
	 */
	private Map<String, Object> unTransFiled(String oldJson, Map<String, Object> map) {
		FieldMappingIn info = new FieldMappingIn();
		info.setSourceTableCode("t_sac_review");
		info.setBillType(map.get("billType").toString());
		if (!StringHelper.IsEmptyOrNull(map.get("businessType"))) {
			info.setBusinessType(map.get("businessType").toString());
		} else {
			info.setBusinessType("-1");
		}
		info.setParam(map);
		info.setOldJson(oldJson);
		Map<String, Object> filedMap = sacFieldMappingConfigService.unTranFieldToMap(info);
		if (filedMap != null && filedMap.size() > 0) {
			// 合并
			map.putAll(filedMap);
		}
		return map;
	}

	/**
	 * 本人待回访任务查询
	 *
	 * @param token token
	 * @param map   输入参数
	 * @return ListResult
	 */
	@Override
	public ListResult<Map<String, Object>> queryListMeReviewInfo(ParamPage<Map<String, Object>> map, String token) {
		try {

			int pageIndex = map.getPageIndex();
			int pageSize = map.getPageSize();
			UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
			map.getParam().put("userId", userBusiEntity.getUserID());
			Page<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);
			List<Map<String, Object>> list = baseMapper.queryListMeReviewInfo(page, map.getParam());
			for(int i=0;i<list.size();i++){
				Map<String, Object> infoMap = list.get(i);
				if(!StringHelper.IsEmptyOrNull(infoMap.get("extendsJson"))){
					infoMap.putAll(JSON.parseObject(infoMap.get("extendsJson").toString()));
				}
			}
			page.setRecords(list);
			return BusicenUtils.page2ListResult(page);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("queryListReviewAssignInfo:", e);
			throw e;
			// throw new BusicenException(message.get("CLUE-SYSTECONFIGVALUE-01"));
		}
	}

	/**
	 * 本组待回访任务查询
	 *
	 * @param token token
	 * @param map   输入参数
	 * @return ListResult
	 */
	@Override
	public ListResult<Map<String, Object>> queryListGroupReviewInfo(ParamPage<Map<String, Object>> map, String token) {
		try {
			int pageIndex = map.getPageIndex();
			int pageSize = map.getPageSize();
			UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
			// 当前登陆人的工作组的所有人员用户ID
			String userIdList = cacheDataFactory.selectGroupUserList(userBusiEntity.getEmpID(),"1");
			if (!StringHelper.IsEmptyOrNull(userIdList)) {
				map.getParam().put("userIdList", userIdList);
			} else {
				map.getParam().put("userIdList", userBusiEntity.getUserID());
			}

			Page<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);
			List<Map<String, Object>> list = baseMapper.queryListGroupReviewInfo(page, map.getParam());
			for(int i=0;i<list.size();i++){
				Map<String, Object> infoMap = list.get(i);
				if(!StringHelper.IsEmptyOrNull(infoMap.get("extendsJson"))){
					infoMap.putAll(JSON.parseObject(infoMap.get("extendsJson").toString()));
				}
			}
			page.setRecords(list);
			return BusicenUtils.page2ListResult(page);
		} catch (Exception e) {
			// e.printStackTrace();
			log.error("queryListGroupReviewInfo:", e);
			throw e;
		}
	}


	/**
	 * 待审核任务查询
	 *
	 * @param token token
	 * @param map   输入参数
	 * @return ListResult
	 */
	@Override
	public ListResult<Map<String, Object>> queryListAuditReviewInfo(ParamPage<Map<String, Object>> map, String token) {
		try {
			int pageIndex = map.getPageIndex();
			int pageSize = map.getPageSize();
			UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
			map.getParam().put("orgCode", userBusiEntity.getDlrCode());
			map.getParam().put("shPersonId", userBusiEntity.getUserID());
			Page<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);
			List<Map<String, Object>> list = baseMapper.queryListAuditReviewInfo(page, map.getParam());
			for(int i=0;i<list.size();i++){
				Map<String, Object> infoMap = list.get(i);
				if(!StringHelper.IsEmptyOrNull(infoMap.get("extendsJson"))){
					infoMap.putAll(JSON.parseObject(infoMap.get("extendsJson").toString()));
				}
			}
			page.setRecords(list);
			return BusicenUtils.page2ListResult(page);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("queryListAuditReviewInfo:", e);
			throw e;
		}
	}

	/**
	 * 回访审核任务查询
	 *
	 * @param token token
	 * @param map   输入参数
	 * @return ListResult
	 */
	@Override
	public ListResult<Map<String, Object>> queryListAuditReviewRecordInfo(ParamPage<Map<String, Object>> map,
			String token) {
		try {
			int pageIndex = map.getPageIndex();
			int pageSize = map.getPageSize();
			UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
			map.getParam().put("orgCode", userBusiEntity.getDlrCode());
			map.getParam().put("personId", userBusiEntity.getUserID());
			Page<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);
			List<Map<String, Object>> list = baseMapper.queryListAuditReviewRecordInfo(page, map.getParam());
			for(int i=0;i<list.size();i++){
				Map<String, Object> infoMap = list.get(i);
				String extendsJson="";
				if(!StringHelper.IsEmptyOrNull(infoMap.get("extendsJson"))){
					infoMap.putAll(JSON.parseObject(infoMap.get("extendsJson").toString()));
					extendsJson=infoMap.get("extendsJson").toString();
				}
				unTransFiled(extendsJson,infoMap);
			}
			page.setRecords(list);
			return BusicenUtils.page2ListResult(page);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("queryListAuditReviewRecordInfo:", e);
			throw e;
		}
	}

	/**
	 * 回访记录查询
	 *
	 * @param token token
	 * @param map   输入参数
	 * @return ListResult
	 */
	@Override
	public ListResult<Map<String, Object>> queryReviewRecord(ParamPage<Map<String, Object>> map, String token) {
		try {
			if(StringHelper.IsEmptyOrNull(map.getParam().get("billCode"))) {
				throw new BusicenException(message.get("CLUE-REVIEW-RECODE-01"));
			}
			int pageIndex = map.getPageIndex();
			int pageSize = map.getPageSize();
			Page<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);
			List<Map<String, Object>> list = baseMapper.queryReviewRecord(page, map.getParam());
			page.setRecords(list);
			return BusicenUtils.page2ListResult(page);
		} catch (Exception e) {
			log.error("queryReviewRecord:", e);
			throw e;
		}
	}

	/**
	 * 回访详情查询
	 *
	 * @param token token
	 * @param map   输入参数
	 * @return ListResult
	 */
	@Override
	public ListResult<Map<String, Object>> queryReviewInfoById(ParamPage<Map<String, Object>> map,String token) {
		try {
			if(StringHelper.IsEmptyOrNull(map.getParam().get("reviewId"))) {
				throw new BusicenException(message.get("CLUE-REVIEW-MSG-01"));
			}
			int pageIndex = map.getPageIndex();
			int pageSize = map.getPageSize();
			Page<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);
			List<Map<String, Object>> list = baseMapper.queryReviewInfoById(page, map.getParam());
			if(list==null || list.size()<=0){
				list = baseMapper.queryReviewInfoHisById(page, map.getParam());
			}

			for(int i=0;i<list.size();i++){
				Map<String, Object> infoMap = list.get(i);
				String extendsJson="";
				if(!StringHelper.IsEmptyOrNull(infoMap.get("extendsJson"))){
					infoMap.putAll(JSON.parseObject(infoMap.get("extendsJson").toString()));
					extendsJson=infoMap.get("extendsJson").toString();
				}
				unTransFiled(extendsJson,infoMap);
			}

			page.setRecords(list);
			return BusicenUtils.page2ListResult(page);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("queryListAuditReviewRecordInfo:", e);
			throw e;
		}
	}

	/**
	 * 获取当天人员的回访任务数 按任务数量顺序排
	 *
	 * @param page  分页参数
	 * @param param 输入参数
	 * @return List
	 */
	@Override
	public ListResult<Map<String, Object>> queryTaskNumByPerson(ParamPage<Map<String, Object>> map, String token) {
		try {
			int pageIndex = map.getPageIndex();
			int pageSize = map.getPageSize();
			//UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
			//map.getParam().put("orgCode", userBusiEntity.getDlrCode());
			Page<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);
			logger.info("sys执行获取当天人员的回访任务数开始");
			List<Map<String, Object>> list = baseMapper.queryTaskNumByPerson(page, map.getParam());
			logger.info("sys执行获取当天人员的回访任务数结束");
			page.setRecords(list);
			return BusicenUtils.page2ListResult(page);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("queryTaskNumByPerson:", e);
			throw e;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	@Interceptor("csc_clue_reviewassign")
	@Transactional
	public OptResult reviewAssign(Map<String, Object> map, String token) {
		try {
			String reviewIdListString = String.valueOf(map.get("reviewIdList"));
			List<Map<String, Object>> personList = (List<Map<String, Object>>) map.get("personList");
			List<String> reviewIdList = Arrays.asList(reviewIdListString.split(","));
			// 将回访任务ID集合转换为队列
			Queue<String> queue = new LinkedList<>();
			reviewIdList.forEach(queue::offer);
			UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
			for (Map<String, Object> person : personList) {
				int num = Integer.parseInt(person.get("fpNum").toString());
				for (int i = 0; i < num; i++) {
					String reviewId = queue.poll();
					person.put("reviewId", reviewId);
					person.put("assignPersonId", userBusiEntity.getEmpID());
					person.put("assignPersonName", userBusiEntity.getEmpName());
					if (baseMapper.updateReviewAssign(person) == 0) {
						throw new BusicenException(message.get("CLUE-REVIEWASSIGN-08"));
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error("reviewAssign:", e);
			throw e;
		}
		return OptResultBuilder.createOk().build();
	}
	
	/**
	 * 自动平均分配
	 * @param map
	 * @param token
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Interceptor("csc_clue_reviewassign_auto")
	@Transactional
	public OptResult reviewAutoAssign(Map<String, Object> map, String token) {
		try {
			StopWatch stopWatch = new StopWatch("生成线索分配任务");
			StopWatch stopWatch1 = new StopWatch("生成线索分配任务1");
			StopWatch stopWatch2 = new StopWatch("生成线索分配任务2");
			StopWatch stopWatch3 = new StopWatch("生成线索分配任务3");
			StopWatch stopWatch4 = new StopWatch("生成线索分配任务4");
			StopWatch stopWatch5 = new StopWatch("生成线索分配任务5");
			StopWatch stopWatch6 = new StopWatch("生成线索分配任务6-异步");
			UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
			//参数校验
			if(StringHelper.IsEmptyOrNull(map.get("dlrCode"))) {
				map.put("dlrCode", userBusiEntity.getDlrCode());
			}
			checkReviewAutoAssign(map,map.get("dlrCode").toString());

			String reviewIdListString = String.valueOf(map.get("reviewIdList"));
			List<String> reviewIdList = Arrays.asList(reviewIdListString.split(","));
			//分配人员列表
			List<Map<String, Object>> personList = (List<Map<String, Object>>) map.get("personList");
			//分配人员ID
			String personListString =personList.stream().map(p -> p.get("personId").toString()).collect(Collectors.joining(","));
			
			List<Map<String, Object>> fpList = new ArrayList<Map<String,Object>>();
			
			
			//获取分配人员的当前任务数
			ParamPage<Map<String, Object>> paramPage = new ParamPage<Map<String, Object>>();
			Map<String, Object> param = new HashMap<>();
			param.put("orgCode", userBusiEntity.getDlrCode());
			param.put("personIdList", personListString);
			//排除掉要分配的回访ID
			param.put("reviewIdList", reviewIdListString);
			paramPage.setPageIndex(-1);
			paramPage.setPageSize(-1);
			paramPage.setParam(param);

			stopWatch.start("queryTaskNumByPerson:开始");
			stopWatch1.start("获取分配人员的当前任务数：开始");
			ListResult<Map<String, Object>> taskNumResult = queryTaskNumByPerson(paramPage,token);
			stopWatch1.stop();
			stopWatch.stop();

			//人员任务列表(如果没任务的，则给0)
			stopWatch.start("人员任务列表:开始");
			stopWatch2.start("人员任务列表2:开始");
			for(Map<String, Object> person : personList){
				Map<String, Object> personMap = new HashMap<>();
				personMap.put("dlrCode", person.get("dlrCode"));
				personMap.put("dlrShortName", person.get("dlrShortName"));
				personMap.put("receiveEmpId", person.get("receiveEmpId"));
				personMap.put("reviewPersonId", person.get("personId"));
				personMap.put("reviewPersonName", person.get("personName"));
				if(taskNumResult!=null && taskNumResult.getRows()!=null && taskNumResult.getRows().size()>0){
					List<Map<String,Object>> fileList =  taskNumResult.getRows().stream().filter(s->person.get("personId").toString().equals(s.get("reviewPersonId").toString())).collect(Collectors.toList());
					if(fileList!=null && fileList.size()>0){
						personMap.put("taskNum", fileList.get(0).get("taskNum"));
					}else{
						personMap.put("taskNum", "0");
					}
				}else{
					personMap.put("taskNum", "0");
				}
				fpList.add(personMap);
			}
			stopWatch.stop();
			stopWatch2.stop();
			
			//平均分配
			stopWatch.start("平均分配：开始");
			stopWatch3.start("平均分配3：开始");
			List<Map<String, Object>> separateList=new ArrayList<Map<String,Object>>();
			Map<String, Object> saveMap = new HashMap<>();
			for(String reviewId : reviewIdList){
				//按照任务数进行排序，每次都取最少的那个
				stopWatch4.start("任务排序取最少"+ reviewId);
				Collections.sort(fpList,new Comparator<Map>() {
    				@Override
    				public int compare(Map agr1,Map agr2){
    					return  Integer.parseInt(agr1.get("taskNum").toString())-Integer.parseInt(agr2.get("taskNum").toString());
    				}
				});
				stopWatch4.stop();
				Map<String, Object> firstPerson = new HashMap<>();
				firstPerson=fpList.get(0);
				firstPerson.put("taskNum", Integer.valueOf(firstPerson.get("taskNum").toString())+1);
				
				saveMap.put("reviewId", reviewId);
				saveMap.put("assignPersonId", userBusiEntity.getEmpID());
				saveMap.put("assignPersonName", userBusiEntity.getEmpName());
				saveMap.put("personId", fpList.get(0).get("reviewPersonId").toString());
				saveMap.put("personName", fpList.get(0).get("reviewPersonName").toString());
				saveMap.put("receiveEmpId", fpList.get(0).get("receiveEmpId").toString());
				saveMap.put("dlrCode", fpList.get(0).get("dlrCode").toString());
				saveMap.put("dlrShortName", fpList.get(0).get("dlrShortName"));
				stopWatch6.start("异步分配更新店");
//				CompletableFuture.runAsync(() -> {
//					// PC端分配更新店
//					updateClueAssign(saveMap);
//				}, asyncTaskExecutor);
				stopWatch6.stop();
				stopWatch5.start("更新主表");
				if (baseMapper.updateReviewAssign(saveMap) == 0) {
					throw new BusicenException(message.get("CLUE-REVIEWASSIGN-08"));
				}
				stopWatch5.stop();

				separateList.add(saveMap);
			}
			stopWatch.stop();
			stopWatch3.stop();
			System.out.println("线索分配任务:" +stopWatch.prettyPrint() +"毫秒");//;
			System.out.println("线索分配任务:" +stopWatch.getTotalTimeMillis() +"毫秒");//;
			System.out.println("生成线索分配任务1:" +stopWatch1.prettyPrint() +"毫秒");//;
			System.out.println("生成线索分配任务1:" +stopWatch1.getTotalTimeMillis() +"毫秒");//;
			System.out.println("生成线索分配任务2:" +stopWatch2.prettyPrint() +"毫秒");//;
			System.out.println("生成线索分配任务2:" +stopWatch2.getTotalTimeMillis() +"毫秒");//;
			System.out.println("生成线索分配任务3:" +stopWatch3.prettyPrint() +"毫秒");//;
			System.out.println("生成线索分配任务3:" +stopWatch3.getTotalTimeMillis() +"毫秒");//;
			System.out.println("生成线索分配任务4:" +stopWatch4.prettyPrint() +"毫秒");//;
			System.out.println("生成线索分配任务4:" +stopWatch4.getTotalTimeMillis() +"毫秒");//;
			System.out.println("生成线索分配任务5:" +stopWatch5.prettyPrint() +"毫秒");//;
			System.out.println("生成线索分配任务5:" +stopWatch5.getTotalTimeMillis() +"毫秒");//;
			System.out.println("生成线索分配任务6-异步:" +stopWatch6.prettyPrint() +"毫秒");//;
			System.out.println("生成线索分配任务6-异步:" +stopWatch6.getTotalTimeMillis() +"毫秒");//;
			// 客制化传参
			map.put("separateList", separateList);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("reviewAssign:", e);
			throw e;
		}
		return OptResultBuilder.createOk().build();
	}

	private void updateClueAssign(Map<String ,Object> assignMap){

		UpdateWrapper<SacReview> updateReview = new UpdateWrapper<SacReview>();
		updateReview.lambda().set(SacReview::getOrgCode, assignMap.get("dlrCode")).set(SacReview::getOrgName, assignMap.get("dlrShortName")).eq(SacReview::getReviewId, assignMap.get("reviewId"));
		this.update(updateReview);
		UpdateWrapper<SacClueInfoDlr> updateClueInfoDlr = new UpdateWrapper<SacClueInfoDlr>();
		updateClueInfoDlr.lambda().set(SacClueInfoDlr::getDlrCode, assignMap.get("dlrCode")).set(SacClueInfoDlr::getDlrShortName, assignMap.get("dlrShortName")).eq(SacClueInfoDlr::getReviewId, assignMap.get("reviewId"));
		sacClueInfoDlrService.update(updateClueInfoDlr);
	}

	@SuppressWarnings("unchecked")
	@Override
	public void regist(InterceptorWrapperRegistor registor) {
		// 回访分配：前置
		registor.before("csc_clue_reviewassign_valid", (context, model) -> {
			checkValidate((Map<String, Object>) context.data().getP()[0]);
		});
		registor.before("csc_clue_reviewassign_check", (context, model) -> {
			checkReviewAssign((Map<String, Object>) context.data().getP()[0]);
		});
		// 回访分配：更新商机线索
		registor.after("csc_clue_reviewassign_updateclueinfo", (context, model) -> {
			reviewassignUpdateClue(context);
		});
		// 回访自动平均分配：更新商机线索
		registor.after("csc_clue_reviewassign_auto_updateclueinfo", (context, model) -> {
			reviewassignUpdateClue(context);
		});
		// 回访分配：后置
		registor.after("csc_clue_reviewassign_msg", (context, model) -> {
			checkAfter((Map<String, Object>) context.data().getP()[0]);
		});

		// 回访完成更新对应的线索状态和信息
		registor.after("csc_clue_review_updateclueinfo", (context, model) -> {
			Map<String, Object> reviewParam = (Map<String, Object>) context.data().getP()[0];
			String token = (String) context.data().getP()[1];
			reviewUpdateClue(reviewParam, token);
		});

		// 生产回访任务
		// 前置：校验参数
		registor.before("csc_clue_review_addtask_valid", (context, model) -> {
			Map<String, Object> mapParam = (Map<String, Object>) context.data().getP()[0];
			mapParam.put("article", "csc-clue-review-addtask-check");
			checkValidate(mapParam);
		});
		// 生产回访完成更新对应的线索状态和信息
		registor.after("csc_clue_review_addtask_updateclueinfo", (context, model) -> {
			Map<String, Object> reviewParam = (Map<String, Object>) context.data().getP()[0];
			String token = (String) context.data().getP()[1];
			reviewUpdateClue(reviewParam, token);
		});

		// 回访审核更新线索状态
		registor.after("csc_clue_reviewaudit_updateclueinfo", (context, model) -> {
			Map<String, Object> reviewParam = (Map<String, Object>) context.data().getP()[0];
			String token = (String) context.data().getP()[1];
			reviewUpdateClue(reviewParam, token);
		});
		
		// 回访审核撤回更新线索状态
		registor.after("csc_clue_review_shenhecancle_updateclue", (context, model) -> {
			Map<String, Object> reviewParam = (Map<String, Object>) context.data().getP()[0];
			String token = (String) context.data().getP()[1];
			shenheCancleUpdateClue(reviewParam, token);
		});

		// 抢单后置更新线索状态
		registor.after("csc_clue_review_qiangdan_updateclueinfo", (context, model) -> {
			Map<String, Object> reviewParam = (Map<String, Object>) context.data().getP()[0];
			String token = (String) context.data().getP()[1];
			reviewUpdateClue(reviewParam, token);
		});

	}

	// 【回访分配】 后置 更新总部商机或者店端线索
	@SuppressWarnings("unchecked")
	private void reviewassignUpdateClue(InterceptorDataContext context) {
		Map<String, Object> reviewAssignMap = (Map<String, Object>)context.data().getP()[0];
		String token = (String)context.data().getP()[1];
		String reviewIdListString = (String)reviewAssignMap.get("reviewIdList");
		if(StringUtils.isNotBlank(reviewIdListString)) {
			List<String> reviewIdList = Arrays.asList(reviewIdListString.split(","));

			StopWatch stopWatch = new StopWatch("线索分配后置3-生成回访分配任务");
			stopWatch.start("更新总部商机或者店端线索:开始");
			reviewIdList.forEach(reviewId->{
				SacReview review = this.getById(reviewId);
				String billType = review.getBillType();
				String billCode = review.getBillCode();
				if(review != null) {
					if("CLUE".equals(billType)) {// 商机
						Map<String, Object> clueMap = getClueMap(billCode);
						if(clueMap != null) {
							// 回访人员名称
							clueMap.put("reviewPersonName", review.getReviewPersonName());
							clueMap.put("reviewPersonId", review.getReviewPersonId());
							// 分配时间
							clueMap.put("assignTime", Calendar.getInstance().getTime());
							// 分配后 商机状态修改成 待回访
							clueMap.put("statusCode", "2");
							clueMap.put("statusName", "待回访");
							clueInfoService.updateMap(clueMap, token);
						}
					}  else if("DLRCLUE".equals(billType)) {//店端
						Map<String, Object> dlrClueMap = getDlrClueMap(billCode);
						if(dlrClueMap != null) {
							// 回访人员名称
							dlrClueMap.put("reviewPersonName", review.getReviewPersonName());
							dlrClueMap.put("reviewPersonId", review.getReviewPersonId());
							dlrClueMap.put("dlrCode", review.getOrgCode());
							dlrClueMap.put("dlrShortName", review.getOrgName());
							// 分配时间
							dlrClueMap.put("assignTime", Calendar.getInstance().getTime());
							dlrClueMap.put("statusCode", "2");
							dlrClueMap.put("statusName", "待回访");
							clueInfoDlrService.updateMap(dlrClueMap, token);
						}
					}
				}
			});
			stopWatch.stop();
			System.out.println("线索分配后置3-生成回访分配任务:" +stopWatch.prettyPrint() +"毫秒");//;
			System.out.println("线索分配后置3-生成回访分配任务:" +stopWatch.getTotalTimeMillis() +"毫秒");//;
		}
	}

	// 【回访】 后置 更新总部商机或者店端线索
	private void reviewUpdateClue(Map<String, Object> reviewParam, String token) {
		String billType = (String) reviewParam.get("billType");
		String billCode = (String) reviewParam.get("billCode");
		if("CLUE".equals(billType)) {// 商机
			Map<String, Object> clueMap= getClueMap(billCode);
			if(ReviewUpdateClueUtil.needUpdateClue(clueMap, reviewParam, token)) {
				clueInfoService.updateMap(clueMap, token);
			}
			logger.debug("[statusCode={}]", clueMap.get("statusCode"));
		} else if("DLRCLUE".equals(billType)) {//店端
			Map<String, Object> dlrClueMap= getDlrClueMap(billCode);
			if(ReviewUpdateClueUtil.needUpdateDlrClue(dlrClueMap, reviewParam, token)) {
				clueInfoDlrService.updateMap(dlrClueMap, token);
			}
			logger.debug("[statusCode={}]", dlrClueMap.get("statusCode"));
		}
	}
	
	// 【战败/失控/无效撤回】 后置 更新总部商机或者店端线索
	private void shenheCancleUpdateClue(Map<String, Object> reviewParam, String token) {
		String billType = (String) reviewParam.get("billType");
		String billCode = (String) reviewParam.get("billCode");
		if("CLUE".equals(billType)) {// 商机
			Map<String, Object> clueMap= getClueMap(billCode);
			clueMap.put("nodeCode", ReviewNodeEnum.Save.getResult());
			if(ReviewUpdateClueUtil.needUpdateClue(clueMap, reviewParam, token)) {
				clueInfoService.updateMap(clueMap, token);
			}
			logger.debug("[statusCode={}]", clueMap.get("statusCode"));
		} else if("DLRCLUE".equals(billType)) {//店端
			Map<String, Object> dlrClueMap= getDlrClueMap(billCode);
			reviewParam.put("nodeCode", ReviewNodeEnum.Save.getResult());
			if(ReviewUpdateClueUtil.needUpdateDlrClue(dlrClueMap, reviewParam, token)) {
				clueInfoDlrService.updateMap(dlrClueMap, token);
			}
			logger.debug("[statusCode={}]", dlrClueMap.get("statusCode"));
		}
	}

	public void checkAfter(Map<String, Object> mapParam) {

	}

	@SuppressWarnings("unchecked")
	public void checkReviewAssign(Map<String, Object> mapParam) {
		try {
			String reviewIdListString = String.valueOf(mapParam.get("reviewIdList"));
			List<String> reviewIdList = Arrays.asList(reviewIdListString.split(","));
			List<Map<String, Object>> personList = (List<Map<String, Object>>) mapParam.get("personList");
			// 校验reviewId是否存在
			for (String reviewId : reviewIdList) {
				QueryWrapper<SacReview> queryWrapper = new QueryWrapper<SacReview>();
				queryWrapper.eq("REVIEW_ID", reviewId);
				int count = baseMapper.selectCount(queryWrapper);
				if (count == 0) {
					throw BusicenException.create("回访ID: " + reviewId + "不存在");
				}

			}
			for (Map<String, Object> person : personList) {
				// 字段校验
				ValidResultCtn fireRule = fireFieldRule.fireRule(person, "csc-clue-review-personlist-check",
						"maindata");
				String resMsg = fireRule.getNotValidMessage();
				if (!fireRule.isValid()) {
					throw new BusicenException(resMsg);
				}
			}
			IntSummaryStatistics statistics = personList.stream()
					.collect(Collectors.summarizingInt(e -> Integer.parseInt(e.get("fpNum").toString())));
			// 分配总数量
			if (reviewIdList.size() != statistics.getSum()) {
				throw new BusicenException(message.get("CLUE-REVIEWASSIGN-07"));
			}
		} catch (Exception e) {
			throw e;
		}
	}
	
	@SuppressWarnings("unchecked")
	public void checkReviewAutoAssign(Map<String, Object> mapParam,String dlrCode) {
		try {
			//参数校验
			fireFieldRule.fireRuleExcpt(mapParam, "csc-clue-review-check-0007", "maindata");
			
			String reviewIdListString = String.valueOf(mapParam.get("reviewIdList"));
			List<String> reviewIdList = Arrays.asList(reviewIdListString.split(","));
			List<Map<String, Object>> personList = (List<Map<String, Object>>) mapParam.get("personList");
			// 校验reviewId是否存在
			for (String reviewId : reviewIdList) {
				QueryWrapper<SacReview> queryWrapper = new QueryWrapper<SacReview>();
				queryWrapper.lambda().eq(SacReview::getReviewId, reviewId);
				//queryWrapper.lambda().eq(SacReview::getOrgCode, dlrCode);
				int count = baseMapper.selectCount(queryWrapper);
				if (count == 0) {
					throw BusicenException.create("回访ID: " + reviewId + "不存在");
				}

			}
			for (Map<String, Object> person : personList) {
				// 字段校验
				fireFieldRule.fireRuleExcpt(person, "review-autoassign-person-check","maindata");
			}
		} catch (Exception e) {
			throw e;
		}
	}

	@Autowired ISacClueInfoService clueInfoService;
	@Autowired SacClueInfoMapper clueInfoMapper;

	@Autowired SacClueInfoDlrService clueInfoDlrService;
	@Autowired SacClueInfoDlrMapper clueInfoDlrMapper;

	private Map<String, Object> getClueMap(String billCode) {
		if (StringUtils.isBlank(billCode)) {
			return null;
		}
		Page<Map<String, Object>> page = new Page<Map<String, Object>>(1, Integer.MAX_VALUE);
		Map<String, Object> param = new HashMap<>();
		param.put("serverOrder", billCode);
		List<Map<String, Object>> list = clueInfoMapper.selectByPage(page, param);
		if (list == null || list.size() ==0) {
			return null;
		}
		return list.get(0);
	}
	private Map<String, Object> getDlrClueMap(String billCode) {
		if (StringUtils.isBlank(billCode)) {
			return null;
		}
		Page<Map<String, Object>> page = new Page<Map<String, Object>>(1, Integer.MAX_VALUE);
		Map<String, Object> param = new HashMap<>();
		param.put("serverOrder", billCode);
		List<Map<String, Object>> list = clueInfoDlrMapper.selectByPage(page, param);
		if (list == null || list.size() ==0) {
			return null;
		}
		return list.get(0);
	}


	// 回访审核后置
	public void updateClueAfterAudit(Map<String, Object> reviewParam) {
		String token = (String) reviewParam.get("token");
		String billCode = (String) reviewParam.get("billCode");
		String shStatusCode = (String) reviewParam.get("shStatus");
		String applyTypeCode = (String) reviewParam.get("applyTypeCode");

		if (StringUtils.isNotBlank(billCode)) {
			Page<Map<String, Object>> page = new Page<Map<String, Object>>(1, 1);
			Map<String, Object> param = new HashMap<>();
			param.put("serverOrder", billCode);
			List<Map<String, Object>> list = clueInfoMapper.selectByPage(page, param);
			if (list != null && !list.isEmpty()) {
				Map<String, Object> clueMap = list.get(0);
				/*
				 * 商机状态：1 待分配 2 待回访 3 待派发 4 已派发 5 重复留资 6 派发失败 7 战败申请 8 失控申请 9 无效申请 10 战败 11 失控
				 * 12 无效线索 13 关闭
				 */
				// 通过
				if (ReviewAuditStatusEnum.ok.getResult().equals(shStatusCode)) {
					if (ReviewAuditTypeEnum.defeat.getResult().equals(applyTypeCode)) {
						clueMap.put("statusCode", "10");
						clueMap.put("statusName", "战败");
					} else if (ReviewAuditTypeEnum.notctrl.getResult().equals(applyTypeCode)) {
						clueMap.put("statusCode", "11");
						clueMap.put("statusName", "失控 ");
					} else if (ReviewAuditTypeEnum.invalid.getResult().equals(applyTypeCode)) {
						clueMap.put("statusCode", "12");
						clueMap.put("statusName", "无效线索 ");
					}
				} else if (ReviewAuditStatusEnum.bh.getResult().equals(shStatusCode)) {
					// 驳回
					clueMap.put("statusCode", "2");
					clueMap.put("statusName", "待回访 ");
				}
				clueMap.put("token", token);
				ParamBase<Map<String, Object>> clueParam = new ParamBase<>();
				clueParam.setParam(clueMap);
				//				UserBusiEntity user = BusicenContext.getCurrentUserBusiInfo(token);
				clueInfoService.saveMap(clueParam, token);
			}
		}

	}

	public void checkValidate(Map<String, Object> mapParam) {
		String article = (String) mapParam.get("article");
		ValidResultCtn fireRule = fireFieldRule.fireRule(mapParam, article, "maindata");
		String resMsg = fireRule.getNotValidMessage();
		if (!fireRule.isValid()) {
			throw new BusicenException(resMsg);
		}
	}

	/**
	 * 回访抢单
	 *
	 * @param reviewMap
	 * @param token
	 */
	@Transactional(rollbackFor = Exception.class)
	@Interceptor("csc_clue_review_qiangdan")
	@Override
	public EntityResult<Map<String, Object>> qiangdan(Map<String, Object> reviewMap, String token) {
		try {
			// 校验参数
			fireFieldRule.fireRuleExcpt(reviewMap, "csc_clue_review_qiangdan-check", "maindata");
			// 校验是否存在
			QueryWrapper<SacReview> query1 = new QueryWrapper<>();
			query1.lambda().eq(SacReview::getReviewId, reviewMap.get("reviewId").toString());
			SacReview reviewInfo = baseMapper.selectOne(query1);
			if (reviewInfo == null) {
				throw BusicenException.create("该回访单不存在!");
			} else if (!reviewInfo.getUpdateControlId().equals(reviewMap.get("updateControlId").toString())) {
				throw BusicenException.create("并发操作,请重试!");
			}

			Map<String, Object> tmpMap = MapUtil.convertToMap(reviewInfo);
			MapUtil.removeNullValue(tmpMap);
			reviewMap.putAll(tmpMap);

			// 获取用户信息并赋值
			UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
			reviewMap.put("assignTime", Calendar.getInstance().getTime());
			reviewMap.put("assignPersonId", userBusiEntity.getUserID());
			reviewMap.put("assignPersonName", userBusiEntity.getEmpName());
			reviewMap.put("reviewPersonId", userBusiEntity.getUserID());
			reviewMap.put("reviewPersonName", userBusiEntity.getEmpName());
			reviewMap.put("modifier", userBusiEntity.getUserID());
			reviewMap.put("modifyName", userBusiEntity.getEmpName());
			//			reviewMap.put("billCode", reviewInfo.getBillCode());
			//			reviewMap.put("billType", reviewInfo.getBillType());
			//			reviewMap.put("nodeCode", reviewInfo.getNodeCode());
			EntityResult<Map<String, Object>> returnMap = sacReviewUpdate(reviewMap, token);
			return ResultHandler.updateOk(returnMap.getRows());
		} catch (Exception e) {
			throw BusicenException.create("保存失败" + e.getMessage());
		}
	}

	/**
	 * 根据主键判断插入或更新
	 *
	 * @param info
	 * @return
	 */
	@Override
	@Transactional
	public EntityResult<Map<String, Object>> sacReviewSave(Map<String, Object> mapParam, String token) {
		try {
			Boolean updateFlag = false;
			if (!StringHelper.IsEmptyOrNull(mapParam.get("reviewId"))) {
				QueryWrapper<SacReview> wrapper = new QueryWrapper<>();
				wrapper.lambda().eq(SacReview::getReviewId, mapParam.get("reviewId"));
				if (list(wrapper).size() > 0) {
					updateFlag = true;
				}
			}
			if (!updateFlag) {
				// 新增
				if (StringHelper.IsEmptyOrNull(mapParam.get("reviewId"))) {
					// 主键
					mapParam.put("reviewId", UUID.randomUUID().toString());
				}
				BusicenUtils.invokeUserInfo(mapParam, SOU.Save, token);
				sacReviewMapper.insertSacReview(mapParam);
			} else {
				// 更新
				BusicenUtils.invokeUserInfo(mapParam, SOU.Update, token);
				sacReviewMapper.updateSacReview(mapParam);
			}
			QueryWrapper<SacReview> wrapper = new QueryWrapper<>();
			wrapper.lambda().eq(SacReview::getReviewId, mapParam.get("reviewId"));
			return ResultHandler.updateOk(listMaps(wrapper).get(0));
		} catch (Exception e) {
			log.error("sacReviewSave", e);
			throw e;
		}
	}

	/**
	 * 更新回访表
	 *
	 * @param info
	 * @return
	 */
	@Override
	@Transactional
	public EntityResult<Map<String, Object>> sacReviewUpdate(Map<String, Object> mapParam, String token) {
		try {
			// invokeUserInfo会把updateControlId更新掉
			String updateControlId = !StringHelper.IsEmptyOrNull(mapParam.get("updateControlId"))
					? mapParam.get("updateControlId").toString()
							: "";
					// 更新
					BusicenUtils.invokeUserInfo(mapParam, SOU.Update, token);
					if (!StringHelper.IsEmptyOrNull(updateControlId)) {
						mapParam.put("updateControlId", updateControlId);
					}
					int rows = sacReviewMapper.updateSacReview(mapParam);
					if (rows <= 0) {
						throw BusicenException.create("并发操作，请重试");
					}

					QueryWrapper<SacReview> wrapper = new QueryWrapper<>();
					wrapper.lambda().eq(SacReview::getReviewId, mapParam.get("reviewId"));

					return ResultHandler.updateOk(listMaps(wrapper).get(0));
		} catch (Exception e) {
			log.error("sacReviewUpdate", e);
			throw e;
		}
	}

	/**
	 * 本人待回访任务导出 @throws
	 */
	@SuppressWarnings("unchecked")
	@Override
	public OptResult exportListMeReviewInfo(ParamBase<Map<String, Object>> dataInfo, String token,
			HttpServletResponse response) {

		try {
			String title = "本人待回访任务";// 导出文件名称
			List<Map<String, Object>> columnList=(List<Map<String, Object>>) dataInfo.getParam().get("columnList");// 页面网格列列表
			if (columnList == null) {
				throw BusicenException.create(message.get("EXCEL-EXPORT-01"));
			}
			// 先将结果查询出来
			ParamPage<Map<String, Object>> mapParamPage = new ParamPage<Map<String, Object>>();
			mapParamPage.setPageIndex(1);
			mapParamPage.setPageSize(-1);
			mapParamPage.setParam(dataInfo.getParam());
			ListResult<Map<String, Object>> listResult = queryListMeReviewInfo(mapParamPage, token);
			List<Map<String, Object>> rows = listResult.getRows();
			// 导出excel
			ExcelExport export = new ExcelExport();
			export.excelExport(token, title, response, rows, columnList);

		} catch (Exception e) {
			e.printStackTrace();
			throw new BusicenException(e.getMessage());
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public OptResult exportListGroupReviewInfo(ParamBase<Map<String, Object>> dataInfo, String token,
			HttpServletResponse response) {
		try {
			String title = "本组待回访任务";// 导出文件名称
			List<Map<String, Object>> columnList=(List<Map<String, Object>>) dataInfo.getParam().get("columnList");// 页面网格列列表
			if (columnList == null) {
				throw BusicenException.create(message.get("EXCEL-EXPORT-01"));
			}
			// 先将结果查询出来
			ParamPage<Map<String, Object>> mapParamPage = new ParamPage<Map<String, Object>>();
			mapParamPage.setPageIndex(1);
			mapParamPage.setPageSize(-1);
			mapParamPage.setParam(dataInfo.getParam());
			ListResult<Map<String, Object>> listResult = queryListGroupReviewInfo(mapParamPage, token);
			List<Map<String, Object>> rows = listResult.getRows();
			// 导出excel
			ExcelExport export = new ExcelExport();
			export.excelExport(token, title, response, rows, columnList);

		} catch (Exception e) {
			e.printStackTrace();
			throw new BusicenException(e.getMessage());
		}
		return null;
	}

	/**
	 * 获取下次回访时间
	 */
	@Override
	public OptResult getNextReviewTime(Map<String, Object> mapParam, String token) {
		// 校验字段
		String article = (String) mapParam.get("article");
		ValidResultCtn fireRule = fireFieldRule.fireRule(mapParam, article, "maindata");
		String resMsg = fireRule.getNotValidMessage();
		if (!fireRule.isValid()) {
			throw new BusicenException(resMsg);
		}

		// 查询回访计划配置表
		ParamPage<Map<String, Object>> paramPageMap = new ParamPage<Map<String, Object>>();
		paramPageMap.setPageIndex(1);
		paramPageMap.setPageSize(-1);
		paramPageMap.setParam(mapParam);
		List<Map<String, Object>> list=sacReviewPlanService.queryListReviewPlanInfo(paramPageMap,token).getRows();
		Integer dayInteger=0;
		if(list.size()>0) {
			dayInteger = Integer.valueOf(String.valueOf(list.get(0).get("nextReviewTime")));
		}
		OptResult result = new OptResult();
		result.setResult("1");
		if (dayInteger == 0) {
			result.setMsg(null);
		} else {
			// 计算下次回访时间=当前时间+下次回访天数
			Date date = new Date();
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);// 设置起时间
			cal.add(Calendar.DATE, dayInteger);// 增加天数
			SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String str1 = sdf1.format(cal.getTime());
			result.setMsg(str1);
		}
		return result;
	}


}
