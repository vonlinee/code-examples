package com.ly.mp.csc.clue.controller;

import java.util.Arrays;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.constant.UserBusiEntity;
import com.ly.mp.busi.base.context.BusicenContext;
import com.ly.mp.busi.base.context.BusicenInvoker;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.enums.ReviewAuditStatusEnum;
import com.ly.mp.csc.clue.service.ISacTransferApplyService;
import com.ly.mp.csc.clue.service.ISacTransferAuditService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import javax.servlet.http.HttpServletResponse;

@Api(value = "划转审核", tags = { "划转审核" })
@RestController
@RequestMapping(value = "/ly/sac/transfer")
public class SacTransferApplyController {

	@Autowired ISacTransferApplyService sacTransferApplyService;
	@Autowired ISacTransferAuditService sacTransferAuditService;

	@ApiOperation(value="划转申请",notes="划转申请")
	@RequestMapping(value="/transferapply.do",method=RequestMethod.POST)
	public EntityResult<Map<String, Object>> transferApply(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) ParamBase<Map<String, Object>> queryCondition) throws Exception{
		queryCondition.getParam().put("token", authentication);
		return BusicenInvoker.doEntity(()->sacTransferApplyService.transferApply(queryCondition.getParam(), authentication)).result();
	}

	@ApiOperation(value="本人划转申请单列表查询",notes="划转申请单列表查询")
	@RequestMapping(value="/transferapplyquery.do",method=RequestMethod.POST)
	public ListResult<Map<String, Object>> transferApplyQuery(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) ParamPage<Map<String, Object>> queryCondition) throws Exception{
		return BusicenInvoker.doList(()->{
			Map<String, Object> param = queryCondition.getParam();
			Assert.notNull(param, "参数param不能为空");
			param.put("token", authentication);
			// 根据token获取当前用户，当前用户就是接收门店的人员，作为过滤条件
			UserBusiEntity user = BusicenContext.getCurrentUserBusiInfo(authentication);
			// 申请人ID与当前登录人ID相同的申请单
			param.put("creator", user.getUserID());
			return sacTransferApplyService.queryApplyList(queryCondition, authentication);
		}).result();
	}

	@ApiOperation(value="划转申请单列表查询",notes="划转申请单列表查询")
	@RequestMapping(value="/transferapplydlrquery.do",method=RequestMethod.POST)
	public ListResult<Map<String, Object>> transferApplyDlrQuery(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) ParamPage<Map<String, Object>> queryCondition) throws Exception{
		return BusicenInvoker.doList(()->{
			Map<String, Object> param = queryCondition.getParam();
			Assert.notNull(param, "参数param不能为空");
			param.put("token", authentication);
			// 根据token获取当前用户，当前用户就是接收门店的人员，作为过滤条件
			//UserBusiEntity user = BusicenContext.getCurrentUserBusiInfo(authentication);
			// 调出店或者调入店与当前登录人专营店编码相同的申请单
//			if(user.getDlrCode() == null) {
//				// 如果 DlrCode为空则不能查出记录
//				param.put("orDlrCode", "-1");
//			} else {
//				param.put("orDlrCode", user.getDlrCode());
//			}
			return sacTransferApplyService.queryApplyList(queryCondition, authentication);
		}).result();
	}

	@ApiOperation(value="划转申请单列表导出", notes="划转申请单列表导出")
	@RequestMapping(value = "/exportTransferapplydlrquery.do", method = RequestMethod.POST)
	public OptResult exportTransferapplydlrquery(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
										   @RequestBody(required = false) ParamPage<Map<String, Object>> param,
										   HttpServletResponse response) throws Exception{
		return sacTransferApplyService.exportTransferapplydlrquery(param,response,authentication);
	}

	@ApiOperation(value="审核任务列表查询",notes="审核任务列表查询")
	@RequestMapping(value="/auditlistquery.do",method=RequestMethod.POST)
	public ListResult<Map<String, Object>> auditListQuery(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) ParamPage<Map<String, Object>> queryCondition) throws Exception{
		return BusicenInvoker.doList(()->{
			Map<String, Object> param = queryCondition.getParam();
			Assert.notNull(param, "参数param不能为空");
			param.put("token", authentication);
			param.put("shStatus", ReviewAuditStatusEnum.unAudit.getResult());
			return sacTransferApplyService.queryAuditList(queryCondition, authentication);
		}).result();
	}

	@ApiOperation(value = "划转审核", notes = "划转审核")
	@RequestMapping(value = "/transferaudit.do", method = RequestMethod.POST)
	public OptResult transferAudit(@RequestHeader(name = "authorization", required = false) String authentication,
			@RequestBody(required = false) ParamBase<Map<String, Object>> mapParam) {
		mapParam.getParam().put("token", authentication);
		return BusicenInvoker.doOpt(() -> sacTransferAuditService.transferAudit(mapParam.getParam(), authentication)).result();
	}

	@ApiOperation(value="审核历史列表查询",notes="审核历史列表查询")
	@RequestMapping(value="/historylistquery.do",method=RequestMethod.POST)
	public ListResult<Map<String, Object>> historyListQuery(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) ParamPage<Map<String, Object>> queryCondition) throws Exception{
		return BusicenInvoker.doList(()->{
			Map<String, Object> param = queryCondition.getParam();
			Assert.notNull(param, "参数param不能为空");
			param.put("token", authentication);
			param.put("shStatusList", Arrays.asList(ReviewAuditStatusEnum.ok.getResult(), ReviewAuditStatusEnum.bh.getResult()));
			return sacTransferApplyService.queryAuditHisList(queryCondition, authentication);
		}).result();
	}
}
