package com.ly.mp.csc.clue.service;

import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.entities.SacWorkGroup;
import com.baomidou.mybatisplus.extension.service.IService;

import com.ly.mp.component.entities.EntityResult;
import java.util.Map;

/**
 * <p>
 * 工作组表 服务类
 * </p>
 *
 * @author ly-busicen
 * @since 2021-08-17
 */
public interface ISacWorkGroupService extends IService<SacWorkGroup> {

	
	/**
	 * 根据主键判断插入或更新
	 * @param info
	 * @return
	 */
	EntityResult<Map<String, Object>> sacWorkGroupSave(Map<String, Object> mapParam, String token);

    /**
     * 查询工作组信息
     * @param map 输入参数
     * @param token token
     * @return ListResult
     */
    ListResult<Map<String,Object>> queryListWorkGroupInfo(ParamPage<Map<String,Object>> map, String token);

    /**
     * 保存工作组和工作组人员信息
     * @param map 输入参数 csc-clue-group-check-0001
     * @param token token
     * @return OptResult
     */
    OptResult saveWorkGroupInfo(Map<String, Object> map, String token);

	/**
	 * 工作组设置组长
	 * @param map 输入参数  csc-clue-group-check-0002
	 * @return OptResult
	 */
	OptResult saveLeader(Map<String,Object> map,String token);

	/**
	 * 删除成员
	 * @param map 输入参数 csc-clue-group-check-0003
	 * @return OptResult
	 */
	OptResult deleteWorkGroupUserInfo(Map<String,Object> map);

	/**
	 * 查询工作组人员信息
	 * @param map 输入参数
	 * @param token token
	 * @return listResult
	 */
	ListResult<Map<String,Object>> queryListWorkGroupUserInfo(ParamPage<Map<String,Object>> map, String token);
	
	//查询本组所有人员用户列表,逗号分割
	String selectGroupUserList(String empId,String isLeader);
	
	/**
	 * 获取本组员工待回访数列表
	 * @param map 输入参数
	 * @param token token
	 * @return ListResult
	 */
	ListResult<Map<String,Object>> selectGroupUserReviewNum(ParamPage<Map<String,Object>> map, String token);
}
