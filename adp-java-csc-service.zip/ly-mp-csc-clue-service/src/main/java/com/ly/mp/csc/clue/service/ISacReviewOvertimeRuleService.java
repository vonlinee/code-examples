package com.ly.mp.csc.clue.service;

import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.entities.SacReviewOvertimeRule;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.Map;

public interface ISacReviewOvertimeRuleService extends IService<SacReviewOvertimeRule>{

    /**
     * com.ly.mp.csc.clue.service.SacReviewOvertimeRuleService
     * 超期规则保存
     * @param map 输入参数
     * @param token token
     * @return com.ly.mp.component.entities.OptResult
     * @author zhouhao
     * @date 2021/8/17 14:26
     */
    OptResult saveReviewOvertimeRuleInfo(Map<String,Object> map , String token);

    /**
     * com.ly.mp.csc.clue.service.SacReviewOvertimeRuleService
     * 超期规则查询
     * @param map 查询条件
     * @return com.ly.mp.component.entities.ListResult<java.util.Map<java.lang.String,java.lang.Object>>
     * @author zhouhao
     * @date 2021/8/17 14:26
     */
    ListResult<Map<String,Object>> queryListReviewOvertimeRuleInfo(ParamPage<Map<String,Object>> dataInfo,String token);

    /**
     * 超期规则明细保存
     * @param map 输入参数
     * @param token token
     * @return OptResult
     */
    OptResult saveReviewOvertimeRuleDInfo(Map<String,Object> map,String token);

    OptResult deleteReviewOvertimeRuleDInfo(Map<String,Object> map,String token);

    /**
     *  超期规则删除
     * @param map 输出参数
     * @param token token
     * @return OptResult
     */
    OptResult deleteReviewOvertimeRuleInfo(Map<String,Object> map , String token);

    /**
     * com.ly.mp.csc.clue.service.SacReviewOvertimeRuleService
     * 超期规则明细查询
     * @param map 查询条件
     * @return com.ly.mp.component.entities.ListResult
     * @author zhouhao
     * @date 2021/8/17 14:26
     */
    ListResult<Map<String,Object>> queryListReviewOvertimeRuleDInfo(ParamPage<Map<String,Object>> dataInfo);
}
