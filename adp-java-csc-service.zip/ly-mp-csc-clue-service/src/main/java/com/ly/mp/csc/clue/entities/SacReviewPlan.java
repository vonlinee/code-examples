package com.ly.mp.csc.clue.entities;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.time.LocalDateTime;

/**
    * 回访计划设置表
    */
@TableName(value = "t_sac_review_plan")
public class SacReviewPlan {
    /**
     * 计划ID
     */
    @TableId(value = "PLAN_ID", type = IdType.INPUT)
    private String planId;

    /**
     * 所属组织
     */
    @TableField(value = "ORG_CODE")
    private String orgCode;

    /**
     * 所属组织名称
     */
    @TableField(value = "ORG_NAME")
    private String orgName;

    /**
     * 回访单据类型
     */
    @TableField(value = "BILL_TYPE")
    private String billType;

    /**
     * 回访单据类型名称
     */
    @TableField(value = "BILL_TYPE_NAME")
    private String billTypeName;

    /**
     * 回访单据业务类型
     */
    @TableField(value = "BUSINESS_TYPE")
    private String businessType;

    /**
     * 回访单据业务类型名称
     */
    @TableField(value = "BUSINESS_TYPE_NAME")
    private String businessTypeName;

    /**
     * 校验字段编码
     */
    @TableField(value = "FIELD_CODE")
    private String fieldCode;

    /**
     * 校验字段说明
     */
    @TableField(value = "FIELD_NAME")
    private String fieldName;

    /**
     * 校验字段值
     */
    @TableField(value = "FIELD_VALUE")
    private String fieldValue;

    /**
     * 下次回访时间(天)
     */
    @TableField(value = "NEXT_REVIEW_TIME")
    private String nextReviewTime;

    /**
     * 厂商标识ID
     */
    @TableField(value = "OEM_ID")
    private String oemId;

    /**
     * 集团标识ID
     */
    @TableField(value = "GROUP_ID")
    private String groupId;

    /**
     * 创建人ID
     */
    @TableField(value = "CREATOR")
    private String creator;

    /**
     * 创建人
     */
    @TableField(value = "CREATED_NAME")
    private String createdName;

    /**
     * 创建日期
     */
    @TableField(value = "CREATED_DATE")
    private LocalDateTime createdDate;

    /**
     * 修改人ID
     */
    @TableField(value = "MODIFIER")
    private String modifier;

    /**
     * 修改人
     */
    @TableField(value = "MODIFY_NAME")
    private String modifyName;

    /**
     * 最后更新日期
     */
    @TableField(value = "LAST_UPDATED_DATE")
    private LocalDateTime lastUpdatedDate;

    /**
     * 是否可用
     */
    @TableField(value = "IS_ENABLE")
    private String isEnable;

    /**
     * 并发控制ID
     */
    @TableField(value = "UPDATE_CONTROL_ID")
    private String updateControlId;

    /**
     * 获取计划ID
     *
     * @return PLAN_ID - 计划ID
     */
    public String getPlanId() {
        return planId;
    }

    /**
     * 设置计划ID
     *
     * @param planId 计划ID
     */
    public void setPlanId(String planId) {
        this.planId = planId;
    }

    /**
     * 获取所属组织
     *
     * @return ORG_CODE - 所属组织
     */
    public String getOrgCode() {
        return orgCode;
    }

    /**
     * 设置所属组织
     *
     * @param orgCode 所属组织
     */
    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }

    /**
     * 获取所属组织名称
     *
     * @return ORG_NAME - 所属组织名称
     */
    public String getOrgName() {
        return orgName;
    }

    /**
     * 设置所属组织名称
     *
     * @param orgName 所属组织名称
     */
    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    /**
     * 获取回访单据类型
     *
     * @return BILL_TYPE - 回访单据类型
     */
    public String getBillType() {
        return billType;
    }

    /**
     * 设置回访单据类型
     *
     * @param billType 回访单据类型
     */
    public void setBillType(String billType) {
        this.billType = billType;
    }

    /**
     * 获取回访单据类型名称
     *
     * @return BILL_TYPE_NAME - 回访单据类型名称
     */
    public String getBillTypeName() {
        return billTypeName;
    }

    /**
     * 设置回访单据类型名称
     *
     * @param billTypeName 回访单据类型名称
     */
    public void setBillTypeName(String billTypeName) {
        this.billTypeName = billTypeName;
    }

    /**
     * 获取回访单据业务类型
     *
     * @return BUSINESS_TYPE - 回访单据业务类型
     */
    public String getBusinessType() {
        return businessType;
    }

    /**
     * 设置回访单据业务类型
     *
     * @param businessType 回访单据业务类型
     */
    public void setBusinessType(String businessType) {
        this.businessType = businessType;
    }

    /**
     * 获取回访单据业务类型名称
     *
     * @return BUSINESS_TYPE_NAME - 回访单据业务类型名称
     */
    public String getBusinessTypeName() {
        return businessTypeName;
    }

    /**
     * 设置回访单据业务类型名称
     *
     * @param businessTypeName 回访单据业务类型名称
     */
    public void setBusinessTypeName(String businessTypeName) {
        this.businessTypeName = businessTypeName;
    }

    /**
     * 获取校验字段编码
     *
     * @return FIELD_CODE - 校验字段编码
     */
    public String getFieldCode() {
        return fieldCode;
    }

    /**
     * 设置校验字段编码
     *
     * @param fieldCode 校验字段编码
     */
    public void setFieldCode(String fieldCode) {
        this.fieldCode = fieldCode;
    }

    /**
     * 获取校验字段说明
     *
     * @return FIELD_NAME - 校验字段说明
     */
    public String getFieldName() {
        return fieldName;
    }

    /**
     * 设置校验字段说明
     *
     * @param fieldName 校验字段说明
     */
    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    /**
     * 获取校验字段值
     *
     * @return FIELD_VALUE - 校验字段值
     */
    public String getFieldValue() {
        return fieldValue;
    }

    /**
     * 设置校验字段值
     *
     * @param fieldValue 校验字段值
     */
    public void setFieldValue(String fieldValue) {
        this.fieldValue = fieldValue;
    }

    /**
     * 获取下次回访时间(天)
     *
     * @return NEXT_REVIEW_TIME - 下次回访时间(天)
     */
    public String getNextReviewTime() {
        return nextReviewTime;
    }

    /**
     * 设置下次回访时间(天)
     *
     * @param nextReviewTime 下次回访时间(天)
     */
    public void setNextReviewTime(String nextReviewTime) {
        this.nextReviewTime = nextReviewTime;
    }

    /**
     * 获取厂商标识ID
     *
     * @return OEM_ID - 厂商标识ID
     */
    public String getOemId() {
        return oemId;
    }

    /**
     * 设置厂商标识ID
     *
     * @param oemId 厂商标识ID
     */
    public void setOemId(String oemId) {
        this.oemId = oemId;
    }

    /**
     * 获取集团标识ID
     *
     * @return GROUP_ID - 集团标识ID
     */
    public String getGroupId() {
        return groupId;
    }

    /**
     * 设置集团标识ID
     *
     * @param groupId 集团标识ID
     */
    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    /**
     * 获取创建人ID
     *
     * @return CREATOR - 创建人ID
     */
    public String getCreator() {
        return creator;
    }

    /**
     * 设置创建人ID
     *
     * @param creator 创建人ID
     */
    public void setCreator(String creator) {
        this.creator = creator;
    }

    /**
     * 获取创建人
     *
     * @return CREATED_NAME - 创建人
     */
    public String getCreatedName() {
        return createdName;
    }

    /**
     * 设置创建人
     *
     * @param createdName 创建人
     */
    public void setCreatedName(String createdName) {
        this.createdName = createdName;
    }

    /**
     * 获取创建日期
     *
     * @return CREATED_DATE - 创建日期
     */
    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    /**
     * 设置创建日期
     *
     * @param createdDate 创建日期
     */
    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * 获取修改人ID
     *
     * @return MODIFIER - 修改人ID
     */
    public String getModifier() {
        return modifier;
    }

    /**
     * 设置修改人ID
     *
     * @param modifier 修改人ID
     */
    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    /**
     * 获取修改人
     *
     * @return MODIFY_NAME - 修改人
     */
    public String getModifyName() {
        return modifyName;
    }

    /**
     * 设置修改人
     *
     * @param modifyName 修改人
     */
    public void setModifyName(String modifyName) {
        this.modifyName = modifyName;
    }

    /**
     * 获取最后更新日期
     *
     * @return LAST_UPDATED_DATE - 最后更新日期
     */
    public LocalDateTime getLastUpdatedDate() {
        return lastUpdatedDate;
    }

    /**
     * 设置最后更新日期
     *
     * @param lastUpdatedDate 最后更新日期
     */
    public void setLastUpdatedDate(LocalDateTime lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }

    /**
     * 获取是否可用
     *
     * @return IS_ENABLE - 是否可用
     */
    public String getIsEnable() {
        return isEnable;
    }

    /**
     * 设置是否可用
     *
     * @param isEnable 是否可用
     */
    public void setIsEnable(String isEnable) {
        this.isEnable = isEnable;
    }

    /**
     * 获取并发控制ID
     *
     * @return UPDATE_CONTROL_ID - 并发控制ID
     */
    public String getUpdateControlId() {
        return updateControlId;
    }

    /**
     * 设置并发控制ID
     *
     * @param updateControlId 并发控制ID
     */
    public void setUpdateControlId(String updateControlId) {
        this.updateControlId = updateControlId;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", planId=").append(planId);
        sb.append(", orgCode=").append(orgCode);
        sb.append(", orgName=").append(orgName);
        sb.append(", billType=").append(billType);
        sb.append(", billTypeName=").append(billTypeName);
        sb.append(", businessType=").append(businessType);
        sb.append(", businessTypeName=").append(businessTypeName);
        sb.append(", fieldCode=").append(fieldCode);
        sb.append(", fieldName=").append(fieldName);
        sb.append(", fieldValue=").append(fieldValue);
        sb.append(", nextReviewTime=").append(nextReviewTime);
        sb.append(", oemId=").append(oemId);
        sb.append(", groupId=").append(groupId);
        sb.append(", creator=").append(creator);
        sb.append(", createdName=").append(createdName);
        sb.append(", createdDate=").append(createdDate);
        sb.append(", modifier=").append(modifier);
        sb.append(", modifyName=").append(modifyName);
        sb.append(", lastUpdatedDate=").append(lastUpdatedDate);
        sb.append(", isEnable=").append(isEnable);
        sb.append(", updateControlId=").append(updateControlId);
        sb.append("]");
        return sb.toString();
    }
}