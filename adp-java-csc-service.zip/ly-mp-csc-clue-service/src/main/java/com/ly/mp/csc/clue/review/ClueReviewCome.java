package com.ly.mp.csc.clue.review;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegist;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegistor;
import com.ly.bucn.component.interceptor.annotation.Interceptor;
import com.ly.bucn.component.strategy.annotation.Strategy;
import com.ly.mp.busicen.rule.field.IFireFieldRule;
import com.ly.mp.csc.clue.idal.mapper.SacClueInfoDlrMapper;
import com.ly.mp.csc.clue.service.impl.SacClueInfoDlrService;
import com.ly.mp.csc.clue.util.ReviewUpdateClueUtil;

/**
 * 预约到店
 * @author ly-shenyw
 *
 */
@Strategy(isDefault=false,names="clueReviewCome")
@Service
public class ClueReviewCome extends AbstractClueReview implements InterceptorWrapperRegist{

	@Autowired
	IFireFieldRule fireFieldRule;

	/**
	 * 前置操作
	 */
	@Override
	public void before(Map<String, Object> reviewMap,String token){
		//校验参数
		fireFieldRule.fireRuleExcpt(reviewMap, "csc-clue-review-come-check", "maindata");
	}

	/**
	 * 其他操作
	 */
	@Override
	@Interceptor("csc_clue_review_come")
	public void handle(Map<String, Object> reviewMap,String token){

	}

	@SuppressWarnings("unchecked")
	@Override
	public void regist(InterceptorWrapperRegistor registor) {
		//  预约到店 后置更新线索状态
		registor.after("csc_clue_review_come_updateclueinfo", (context, model) -> {
			Map<String, Object> reviewParam = (Map<String, Object>) context.data().getP()[0];
			String token = (String) context.data().getP()[1];
			reviewUpdateClue(reviewParam, token);
		});
	}

	private void reviewUpdateClue(Map<String, Object> reviewParam, String token) {
		String billType = (String) reviewParam.get("billType");
		String billCode = (String) reviewParam.get("billCode");
		if("DLRCLUE".equals(billType)) {//店端
			Map<String, Object> dlrClueMap= getDlrClueMap(billCode);
			if(ReviewUpdateClueUtil.needUpdateDlrClue(dlrClueMap, reviewParam, token)) {
				clueInfoDlrService.updateMap(dlrClueMap, token);
			}
		}
	}

	@Autowired SacClueInfoDlrService clueInfoDlrService;
	@Autowired SacClueInfoDlrMapper clueInfoDlrMapper;
	private Map<String, Object> getDlrClueMap(String billCode) {
		if (StringUtils.isBlank(billCode)) {
			return null;
		}
		Page<Map<String, Object>> page = new Page<Map<String, Object>>(1, Integer.MAX_VALUE);
		Map<String, Object> param = new HashMap<>();
		param.put("serverOrder", billCode);
		List<Map<String, Object>> list = clueInfoDlrMapper.selectByPage(page, param);
		if (list == null || list.size() ==0) {
			return null;
		}
		return list.get(0);
	}
}
