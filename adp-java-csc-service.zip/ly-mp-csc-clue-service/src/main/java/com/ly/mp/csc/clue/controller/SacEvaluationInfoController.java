package com.ly.mp.csc.clue.controller;


import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.context.BusicenInvoker;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.service.ISacEvaluationInfoService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * <p>
 * 试乘试驾评价表 前端控制器
 * </p>
 *
 * @author ly-linliq
 * @since 2021-10-19
 */
@Api(value = "试乘试驾单评价管理",tags = {"试乘试驾单评价管理"})
@RestController
@RequestMapping("/ly/sac/sacEvaluationInfo")
public class SacEvaluationInfoController {

	@Autowired
	ISacEvaluationInfoService sacEvaluationInfoService;
	
	@ApiOperation(value = "试乘试驾单评价查询", notes = "试乘试驾单评价查询")
	@RequestMapping(value = "/sacevaluationinfoquerylist.do", method = RequestMethod.POST)
	public ListResult<Map<String, Object>> sacEvaluationInfoQueryList(
			@RequestHeader(name = "authorization", required = false) String authentication,
			@RequestBody(required = false) ParamPage<Map<String, Object>> mapParam){
		mapParam.getParam().put("token", authentication);
		return BusicenInvoker.doList(()->sacEvaluationInfoService.sacEvaluationInfoQueryList(mapParam)).result();
	}
	
	@ApiOperation(value = "试乘试驾单评价保存", notes = "试乘试驾单评价保存")
	@RequestMapping(value = "/sacevaluationinfosave.do", method = RequestMethod.POST)
	public OptResult sacEvaluationInfoSave(@RequestHeader(name = "authorization", required = false) String authentication,
			@RequestBody(required = false) ParamBase<Map<String, Object>> mapParam) {
		mapParam.getParam().put("token", authentication);
		return BusicenInvoker.doOpt(() -> sacEvaluationInfoService.sacEvaluationInfoSave(mapParam.getParam())).result();
	}
}
