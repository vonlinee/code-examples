package com.ly.mp.csc.clue.util;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.idal.mapper.SacClueInfoMapper;
import com.ly.mp.csc.clue.idal.mapper.SacDlrRelationMapper;
import com.ly.mp.csc.clue.service.ISacClueInfoDlrService;
import com.ly.mp.csc.clue.service.ISacDlrRelationService;

@Component
public class SendDlrUtil {

	private static Logger logger = LoggerFactory.getLogger(SendDlrUtil.class);

	@Autowired ISacClueInfoDlrService clueInfoDlrService;
	@Autowired ISacDlrRelationService sacDlrRelationService;
	@Autowired SacDlrRelationMapper dlrRelationMapper;
	@Autowired FiledMappingUtil filedMappingUtil;

	public void send(String billCode, String token) {
		Map<String, Object> clueMap= getClueMap(billCode);
		send(clueMap, token);
	}

	public void send(Map<String, Object> clueMap, String token) {
		if(clueMap != null) {
			Map<String, Object> dlrClueMap = new HashMap<>();
			dlrClueMap.putAll(clueMap);
			dlrClueMap.put("pvServerOrder", clueMap.get("serverOrder")); // 总部线索单号
			dlrClueMap.put("receiveTime", Calendar.getInstance().getTime()); // 下发时间
			dlrClueMap.put("token", token);

			// 获取映射网点
			dlrClueMap.putAll(getDlrMap(clueMap));

			dlrClueMap.remove("id");
			dlrClueMap.remove("sendDlrCode");
			dlrClueMap.remove("sendDlrShortName");
			dlrClueMap.remove("serverOrder");
			dlrClueMap.remove("statusCode");
			dlrClueMap.remove("statusName");
			dlrClueMap.remove("firstReviewTime");
			dlrClueMap.remove("lastReviewTime");
			dlrClueMap.remove("assignTime");
			dlrClueMap.remove("reviewPersonName");
			dlrClueMap.remove("reviewPersonId");

			ParamBase<Map<String, Object>> clueParam = new ParamBase<>();
			clueParam.setParam(dlrClueMap);
			EntityResult<Map<String, Object>> optResult = clueInfoDlrService.saveMap(clueParam, token);
			if(!"1".equals(optResult.getResult())) {
				throw new BusicenException("下发专营店失败！【serverOrder=" + clueMap.get("serverOrder") + "】");
			}
		}
	}

	@Autowired SacClueInfoMapper clueInfoMapper;
	private Map<String, Object> getClueMap(String billCode) {
		if (StringUtils.isBlank(billCode)) {
			return null;
		}
		Page<Map<String, Object>> page = new Page<Map<String, Object>>(1, Integer.MAX_VALUE);
		Map<String, Object> param = new HashMap<>();
		param.put("serverOrder", billCode);
		List<Map<String, Object>> list = clueInfoMapper.selectByPage(page, param);
		if (list == null || list.size() ==0) {
			return null;
		}
		return list.get(0);
	}

	// 网点映射配置，取映射网点
	public Map<String, Object> getDlrMap(String billCode) {
		Map<String, Object> clueMap= getClueMap(billCode);
		return getDlrMap(clueMap);
	}

	/**
	 *  获取映射网点 Map[dlrCode=, dlrShortName=]
	 * @param clueMap
	 * @return
	 */
	public Map<String, Object> getDlrMap(Map<String, Object> clueMap) {
		Map<String, Object> dlrMap = new HashMap<>();
		String channelCode = (String)clueMap.get("channelCode");
		String sendDlrCode = (String)clueMap.get("sendDlrCode");
		if(clueMap == null || StringUtils.isBlank(channelCode) || StringUtils.isBlank(sendDlrCode)) {
			return dlrMap;
		}
		// 默认取原网点
		dlrMap.put("dlrCode", clueMap.get("sendDlrCode"));
		dlrMap.put("dlrShortName", clueMap.get("sendDlrShortName"));

		List<Map<String, Object>> dlrRelationList = dlrRelationMapper.machDlrRelation(channelCode, sendDlrCode);
		logger.info("channelCode={}, {}, {}", channelCode, sendDlrCode, dlrRelationList);

		for(Map<String, Object> dlrRelationMap : dlrRelationList) {
			boolean matchClue = _matchClue((String)dlrRelationMap.get("wherestr"), clueMap);
			logger.info("matchClue={}", matchClue);
			if(matchClue) {
				dlrRelationMap.get("");
				// oldDlrName=乘用车公司, newDlrCode=H2903, oldDlrCode=PV, newDlrName=广州华溢石槎
				logger.info("dlrRelationMap={}", dlrRelationMap);
				dlrMap.put("dlrCode", dlrRelationMap.get("newDlrCode"));
				dlrMap.put("dlrShortName", dlrRelationMap.get("newDlrName"));
				return dlrMap;
			}
		}
		return dlrMap;
	}


	/**
	 * 匹配查找商机
	 * @param columInfo
	 * @param originalClueMap
	 * @return false:找不到; true:一个或多个
	 */
	@SuppressWarnings("unchecked")
	private boolean _matchClue(String columInfo, Map<String, Object> originalClueMap) {
		if(originalClueMap == null) {
			return false;
		}
		Map<String, Object> clueMap = new HashMap<>();
		clueMap.putAll(originalClueMap);

		String id = (String)clueMap.get("id");
		String partColumInfo = "id[=]" + id;
		clueMap.remove("id");
		// 自定义参数为空 默认匹配
		if (StringHelper.IsEmptyOrNull(columInfo)) {
			columInfo = partColumInfo;
		} else {
			columInfo += ";" + partColumInfo;
		}

		String customSqlString = "";
		List<Map<String, Object>> noFieldMappingList = new ArrayList<Map<String, Object>>();
		List<String> jsonFieldMappingList = new ArrayList<String>();
		// 处理参数
		List<Map<String, Object>> columnList = filedMappingUtil.customHandle(columInfo);

		// 查询字段映射情况
		Map<String, Object> info = new HashMap<String, Object>();
		info.put("sourceTableCode", "t_sac_clue_info");
		info.put("billType", "CLUE");
		info.put("businessType", "-1");
		info.put("columnList", columnList);
		Map<String, Object> fieldMap = filedMappingUtil.queryFieldMappingList(info);
		if (!StringHelper.IsEmptyOrNull(fieldMap.get("fieldMapping"))) {
			// 将有字段映射的参数、运算符、参数值拼接成sql
			customSqlString = filedMappingUtil
					.joinFieldMappingCustom((List<Map<String, Object>>) fieldMap.get("fieldMapping"));
		}
		if (!StringHelper.IsEmptyOrNull(fieldMap.get("field"))) {
			// 将没有字段映射的字段拼接成sql(字段名+运算符+值)
			noFieldMappingList = filedMappingUtil
					.joinNoFieldMappingCustom((List<Map<String, Object>>) fieldMap.get("field"));
		}
		if (!StringHelper.IsEmptyOrNull(fieldMap.get("jsonFieldMapping"))) {
			// 将字段映射类型为2的字段拼接成sql
			jsonFieldMappingList = filedMappingUtil.joinJsonFieldMappingCustom(
					(List<Map<String, Object>>) fieldMap.get("jsonFieldMapping"));
		}
		// 将字段映射类型为2的参数数组放进map中
		if (jsonFieldMappingList.size() > 0) {
			clueMap.put("jsonFieldMappingList", jsonFieldMappingList);
		}
		// 将没有字段映射的参数数组，将其放进map中
		if (noFieldMappingList.size() > 0) {
			clueMap.put("noFieldMappingList", noFieldMappingList);
		}
		// 将有字段映射的sql放进map中
		if (!StringHelper.IsEmptyOrNull(customSqlString)) {
			clueMap.put("customSqlString", customSqlString);
		}

		return clueInfoMapper.checkRepeat(clueMap) == 0 ? false: true;
	}
}
