package com.ly.mp.csc.clue.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ly.mp.csc.clue.service.IXapiHandleService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * <p>
 * Xapi服务调用
 * </p>
 *
 */

@Api(value = "Xapi服务调用", tags = "Xapi服务调用")
@RestController
@RequestMapping(value = "/xapihandle", produces = { MediaType.APPLICATION_JSON_VALUE })
public class XapiHandleController {

	@Autowired
	private IXapiHandleService xapiHandleService;


	@ApiOperation(value = "归档定时任务_查询数据", notes = "归档定时任务_查询数据")
	@RequestMapping(value = "queryData", method = RequestMethod.POST)
	public List<Map<String, Object>> queryData(@RequestBody(required = false) Map<String, Object> info) throws Exception {
		return xapiHandleService.queryData(info);
	}

	@ApiOperation(value = "归档定时任务_写入历史表", notes = "归档定时任务_写入历史表")
	@RequestMapping(value = "insertData", method = RequestMethod.POST)
	public int insertData(@RequestBody(required = false) Map<String, Object> info) throws Exception {
		return xapiHandleService.insertData(info);
	}

	@ApiOperation(value = "归档定时任务_删除原数据", notes = "归档定时任务_删除原数据")
	@RequestMapping(value = "delData", method = RequestMethod.POST)
	public int delData(@RequestBody(required = false) Map<String, Object> info) throws Exception {
		return xapiHandleService.delData(info);
	}

	
}
