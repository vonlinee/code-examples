package com.ly.mp.csc.clue.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegist;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegistor;
import com.ly.bucn.component.interceptor.annotation.Interceptor;
import com.ly.bucn.component.message.Message;
import com.ly.bucn.component.strategy.runtime.ChooseContext;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.constant.UserBusiEntity;
import com.ly.mp.busi.base.context.BusicenContext;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.busi.base.handler.OptResultBuilder;
import com.ly.mp.busicen.rule.field.IFireFieldRule;
import com.ly.mp.busicen.rule.field.execution.ValidResultCtn;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.entities.SacReviewFpSet;
import com.ly.mp.csc.clue.entities.out.ReviewPersonQueneOut;
import com.ly.mp.csc.clue.idal.mapper.SacReviewFpSetMapper;
import com.ly.mp.csc.clue.service.ISacReviewFpSetService;
import com.ly.mp.csc.clue.strategy.service.IReviewFpQueueStrategy;


/**
 * com.ly.mp.csc.clue.service.impl.SacReviewFpSetServiceImpl
 * 回访分配服务实现类
 * @author zhouhao
 * @date 2021/8/16 14:11
 * Modification History:
 * Date               Author          Version            Description
 *---------------------------------------------------------------------*
 * 2021/9/14 14:28     linliq           v1.0.0            修改报错问题
 */
@Service("SacReviewFpSetService")
public class SacReviewFpSetService extends ServiceImpl<SacReviewFpSetMapper, SacReviewFpSet> implements ISacReviewFpSetService, InterceptorWrapperRegist {

    @Autowired
    Message message;
    @Autowired
    IFireFieldRule fireFieldRule;

    private final Logger log = LoggerFactory.getLogger(SacReviewFpSetService.class);

    /**
     * 回访分配设置查询
     * @param map 入参查询条件
	 * @param token token
     * @return com.ly.mp.component.entities.ListResult<com.ly.mp.csc.clue.entities.out.ReviewAssignSetOut>
     * @author zhouhao
     * @date 2021/8/16 15:06
     */
    @Override
    public ListResult<Map<String,Object>> queryListReviewAssignInfo(ParamPage<Map<String,Object>>map, String token){
        ListResult<Map<String,Object>> result = new ListResult<Map<String,Object>>();
        try {
            int pageIndex=map.getPageIndex();
            int pageSize=map.getPageSize();
            
            UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
            map.getParam().put("orgCode", userBusiEntity.getDlrCode());
            
            Page<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);
            List<Map<String, Object>> list = baseMapper.queryListReviewAssignInfo(page, map.getParam());
            page.setRecords(list);
            result = BusicenUtils.page2ListResult(page);
        }catch (Exception e){
            e.printStackTrace();
            log.error("queryListReviewAssignInfo:",e);
            throw e;
        }
        return result;
    }

    /**
     * 回访分配设置
     * @param map 输入参数
     * @param token token
     * @return com.ly.mp.component.entities.OptResult
     * @author zhouhao
     * @date 2021/8/16 18:03
     */
    @SuppressWarnings("unchecked")
	@Override
    @Transactional(rollbackFor = Exception.class)
    @Interceptor("csc_clue_savereviewassigninfo")
    public OptResult saveReviewAssignInfo(Map<String,Object> map, String token){

        try {
            UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
            boolean updateFlag = (boolean)map.get("updateFlag");
            if(!updateFlag){
                BusicenUtils.invokeUserInfo(map, BusicenUtils.SOU.Save,token);
//                map.put("modifyName", userBusiEntity.getEmpName());
//                map.put("createdName", userBusiEntity.getEmpName());
                map.put("setId", StringHelper.GetGUID());
//                map.put("updateControlId", StringHelper.GetGUID());
                map.put("orgCode", userBusiEntity.getDlrCode());
                map.put("orgName", userBusiEntity.getDlrName());
                if(StringHelper.IsEmptyOrNull(map.get("isEnable"))) {
             	   map.put("isEnable","1");
                }
                if(StringHelper.IsEmptyOrNull(map.get("isFirstSelf"))) {
              	   map.put("isFirstSelf","0");
                 }
                if(baseMapper.insertSacReviewFpSet(map)==0){
                    return OptResultBuilder.createFail().Msg(message.get("CLUE-REVIEWASSIGN-04")).result("0").build();
                }
            }else{
                BusicenUtils.invokeUserInfo(map, BusicenUtils.SOU.Update,token);
                if(baseMapper.updateByPrimaryKeySetId(map)==0){
                    return OptResultBuilder.createFail().Msg(message.get("CLUE-REVIEWASSIGN-05")).result("0").build();
                }
            }
            List<Map<String,Object>> list = (List<Map<String,Object>>)map.get("dList");
            if(!StringHelper.IsEmptyOrNull(list)){
                String setId = String.valueOf(map.get("setId"));
                //先根据设置ID删除回访分配人员阀值
                baseMapper.deleteBySetId(setId);
                List<Map<String, Object>> listVo = new ArrayList<>();
                //再将新的数据插入数据库
                for (Map<String,Object> mapObj: list) {
                	//先进行人员字段校验
                	ValidResultCtn fireRule = fireFieldRule.fireRule(mapObj, "csc-clue-reviewuser-check-0001", "maindata");
                    String resMsg = fireRule.getNotValidMessage();
                    if (!fireRule.isValid()){
                        throw new BusicenException(resMsg);
                    }
                    BusicenUtils.invokeUserInfo(mapObj, BusicenUtils.SOU.Save,token);
                    mapObj.put("id", StringHelper.GetGUID());
                    mapObj.put("setId", setId);
                    mapObj.put("isEnable", "1");
                    listVo.add(mapObj);
                }
                if(baseMapper.insertSacReviewFpSetD(listVo)==0){
                    return OptResultBuilder.createFail().Msg(message.get("CLUE-REVIEWASSIGN-06")).result("0").build();
                }
            }
        }catch (Exception e){
            e.printStackTrace();
            log.error("saveReviewAssignInfo:",e);
            throw e;
            //throw new BusicenException(message.get("CLUE-SYSTECONFIGVALUE-01"));
        }
        return OptResultBuilder.createOk().build();
    }

    @SuppressWarnings("unchecked")
	@Override
    public void regist(InterceptorWrapperRegistor registor) {
        //切点编码要和切点表里面的保持一致
        registor.before("csc_clue_savereviewassigninfo_valid", (context, model)->{
            checkValidate((Map<String,Object>)context.data().getP()[0]);
        });
        registor.before("csc_clue_savereviewassigninfo_repeat", (context, model)->{
            checkRepeat((Map<String,Object>)context.data().getP()[0],String.valueOf( context.data().getP()[1]));
        });
        registor.before("csc_clue_savereviewassigninfo_check", (context, model)->{
            checkValidate1((Map<String,Object>)context.data().getP()[0]);
        });
        registor.after("csc_clue_savereviewassigninfo_msg", (context, model)->{
            checkAfter((Map<String,Object>)context.data().getP()[0]);
        });
    }

    public void checkValidate(Map<String,Object> mapParam)
    {
        ValidResultCtn fireRule = fireFieldRule.fireRule(mapParam, "csc-clue-review-check-0001", "maindata");
        String resMsg = fireRule.getNotValidMessage();
        if (!fireRule.isValid()){
            throw new BusicenException(resMsg);
        }
        //校验二级渠道不为空时,一级渠道是否为空
        if(!StringHelper.IsEmptyOrNull(mapParam.get("infoChanDCode"))&&StringHelper.IsEmptyOrNull(mapParam.get("infoChanMCode"))) {
        	throw new BusicenException(message.get("CSC-MESSAGE-01"));
        }
        //校验三级渠道不为空时,一二级渠道是否为空
        if(!StringHelper.IsEmptyOrNull(mapParam.get("infoChanDDCode"))) {
        	//一二级渠道
        	if(StringHelper.IsEmptyOrNull(mapParam.get("infoChanMCode"))&&StringHelper.IsEmptyOrNull(mapParam.get("infoChanDCode"))) {
        		throw new BusicenException(message.get("CSC-MESSAGE-03"));
        	}
        	//一级渠道校验
        	if(StringHelper.IsEmptyOrNull(mapParam.get("infoChanMCode"))) {
        		throw new BusicenException(message.get("CSC-MESSAGE-01"));
        	}
        	//二级渠道校验
        	if(StringHelper.IsEmptyOrNull(mapParam.get("infoChanDCode"))) {
        		throw new BusicenException(message.get("CSC-MESSAGE-02"));
        	}
        }
    }

    public void checkValidate1(Map<String,Object> mapParam)
    {
    	boolean updateFlag = false;
        if(!StringHelper.IsEmptyOrNull(mapParam.get("setId"))){
            int size = baseMapper.countBySetId((String)mapParam.get("setId"));
            if (size > 0) {
                updateFlag = true;
            }else {
            	throw new BusicenException(message.get("CLUE-REVIEWASSIGN-29"));
            }
        }
        mapParam.put("updateFlag",updateFlag);
    }

    public void checkRepeat(Map<String,Object> mapParam,String token)
    {
    	UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
    	mapParam.put("dlrCode", userBusiEntity.getDlrCode());
    	int check = baseMapper.checkReviewAssign(mapParam);
        if(check>=1){
            throw new BusicenException(message.get("CLUE-REVIEWASSIGN-15"));
        }
    }

    public void checkAfter(Map<String,Object> mapParam) {

    }

    /**
     * 分配规则查询
     * @param map 输入参数
     * @param token token
     * @return com.ly.mp.component.entities.ListResult<java.util.Map<java.lang.String,java.lang.Object>>
     * @author zhouhao
     * @date 2021/8/17 10:35
     */
    @Override
    public ListResult<Map<String, Object>> queryListReviewRuleInfo(ParamPage<Map<String,Object>> map, String token){

        ListResult<Map<String,Object>> result = new ListResult<Map<String,Object>>();
        try {
            int pageIndex=map.getPageIndex();
            int pageSize=map.getPageSize();
            Page<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);
            List<Map<String, Object>> list = baseMapper.queryReviewRuleInfo(page, map.getParam());
            page.setRecords(list);
            result = BusicenUtils.page2ListResult(page);
        }catch (Exception e){
            e.printStackTrace();
            log.error("queryListReviewRuleInfo:",e);
            throw e;
            //throw new BusicenException(message.get("CLUE-SYSTECONFIGVALUE-01"));
        }
        return result;
    }

    /**
     * 分配规则删除
     * @param map 输入参数
     * @param token token
     * @return OptResult
     */
    @Override
    public OptResult deleteReviewAssignInfo(Map<String,Object> map, String token){
        try {
        	ValidResultCtn fireRule = fireFieldRule.fireRule(map, "csc-clue-review-check-0009", "maindata");
            String resMsg = fireRule.getNotValidMessage();
            if (!fireRule.isValid()){
                throw new BusicenException(resMsg);
            }
            String setId = map.get("setId").toString();
            baseMapper.deleteReviewAssignInfo(setId);
            baseMapper.deleteById(setId);
        }catch (Exception e){
        e.printStackTrace();
        log.error("deleteReviewAssignInfo:",e);
        throw e;
        //throw new BusicenException(message.get("CLUE-SYSTECONFIGVALUE-01"));
        }
        return OptResultBuilder.createOk().build();
    }
    
    /**
     * 获取匹配的分配规则
     * @param param
     * @return
     */
    @Override
    public List<Map<String, Object>> machReviewFpRule(Map<String,Object> map, String token){
        try {
        	if(StringHelper.IsEmptyOrNull(map.get("businessType"))){
        		map.put("businessType", "-1");
        	}
            return baseMapper.machReviewFpRule(map);
        }catch (Exception e){
            e.printStackTrace();
            log.error("machReviewFpRule:",e);
            throw e;
        }
    }
    
    /**
     * 获取人员阀值列表及当前回访数
     * @param map
     * @param token
     * @return
     */
    @Override
    public ListResult<Map<String, Object>> queryReviewPersonBySetD(ParamPage<Map<String,Object>> map, String token){

        ListResult<Map<String,Object>> result = new ListResult<Map<String,Object>>();
        try {
            int pageIndex=map.getPageIndex();
            int pageSize=map.getPageSize();
            Page<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);
            List<Map<String, Object>> list = baseMapper.queryReviewPersonBySetD(page, map.getParam());
            page.setRecords(list);
            result = BusicenUtils.page2ListResult(page);
        }catch (Exception e){
            e.printStackTrace();
            log.error("queryFpSetDBySetId:",e);
            throw e;
        }
        return result;
    }
    
    /**
     * 获取人员阀值列表
     * @param page
     * @param param
     * @return
     */
    @Override
    public ListResult<Map<String, Object>> queryReviewFpSetD(ParamPage<Map<String,Object>> map, String token){

    	ListResult<Map<String,Object>> result = new ListResult<Map<String,Object>>();
        try {
            int pageIndex=map.getPageIndex();
            int pageSize=map.getPageSize();
            Page<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);
            List<Map<String, Object>> list = baseMapper.queryReviewFpSetD(page, map.getParam());
            page.setRecords(list);
            result = BusicenUtils.page2ListResult(page);
        }catch (Exception e){
            e.printStackTrace();
            log.error("queryReviewFpSetD:",e);
            throw e;
        }
        return result;
    }
    
    /**
     * 获取队列中的人员列表及阀值
     * @param map setId,personQueueCode,personQueueValueCode
     * @param token
     * @return personUserId,personName,maxNum,orderNo
     */
    @SuppressWarnings("rawtypes")
	@Override
    public ListResult<Map<String, Object>> queryFpPersonList(ParamPage<Map<String,Object>> map, String token){

    	//校验参数
		fireFieldRule.fireRuleExcpt(map.getParam(), "csc-clue-fpset-queryfpperson-check", "maindata");
		
        ListResult<Map<String,Object>> result = new ListResult<Map<String,Object>>();
        List<Map<String, Object>> rowlist = new ArrayList<>();
        try {
        	UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
        	Map<String,Object> param = map.getParam();
        	
        	//获取阀值列表
        	List<Map<String, Object>> dlist = new ArrayList<>();
        	if(!StringHelper.IsEmptyOrNull(param.get("setId"))){
        		ParamPage<Map<String,Object>> setDParam = new ParamPage<>();
            	setDParam.setPageIndex(-1);
            	setDParam.setPageSize(-1);
            	Map<String,Object> dparam = new HashMap<>();
            	dparam.put("setId", param.get("setId").toString());
            	setDParam.setParam(dparam);
            	ListResult<Map<String, Object>> setdResult = queryReviewFpSetD(setDParam,token);
            	if(setdResult!=null && setdResult.getRows()!=null && setdResult.getRows().size()>0){
            		dlist=setdResult.getRows();
            	}
        	}
        	//回访人员队列策略
			String queueStategy = String.format("reviewFpQueueStrategy%s", param.get("personQueueCode").toString());
			//回访人员队列值
			String queueValueCode = param.get("personQueueValueCode").toString();
        	//获取回访人员列表
    		List<ReviewPersonQueneOut> personList = ChooseContext.chooseBeanOrDefault(queueStategy, IReviewFpQueueStrategy.class).queryPersonList(userBusiEntity.getDlrCode(),queueValueCode,token);
            
    		for(int i=0;i<personList.size();i++){
    			Map<String, Object> personMap = new HashMap<>();
    			
    			ReviewPersonQueneOut personInfo = personList.get(i);
    			personMap.put("personUserId", personInfo.getReviewPersonUserId());
    			personMap.put("personName", personInfo.getReviewPersonName());
    			personMap.put("maxNum", "0");
				personMap.put("orderNo", dlist.size()+(i+1));
				
    			//判断是否已设置阀值
    			if(dlist!=null && dlist.size()>0){
    				List<Map<String, Object>> filerList = dlist.stream().filter(d->personInfo.getReviewPersonUserId().equals(d.get("personUserId")))
    				.collect(Collectors.toList());
    				if(filerList!=null&&filerList.size()>0){
    					personMap.put("maxNum", filerList.get(0).get("maxNum").toString());
    					personMap.put("orderNo", filerList.get(0).get("orderNo").toString());
    				}
    			}
    			rowlist.add(personMap);
    		}
    		
    		//对结果进行排序，按orderNo顺序排
    		if(rowlist.size()>0){
    			Collections.sort(rowlist,new Comparator<Map>() {
    				@Override
    				public int compare(Map agr1,Map agr2){
    					return  Integer.parseInt(agr1.get("orderNo").toString())-Integer.parseInt(agr2.get("orderNo").toString());
    				}
				});
    		}
    		result.setMsg("查询成功");
    		result.setRecords(rowlist.size());
    		result.setRows(rowlist);
        }catch (Exception e){
            e.printStackTrace();
            log.error("queryFpPersonList:",e);
            throw e;
        }
        return result;
    }
    

}
