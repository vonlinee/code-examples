package com.ly.mp.csc.clue.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ly.bucn.component.message.Message;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.csc.clue.entities.OutboundConfig;
import com.ly.mp.csc.clue.service.IOutboundConfigService;

/**
 * 商机外呼配置校验
 *
 * @author ly-zhengzc
 *
 */
@Component
public class CheckSendDlrCodeUtil {

	private static Logger log = LoggerFactory.getLogger(CheckSendDlrCodeUtil.class);

	@Autowired Message message;
	@Autowired IOutboundConfigService outboundConfigService;

	/**
	 *
	 * @param mapParam
	 * @param outboundConfigList
	 * @param checkMsg
	 * @return 1 需要外呼 0 不需要外呼
	 */
	public String checkSendDlrCode(Map<String, Object> mapParam) {
		List<OutboundConfig> outboundConfigList = getOutboundConfigList();
		Map<String, String> outboundConfigMap = _getOutboundConfigMap(outboundConfigList);
		// 一级信息来源编码
		String chanCode1 = (String) mapParam.get("infoChanMCode");
		// 二级信息来源编码
		String chanCode2 = (String) mapParam.get("infoChanDCode");
		// 三级信息来源编码
		String chanCode3 = (String) mapParam.get("infoChanDdCode");

		String key1 = chanCode1;
		String key2 = chanCode1 + "#" + chanCode2;
		String key3 = chanCode1 + "#" + chanCode2 + "#" + chanCode3;

		boolean isOutbound = true; // 是否需要外呼， 默认需要外呼
		if (StringUtils.isNotBlank(chanCode1)) {
			if (StringUtils.isNotBlank(chanCode2)) {
				if (StringUtils.isNotBlank(chanCode3)) {
					// 校验1、2、3级
					if (outboundConfigMap.get(key3) != null) {
						isOutbound = _isOutbound(outboundConfigMap.get(key3));
						log.debug("匹配3级渠道[{}={}]",key3, outboundConfigMap.get(key3));
					} else if (outboundConfigMap.get(key2) != null) {
						isOutbound = _isOutbound(outboundConfigMap.get(key2));
						log.debug("匹配2级渠道[{}={}]",key2, outboundConfigMap.get(key2));
					} else if (outboundConfigMap.get(key1) != null) {
						isOutbound = _isOutbound(outboundConfigMap.get(key1));
						log.debug("匹配1级渠道[{}={}]",key1, outboundConfigMap.get(key1));
					}
				} else {
					// 校验1、2级
					if (outboundConfigMap.get(key2) != null) {
						isOutbound = _isOutbound(outboundConfigMap.get(key2));
						log.debug("匹配2级渠道[{}={}]",key2, outboundConfigMap.get(key2));
					} else if (outboundConfigMap.get(key1) != null) {
						isOutbound = _isOutbound(outboundConfigMap.get(key1));
						log.debug("匹配1级渠道[{}={}]",key1, outboundConfigMap.get(key1));
					}
				}
			} else {
				if (outboundConfigMap.get(key1) != null) {
					isOutbound = _isOutbound(outboundConfigMap.get(key1));
					log.debug("匹配1级渠道[{}={}]",key1, outboundConfigMap.get(key1));
				}
			}
		}
		log.debug("匹配渠道结果[{},{}]", isOutbound, isOutbound == true ? "1" : "0");
		if (isOutbound == false) {// 不需要外呼
			// 保存时需判断是否设置了不需要外呼，如果不需要外呼则意向网点必填
			String sendDlrCode = (String) mapParam.get("sendDlrCode");
			String sendDlrShortName = (String) mapParam.get("sendDlrShortName");
			if (StringUtils.isBlank(sendDlrCode) || StringUtils.isBlank(sendDlrShortName)) {
				// 商机外呼配置为不需要外呼时，意向网点必填
				throw new BusicenException(message.get("CLUE-BASE-03"));
			}
		}
		return isOutbound == true ? "1" : "0";
	}

	private List<OutboundConfig> getOutboundConfigList() {
		QueryWrapper<OutboundConfig> queryWrapper = new QueryWrapper<OutboundConfig>();
		queryWrapper.eq("IS_ENABLE", "1");
		List<OutboundConfig> outboundConfigList = outboundConfigService.list(queryWrapper);
		return outboundConfigList;
	}

	// 是否外呼
	private static boolean _isOutbound(String isOutbound) {
		return "1".equals(isOutbound) ? true : false;
	}

	private static Map<String, String> _getOutboundConfigMap(List<OutboundConfig> outboundConfigList) {
		HashMap<String, String> outboundConfigMap = new HashMap<>();
		for (OutboundConfig tmp : outboundConfigList) {
			String chanCode1 = tmp.getInfoChanMCode();// 一级信息来源编码
			String chanCode2 = tmp.getInfoChanDCode();// 二级信息来源编码
			String chanCode3 = tmp.getInfoChanDdCode();// 三级信息来源编码
			if (StringUtils.isNotBlank(chanCode1)) {
				if (StringUtils.isNotBlank(chanCode2)) {
					if (StringUtils.isNotBlank(chanCode3)) {
						// 3级
						outboundConfigMap.put(chanCode1 + "#" + chanCode2 + "#" + chanCode3, tmp.getIsOutbound());
					} else {
						// 2级
						outboundConfigMap.put(chanCode1 + "#" + chanCode2, tmp.getIsOutbound());
					}
				} else {
					// 1级
					outboundConfigMap.put(chanCode1, tmp.getIsOutbound());
				}
			}
		}
		return outboundConfigMap;
	}
}
