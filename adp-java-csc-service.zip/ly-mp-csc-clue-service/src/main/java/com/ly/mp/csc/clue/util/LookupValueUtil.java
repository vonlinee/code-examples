package com.ly.mp.csc.clue.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ly.mp.component.entities.ListResult;
import com.ly.mp.csc.clue.otherservice.ICscSysBaseDataService;

@Component
public class LookupValueUtil {

	@Autowired ICscSysBaseDataService baseDataService;

	public Map<String, Map<String, String>> initClueLookupValue(String token) {
		Map<String, Map<String, String>> allLookupValueMap = new HashMap<>();
		// 试乘试驾时间
		_getLookupValueMap(allLookupValueMap, "BUCN_CLUE_PLAN_TIME", token);
		// 预计购车时间
		_getLookupValueMap(allLookupValueMap, "BUCN_CLUE_DRIVE_TIME", token);
		// 总部商机状态
		_getLookupValueMap(allLookupValueMap, "BUCN_PVCLUE_STATUS", token);
		// 店端线索状态
		_getLookupValueMap(allLookupValueMap, "BUCN_DLRCLUE_STATUS", token);
		// 性别
		_getLookupValueMap(allLookupValueMap, "LX010", token);
		// 商机热度
		_getLookupValueMap(allLookupValueMap, "BUCN_CLUE_HOT", token);
		return allLookupValueMap;
	}

	public void _getLookupValueMap(Map<String, Map<String, String>> allLookupValueMap, String lookupTypeCode, String token) {
		ListResult<Map<String, Object>> listResult = baseDataService.mdslookupvaluefindbypage(lookupTypeCode, token);// 预计购车时间
		if("1".equals(listResult.getResult())) {
			List<Map<String, Object>> rows = listResult.getRows();
			Map<String, String> lookupValueMap = new HashMap<>();
			for(Map<String, Object> map: rows) {
				lookupValueMap.put((String)map.get("lookupValueName"), (String)map.get("lookupValueCode"));
			}
			allLookupValueMap.put(lookupTypeCode, lookupValueMap);
		} else {
			throw new RuntimeException(listResult.getMsg());
		}

	}
}
