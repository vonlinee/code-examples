package com.ly.mp.csc.clue.service.impl;

import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.busi.base.handler.BusicenUtils.SOU;
import com.ly.mp.busi.base.handler.ResultHandler;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.entities.SacReviewAuditHis;
import com.ly.mp.csc.clue.idal.mapper.SacReviewAuditHisMapper;
import com.ly.mp.csc.clue.service.ISacReviewAuditHisService;


/**
 * <p>
 * 回访审核历史表 服务实现类
 * </p>
 *
 * @author ly-busicen
 * @since 2021-08-17
 */
@Service
public class SacReviewAuditHisService extends ServiceImpl<SacReviewAuditHisMapper, SacReviewAuditHis> implements ISacReviewAuditHisService {

private Logger log = LoggerFactory.getLogger(SacReviewAuditHisService.class);
	
	@Autowired
	SacReviewAuditHisMapper sacReviewAuditHisMapper;

	/**
	 * 根据主键判断插入或更新
	 * @param info
	 * @return
	 */
	@Override
	@Transactional
	public EntityResult<Map<String, Object>> sacReviewAuditHisSave(Map<String, Object> mapParam, String token){
		try {
			Boolean updateFlag = false;
		    if (!StringHelper.IsEmptyOrNull(mapParam.get("auditId"))) {
			    QueryWrapper<SacReviewAuditHis> wrapper = new QueryWrapper<>();
			    wrapper.lambda().eq(SacReviewAuditHis::getAuditId, mapParam.get("auditId"));
		    	if (list(wrapper).size() > 0) {
		    		updateFlag = true;
				}
			}
			if(!updateFlag){
				//新增
				if (StringHelper.IsEmptyOrNull(mapParam.get("auditId"))) {
					//主键
					mapParam.put("auditId",UUID.randomUUID().toString());
				}
				BusicenUtils.invokeUserInfo(mapParam, SOU.Save,token);
				sacReviewAuditHisMapper.insertSacReviewAuditHis(mapParam);
			}else{
				//更新
				BusicenUtils.invokeUserInfo(mapParam, SOU.Update,"");
				sacReviewAuditHisMapper.updateSacReviewAuditHis(mapParam);
			}
			return ResultHandler.updateOk(mapParam);
		} catch (Exception e) {
			log.error("sacReviewAuditHisSave", e);
			throw e;
		} 
	}
	
}
