package com.ly.mp.csc.clue.service;

import java.util.Map;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.entities.SacEvaluationInfo;

/**
 * <p>
 * 试乘试驾评价表 服务类
 * </p>
 *
 * @author ly-linliq
 * @since 2021-10-19
 */
public interface ISacEvaluationInfoService extends IService<SacEvaluationInfo> {

	/**
	 * 试乘试驾评价保存
	 * @param mapParam
	 * @return
	 */
	public OptResult sacEvaluationInfoSave(Map<String, Object> mapParam);
	
	/**
	 * 试乘试驾评价查询
	 * @param mapParam
	 * @return
	 */
	public ListResult<Map<String, Object>> sacEvaluationInfoQueryList(ParamPage<Map<String, Object>> mapParam);
	
}
