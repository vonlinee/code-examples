package com.ly.mp.csc.clue.enums;

/**
 * 回访审核状态 值列表BUCN_SHSTATUS
 * @author ly-shenyw
 *
 */
public enum ReviewAuditStatusEnum {
	/**
	 * 待审核
	 */
	unAudit("0","待审核"),
	
	/**
	 * 审核通过
	 */
	ok("1","审核通过"),
	
	/**
	 * 驳回
	 */
	bh("2","驳回");
	
	private String result;
	private String msg;
	
	private ReviewAuditStatusEnum(String result, String msg) {
		this.result = result;
		this.msg = msg;
	}

	public String getResult() {
		return result;
	}

	public String getMsg() {
		return msg;
	}
	
	//根据result获取枚举
	public static ReviewAuditStatusEnum fromString(String code) {
        for (ReviewAuditStatusEnum b : ReviewAuditStatusEnum.values()) {
            if (b.getResult().equalsIgnoreCase(code)) {
                return b;
            }
        }
        return null;
	}
}

