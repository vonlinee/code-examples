package com.ly.mp.csc.clue.strategy.service;

import java.util.Map;

import com.ly.mp.component.entities.EntityResult;

/**
 * 新建回访单策略
 * @author ly-shenyw
 *
 */
public interface IAddReviewStrategy {

	EntityResult<Map<String, Object>> addTask(Map<String, Object> map, String token);
}
