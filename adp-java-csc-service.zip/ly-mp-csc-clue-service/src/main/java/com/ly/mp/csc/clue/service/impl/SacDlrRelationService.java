package com.ly.mp.csc.clue.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegist;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegistor;
import com.ly.bucn.component.interceptor.annotation.Interceptor;
import com.ly.bucn.component.message.Message;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.busi.base.handler.OptResultBuilder;
import com.ly.mp.busicen.rule.field.IFireFieldRule;
import com.ly.mp.busicen.rule.field.execution.ValidResultCtn;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.entities.SacDlrRelation;
import com.ly.mp.csc.clue.idal.mapper.SacDlrRelationMapper;
import com.ly.mp.csc.clue.service.ISacDlrRelationService;
import com.ly.mp.csc.clue.util.FiledMappingUtil;

@Service
public class SacDlrRelationService extends ServiceImpl<SacDlrRelationMapper, SacDlrRelation>
		implements ISacDlrRelationService, InterceptorWrapperRegist {

	@Autowired
	Message message;
	@Autowired
	IFireFieldRule fireFieldRule;
	@Autowired
	FiledMappingUtil filedMappingUtil;

	@Override
	@SuppressWarnings("unchecked")
	public void regist(InterceptorWrapperRegistor registor) {
		// 切点编码要和切点表里面的保持一致
		registor.before("csc_clue_savedlrrelation_validate", (context, model) -> {
			Map<String, Object> map = (Map<String, Object>) context.data().getP()[0];
			map.put("article", "csc-clue-dlrrelation-check-0001");
			checkValidate(map);
		});
		registor.before("csc_clue_savedlrrelation_exits", (context, model) -> {
			checkExists((Map<String, Object>) context.data().getP()[0]);
		});
		registor.before("csc_clue_savedlrrelation_repeat", (context, model) -> {
			checkRepeat((Map<String, Object>) context.data().getP()[0]);
		});
		registor.before("csc_clue_savedlrrelation_custom", (context, model) -> {
			checkCustom((Map<String, Object>) context.data().getP()[0]);
		});
		registor.after("csc_clue_savedlrrelation_after", (context, model) -> {
			checkAfter((Map<String, Object>) context.data().getP()[0]);
		});
	}

	/**
	 * 校验网点映射是否存在
	 * 
	 * @param mapParam 输入参数
	 */
	public void checkExists(Map<String, Object> mapParam) {
		try {
			boolean updateFlag = false;
			if (!StringHelper.IsEmptyOrNull(mapParam.get("relationId"))) {
				int size = baseMapper.checkDlrRelationExists((String) mapParam.get("relationId"));
				if (size > 0) {
					updateFlag = true;
				} else {
					throw new BusicenException(message.get("CLUE-REVIEWASSIGN-29"));
				}
			}
			mapParam.put("updateFlag", updateFlag);
		} catch (Exception ex) {
			throw ex;
		}
	}

	/**
	 * 校验关联条件参数名,运算符,参数值
	 * 
	 * @param mapParam
	 */
	public void checkCustom(Map<String, Object> mapParam) {
		try {
			// 自定义参数不为空时，分割自定义参数
			if (!StringHelper.IsEmptyOrNull(mapParam.get("wherestr"))) {
				filedMappingUtil.checkCustom(String.valueOf(mapParam.get("wherestr")));
			}
		} catch (Exception e) {
			e.printStackTrace();
			// throw new BusicenException(message.get("CLUE-SYSTECONFIGVALUE-01"));
			throw e;
		}
	}

	public void checkValidate(Map<String, Object> mapParam) {
		String article = (String) mapParam.get("article");
		ValidResultCtn fireRule = fireFieldRule.fireRule(mapParam, article, "maindata");
		String resMsg = fireRule.getNotValidMessage();
		if (!fireRule.isValid()) {
			throw new BusicenException(resMsg);
		}

		// 校验二级渠道不为空时,一级渠道是否为空
		if (!StringHelper.IsEmptyOrNull(mapParam.get("infoChanDCode"))
				&& StringHelper.IsEmptyOrNull(mapParam.get("infoChanMCode"))) {
			throw new BusicenException(message.get("CSC-MESSAGE-01"));
		}
		// 校验三级渠道不为空时,一二级渠道是否为空
		if (!StringHelper.IsEmptyOrNull(mapParam.get("infoChanDDCode"))) {
			// 一二级渠道
			if (StringHelper.IsEmptyOrNull(mapParam.get("infoChanMCode"))
					&& StringHelper.IsEmptyOrNull(mapParam.get("infoChanDCode"))) {
				throw new BusicenException(message.get("CSC-MESSAGE-03"));
			}
			// 一级渠道校验
			if (StringHelper.IsEmptyOrNull(mapParam.get("infoChanMCode"))) {
				throw new BusicenException(message.get("CSC-MESSAGE-01"));
			}
			// 二级渠道校验
			if (StringHelper.IsEmptyOrNull(mapParam.get("infoChanDCode"))) {
				throw new BusicenException(message.get("CSC-MESSAGE-02"));
			}
		}
	}

	public void checkRepeat(Map<String, Object> mapParam) {
		// 判断新网点是否与旧网点重复
		String newDlrCode = String.valueOf(mapParam.get("newDlrCode"));
		String oldDlrCode = String.valueOf(mapParam.get("oldDlrCode"));

		if (newDlrCode.equals(oldDlrCode)) {
			throw new BusicenException(message.get("CSC-MESSAGE-04"));
		}

		if (baseMapper.checkSacDlrRelation(mapParam) >= 1) {
			throw new BusicenException(message.get("CLUE-REVIEWASSIGN-20"));
		}
	}

	public void checkAfter(Map<String, Object> mapParam) {

	}

	@Override
	@Interceptor("csc_clue_savedlrrelation")
	public OptResult saveDlrRelation(Map<String, Object> map, String token) {
		try {
			// UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
			boolean updateFlag = (boolean) map.get("updateFlag");
			if (!updateFlag) {
				BusicenUtils.invokeUserInfo(map, BusicenUtils.SOU.Save, token);
				map.put("relationId", StringHelper.GetGUID());
				map.put("isEnable", StringHelper.IsEmptyOrNull(map.get("isEnable")) ? "1" : map.get("isEnable"));
				if (baseMapper.insertSacDlrRelation(map) == 0) {
					throw new BusicenException(message.get("CLUE-SYSTECONFIGVALUE-02"));
				}
			} else {
				BusicenUtils.invokeUserInfo(map, BusicenUtils.SOU.Update, token);
				// map.put("lastUpdatedDate",LocalDateTime.now());
				map.put("updateControlId", StringHelper.GetGUID());
				if (baseMapper.updateByRelationId(map) == 0) {
					throw new BusicenException(message.get("CLUE-SYSTECONFIGVALUE-03"));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			// throw new BusicenException(message.get("CLUE-SYSTECONFIGVALUE-01"));
			throw e;
		}
		return OptResultBuilder.createOk().build();
	}

	@Override
	public OptResult deleteDlrRelation(Map<String, Object> map, String token) {
		try {
			ValidResultCtn fireRule = fireFieldRule.fireRule(map, "csc-clue-dlrrelation-check-0002", "maindata");
			String resMsg = fireRule.getNotValidMessage();
			if (!fireRule.isValid()) {
				throw new BusicenException(resMsg);
			}
			String relationId = (String) map.get("relationId");
			if (baseMapper.deleteById(relationId) == 0) {
				throw new BusicenException(message.get("CLUE-WORKGROUP-06"));
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
//            throw new BusicenException(message.get("CLUE-SYSTECONFIGVALUE-01"));

		}
		return OptResultBuilder.createOk().build();
	}

	@Override
	public ListResult<Map<String, Object>> queryListDlrRelation(ParamPage<Map<String, Object>> map, String token) {
		try {
			int pageIndex = map.getPageIndex();
			int pageSize = map.getPageSize();
			Page<Map<String, Object>> page = new Page<>(pageIndex, pageSize);
			List<Map<String, Object>> list = baseMapper.selectByAll(page, map.getParam());

			for (Map<String, Object> item : list) {
				List<Map<String, Object>> columnList = new ArrayList<Map<String, Object>>();
				// 关联条件不为空时
				if (!StringHelper.IsEmptyOrNull(item.get("wherestr"))) {
					columnList = filedMappingUtil.customHandle(item.get("wherestr").toString());
				}
				// 去除in/not in的单引号
				for (Map<String, Object> columnItem : columnList) {
					if ("in".equals(columnItem.get("operational")) || "not in".equals(columnItem.get("operational"))) {

						String value = columnItem.get("value").toString().replace("'", "");
						value = value.substring(1, value.length() - 1);
						columnItem.put("value", value);
					}
				}
				// 将参数集合放进结果集
				item.put("columnList", columnList);
			}
			page.setRecords(list);
			return BusicenUtils.page2ListResult(page);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("queryListDlrRelation:", e);
			throw e;
			// throw new BusicenException(message.get("CLUE-SYSTECONFIGVALUE-01"));
		}
	}
}
