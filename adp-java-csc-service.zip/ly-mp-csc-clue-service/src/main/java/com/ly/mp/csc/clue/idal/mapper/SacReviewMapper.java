package com.ly.mp.csc.clue.idal.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.ly.mp.csc.clue.entities.SacReview;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * com.ly.mp.csc.clue.idal.mapper.SacReviewMapper
 * 回访任务
 *
 * @author zhouhao
 * @date 2021/8/20 9:04
 */
public interface SacReviewMapper extends BaseMapper<SacReview> {

    /**
     * 本人待回访任务查询
     * @param page 分页参数
     * @param param 输入参数
     * @return List
     */
    List<Map<String, Object>> queryListMeReviewInfo(IPage<Map<String, Object>> page, @Param("param")Map<String, Object> param);

    /**
     * 本组待回访任务查询
     * @param page 分页参数
     * @param param 输入参数
     * @return List
     */
    List<Map<String, Object>> queryListGroupReviewInfo(IPage<Map<String, Object>> page, @Param("param")Map<String, Object> param);
    
    /**
     * 待审核任务查询
     * @param page 分页参数
     * @param param 输入参数
     * @return List
     */
    List<Map<String, Object>> queryListAuditReviewInfo(IPage<Map<String, Object>> page, @Param("param")Map<String, Object> param);

    /**
     * 回访审核任务查询
     * @param page 分页参数
     * @param param 输入参数
     * @return List
     */
    List<Map<String, Object>> queryListAuditReviewRecordInfo(IPage<Map<String, Object>> page, @Param("param")Map<String, Object> param);

    /**
     * 回访记录查询
     * @param page 分页参数
     * @param param 输入参数
     * @return List
     */
    List<Map<String, Object>> queryReviewRecord(IPage<Map<String, Object>> page, @Param("param")Map<String, Object> param);

    
    /**
     * 获取当天人员的回访任务数 按任务数量顺序排
     * @param page 分页参数
     * @param param 输入参数
     * @return List
     */
    List<Map<String, Object>> queryTaskNumByPerson(IPage<Map<String, Object>> page, @Param("param")Map<String, Object> param);
    
    int updateReviewAssign(@Param("param")Map<String, Object> param);
    
    /**
	 * 插入
	 * @param mapParm
	 * @return
	 */
	public int insertSacReview(@Param("param")Map<String, Object> mapParm);
	
	/**
	 * 更新
	 * @param mapParm
	 * @return
	 */
	public int updateSacReview(@Param("param")Map<String, Object> mapParm);
	
	/**
	 * 根据回访ID获取回访信息
	 */
	List<Map<String, Object>> queryReviewInfoById(IPage<Map<String, Object>> page, @Param("param")Map<String, Object> param);
	
	/**
	 * 根据回访ID获取回访信息
	 * 历史表
	 */
	List<Map<String, Object>> queryReviewInfoHisById(IPage<Map<String, Object>> page, @Param("param")Map<String, Object> param);


	List<Map<String, Object>> selectReviewByID(@Param("reviewIdListString") String reviewIdListString);
}