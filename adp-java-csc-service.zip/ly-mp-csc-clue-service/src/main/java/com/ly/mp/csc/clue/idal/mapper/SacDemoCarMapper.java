package com.ly.mp.csc.clue.idal.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ly.mp.csc.clue.entities.SacDemoCar;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 试驾车表 Mapper 接口
 * </p>
 *
 * @author ly-linliq
 * @since 2021-10-14
 */
public interface SacDemoCarMapper extends BaseMapper<SacDemoCar> {

	/**
	 * 试驾车查询
	 * 
	 * @param param
	 * @return
	 */
	public List<Map<String, Object>> selectDemoCar(@Param("param") Map<String, Object> param,Page<Map<String, Object>> page);

	/**
	 * 试驾车新增
	 * 
	 * @param param
	 * @return
	 */
	public int insertDemoCar(@Param("param") Map<String, Object> param);

	/**
	 * 试驾车保存
	 * 
	 * @param param
	 * @return
	 */
	public int updateDemoCar(@Param("param") Map<String, Object> param);
	
	/**
	 * 车牌号查重
	 * @param param
	 * @return
	 */
	public int checkPlateNumberRepeat(@Param("param") Map<String, Object> param);
	
	/**
	 * 车架号查询
	 * @param param
	 * @return
	 */
	public int checkCarVinRepeat(@Param("param") Map<String, Object> param);
	
	/**
	 * 车架号与车牌号一起查重
	 * @param param
	 * @return
	 */
	public int checkRepeat(@Param("param") Map<String, Object> param);
	
	/**
	 * 修改里程
	 * @param param
	 * @return
	 */
	public int updateRoadHaul(@Param("param") Map<String, Object> param);
}
