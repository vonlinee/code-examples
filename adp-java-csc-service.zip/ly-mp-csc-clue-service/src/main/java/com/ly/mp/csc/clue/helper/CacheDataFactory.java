package com.ly.mp.csc.clue.helper;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.csc.clue.service.ISacSystemConfigValueService;
import com.ly.mp.csc.clue.service.ISacWorkGroupService;


/**
 * 缓存数据
 * @author ly-shenyw
 *
 */
@Component
public class CacheDataFactory {
	@Autowired
	ISacSystemConfigValueService sacSystemConfigValueService;
	@Autowired
	ISacWorkGroupService sacWorkGroupService;
	
	private final String CACHE_NAME="BUSICEN_CLUE_REVIEW";
	private final String CACHE_KEY_GROUP_USER="CSC_GROUP_USER_LIST";
	
	
	/**
	 * 获取系统配置信息
	 * @param configCode 配置项编码
	 * @param orgCode 组织编码
	 * @param token
	 * @return
	 */
	public String querySysConfigValue(String configCode,String token){
		try{
			ParamPage<Map<String,Object>> map = new ParamPage<>();
			map.setPageIndex(-1);
			map.setPageSize(-1);
			map.setParam(new HashMap<String,Object>());
			map.getParam().put("configCode", configCode);
			List<Map<String, Object>> list = sacSystemConfigValueService.selectByConfigCode(map,token).getRows();	
	    	if(list!=null && list.size()>0){
	    		return list.get(0).get("valueCode").toString();
	    	}
		}catch (Exception e) {
			return null;
		}
		return null;
    	
    }
	
	/**
	 * 获取当前人员所在工作组的所有用户ID列表，多个逗号分割
	 * @param empId
	 * @return
	 */
	public String  selectGroupUserList(String empId,String isLeader){
		/*
		if(CacheHelper.get(CACHE_NAME,CACHE_KEY_GROUP_USER+empId) ==null){
			String idlist = sacWorkGroupService.selectGroupUserList(empId);
			CacheHelper.put(CACHE_NAME,CACHE_KEY_GROUP_USER+empId,idlist,600);
		}
		return (String)CacheHelper.get(CACHE_NAME,CACHE_KEY_GROUP_USER+empId);
		*/
		return sacWorkGroupService.selectGroupUserList(empId,isLeader);
		
	}

}
