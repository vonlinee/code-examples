package com.ly.mp.csc.clue.service.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateFormatUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;
import org.springframework.util.StopWatch;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ibm.icu.util.Calendar;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegist;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegistor;
import com.ly.bucn.component.interceptor.annotation.Interceptor;
import com.ly.bucn.component.message.Message;
import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.constant.UserBusiEntity;
import com.ly.mp.busi.base.context.BusicenContext;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.busi.base.handler.BusicenUtils.SOU;
import com.ly.mp.busi.base.handler.MapUtil;
import com.ly.mp.busi.base.handler.OptResultBuilder;
import com.ly.mp.busi.base.handler.ResultHandler;
import com.ly.mp.busicen.rule.field.IFireFieldRule;
import com.ly.mp.busicen.rule.field.execution.ValidResultCtn;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.entities.SacClueInfoDlr;
import com.ly.mp.csc.clue.idal.mapper.SacClueInfoDlrMapper;
import com.ly.mp.csc.clue.otherservice.ICscSysBaseDataService;
import com.ly.mp.csc.clue.otherservice.ICscSysOrgService;
import com.ly.mp.csc.clue.service.IRemoveRepeatConfigService;
import com.ly.mp.csc.clue.service.ISacClueInfoDlrService;
import com.ly.mp.csc.clue.service.ISacSystemConfigValueService;
import com.ly.mp.csc.clue.strategy.service.impl.AddReviewFactroy;
import com.ly.mp.csc.clue.util.ExcelExport;
import com.ly.mp.csc.clue.util.FiledMappingUtil;
import com.ly.mp.csc.clue.util.ReviewUpdateClueUtil;

/**
 * <p>
 * 店端线索表 服务实现类
 * </p>
 *
 * @author ly-busicen
 * @since 2021-08-20
 */
@Service
public class SacClueInfoDlrService extends ServiceImpl<SacClueInfoDlrMapper, SacClueInfoDlr>
implements ISacClueInfoDlrService, InterceptorWrapperRegist {

	private Logger log = LoggerFactory.getLogger(SacClueInfoDlrService.class);

	@Autowired
	SacClueInfoDlrMapper sacClueInfoDlrMapper;

	//@Autowired
	//ISacReviewService sacReviewService;
	@Autowired
	AddReviewFactroy addReviewFactroy;
	@Autowired
	ICscSysBaseDataService baseDataService;
	@Autowired
	IRemoveRepeatConfigService removeRepeatConfigService;
	@Autowired
	ISacSystemConfigValueService sacSystemConfigValueService;
	@Autowired
	Message message;
	@Autowired
	IFireFieldRule fireFieldRule;
	@Autowired
	FiledMappingUtil filedMappingUtil;

	@Override
	public OptResult updateMap(Map<String, Object> param, String token) {
		OptResult optResult = new OptResult();
		String id = (String) param.get("id");
		Assert.hasText("主键不能为空", id);
		// 修改记录
		param.remove("custName");
		int result = this.baseMapper.sacClueInfoDlrUpdate(param);
		if (result == 0) {
			optResult.setResult("0");
			optResult.setMsg(message.get("CLUE-BASE-02"));
		} else {
			optResult.setResult("1");
			optResult.setMsg(message.get("CLUE-BASE-01"));
		}
		return optResult;
	}

	@Autowired ICscSysOrgService orgService;
	private void setOrderCode(Map<String, Object> param, String dlrId, String token) {
		// 商机下发专营店会对param的dlrCode赋值，如果dlrCode不为空则优先取dlrCode对应的dlrId
		if(!StringHelper.IsEmptyOrNull(param.get("dlrId"))) {
			dlrId = (String)param.get("dlrId");
		} else if(!StringHelper.IsEmptyOrNull(param.get("dlrCode"))) {
			String dlrCode = (String)param.get("dlrCode");
			Map<String, Object> orgDlrInfo = orgService.getOrgDlrInfo(token, dlrCode);
			if(orgDlrInfo != null && orgDlrInfo.get("dlrId") != null) {
				dlrId = (String)orgDlrInfo.get("dlrId");
			}
		}

		// 店端线索单号生成【线索编码】对应【单据类型】 String billTypeId = "sacdlrcluecode";
		ListResult<Map<String, Object>> generateOrderCode = baseDataService.generateOrderCode(dlrId, "sacdlrcluecode", token);
		if ("1".equals(generateOrderCode.getResult())) {
			param.put("serverOrder", generateOrderCode.getMsg());
		} else {
			throw BusicenException.create("调用生成【线索编码】出错！[result=" + generateOrderCode.getResult() + ", msg="
					+ generateOrderCode.getMsg() + "token="+token+"]");
		}
	}

	@Override
	@Interceptor("csc_clue_base_dlr_save")
	@Transactional(rollbackFor = Exception.class)
	public EntityResult<Map<String, Object>> saveMap(ParamBase<Map<String, Object>> clueParam, String token) {
		StopWatch stopWatch = new StopWatch("新建线索");
		UserBusiEntity user = BusicenContext.getCurrentUserBusiInfo(token);
		// user.getUserName() + ", orgName=" + user.getOrgName());
		Map<String, Object> param = clueParam.getParam();
		// 去掉空字符串
		MapUtil.removeNullValue(param);
		String id = (String) param.get("id");

		EntityResult<Map<String, Object>> optResult = new EntityResult<>();
		optResult.setResult("1");
		try {
			// 新增记录
			if (StringHelper.IsEmptyOrNull(id)) {
				param.put("updateOrSave", BusicenUtils.Save);
				param.put("id", StringHelper.GetGUID());
				param.put("isEnable", "1");
				if(param.get("dlrCode") == null) {
					param.put("dlrCode", user.getDlrCode());
					param.put("dlrShortName", user.getDlrName());
				}

				if(param.get("statusCode") == null) {
					param.put("statusCode", "1");
					param.put("statusName", "待分配");
				}

				// TODO 判断如果最低级的信息来源编码没传，则用一级来源信息覆盖。
				if(!StringHelper.IsEmptyOrNull(param.get("infoChanMName"))) {
					if(StringHelper.IsEmptyOrNull(param.get("channelName"))) {
						param.put("channelName",param.get("infoChanMName"));
//						param.put("channelName",param.get("infoChanMName"));
					}
				}

				//planReviewTime  下次回访时间，前端没传，则默认给当前时间+1天
				if(StringHelper.IsEmptyOrNull(param.get("planReviewTime"))) {
					Calendar planReviewTimeCal = Calendar.getInstance();
					planReviewTimeCal.add(Calendar.DATE, 1);
					param.put("planReviewTime", DateFormatUtils.format(planReviewTimeCal.getTime(), "yyyy-MM-dd HH:mm:ss"));
				}

				stopWatch.start("生成单号");

				BusicenUtils.invokeUserInfo(param, SOU.Save, token);
				if(!StringHelper.IsEmptyOrNull(clueParam.getParam().get("createdDateT"))) {
					param.put("creator", clueParam.getParam().get("creatorT"));
					param.put("createdName", clueParam.getParam().get("createdNameT"));
					param.put("createdDate", clueParam.getParam().get("createdDateT"));
				}
				param.put("serverOrder",StringHelper.GetGUID());
				/*try {
					// 生成线索单号：serverOrder
					setOrderCode(param, user.getDlrID(), token);
				} catch (Exception e) {
					e.printStackTrace();
					log.error("生成线索单号",e);
					param.remove("id");
					optResult.setResult("0");
					throw BusicenException.create(e.getMessage() + ":" + user.getDlrID());
				}*/
				stopWatch.stop();

				stopWatch.start("插入");
				try {
					this.baseMapper.sacClueInfoDlrInsert(param);
					if (param.get("count") != null && Integer.valueOf(param.get("count").toString()) > 0) {
						optResult.setResult("1");
						optResult.setMsg(message.get("CLUE-BASE-DLR-05"));
						optResult.setRows(param);
						return optResult;
					}
				} catch (Exception e) {
					e.printStackTrace();
					param.remove("id");
					optResult.setResult("0");
					throw BusicenException.create(e.getMessage());
				}
				stopWatch.stop();

			} else {
				param.put("updateOrSave", BusicenUtils.Update);
				param.put("lastUpdatedDate", LocalDateTime.now());
				param.put("modifier", user.getUserID());
				param.put("modifyName", user.getEmpName());
				// 修改记录
				int result = this.baseMapper.sacClueInfoDlrUpdate(param);
				if (result == 0) {
					optResult.setResult("0");
					optResult.setMsg(message.get("CLUE-BASE-DLR-02"));
				} else {
					optResult.setResult("1");
					optResult.setMsg(message.get("CLUE-BASE-DLR-01"));
					optResult.setRows(param);
				}
				return optResult;
			}
		} catch (Exception e) {
			log.error("saveMap", e);
			throw e;
		}

		System.out.println("新建线索:" +stopWatch.prettyPrint() +"毫秒");//;
		System.out.println("新建线索:" +stopWatch.getTotalTimeMillis() +"毫秒");//;
		optResult.setRows(param);
		return optResult;
	}

	@Override
	public ListResult<Map<String, Object>> findByPage(ParamPage<Map<String, Object>> paramPage) {
		ListResult<Map<String, Object>> result = new ListResult<Map<String, Object>>();
		try {
			Page<Map<String, Object>> page = new Page<Map<String, Object>>(paramPage.getPageIndex(),
					paramPage.getPageSize());
			Map<String, Object> param = paramPage.getParam();
			List<Map<String, Object>> list = null;
			// 历史表
			if(param != null && "1".equals(param.get("isHis"))) {
				list = this.baseMapper.selectHisByPage(page, param);
			} else {
				list = this.baseMapper.selectByPage(page, param);
			}
			page.setRecords(list);
			result = BusicenUtils.page2ListResult(page);
		} catch (Exception e) {
			log.error("findByPage", e);
			throw e;
		}
		return result;
	}

	@Override
	public EntityResult<Map<String, Object>> findById(String id, String serverOrder) {
		if(StringUtils.isBlank(id) && StringUtils.isBlank(serverOrder)) {
			throw new BusicenException("id和serverOrder不能同时为空！");
		}
		try {
			Map<String, Object> paramMap = new HashMap<>();
			paramMap.put("id", id);
			paramMap.put("serverOrder", serverOrder);
			Map<String, Object> clueMap = this.baseMapper.selectMapById(paramMap);
			if(clueMap == null) {
				// 查询历史表
				clueMap = this.baseMapper.selectHisById(paramMap);
			}
			return ResultHandler.updateOk(clueMap);
		} catch (Exception e) {
			log.error("findByPage", e);
			throw e;
		}
	}

	/**
	 * 店端线索导出
	 */
	@SuppressWarnings("unchecked")
	@Override
	public OptResult exportDlrClue(Map<String, Object> mapParam, String token, HttpServletResponse response) {
		try {
			String title = "店端线索";// 导出文件名称
			List<Map<String, Object>> columnList = (List<Map<String, Object>>) mapParam.get("columnList");// 页面网格列列表
			if (columnList == null) {
				throw BusicenException.create(message.get("EXCEL-EXPORT-01"));
			}
			mapParam.put("token", token);
			// 先将结果查询出来
			ParamPage<Map<String, Object>> mapParamPage = new ParamPage<Map<String, Object>>();
			mapParamPage.setPageIndex(1);
			mapParamPage.setPageSize(-1);
			mapParamPage.setParam(mapParam);
			// 调用店端线索查询接口
			ListResult<Map<String, Object>> listResult = this.findByPage(mapParamPage);
			List<Map<String, Object>> rows = listResult.getRows();
			// 导出excel
			ExcelExport export = new ExcelExport();
			export.excelExport(token, title, response, rows, columnList);

		} catch (Exception e) {
			e.printStackTrace();
			throw new BusicenException(e.getMessage());
		}
		return OptResultBuilder.createOk().build();
	}

	@SuppressWarnings("unchecked")
	@Override
	public void regist(InterceptorWrapperRegistor registor) {
		// 店端线索保存-查重
		registor.before("csc_clue_base_dlr_save_repeat", (context, model) -> {
			// TODO
			// 线索保存接口增加前置：判断是否存在该手机号的线索(查重)，存在则不处理
			int checkRepeat = checkRepeat((ParamBase<Map<String, Object>>) context.data().getP()[0]);
			if(checkRepeat != 0) {
				// 线索保存接口增加前置：判断是否存在该手机号的线索(查重)，存在则不处理
				throw BusicenException.create("重复留资");
			}
		});

		//客制化SacClueExtensionService - 已经实现csc_clue_base_dlr_save_cust_id
		// 店端线索保存-回填客户Id
		// 检查是否存在客户信息,不存在则生成客户，最后回填客户Id
		//		registor.before("csc_clue_base_dlr_save_cust_id", (context, model) -> {
		//			ParamBase<Map<String, Object>> paramBase = (ParamBase<Map<String, Object>>) context.data().getP()[0];
		//			Map<String, Object> clueParam = paramBase.getParam();
		//
		//			String custId = null;
		//			// 回填客户Id
		//			clueParam.put("custId", custId);
		//		});

		// 店端线索保存-生成回访任务
		registor.after("csc_clue_base_dlr_save_addreviewtask", (context, model) -> {
			ParamBase<Map<String, Object>> clueParam = (ParamBase<Map<String, Object>>) context.data().getP()[0];
			addreviewtask(clueParam);
		});
	}

	private void addreviewtask(ParamBase<Map<String, Object>> paramBase) {
		StopWatch stopWatch = new StopWatch("新建线索-生成回访");
		Map<String, Object> dlrClueMap = paramBase.getParam();
		if(dlrClueMap == null) {
			return;
		}
		// 重复记录
		if(dlrClueMap.get("count") != null && Integer.valueOf(dlrClueMap.get("count").toString()) > 0) {
			return ;
		}
		// 不是新增记录 id为空表明新增失败
		if(dlrClueMap.get("id") == null || !BusicenUtils.Save.equals(dlrClueMap.get("updateOrSave"))) {
			return ;
		}
		stopWatch.start("生成回访");
		// 生成回访任务
		String token = dlrClueMap.get("token").toString();
		dlrClueMap.remove("reviewId");
		Map<String, Object> reviewMap = ReviewUpdateClueUtil.getReviewTaskParamFromClueDlr(dlrClueMap, token);

		//EntityResult<Map<String, Object>> addTask = sacReviewService.addTask(reviewMap, token);
		EntityResult<Map<String, Object>> addTask = addReviewFactroy.addTask(reviewMap, token);

		Map<String, Object> rows = addTask.getRows();
		if(rows == null || StringUtils.isBlank((String)rows.get("reviewId"))) {
			throw new BusicenException("生成回访任务失败！");
		}
		stopWatch.stop();

		stopWatch.start("回填回访Id");

		// 回填回访Id
		String id = dlrClueMap.get("id").toString();
		SacClueInfoDlr vo = this.baseMapper.selectById(id);
		if(StringHelper.IsEmptyOrNull(vo.getReviewId())) {
			Map<String, Object> updateMap = new HashMap<>();
			updateMap.put("id", vo.getId());
			updateMap.put("reviewId", rows.get("reviewId"));
			updateMap.put("updateControlId", vo.getUpdateControlId());
			int updateFlag = this.baseMapper.sacClueInfoDlrUpdate(updateMap);
			Assert.isTrue(updateFlag != 0, "回填回访Id失败");
		}

		stopWatch.stop();

		System.out.println("新建线索-生成回访:" +stopWatch.prettyPrint() +"毫秒");//;
		System.out.println("新建线索-生成回访:" +stopWatch.getTotalTimeMillis() +"毫秒");//;
	}


	@Override
	public EntityResult<Map<String, Object>> dlrClueCheckRepeat(ParamBase<Map<String, Object>> mapParam) {
		ValidResultCtn fireRule = fireFieldRule.fireRule(mapParam.getParam(), "dlr-clue-check-repeat", "maindata");
		String resMsg = fireRule.getNotValidMessage();
		if (!fireRule.isValid()){
			throw new BusicenException(resMsg);
		}

		Map<String, Object> orginialParam = new HashMap<String, Object>();
		//orginialParam.putAll(mapParam.getParam());
		int checkRepeat = checkRepeat(mapParam);
		if(checkRepeat == 0) {
			EntityResult<Map<String, Object>> optResult = new EntityResult<>();
			optResult.setResult("1");
			optResult.setMsg("店端线索不重复！");
			return optResult;
		} else {
			// throw new BusicenException("线索已存在，正在跟进中！");
			Page<Map<String, Object>> page = new Page<Map<String, Object>>(1,Integer.MAX_VALUE);
			List<Map<String, Object>> list = null;
			orginialParam.put("id", mapParam.getParam().get("id"));
			list = this.baseMapper.selectByPage(page, orginialParam);

			EntityResult<Map<String, Object>> optResult = new EntityResult<>();
			optResult.setResult("0");
			optResult.setMsg(message.get("CLUE-BASE-DLR-07"));
			optResult.setRows(list.get(0));
			return optResult;
		}
	}


	@Override
	@SuppressWarnings("unchecked")
	public int checkRepeat(ParamBase<Map<String, Object>> mapParam) {
		// Map<String, Object> clueMap = mapParam.getParam();
		// 初始化count为0
		int count = 0;
		List<Map<String, Object>> checkResultMap= new ArrayList<>();
		try {
			ParamPage<Map<String, Object>> map = new ParamPage<Map<String, Object>>();
			String customSqlString = "";
			List<Map<String, Object>> noFieldMappingList = new ArrayList<Map<String, Object>>();
			List<String> jsonFieldMappingList = new ArrayList<String>();
			Map<String, Object> param = new HashMap<String, Object>();

			param.put("token", mapParam.getParam().get("token"));
			map.setPageIndex(1);
			map.setPageSize(-1);
			map.setParam(param);
			List<Map<String, Object>> list = removeRepeatConfigService.queryListRemoveRepeatConfig(map).getRows();

			// 当有线索去重规则时才走查重
			if (list.size() > 0) {
				UserBusiEntity user = BusicenContext.getCurrentUserBusiInfo(String.valueOf(mapParam.getParam().get("token")));
				Map<String, Object> configInfo = list.get(0);
				String columInfo = String.valueOf(configInfo.get("custom"));

				// 设置默认值
				mapParam.getParam().put("count", 0);

				Map<String, Object> clueMap = new HashMap<String, Object>();
				clueMap.putAll(mapParam.getParam());
				clueMap.put("checkPhone", configInfo.get("checkPhone"));
				clueMap.put("checkTime", configInfo.get("checkTime"));
				clueMap.put("checkTimeHorizon", configInfo.get("checkTimeHorizon"));

				
				// 厂家设置【店端线索共享开关】启动时，去重查询时不区分专营店
				if(!"share".equals(configInfo.get("orgCode"))) {
					clueMap.put("dlrCode", user.getDlrCode());
					clueMap.put("dlrShortName", user.getDlrName());
				}else {
					clueMap.remove("dlrCode");
					clueMap.remove("dlrShortName");
				}
				

				// 自定义参数不为空时
				if (!StringHelper.IsEmptyOrNull(columInfo)) {
					// 处理参数
					List<Map<String, Object>> columnList = filedMappingUtil.customHandle(columInfo);
					// 查询字段映射情况
					Map<String, Object> info = new HashMap<String, Object>();
					info.put("sourceTableCode", "t_sac_clue_info");
					info.put("billType", "CLUE");
					info.put("businessType", "-1");
					info.put("columnList", columnList);
					Map<String, Object> fieldMap = filedMappingUtil.queryFieldMappingList(info);
					if (!StringHelper.IsEmptyOrNull(fieldMap.get("fieldMapping"))) {
						// 将有字段映射的参数、运算符、参数值拼接成sql
						customSqlString = filedMappingUtil
								.joinFieldMappingCustom((List<Map<String, Object>>) fieldMap.get("fieldMapping"));
					}
					if (!StringHelper.IsEmptyOrNull(fieldMap.get("field"))) {
						// 将没有字段映射的字段拼接成sql(字段名+运算符+值)
						noFieldMappingList = filedMappingUtil
								.joinNoFieldMappingCustom((List<Map<String, Object>>) fieldMap.get("field"));
					}
					if (!StringHelper.IsEmptyOrNull(fieldMap.get("jsonFieldMapping"))) {
						// 将字段映射类型为2的字段拼接成sql
						jsonFieldMappingList = filedMappingUtil.joinJsonFieldMappingCustom(
								(List<Map<String, Object>>) fieldMap.get("jsonFieldMapping"));
					}
					// 将字段映射类型为2的参数数组放进map中
					if (jsonFieldMappingList.size() > 0) {
						clueMap.put("jsonFieldMappingList", jsonFieldMappingList);
					}
					// 将没有字段映射的参数数组，将其放进map中
					if (noFieldMappingList.size() > 0) {
						clueMap.put("noFieldMappingList", noFieldMappingList);
					}
					// 将有字段映射的sql放进map中
					if (!StringHelper.IsEmptyOrNull(customSqlString)) {
						clueMap.put("customSqlString", customSqlString);
					}
					if (!StringHelper.IsEmptyOrNull(mapParam.getParam().get("id"))) {
						clueMap.put("id", String.valueOf(mapParam.getParam().get("id")));
					}
				}
				// 如果checkPhone为0且自定义参数为空的时候不走查重
				// 查重
				if ("1".equals(clueMap.get("checkPhone"))||!StringHelper.IsEmptyOrNull(columInfo)) {
					checkResultMap = this.baseMapper.checkRepeat(clueMap);
					count=checkResultMap.size();
				}
			}
			if (count > 0) {
				mapParam.getParam().put("id", checkResultMap.get(0).get("id").toString());
				mapParam.getParam().put("count", count);
				mapParam.getParam().put("statusCode", "5");
				mapParam.getParam().put("statusName", "重复留资");
			} else {
				mapParam.getParam().put("count", 0);
			}
		} catch (Exception ex) {
			log.error("csc_clue_base_dlr_save_repeat:",ex);
			throw ex;
		}
		return count;
	}
}
