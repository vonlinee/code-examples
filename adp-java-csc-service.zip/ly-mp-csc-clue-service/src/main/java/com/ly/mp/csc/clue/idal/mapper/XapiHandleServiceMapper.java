package com.ly.mp.csc.clue.idal.mapper;

import java.util.List;
import java.util.Map;


/**
 * <p>
 * Xapi服务调 Mapper
 * </p>
 */
public interface XapiHandleServiceMapper {

	/**
	 * 归档定时任务_查询数据
	 */
	List<Map<String, Object>> queryData(Map<String, Object> info);

	/**
	 * 归档定时任务_写入历史表
	 */
	int insertData(Map<String, Object> info);

	/**
	 * 归档定时任务_删除原数据
	 */
	int delData(Map<String, Object> info);
}
