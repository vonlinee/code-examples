package com.ly.mp.csc.clue.strategy.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ly.bucn.component.strategy.annotation.Strategy;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.csc.clue.entities.out.ReviewFpResultOut;
import com.ly.mp.csc.clue.entities.out.ReviewPersonQueneOut;
import com.ly.mp.csc.clue.service.ISacReviewService;
import com.ly.mp.csc.clue.strategy.service.IReviewFpRuleStrategy;

/**
 * 人员平均分配，新的任务+回访人员当天的任务，平均分配给回访人队列里的人员
 * @author ly-shenyw
 *
 */
@Strategy(isDefault=false,names="personAvg")
@Component
public class ReviewFpRuleStrategyPersonAvg implements IReviewFpRuleStrategy{
	
	@Autowired
	ISacReviewService sacReviewService;
	
	/**
	 * 单个任务
	 * @param orgCode 组织编码
	 * @param personList 人员队列
	 * @param setId 分配规则设置ID
	 * @param planReviewTime 计划回访时间
	 * @return 返回匹配的分配人员信息
	 */
	@Override
	public ReviewFpResultOut handle(String orgCode, List<ReviewPersonQueneOut> personList,String setId,String planReviewTime){
		ParamPage<Map<String, Object>> map = new ParamPage<Map<String, Object>>();
		map.setPageIndex(-1);
		map.setPageSize(-1);
		Map<String, Object> param = new HashMap<>();
		param.put("orgCode", orgCode);
		if(personList!=null){
			List<String> personIdList = personList.stream().map(s->s.getReviewPersonUserId()).collect(Collectors.toList());
			param.put("personIdList", String.join(",", personIdList));
		}
		param.put("planReviewTime", planReviewTime);
		map.setParam(param);
		ListResult<Map<String, Object>> result = sacReviewService.queryTaskNumByPerson(map, "");
		if(result!=null && result.getRows()!=null && result.getRows().size()>0){
			if(personList!=null){
				//当天有任务的人
				List<Map<String, Object>> list = result.getRows();
				//过滤出当天没任务的人
				List<ReviewPersonQueneOut> filtList = personList.stream().filter(p->
				list.stream().filter(l->p.getReviewPersonUserId().equals(l.get("reviewPersonId").toString())).count()<=0
				).collect(Collectors.toList());
				if(filtList!=null && filtList.size()>0){
					//当天没任务 随机取一个人
					Random random = new Random();
					int n = random.nextInt(filtList.size());
					ReviewPersonQueneOut personQueneOut = filtList.get(n);
					ReviewFpResultOut out = new ReviewFpResultOut();
					out.setReviewPersonUserId(personQueneOut.getReviewPersonUserId());
					out.setReviewPersonName(personQueneOut.getReviewPersonName());
					return out;
				}
			}
			
			ReviewFpResultOut out = new ReviewFpResultOut();
			out.setReviewPersonUserId(result.getRows().get(0).get("reviewPersonId").toString()); 
			out.setReviewPersonName(result.getRows().get(0).get("reviewPersonName").toString()); 
			return out;
			
		}else if(personList!=null){
			//当天没任务 随机取一个人
			Random random = new Random();
			int n = random.nextInt(personList.size());
			ReviewPersonQueneOut personQueneOut = personList.get(n);
			ReviewFpResultOut out = new ReviewFpResultOut();
			out.setReviewPersonUserId(personQueneOut.getReviewPersonUserId());
			out.setReviewPersonName(personQueneOut.getReviewPersonName());
			return out;
		}
		return null;
	}
}
