package com.ly.mp.csc.clue.entities;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

/**
 * <p>
 * 线索分配记录表
 * </p>
 *
 * @author CaiYunXiang
 * @since 2022-05-24
 */
@TableName("t_sac_clue_allocating_record")
public class SacClueAllocatingRecord implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 记录主键ID
     */
    @TableId("RECORD_ID")
    private String recordId;

    /**
     * 原门店ID
     */
    @TableField("OLD_DLR_ID")
    private String oldDlrId;

    /**
     * 原经销商编码
     */
    @TableField("OLD_DLR_CODE")
    private String oldDlrCode;

    /**
     * 原经销商名称
     */
    @TableField("OLD_DLR_SHORT_NAME")
    private String oldDlrShortName;

    /**
     * 原销售ID
     */
    @TableField("OLD_SALESPERSON_ID")
    private String oldSalespersonId;

    /**
     * 原销售名称
     */
    @TableField("OLD_SALESPERSON_NAME")
    private String oldSalespersonName;

    /**
     * 现门店ID
     */
    @TableField("NEW_DLR_ID")
    private String newDlrId;

    /**
     * 现经销商编码
     */
    @TableField("NEW_DLR_CODE")
    private String newDlrCode;

    /**
     * 现经销商名称
     */
    @TableField("NEW_DLR_SHORT_NAME")
    private String newDlrShortName;

    /**
     * 现销售ID
     */
    @TableField("NEW_SALESPERSON_ID")
    private String newSalespersonId;

    /**
     * 现销售名称
     */
    @TableField("NEW_SALESPERSON_NAME")
    private String newSalespersonName;

    /**
     * 扩展字段1
     */
    @TableField("COLUMN1")
    private String column1;

    /**
     * 扩展字段2
     */
    @TableField("COLUMN2")
    private String column2;

    /**
     * 扩展字段3
     */
    @TableField("COLUMN3")
    private String column3;

    /**
     * 扩展字段4
     */
    @TableField("COLUMN4")
    private String column4;

    /**
     * 扩展字段5
     */
    @TableField("COLUMN5")
    private String column5;

    /**
     * 扩展字段6
     */
    @TableField("COLUMN6")
    private String column6;

    /**
     * 扩展字段7
     */
    @TableField("COLUMN7")
    private String column7;

    /**
     * 扩展字段8
     */
    @TableField("COLUMN8")
    private String column8;

    /**
     * 扩展字段9
     */
    @TableField("COLUMN9")
    private String column9;

    /**
     * 扩展字段10
     */
    @TableField("COLUMN10")
    private String column10;

    /**
     * JSON扩展字段
     */
    @TableField("EXTENDS_JSON")
    private String extendsJson;

    /**
     * 厂商标识ID
     */
    @TableField("OEM_ID")
    private String oemId;

    /**
     * 集团标识ID
     */
    @TableField("GROUP_ID")
    private String groupId;

    /**
     * 创建人ID
     */
    @TableField(value = "CREATOR", fill = FieldFill.INSERT)
    private String creator;

    /**
     * 创建人
     */
    @TableField(value = "CREATED_NAME", fill = FieldFill.INSERT)
    private String createdName;

    /**
     * 创建日期
     */
    @TableField(value = "CREATED_DATE", fill = FieldFill.INSERT)
    private LocalDateTime createdDate;

    /**
     * 修改人ID
     */
    @TableField(value = "MODIFIER", fill = FieldFill.INSERT_UPDATE)
    private String modifier;

    /**
     * 修改人
     */
    @TableField(value = "MODIFY_NAME", fill = FieldFill.INSERT_UPDATE)
    private String modifyName;

    /**
     * 最后更新日期
     */
    @TableField(value = "LAST_UPDATED_DATE", fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime lastUpdatedDate;

    /**
     * 是否可用
     */
    @TableField("IS_ENABLE")
    private String isEnable;

    /**
     * 并发控制ID
     */
    @TableField(value = "UPDATE_CONTROL_ID", fill = FieldFill.INSERT_UPDATE)
    private String updateControlId;

    public String getRecordId() {
        return recordId;
    }

    public void setRecordId(String recordId) {
        this.recordId = recordId;
    }
    public String getOldDlrId() {
        return oldDlrId;
    }

    public void setOldDlrId(String oldDlrId) {
        this.oldDlrId = oldDlrId;
    }
    public String getOldDlrCode() {
        return oldDlrCode;
    }

    public void setOldDlrCode(String oldDlrCode) {
        this.oldDlrCode = oldDlrCode;
    }
    public String getOldDlrShortName() {
        return oldDlrShortName;
    }

    public void setOldDlrShortName(String oldDlrShortName) {
        this.oldDlrShortName = oldDlrShortName;
    }
    public String getOldSalespersonId() {
        return oldSalespersonId;
    }

    public void setOldSalespersonId(String oldSalespersonId) {
        this.oldSalespersonId = oldSalespersonId;
    }
    public String getOldSalespersonName() {
        return oldSalespersonName;
    }

    public void setOldSalespersonName(String oldSalespersonName) {
        this.oldSalespersonName = oldSalespersonName;
    }
    public String getNewDlrId() {
        return newDlrId;
    }

    public void setNewDlrId(String newDlrId) {
        this.newDlrId = newDlrId;
    }
    public String getNewDlrCode() {
        return newDlrCode;
    }

    public void setNewDlrCode(String newDlrCode) {
        this.newDlrCode = newDlrCode;
    }
    public String getNewDlrShortName() {
        return newDlrShortName;
    }

    public void setNewDlrShortName(String newDlrShortName) {
        this.newDlrShortName = newDlrShortName;
    }
    public String getNewSalespersonId() {
        return newSalespersonId;
    }

    public void setNewSalespersonId(String newSalespersonId) {
        this.newSalespersonId = newSalespersonId;
    }
    public String getNewSalespersonName() {
        return newSalespersonName;
    }

    public void setNewSalespersonName(String newSalespersonName) {
        this.newSalespersonName = newSalespersonName;
    }
    public String getColumn1() {
        return column1;
    }

    public void setColumn1(String column1) {
        this.column1 = column1;
    }
    public String getColumn2() {
        return column2;
    }

    public void setColumn2(String column2) {
        this.column2 = column2;
    }
    public String getColumn3() {
        return column3;
    }

    public void setColumn3(String column3) {
        this.column3 = column3;
    }
    public String getColumn4() {
        return column4;
    }

    public void setColumn4(String column4) {
        this.column4 = column4;
    }
    public String getColumn5() {
        return column5;
    }

    public void setColumn5(String column5) {
        this.column5 = column5;
    }
    public String getColumn6() {
        return column6;
    }

    public void setColumn6(String column6) {
        this.column6 = column6;
    }
    public String getColumn7() {
        return column7;
    }

    public void setColumn7(String column7) {
        this.column7 = column7;
    }
    public String getColumn8() {
        return column8;
    }

    public void setColumn8(String column8) {
        this.column8 = column8;
    }
    public String getColumn9() {
        return column9;
    }

    public void setColumn9(String column9) {
        this.column9 = column9;
    }
    public String getColumn10() {
        return column10;
    }

    public void setColumn10(String column10) {
        this.column10 = column10;
    }
    public String getExtendsJson() {
        return extendsJson;
    }

    public void setExtendsJson(String extendsJson) {
        this.extendsJson = extendsJson;
    }
    public String getOemId() {
        return oemId;
    }

    public void setOemId(String oemId) {
        this.oemId = oemId;
    }
    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }
    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }
    public String getCreatedName() {
        return createdName;
    }

    public void setCreatedName(String createdName) {
        this.createdName = createdName;
    }
    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }
    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier;
    }
    public String getModifyName() {
        return modifyName;
    }

    public void setModifyName(String modifyName) {
        this.modifyName = modifyName;
    }
    public LocalDateTime getLastUpdatedDate() {
        return lastUpdatedDate;
    }

    public void setLastUpdatedDate(LocalDateTime lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }
    public String getIsEnable() {
        return isEnable;
    }

    public void setIsEnable(String isEnable) {
        this.isEnable = isEnable;
    }
    public String getUpdateControlId() {
        return updateControlId;
    }

    public void setUpdateControlId(String updateControlId) {
        this.updateControlId = updateControlId;
    }

    @Override
    public String toString() {
        return "SacClueAllocatingRecord{" +
        "recordId=" + recordId +
        ", oldDlrId=" + oldDlrId +
        ", oldDlrCode=" + oldDlrCode +
        ", oldDlrShortName=" + oldDlrShortName +
        ", oldSalespersonId=" + oldSalespersonId +
        ", oldSalespersonName=" + oldSalespersonName +
        ", newDlrId=" + newDlrId +
        ", newDlrCode=" + newDlrCode +
        ", newDlrShortName=" + newDlrShortName +
        ", newSalespersonId=" + newSalespersonId +
        ", newSalespersonName=" + newSalespersonName +
        ", column1=" + column1 +
        ", column2=" + column2 +
        ", column3=" + column3 +
        ", column4=" + column4 +
        ", column5=" + column5 +
        ", column6=" + column6 +
        ", column7=" + column7 +
        ", column8=" + column8 +
        ", column9=" + column9 +
        ", column10=" + column10 +
        ", extendsJson=" + extendsJson +
        ", oemId=" + oemId +
        ", groupId=" + groupId +
        ", creator=" + creator +
        ", createdName=" + createdName +
        ", createdDate=" + createdDate +
        ", modifier=" + modifier +
        ", modifyName=" + modifyName +
        ", lastUpdatedDate=" + lastUpdatedDate +
        ", isEnable=" + isEnable +
        ", updateControlId=" + updateControlId +
        "}";
    }
}
