package com.ly.mp.csc.clue.review;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ly.bucn.component.interceptor.InterceptorWrapperRegist;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegistor;
import com.ly.bucn.component.interceptor.annotation.Interceptor;
import com.ly.bucn.component.strategy.annotation.Strategy;
import com.ly.mp.busicen.rule.field.IFireFieldRule;

/**
 * 回访结束
 * @author ly-shenyw
 *
 */
@Strategy(isDefault=false,names="clueReviewEnd")
@Service
public class ClueReviewEnd extends AbstractClueReview implements InterceptorWrapperRegist{
	
	@Autowired
	IFireFieldRule fireFieldRule;
	
	/**
	 * 前置操作
	 */
	@Override
	public void before(Map<String, Object> reviewMap,String token){
		//校验下发字段
		fireFieldRule.fireRuleExcpt(reviewMap, "csc-clue-review-end-check", "maindata");
	}
	
	/**
	 * 其他操作
	 */
	@Override
	@Interceptor("csc_clue_review_end")
	public void handle(Map<String, Object> reviewMap,String token){
		//删除回访任务
		deleteReview(reviewMap.get("reviewId").toString());
	}
	
	@Override
    public void regist(InterceptorWrapperRegistor registor) {

    }
}
