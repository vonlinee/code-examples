package com.ly.mp.csc.clue.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegist;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegistor;
import com.ly.bucn.component.interceptor.annotation.Interceptor;
import com.ly.bucn.component.message.Message;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.constant.UserBusiEntity;
import com.ly.mp.busi.base.context.BusicenContext;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.busi.base.handler.BusicenUtils.SOU;
import com.ly.mp.busi.base.handler.MapUtil;
import com.ly.mp.busi.base.handler.OptResultBuilder;
import com.ly.mp.busi.base.handler.ResultHandler;
import com.ly.mp.busicen.common.helper.SpringContextHolder;
import com.ly.mp.busicen.rule.field.FireFieldRule;
import com.ly.mp.busicen.rule.field.IFireFieldRule;
import com.ly.mp.busicen.rule.field.execution.ValidResultCtn;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.entities.SacAppointmentSheet;
import com.ly.mp.csc.clue.entities.SacTestDriveSheet;
import com.ly.mp.csc.clue.idal.mapper.SacAppointmentSheetMapper;
import com.ly.mp.csc.clue.idal.mapper.SacDemoCarMapper;
import com.ly.mp.csc.clue.idal.mapper.SacTestDriveSheetHisMapper;
import com.ly.mp.csc.clue.idal.mapper.SacTestDriveSheetMapper;
import com.ly.mp.csc.clue.otherservice.ICscSysBaseDataService;
import com.ly.mp.csc.clue.service.ISacAppointmentSheetService;
import com.ly.mp.csc.clue.service.ISacEvaluationInfoService;
import com.ly.mp.csc.clue.service.ISacEvaluationItemService;
import com.ly.mp.csc.clue.service.ISacTestDriveSheetService;

/**
 * <p>
 * 试乘试驾单表 服务实现类
 * </p>
 *
 * @author ly-linliq
 * @since 2021-10-18
 */
@Service
public class SacTestDriveSheetService extends ServiceImpl<SacTestDriveSheetMapper, SacTestDriveSheet>
		implements ISacTestDriveSheetService, InterceptorWrapperRegist {

	@Autowired
	SacTestDriveSheetMapper sacTestDriveSheetMapper;
	@Autowired
	SacDemoCarMapper sacDemoCarMapper;
	@Autowired
	SacTestDriveSheetHisMapper sacTestDriveSheetHisMapper;
	@Autowired
	SacAppointmentSheetMapper sacAppointmentSheetMapper;
	@Autowired
	ISacEvaluationItemService sacEvaluationItemService;
	@Autowired
	ISacEvaluationInfoService sacEvaluationInfoService;
	@Autowired
	ISacAppointmentSheetService sacAppointmentSheetService;
	@Autowired
	Message message;
	@Autowired
	ICscSysBaseDataService baseDataService;
	@Autowired
	IFireFieldRule fireFieldRule;

	/**
	 * 试乘试驾单查询
	 */
	@Override
	public ListResult<Map<String, Object>> sacTestDriveSheetQueryList(ParamPage<Map<String, Object>> mapParam) {
		ListResult<Map<String, Object>> result = new ListResult<Map<String, Object>>();
		try {
			// 去掉空字符串
			MapUtil.removeNullValue(mapParam.getParam());
			// 字段检验
			ValidResultCtn fireRule = fireFieldRule.fireRule(mapParam, "csc-clue-test-driver-sheet-check1", "maindata");
			String resMsg = fireRule.getNotValidMessage();
			if (!fireRule.isValid()) {
				throw new BusicenException(resMsg);
			}
			//默认查询可用的
			if (StringHelper.IsEmptyOrNull(mapParam.getParam().get("isEnable"))) {
				mapParam.getParam().put("isEnable", "1");
			}
			String token = mapParam.getParam().get("token").toString();
			// 根据token获取当前用户信息
			UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
			//查看已完成的试驾单时，需要关联线索表,指定销售顾问：查找这个销售顾问负责的线索的所有已完成的试驾单，不指定销售顾问则查本店销售顾问所有负责的已完成的试驾单（不区分门店）
			if("1".equals(mapParam.getParam().get("isEnd"))) {
				//指定销售顾问
				if(!StringHelper.IsEmptyOrNull(mapParam.getParam().get("salesConsultantId"))) {
					mapParam.getParam().put("reviewPersonId", mapParam.getParam().get("salesConsultantId"));
				}else {
					//店长--查专营店
					mapParam.getParam().put("clueDlrCode", userBusiEntity.getDlrCode());
				}
				mapParam.getParam().remove("salesConsultantId");
			}else {
				//其他的正常查询
				mapParam.getParam().put("dlrCode", userBusiEntity.getDlrCode());
				mapParam.getParam().put("dlrName", userBusiEntity.getDlrName());
			}
			Page<Map<String, Object>> page = new Page<Map<String, Object>>(mapParam.getPageIndex(),
					mapParam.getPageSize());

			List<Map<String, Object>> list = sacTestDriveSheetMapper.selectSacTestDriveSheet(mapParam.getParam(), page);
			page.setRecords(list);
			result = BusicenUtils.page2ListResult(page);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("sacTestDriveSheetQueryList", e);
			throw e;
		}
		return result;
	}

	/**
	 * 试乘试驾单保存
	 */
	@Override
	@Transactional(rollbackFor = Exception.class)
	@Interceptor("csc_clue_test_driver_sheet")
	public OptResult sacTestDriveSheetSave(Map<String, Object> mapParam) {
		OptResult optResult = new OptResult();
		String token = String.valueOf(mapParam.get("token"));
		try {
			Boolean updateFlag = false;
			if (!StringHelper.IsEmptyOrNull(mapParam.get("updateFlag"))) {
				updateFlag = (Boolean) mapParam.get("updateFlag");
			}
			// 新增
			if (!updateFlag) {
				if (StringHelper.IsEmptyOrNull(mapParam.get("testDriveSheetId"))) {
					mapParam.put("testDriveSheetId", StringHelper.GetGUID());
				}
				if (StringHelper.IsEmptyOrNull(mapParam.get("customerSex"))) {
					mapParam.put("customerSex", "1");
				}
				if (StringHelper.IsEmptyOrNull(mapParam.get("isEnable"))) {
					mapParam.put("isEnable", "1");
				}
				if (StringHelper.IsEmptyOrNull(mapParam.get("appointmentChannel"))) {
					mapParam.put("appointmentChannel", "0");
				}
				if (StringHelper.IsEmptyOrNull(mapParam.get("isCanChange"))) {
					mapParam.put("isCanChange", "1");
				}
				// 开始里程为空时，将里程初始化为0
				if (StringHelper.IsEmptyOrNull(mapParam.get("testStartRoadHaul"))) {
					mapParam.put("testStartRoadHaul", "0");
				}
				// 试乘试驾里程初始化为0
				mapParam.put("testRoadHaul", "0");

				// 初始化试乘试驾状态为0：未开始
				if (StringHelper.IsEmptyOrNull(mapParam.get("testStatus"))) {
					mapParam.put("testStatus", "0");
				}
				BusicenUtils.invokeUserInfo(mapParam, SOU.Save, token);
				// 单号生成
				setOrderCode(mapParam);
				int result = sacTestDriveSheetMapper.insertSacTestDriveSheet(mapParam);
				if (result == 0) {
					optResult.setMsg(message.get("TEST-DRIVER-SHEET-01"));
					optResult.setResult("0");
					return optResult;
				}
			} else {
				BusicenUtils.invokeUserInfo(mapParam, SOU.Update, token);
				int result = sacTestDriveSheetMapper.updateSacTestDriveSheet(mapParam);
				if (result == 0) {
					optResult.setMsg(message.get("TEST-DRIVER-SHEET-02"));
					optResult.setResult("0");
					return optResult;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error("sacTestDriveSheetSave", e);
			throw e;
		}
		return OptResultBuilder.createOk().build();
	}

	private void setOrderCode(Map<String, Object> mapParam) {
		try {
			// 试乘试驾预约单单号生成
			String billTypeId = "bucn_sjsc_no";
			String dlrId = mapParam.get("dlrId").toString();
			String token = String.valueOf(mapParam.get("token"));
			ListResult<Map<String, Object>> generateOrderCode = baseDataService.generateOrderCode(dlrId, billTypeId,
					token);
			// 调用服务成功则直接获取单号，不成功则调用自定义单号生成方法
			if ("1".equals(generateOrderCode.getResult())) {
				mapParam.put("testDriveOrderNo", generateOrderCode.getMsg());
			} else {
				throw BusicenException.create("调用生成【试驾单单号】出错！[result=" + generateOrderCode.getResult() + ", msg="
						+ generateOrderCode.getMsg() + "]");
			}
		} catch (Exception e) {
			throw e;
		}
	}

	/**
	 * 试乘试驾协议保存
	 */
	@Override
	@Interceptor("csc_clue_test_driver_agreement")
	public OptResult sacTestDriveAgreementSave(Map<String, Object> mapParam) {
		OptResult optResult = new OptResult();
		String token = String.valueOf(mapParam.get("token"));
		// 只需要传协议url以及试乘试驾单id
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("testDriveAgreement", mapParam.get("testDriveAgreement"));
		param.put("testDriveSheetId", mapParam.get("testDriveSheetId"));
		try {
			BusicenUtils.invokeUserInfo(param, SOU.Update, token);
			int result = sacTestDriveSheetMapper.updateSacTestDriveSheet(param);
			if (result == 0) {
				optResult.setMsg(message.get("TEST-DRIVER-SHEET-01"));
				optResult.setResult("0");
				return optResult;
			}
		} catch (Exception e) {
			throw e;
		}
		return OptResultBuilder.createOk().build();
	}

	/**
	 * 前后置方法
	 * 
	 * @param registor
	 */
	@Override
	@SuppressWarnings("unchecked")
	public void regist(InterceptorWrapperRegistor registor) {
		// 校验字段
		registor.before("csc_clue_test_driver_sheet_valid", (context, model) -> {
			checkValidate((Map<String, Object>) context.data().getP()[0]);
		});
		// 校验是新增还是修改并查重
		registor.before("csc_clue_test_driver_sheet_repeat", (context, model) -> {
			checkRepeat((Map<String, Object>) context.data().getP()[0]);
		});
		//校验是否可以更换跟进门店，已开始的话不能更换门店/已经是从别的门店更换过来的试驾单不能做二次更换
		registor.before("csc_clue_test_driver_sheet_canChange", (context, model) -> {
			checkCanChange((Map<String, Object>) context.data().getP()[0]);
		});
		// 修改试驾单后修改预约单（模型不需要用到）
		registor.after("csc_clue_test_driver_sheet_change", (context, model) -> {
			saveAppointment((Map<String, Object>) context.data().getP()[0]);
		});
		// 更新试驾车的里程与试驾车状态
		registor.after("csc_clue_test_driver_sheet_addhaul", (context, model) -> {
			addHaul((Map<String, Object>) context.data().getP()[0]);
		});
		// 更新试乘试驾预约的是否试驾状态
		registor.after("csc_clue_test_driver_sheet_istest", (context, model) -> {
			updateIsTest((Map<String, Object>) context.data().getP()[0]);
		});
		//更改跟进门店后置
		registor.after("csc_clue_test_driver_sheet_isChange", (context, model) -> {
			changeDlr((Map<String, Object>) context.data().getP()[0]);
		});
		// 试乘试驾协议字段校验
		registor.before("csc_clue_test_driver_agreement_valid", (context, model) -> {
			checkAgreementValidate((Map<String, Object>) context.data().getP()[0]);
		});
		// 试乘试驾协议保存：判断id是否存在
		registor.before("csc_clue_test_driver_agreement_exits", (context, model) -> {
			checkAgreementExits((Map<String, Object>) context.data().getP()[0]);
		});
		// 新增时更新评价表，初始化各评价项为0分
		registor.after("csc_clue_test_driver_sheet_evaluation", (context, model) -> {
			updateEvaluationInfo((Map<String, Object>) context.data().getP()[0]);
		});
		// 试乘试驾开始/结束字段校验
		registor.before("csc_clue_test_driver_status_valid", (context, model) -> {
			checkDriveStatusValidate((Map<String, Object>) context.data().getP()[0]);
		});
		// 更新试驾车状态
		registor.after("csc_clue_test_driver_status_car", (context, model) -> {
			addHaul((Map<String, Object>) context.data().getP()[0]);
		});
		// 更新试乘试驾预约的是否试驾状态
		registor.after("csc_clue_test_driver_status_istest", (context, model) -> {
			updateIsTest((Map<String, Object>) context.data().getP()[0]);
		});
		// 试乘试驾结束时，若存在原试乘试驾单则修改原试乘试驾单与原预约单
		registor.after("csc_clue_test_driver_status_old", (context, model) -> {
			editHis((Map<String, Object>) context.data().getP()[0]);
		});
	}

	/**
	 * 试乘试驾单保存字段校验
	 * 
	 * @param mapParam
	 */
	public void checkValidate(Map<String, Object> mapParam) {
		ValidResultCtn fireRule = fireFieldRule.fireRule(mapParam, "csc-clue-test-driver-sheet-check", "maindata");
		String resMsg = fireRule.getNotValidMessage();
		if (!fireRule.isValid()) {
			throw new BusicenException(resMsg);
		}
		// 如果试乘试驾单开始时间大于等于结束时间则不合法
		try {
			if (!StringHelper.IsEmptyOrNull(mapParam.get("startTime"))
					&& !StringHelper.IsEmptyOrNull(mapParam.get("endTime"))) {
				SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date startTime = ft.parse(mapParam.get("startTime").toString());
				Date endTime = ft.parse(mapParam.get("endTime").toString());
				// 开始时间不能大于等于结束时间
				if (startTime.compareTo(endTime) >= 0) {
					throw new BusicenException(message.get("TEST-DRIVER-SHEET-07"));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusicenException(e.getMessage());
		}
	}
	
	/**
	 * 校验是否可以更换跟进门店，已开始的话不能更换门店/已经是从别的门店更换过来的试驾单不能做二次更换
	 * @param mapParam
	 */
	public void checkCanChange(Map<String, Object> mapParam) {
		Boolean updateFlag = false;
		updateFlag=(Boolean) mapParam.get("updateFlag");
		if(updateFlag) {
			//若想要更换门店
			if (!StringHelper.IsEmptyOrNull(mapParam.get("testDlrCode"))
					&& !mapParam.get("testDlrCode").equals(mapParam.get("dlrCode"))) {
				// 判断是否二次更换门店,根据id去查询试驾单，若isCanChange为0则代表已经更换门店了，不能再次更换
				QueryWrapper<SacTestDriveSheet> sacTestDriveSheetqQueryWrapper = new QueryWrapper<SacTestDriveSheet>();
				sacTestDriveSheetqQueryWrapper.eq("TEST_DRIVE_SHEET_ID", mapParam.get("testDriveSheetId"))
						.eq("IS_ENABLE", "1");
				SacTestDriveSheet sacTestDriveSheet = baseMapper.selectOne(sacTestDriveSheetqQueryWrapper);
				if (sacTestDriveSheet != null && "0".equals(sacTestDriveSheet.getIsCanChange())) {
					throw new BusicenException("不能进行二次更换门店");
				}
				// 更换之后原试驾单与新试驾单的isCanChange都为0
				mapParam.put("isCanChange", "0");
				// 备份一个原原试驾单id
				mapParam.put("newOldTestDriveSheetId", mapParam.get("oldTestDriveSheetId"));
				// 这个是避免原试驾单保存时将自身id存进oldTestDriveSheetId
				mapParam.remove("oldTestDriveSheetId");
				//代表当前是更换门店操作
				mapParam.put("isChangeDlr", "1");
		}
		}
	}
	
	/**
	 * 判断是否修改
	 * 
	 * @param mapParam
	 */
	public void checkRepeat(Map<String, Object> mapParam) {
		try {
			String token = String.valueOf(mapParam.get("token"));
			UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
			// 判断是新增还是修改
			Boolean updateFlag = false;
			if (!StringHelper.IsEmptyOrNull(mapParam.get("testDriveSheetId"))) {
				// 数据库查询是否存在此id
				Map<String, Object> map = new HashMap<String, Object>();
				map.put("testDriveSheetId", mapParam.get("testDriveSheetId"));
				Page<Map<String, Object>> page = new Page<Map<String, Object>>(1, -1);
				List<Map<String, Object>> list = baseMapper.selectSacTestDriveSheet(map, page);
				if (list.size() > 0) {
					updateFlag = true;
				}
			}
			
			mapParam.put("updateFlag", updateFlag);
			mapParam.put("dlrCode", userBusiEntity.getDlrCode());
			mapParam.put("dlrName", userBusiEntity.getDlrName());
			mapParam.put("dlrId", userBusiEntity.getDlrID());

		} catch (Exception e) {
			throw e;
		}
	}

	/**
	 * 试乘试驾协议字段校验
	 * 
	 * @param mapParam
	 */
	public void checkAgreementValidate(Map<String, Object> mapParam) {
		ValidResultCtn fireRule = fireFieldRule.fireRule(mapParam, "csc-clue-test-driver-agreement-check", "maindata");
		String resMsg = fireRule.getNotValidMessage();
		if (!fireRule.isValid()) {
			throw new BusicenException(resMsg);
		}
	}

	/**
	 * 试乘试驾协议保存：判断id是否存在
	 * 
	 * @param mapParam
	 */
	public void checkAgreementExits(Map<String, Object> mapParam) {
		String testDriveSheetId = mapParam.get("testDriveSheetId").toString();
		QueryWrapper<SacTestDriveSheet> queryWrapper = new QueryWrapper<SacTestDriveSheet>();
		queryWrapper.eq("TEST_DRIVE_SHEET_ID", testDriveSheetId);
		int count = baseMapper.selectCount(queryWrapper);
		if (count < 1) {
			throw new BusicenException(message.get("TEST-DRIVER-SHEET-03"));
		}
	}

	/**
	 * 更新试驾车的里程与试驾车状态
	 * 
	 * @param mapParam
	 */
	public void addHaul(Map<String, Object> mapParam) {
		try {
			if ("1".equals(mapParam.get("testStatus"))||"2".equals(mapParam.get("testStatus"))) {
				Map<String,Object> carParam=new HashMap<String, Object>();
				// 结束试乘试驾则更新试驾车表（里程，试驾车状态）
				if ("2".equals(mapParam.get("testStatus"))) {
					//结束时更新最新里程
					carParam.put("testcarKilometers", mapParam.get("testEndRoadHaul"));
					carParam.put("testcarFrequency", 1);
					carParam.put("carStatusCode", "0");
					carParam.put("carStatusName", "空闲中");
				} else{
					carParam.put("carStatusCode", "1");
					carParam.put("carStatusName", "试驾中");
				}
				//车架号
				carParam.put("vin", mapParam.get("carVin"));
				ParamPage<Map<String,Object>> carParamPage=new ParamPage<Map<String,Object>>();
				carParamPage.setParam(carParam);
				EntityResult<Map<String, Object>> result=baseDataService.inset(String.valueOf(mapParam.get("token")), carParamPage);
				if(!"1".equals(result.getResult())) {
					throw new BusicenException(message.get("TEST-DRIVER-SHEET-04"));
				}
			}
		} catch (Exception e) {
			throw e;
		}
	}

	// 修改试驾单后修改预约
	public void saveAppointment(Map<String, Object> mapParam) {
		Boolean updateFlag = (Boolean) mapParam.get("updateFlag");
		if (!StringHelper.IsEmptyOrNull(mapParam.get("appointmentId")) && updateFlag) {
			// 更改预约单
			Map<String, Object> newParam = new HashMap<String, Object>();
			newParam.put("token", mapParam.get("token"));
			//更换门店时不改原门店的任何预约时间
			if ("1".equals(mapParam.get("isChangeDlr"))) {
				//更换跟进门店时则不能修改原试驾预约单的预约时间，将当前传来的时间包装成新的门店预约时间
				if(!StringHelper.IsEmptyOrNull(mapParam.get("appointmentTestDate"))
					&& !StringHelper.IsEmptyOrNull(mapParam.get("appointmentTestTime"))) {
					String[] timeStrings = String.valueOf(mapParam.get("appointmentTestTime")).split("-");
					String newAppointmentStartTime = String.valueOf(mapParam.get("appointmentTestDate")) + " " + timeStrings[0] + ":00";
					String newAppointmentEndTime = String.valueOf(mapParam.get("appointmentTestDate")) + " " + timeStrings[1] + ":00";
					newParam.put("newDlrAppointmentStartTime", newAppointmentStartTime);
					newParam.put("newDlrAppointmentEndTime", newAppointmentEndTime);
				}
				// 根据appointmentid查询原预约单的预约时间
				SacAppointmentSheet appointmentSheet = sacAppointmentSheetMapper.selectById(String.valueOf(mapParam.get("appointmentId")));
				if (appointmentSheet == null) {
					throw new BusicenException("未找到该预约单，请检查预约单id是否正确");
				}
				newParam.put("appointmentTestDate", appointmentSheet.getAppointmentTestDate());
				newParam.put("appointmentTestTime", appointmentSheet.getAppointmentTestTime());
				newParam.put("appointmentStartTime", appointmentSheet.getAppointmentStartTime());
				newParam.put("appointmentEndTime", appointmentSheet.getAppointmentEndTime());
			} else {
				// 不更换门店时直接获取参数
				newParam.put("appointmentTestDate", mapParam.get("appointmentTestDate"));
				newParam.put("appointmentTestTime", mapParam.get("appointmentTestTime"));
				newParam.put("appointmentStartTime", mapParam.get("appointmentStartTime"));
				newParam.put("appointmentEndTime", mapParam.get("appointmentEndTime"));
			}
			newParam.put("testType", mapParam.get("testType"));
			newParam.put("plateNumber", mapParam.get("plateNumber"));
			newParam.put("carVin", mapParam.get("carVin"));
			newParam.put("smallCarTypeCode", mapParam.get("smallCarTypeCode"));
			newParam.put("smallCarTypeName", mapParam.get("smallCarTypeName"));
			newParam.put("appointmentId", mapParam.get("appointmentId"));
			newParam.put("isTestDrive", "0");
			newParam.put("customerId", mapParam.get("customerId"));
			newParam.put("customerName", mapParam.get("customerName"));
			newParam.put("customerPhone", mapParam.get("customerPhone"));
			newParam.put("dlrClueOrderNo", mapParam.get("dlrClueOrderNo"));
			newParam.put("appointmentChannel", mapParam.get("appointmentChannel"));
			if(StringHelper.IsEmptyOrNull(mapParam.get("isFollow"))) {
				newParam.put("isFollow", "0");
			}
			SpringContextHolder.getBean(SacAppointmentSheetService.class).appointmentSheetSave(newParam);
		}

	}

	/**
	 * 更新试乘试驾预约的是否试驾状态为1，表示已开始试驾
	 * 
	 * @param mapParam
	 */
	public void updateIsTest(Map<String, Object> mapParam) {
		try {
			// 开始或结束试乘试驾单时，修改预约单的状态
			if ("1".equals(mapParam.get("testStatus")) || "2".equals(mapParam.get("testStatus"))) {
				//判断是否有预约单
				SacTestDriveSheet sacTestDriveSheet = sacTestDriveSheetMapper
						.selectById(String.valueOf(mapParam.get("testDriveSheetId")));
				if (!StringHelper.IsEmptyOrNull(sacTestDriveSheet.getAppointmentId())) {
					// 先验证一下预约单id是否存在
					QueryWrapper<SacAppointmentSheet> queryWrapper = new QueryWrapper<SacAppointmentSheet>();
					queryWrapper.eq("APPOINTMENT_ID", sacTestDriveSheet.getAppointmentId());
					int count = sacAppointmentSheetMapper.selectCount(queryWrapper);
					if (count == 0) {
						throw new BusicenException(message.get("APPOINTMENT-SHEET-08"));
					}
					// id存在则修改预约单
					Map<String, Object> param = new HashMap<String, Object>();
					param.put("appointmentId", sacTestDriveSheet.getAppointmentId());
					param.put("isTestDrive", "1");
					BusicenUtils.invokeUserInfo(param, SOU.Update, mapParam.get("token").toString());
					int result = sacAppointmentSheetMapper.updateSacAppointmentSheet(param);
					if (result == 0) {
						throw new BusicenException(message.get("TEST-DRIVER-SHEET-06"));
					}
				}
			}
		} catch (Exception e) {
			throw e;
		}
	}
	
	/**
	 * 更换门店操作
	 */
	public void changeDlr(Map<String, Object> mapParam) {
		
		if("1".equals(mapParam.get("isChangeDlr"))) {
			mapParam.put("oldTestDriveSheetId", mapParam.get("newOldTestDriveSheetId"));
		}
		
	}

	/**
	 * 新增时把评价信息插入评价表,初始化为0
	 * 
	 * @param mapParam
	 */
	public void updateEvaluationInfo(Map<String, Object> mapParam) {
		Boolean updateFlag = false;
		updateFlag = (Boolean) mapParam.get("updateFlag");
		// 新增时需要初始化评价
		if (!updateFlag) {
			// 查询评价项表有哪些评价项
			String token = mapParam.get("token").toString();
			ParamPage<Map<String, Object>> mapParamPage = new ParamPage<Map<String, Object>>();
			mapParamPage.setPageIndex(1);
			mapParamPage.setPageSize(-1);
			mapParamPage.setParam(new HashMap<String, Object>());

			List<Map<String, Object>> evaluationItemList = sacEvaluationItemService
					.evaluationItemQueryList(mapParamPage, token).getRows();
			if (evaluationItemList.size() > 0) {
				// 新建评价项数组
				List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
				// 初始化该试乘试驾单各个评价项分数为0
				for (Map<String, Object> item : evaluationItemList) {
					Map<String, Object> mapItem = new HashMap<String, Object>();
					mapItem.put("evaluationType", item.get("evaluationType"));
					mapItem.put("evaluationItem", item.get("evaluationItem"));
					mapItem.put("evaluationScore", 0);
					list.add(mapItem);
				}
				Map<String, Object> evaluationMap = new HashMap<String, Object>();
				evaluationMap.put("token", mapParam.get("token"));
				evaluationMap.put("testDriveSheetId", mapParam.get("testDriveSheetId"));
				evaluationMap.put("evaluationList", list);
				if (!StringHelper.IsEmptyOrNull(mapParam.get("dlrCode"))) {
					evaluationMap.put("dlrCode", mapParam.get("dlrCode"));
					evaluationMap.put("dlrName", mapParam.get("dlrName"));
				}
				// 将评价保存到评价表中
				sacEvaluationInfoService.sacEvaluationInfoSave(evaluationMap);
			}
		}

	}

	/**
	 * 字段校验
	 * 
	 * @param mapParam
	 */
	public void checkDriveStatusValidate(Map<String, Object> mapParam) {
		ValidResultCtn fireRule = fireFieldRule.fireRule(mapParam, "csc-clue-test-driver-status-check", "maindata");
		String resMsg = fireRule.getNotValidMessage();
		if (!fireRule.isValid()) {
			throw new BusicenException(resMsg);
		}
	}

	/**
	 * 试乘试驾开始/结束
	 */
	@Override
	@Interceptor("csc_clue_test_driver_status")
	public OptResult sacTestDriveSheetStatus(Map<String, Object> mapParam) {
		try {
			
			// 如果试乘试驾单结束，则更新行驶里程
			if ("2".equals(mapParam.get("testStatus"))) {
				if (StringHelper.IsEmptyOrNull(mapParam.get("testEndRoadHaul"))) {
					throw new BusicenException(message.get("TEST-DRIVER-SHEET-08"));
				}
				// 记录开始里程
				double testStartRoadHaul = Double.valueOf(String.valueOf(mapParam.get("testStartRoadHaul")));
				double testEndRoadHaul = Double.valueOf(String.valueOf(mapParam.get("testEndRoadHaul")));
				if (testStartRoadHaul >= testEndRoadHaul) {
					throw new BusicenException(message.get("TEST-DRIVER-SHEET-09"));
				}
				double testRoadHaul = testEndRoadHaul - testStartRoadHaul;
				mapParam.put("testRoadHaul",testRoadHaul);
			}
			BusicenUtils.invokeUserInfo(mapParam, SOU.Update, mapParam.get("token").toString());
			sacTestDriveSheetMapper.updateSacTestDriveSheet(mapParam);
			return OptResultBuilder.createOk().build();

		} catch (Exception e) {
			e.printStackTrace();
			log.error("sacTestDriveSheetStatus", e);
			throw e;
		}
	}

	/**
	 * 若试驾单结束且存在原试驾单则修改原试驾单状态、原预约单状态
	 */
	public void editHis(Map<String, Object> mapParam) {
		try {
			// 先查询试乘试驾单是否存在
			SacTestDriveSheet sacTestDriveSheet = sacTestDriveSheetMapper
					.selectById(String.valueOf(mapParam.get("testDriveSheetId")));
			if (sacTestDriveSheet != null && "2".equals(mapParam.get("testStatus"))
					&& sacTestDriveSheet.getOldTestDriveSheetId() != null) {
				// 当试乘试驾单结束后更改原试驾单状态、原预约单状态
				String[] oldIdList = sacTestDriveSheet.getOldTestDriveSheetId().split(",");
				for (String oldId : oldIdList) {
					// 根据id查询试乘试驾单
					SacTestDriveSheet testDriveSheet = sacTestDriveSheetMapper.selectById(oldId);
					if (testDriveSheet != null) {
						// 若存在原试驾单，修改原试乘试驾单状态
						testDriveSheet.setTestStatus(String.valueOf(mapParam.get("testStatus")));
						sacTestDriveSheetMapper.updateById(testDriveSheet);
						// 修改预约单状态
						if (!StringHelper.IsEmptyOrNull(testDriveSheet.getAppointmentId())) {
							SacAppointmentSheet sacAppointmentSheet = new SacAppointmentSheet();
							sacAppointmentSheet.setAppointmentId(testDriveSheet.getAppointmentId());
							sacAppointmentSheet.setIsTestDrive("1");
							sacAppointmentSheetMapper.updateById(sacAppointmentSheet);
						}
					}
				}
			}
		} catch (Exception e) {
			throw e;
		}

	}

	/**
	 * 试乘试驾详情查询
	 */
	@Override
	public EntityResult<Map<String, Object>> sacTestDriveSheetQueryDetail(Map<String, Object> mapParam) {
		// 判断id是否为空
		if (StringHelper.IsEmptyOrNull(mapParam.get("testDriveSheetId"))) {
			throw new BusicenException(message.get("TEST-DRIVER-SHEET-10"));
		}
		// 查找详情
		List<Map<String, Object>> list = sacTestDriveSheetMapper.selectSacTestDriveSheetDetail(mapParam);
		// 校验试乘试驾单id是否存在
		if (list.size() == 0 || list.get(0).isEmpty()) {
			throw new BusicenException(message.get("TEST-DRIVER-SHEET-11"));
		}
		return ResultHandler.updateOk(list.get(0));

	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public OptResult sacTestDriveSheetAllSave(Map<String, Object> mapParam) {
		try {
			SpringContextHolder.getBean(SacAppointmentSheetService.class).appointmentSheetSave(mapParam);
			mapParam.put("custId", mapParam.get("customerId"));
			SpringContextHolder.getBean(SacTestDriveSheetService.class).sacTestDriveSheetSave(mapParam);
		}catch (Exception e) {
			throw e;
		}
		return OptResultBuilder.createOk().build();
	}

}
