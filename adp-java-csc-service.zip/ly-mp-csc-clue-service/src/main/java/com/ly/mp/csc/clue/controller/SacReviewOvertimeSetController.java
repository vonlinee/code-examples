package com.ly.mp.csc.clue.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.context.BusicenInvoker;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.service.ISacReviewOvertimeSetService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * com.ly.mp.csc.clue.controller.SacReviewPlanController
 * 回访超时规则服务控制类
 * @author zhouhao
 * @date 2021/8/18 16:18
 */
@Api(value = "任务超时规则设置服务", tags = { "任务超时规则设置服务" })
@RestController
@RequestMapping(value = "/ly/sac/reviewovertimeset", produces = { MediaType.APPLICATION_JSON_VALUE })
public class SacReviewOvertimeSetController {
	//注入服务
	@Autowired
	ISacReviewOvertimeSetService sacReviewOvertimeSetService;
	
	@ApiOperation(value="任务超时规则设置查询", notes="任务超时规则设置查询")
	@RequestMapping(value = "/querylist.do", method = RequestMethod.POST)
	public ListResult<Map<String,Object>> queryListReviewOvertimeSetInfo(
			@RequestHeader(name = "authorization",required = false) String token,
			@RequestBody(required = false) ParamPage<Map<String,Object>> dataInfo){
		return BusicenInvoker.doList(()->sacReviewOvertimeSetService.queryListReviewOvertimeSetInfo(dataInfo,token)).result();
	}
	
		
	@ApiOperation(value="任务超时规则设置保存", notes="任务超时规则设置保存")
	@RequestMapping(value = "/save.do", method = RequestMethod.POST)
	public OptResult saveReviewOvertimeSetInfo(
			@RequestHeader(name = "authorization",required = false) String token,
			@RequestBody(required = true) ParamBase<Map<String, Object>> dataInfo){
		return BusicenInvoker.doOpt(()->sacReviewOvertimeSetService.saveReviewOvertimeSetInfo(dataInfo.getParam(), token)).result();
	}

	@ApiOperation(value="任务超时规则设置删除", notes="任务超时规则设置删除")
	@RequestMapping(value = "/delete.do", method = RequestMethod.POST)
	public OptResult deleteReviewOvertimeSetInfo(
			@RequestHeader(name = "authorization",required = false) String token,
			@RequestBody(required = true) ParamBase<Map<String, Object>> dataInfo){
		return BusicenInvoker.doOpt(()->sacReviewOvertimeSetService.deleteReviewOvertimeSetInfo(dataInfo.getParam(), token)).result();
	}
}

