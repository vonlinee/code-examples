package com.ly.mp.csc.clue.service;
import java.util.Map;
import com.baomidou.mybatisplus.extension.service.IService;
import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.entities.SacClueAllocatingRecord;

/**
 * <p>
 * 线索分配记录表 服务类
 * </p>
 *
 * @author CaiYunXiang
 * @since 2022-05-24
 */
public interface ISacClueAllocatingRecordService extends IService<SacClueAllocatingRecord> {
	/**
	 * 分页查询
	 * @param pageInfo
	 * @param info
	 * @return
	 */
	ListResult<Map<String, Object>> sacClueAllocatingRecordFindInfo(ParamPage<Map<String, Object>> dataInfo, String token);
	
	/**
	 * 根据主键判断插入或更新
	 * @param info
	 * @return
	 */
	OptResult sacClueAllocatingRecordSaveInfo(ParamBase<Map<String, Object>> dataInfo, String token);
}
