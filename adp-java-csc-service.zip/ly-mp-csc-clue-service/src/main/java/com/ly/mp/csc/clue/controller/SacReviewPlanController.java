package com.ly.mp.csc.clue.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.context.BusicenInvoker;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.service.ISacReviewPlanService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * com.ly.mp.csc.clue.controller.SacReviewPlanController
 * 回访计划设置控制类
 * @author zhouhao
 * @date 2021/8/16 15:18
 */
@Api(value = "回访计划服务", tags = { "回访计划服务" })
@RestController
@RequestMapping(value = "/ly/sac/reviewplan", produces = { MediaType.APPLICATION_JSON_VALUE })
public class SacReviewPlanController {
	//注入服务
	@Autowired
	ISacReviewPlanService sacReviewPlanService;
	
	@ApiOperation(value="回访计划设置查询", notes="回访计划设置查询")
	@RequestMapping(value = "/querylist.do", method = RequestMethod.POST)
	public ListResult<Map<String,Object>> queryListReviewPlanInfo(
			@RequestHeader(name = "authorization",required = false) String token,
			@RequestBody(required = false)ParamPage<Map<String,Object>> dataInfo){
		dataInfo.getParam().put("token", token);
		return BusicenInvoker.doList(()->sacReviewPlanService.queryListReviewPlanInfo(dataInfo,token)).result();
	}
	
		
	@ApiOperation(value="回访计划设置保存", notes="回访计划设置保存")
	@RequestMapping(value = "/save.do", method = RequestMethod.POST)
	public OptResult saveReviewPlanInfo(
			@RequestHeader(name = "authorization",required = false) String token,
			@RequestBody(required = true)ParamBase<Map<String,Object>> dataInfo){
		return BusicenInvoker.doOpt(()->sacReviewPlanService.saveReviewPlanInfo(dataInfo.getParam(), token)).result();
	}

	@ApiOperation(value="回访计划设置删除", notes="回访计划设置删除")
	@RequestMapping(value = "/delete.do", method = RequestMethod.POST)
	public OptResult deleteReviewPlanInfo(
			@RequestHeader(name = "authorization",required = false) String token,
			@RequestBody(required = true) ParamBase<Map<String, Object>> dataInfo){
		return BusicenInvoker.doOpt(()->sacReviewPlanService.deleteReviewPlanInfo(dataInfo.getParam(), token)).result();
	}
}
