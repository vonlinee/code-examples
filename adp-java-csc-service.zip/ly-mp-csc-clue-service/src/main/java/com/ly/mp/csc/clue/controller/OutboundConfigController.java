package com.ly.mp.csc.clue.controller;


import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.context.BusicenInvoker;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.service.IOutboundConfigService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 
 * @Description: 商机外呼配置服务
 * @author ly-linliq
 * @date 2021/09/06 19:52:33
 */
@Api(value = "商机外呼配置服务", tags = { "商机外呼配置服务" })
@RestController
@RequestMapping(value = "/ly/sac/outboundconfig", produces = { MediaType.APPLICATION_JSON_VALUE })
public class OutboundConfigController {
	//注入服务
	@Autowired
	IOutboundConfigService outboundConfigService;
	
	@ApiOperation(value="商机外呼配置查询", notes="商机外呼配置查询")
	@RequestMapping(value = "/outboundconfigquery.do", method = RequestMethod.POST)
	public ListResult<Map<String,Object>> queryListOutboundConfig(
			@RequestHeader(name = "authorization",required = false) String authentication,
			@RequestBody(required = false) ParamPage<Map<String, Object>> dataInfo){
		dataInfo.getParam().put("token", authentication);
		return BusicenInvoker.doList(()->outboundConfigService.queryListOutboundConfig(dataInfo)).result();
	}
	
	@ApiOperation(value="商机外呼配置保存", notes="商机外呼配置保存")
	@RequestMapping(value = "/outboundconfigsave.do", method = RequestMethod.POST)
	public  OptResult repeatRuleConfigSave(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false)ParamBase<Map<String,Object>> dataInfo) throws Exception{
		dataInfo.getParam().put("token", authentication);
		return BusicenInvoker.doOpt(()->outboundConfigService.outboundConfigSave(dataInfo.getParam())).result();
	}
}
