package com.ly.mp.csc.clue.service.impl;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.bucn.component.interceptor.annotation.Interceptor;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.busi.base.handler.BusicenUtils.SOU;
import com.ly.mp.busi.base.handler.ResultHandler;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.entities.SacAttachment;
import com.ly.mp.csc.clue.idal.mapper.SacAttachmentMapper;
import com.ly.mp.csc.clue.service.ISacAttachmentService;


@Service
public class SacAttachmentService extends ServiceImpl<SacAttachmentMapper, SacAttachment> implements ISacAttachmentService {
	private static Logger log = LoggerFactory.getLogger(SacAttachmentService.class);

	@Autowired SacAttachmentMapper sacAttachmentMapper;


	@Override
	@Interceptor("sac_attachment_add")
	public EntityResult<Map<String, Object>> sacAttachmentAdd(Map<String, Object> mapParam, String token) {
		mapParam.remove("attachmentId");
		return sacAttachmentSave(mapParam, token);
	}

	@Override
	public EntityResult<Map<String, Object>> sacAttachmentSave(Map<String, Object> mapParam, String token) {
		try {
			Boolean updateFlag = false;
			if (!StringHelper.IsEmptyOrNull(mapParam.get("attachmentId"))) {
				QueryWrapper<SacAttachment> wrapper = new QueryWrapper<>();
				wrapper.lambda().eq(SacAttachment::getAttachmentId, mapParam.get("attachmentId"));
				if (list(wrapper).size() > 0) {
					updateFlag = true;
				}
			}
			if (!updateFlag) {
				// 新增
				if (StringHelper.IsEmptyOrNull(mapParam.get("attachmentId"))) {
					// 主键
					mapParam.put("attachmentId", UUID.randomUUID().toString());
				}
				mapParam.put("isEnable", 1);
				BusicenUtils.invokeUserInfo(mapParam, SOU.Save, token);
				sacAttachmentMapper.insertSacAttachment(mapParam);
			} else {
				// 更新
				BusicenUtils.invokeUserInfo(mapParam, SOU.Update, token);
				sacAttachmentMapper.updateSacAttachment(mapParam);
			}
			QueryWrapper<SacAttachment> wrapper = new QueryWrapper<>();
			wrapper.lambda().eq(SacAttachment::getAttachmentId, mapParam.get("attachmentId"));
			return ResultHandler.updateOk(listMaps(wrapper).get(0));
		} catch (Exception e) {
			log.error("sacReviewSave", e);
			throw e;
		}
	}

	@Override
	public ListResult<Map<String, Object>> sacAttachmentQueryList(ParamPage<Map<String, Object>> map,String token){
		ListResult<Map<String,Object>> result = new ListResult<Map<String,Object>>();
		try {
			int pageIndex=map.getPageIndex();
			int pageSize=map.getPageSize();
			Page<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);
			List<Map<String, Object>> list = baseMapper.selectByPage(page, map.getParam());
			page.setRecords(list);
			result = BusicenUtils.page2ListResult(page);
		}catch (Exception e){
			e.printStackTrace();
			log.error("queryListReviewPlanInfo:",e);
			throw e;
		}
		return result;
	}

	@Override
	public EntityResult<Map<String, Object>> sacAttachmentDelete(Map<String, Object> mapParam, String token) {
		try {
			if (!StringHelper.IsEmptyOrNull(mapParam.get("attachmentId"))) {
				QueryWrapper<SacAttachment> wrapper = new QueryWrapper<>();
				wrapper.lambda().eq(SacAttachment::getAttachmentId, mapParam.get("attachmentId"));
				SacAttachment one = this.getOne(wrapper);
				one.setIsEnable("0");
				this.updateById(one);
			}
			QueryWrapper<SacAttachment> wrapper = new QueryWrapper<>();
			wrapper.lambda().eq(SacAttachment::getAttachmentId, mapParam.get("attachmentId"));
			return ResultHandler.updateOk(listMaps(wrapper).get(0));
		} catch (Exception e) {
			log.error("sacAttachmentDelete", e);
			throw e;
		}
	}
}
