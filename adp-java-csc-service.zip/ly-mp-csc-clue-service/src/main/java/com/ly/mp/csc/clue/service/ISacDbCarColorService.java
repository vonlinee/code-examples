package com.ly.mp.csc.clue.service;

import java.util.Map;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.csc.clue.entities.DbCarColor;

/**
 * <p>
 * 车身颜色 服务类
 * </p>
 *
 * @author ly-林丽情
 * @since 2021-09-07
 */
public interface ISacDbCarColorService extends IService<DbCarColor> {

	public ListResult<Map<String,Object>> carColorQuery(ParamPage<Map<String, Object>> mapParam);
}
