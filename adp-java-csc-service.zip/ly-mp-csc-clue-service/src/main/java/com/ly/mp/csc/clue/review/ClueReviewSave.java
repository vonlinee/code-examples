package com.ly.mp.csc.clue.review;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ly.bucn.component.interceptor.InterceptorWrapperRegist;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegistor;
import com.ly.bucn.component.interceptor.annotation.Interceptor;
import com.ly.bucn.component.strategy.annotation.Strategy;
import com.ly.mp.busicen.rule.field.IFireFieldRule;

/**
 * 继续跟进
 * @author ly-shenyw
 *
 */
@Strategy(isDefault=false,names="clueReviewSave")
@Service
public class ClueReviewSave extends AbstractClueReview implements InterceptorWrapperRegist{

	@Autowired
	IFireFieldRule fireFieldRule;
	
	/**
	 * 前置操作
	 */
	@Override
	public void before(Map<String, Object> reviewMap,String token){
		//校验参数
		fireFieldRule.fireRuleExcpt(reviewMap, "csc-clue-review-save-check", "maindata");
	}
	
	/**
	 * 其他操作
	 */
	@Override
	@Interceptor("csc_clue_review_save")
	public void handle(Map<String, Object> reviewMap,String token){
		
	}
	
	@Override
    public void regist(InterceptorWrapperRegistor registor) {

    }
}
