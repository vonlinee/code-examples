package com.ly.mp.csc.clue.review;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ly.bucn.component.interceptor.InterceptorWrapperRegist;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegistor;
import com.ly.bucn.component.interceptor.annotation.Interceptor;
import com.ly.bucn.component.strategy.annotation.Strategy;
import com.ly.mp.busicen.rule.field.IFireFieldRule;

/**
 * 失控
 * @author ly-shenyw
 *
 */
@Strategy(isDefault=false,names="clueReviewNotctrled")
@Service
public class ClueReviewNotctrled extends AbstractClueReview implements InterceptorWrapperRegist{
	
	@Autowired
	IFireFieldRule fireFieldRule;
	
	/**
	 * 前置操作
	 */
	@Override
	public void before(Map<String, Object> reviewMap,String token){
		//校验下发字段
		fireFieldRule.fireRuleExcpt(reviewMap, "csc-clue-review-notctrled-check", "maindata");
		//校验是否存在未审核的记录
		checkAudit(reviewMap.get("reviewId").toString());
	}
	
	/**
	 * 其他操作
	 */
	@Override
	@Interceptor("csc_clue_review_notctrled")
	public void handle(Map<String, Object> reviewMap,String token){
		//删除回访任务
		deleteReview(reviewMap.get("reviewId").toString());
	}
	
	@Override
    public void regist(InterceptorWrapperRegistor registor) {

    }
}