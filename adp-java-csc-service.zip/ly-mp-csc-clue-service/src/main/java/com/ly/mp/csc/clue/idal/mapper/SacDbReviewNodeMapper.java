package com.ly.mp.csc.clue.idal.mapper;

import com.ly.mp.csc.clue.entities.SacDbReviewNode;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import java.util.Map;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 回访节点表 Mapper 接口
 * </p>
 *
 * @author ly-busicen
 * @since 2021-09-10
 */
public interface SacDbReviewNodeMapper extends BaseMapper<SacDbReviewNode> {

	/**
	 * 插入
	 * @param mapParm
	 * @return
	 */
	public int insertSacDbReviewNode(@Param("param")Map<String, Object> mapParm);
	
	/**
	 * 更新
	 * @param mapParm
	 * @return
	 */
	public int updateSacDbReviewNode(@Param("param")Map<String, Object> mapParm);
}
