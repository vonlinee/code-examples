package com.ly.mp.csc.clue.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.context.BusicenInvoker;
import com.ly.mp.component.entities.ListResult;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Api(value = "test2", tags = { "test2" })
@RestController
@RequestMapping(value = "/ly/test/test", produces = { MediaType.APPLICATION_JSON_VALUE })
public class TestController {
	@ApiOperation(value="排序", notes="排序")
	@RequestMapping(value = "/querylist2", method = RequestMethod.POST)
	public Map<String, Object> queryListWorkGroupInfo(
			@RequestHeader(name = "authorization",required = false) String token,
			@RequestBody(required = false)Map<String, Object> dataInfo){
		
		
		
		int[] intpao = new int[] { 4, 2, 1, 3, 5, 6, 9, 7, 8 };
		int temp = 0;
		int temp2 = 0;
		for(int i=0;i<intpao.length-1;i++){
			for(int j=i+1;j<intpao.length;j++){
				temp=intpao[i];
				temp2=intpao[j];
				if(temp2 < temp){
					intpao[i]=temp2;
					intpao[j]=temp;
				}
			}
		}

	    
		/*
		int temp = 0;
		int temp2 = 0;
		for (int i = 0; i < intpao.length - 1; i++)
		{
			for (int j = i + 1; j < intpao.length; j++)
			{
				temp = intpao[i];//2
				temp2 = intpao[j];//1

				if (intpao[j] < intpao[i]) //1<2
				{

					intpao[i] = intpao[j]; 
					intpao[j] = temp;
				}
			}
		}
		*/
		String a="123";
		String b ="3211";
		
		System.out.println("test:"+a.hashCode()+"," + b.hashCode());
		System.out.println("test2:"+intpao.hashCode());
		Map<String, Object> returnMap = new HashMap<>();
		returnMap.put("arr", intpao.toString());
		returnMap.put(null, "123");
		returnMap.put("aaa", "null");
		return returnMap;

	}
}
