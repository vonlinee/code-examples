package com.ly.mp.csc.clue.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.context.BusicenInvoker;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.service.ISacSystemConfigValueService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * com.ly.mp.csc.clue.controller.SacReviewPlanController
 * 系统配置值控制类
 * @author zhouhao
 * @date 2021/8/18 16:18
 */
@Api(value = "系统配置值服务", tags = { "系统配置值服务" })
@RestController
@RequestMapping(value = "/ly/sac/systemconfigvalue", produces = { MediaType.APPLICATION_JSON_VALUE })
public class SacSystemConfigValueController {
	//注入服务
	@Autowired
	ISacSystemConfigValueService sacSystemConfigValueService;
	
	@ApiOperation(value="系统配置值查询", notes="系统配置值查询")
	@RequestMapping(value = "/querylist.do", method = RequestMethod.POST)
	public ListResult<Map<String,Object>> queryListSysteConfigValueInfo(
			@RequestHeader(name = "authorization",required = false) String token,
			@RequestBody(required = false) ParamPage<Map<String,Object>> dataInfo){
		return BusicenInvoker.doList(()->sacSystemConfigValueService.queryListSysteConfigValueInfo(dataInfo,token)).result();
	}
	
	@ApiOperation(value="系统配置值查询-根据编码", notes="系统配置值查询-根据编码")
	@RequestMapping(value = "/querybycode.do", method = RequestMethod.POST)
	public ListResult<Map<String,Object>> queryListSysteConfigValueByCode(
			@RequestHeader(name = "authorization",required = false) String token,
			@RequestBody(required = false) ParamPage<Map<String,Object>> dataInfo){
		return BusicenInvoker.doList(()->sacSystemConfigValueService.selectByConfigCode(dataInfo,token)).result();
	}
	
	@ApiOperation(value="系统配置值保存", notes="系统配置值保存")
	@RequestMapping(value = "/save.do", method = RequestMethod.POST)
	public OptResult saveSysteConfigValueInfo(
			@RequestHeader(name = "authorization",required = false) String token,
			@RequestBody(required = true) ParamBase<Map<String, Object>> dataInfo){
		return BusicenInvoker.doOpt(()->sacSystemConfigValueService.saveSysteConfigValueInfo(dataInfo.getParam(), token)).result();
	}
	
	@ApiOperation(value="网点系统配置值查询", notes="网点系统配置值查询")
	@RequestMapping(value = "/networksquerylist.do", method = RequestMethod.POST)
	public ListResult<Map<String,Object>> queryListNetworksSysteConfigValueInfo(
			@RequestHeader(name = "authorization",required = false) String token,
			@RequestBody(required = false) ParamPage<Map<String,Object>> dataInfo){
		return BusicenInvoker.doList(()->sacSystemConfigValueService.queryListSysteConfigValueInfo(dataInfo,token)).result();
	}
	
		
	@ApiOperation(value="网点系统配置值保存", notes="网点系统配置值保存")
	@RequestMapping(value = "/networkssave.do", method = RequestMethod.POST)
	public OptResult saveNetworksSysteConfigValueInfo(
			@RequestHeader(name = "authorization",required = false) String token,
			@RequestBody(required = true) ParamBase<Map<String, Object>> dataInfo){
		return BusicenInvoker.doOpt(()->sacSystemConfigValueService.saveSysteConfigValueInfo(dataInfo.getParam(), token)).result();
	}
	
	@ApiOperation(value="根据编码获取配置值", notes="根据编码获取配置值")
	@RequestMapping(value = "/queryByCode.do", method = RequestMethod.POST)
	public ListResult<Map<String,Object>> selectByConfigCode(
			@RequestHeader(name = "authorization",required = false) String token,
			@RequestBody(required = true) ParamPage<Map<String, Object>> dataInfo){
		return BusicenInvoker.doList(()->sacSystemConfigValueService.selectByConfigCode(dataInfo, token)).result();
	}
	
}
