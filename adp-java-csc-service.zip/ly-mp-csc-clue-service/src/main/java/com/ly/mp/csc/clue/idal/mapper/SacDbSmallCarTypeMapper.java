package com.ly.mp.csc.clue.idal.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ly.mp.csc.clue.entities.DbSmallCarType;

/**
 * <p>
 * 车型小类 Mapper 接口
 * </p>
 *
 * @author ly-linliq
 * @since 2021-09-07
 */
public interface SacDbSmallCarTypeMapper extends BaseMapper<DbSmallCarType> {

	/**
	* @Description: 车型查询
	* @author: linliq
	* @date 2021/09/07 14:42:16
	* @param page
	* @param map
	* @return
	 */
	 public List<Map<String,Object>> selectDbSmallCarType(Page<Map<String, Object>> page,@Param("param") Map<String,Object> map);
}
