package com.ly.mp.csc.clue.strategy.service;

import java.util.Map;

/**
 * 审核驳回-关联单据处理
 * @author ly-shenyw
 *
 */
public interface IShCancleBillStrategy {

	//单据校验
	void checkBill(String billCode,String token);
}
