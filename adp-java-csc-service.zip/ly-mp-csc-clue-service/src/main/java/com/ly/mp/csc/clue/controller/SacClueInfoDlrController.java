package com.ly.mp.csc.clue.controller;

import java.util.Arrays;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.constant.UserBusiEntity;
import com.ly.mp.busi.base.context.BusicenContext;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.busi.base.context.BusicenInvoker;
import com.ly.mp.busi.base.handler.ResultHandler;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.otherservice.ICscSysOrgService;
import com.ly.mp.csc.clue.service.IRemoveRepeatConfigService;
import com.ly.mp.csc.clue.service.ISacClueInfoDlrService;
import com.ly.mp.csc.clue.service.ISacClueInfoDlrTemporaryService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Api(value = "店端线索", tags = { "店端线索" })
@RestController
@RequestMapping(value = "/ly/sac/cluedlr")
public class SacClueInfoDlrController {

	//	private static Logger logger = LoggerFactory.getLogger(SacClueInfoDlrController.class);

	@Autowired ICscSysOrgService orgService;
	@Autowired ISacClueInfoDlrService clueInfoDlrService;
	@Autowired ISacClueInfoDlrTemporaryService clueInfoDlrTemporaryService;
	@Autowired IRemoveRepeatConfigService removeRepeatConfigService;

	@ApiOperation(value="店端线索重复检查",notes="店端线索重复检查")
	@RequestMapping(value="/cluedlrcheckrepeat.do",method=RequestMethod.POST)
	public EntityResult<Map<String, Object>> clueDlrCheckRepeat(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) ParamBase<Map<String, Object>> queryCondition) throws Exception{
		queryCondition.getParam().put("token", authentication);
		return BusicenInvoker.doEntity(()->clueInfoDlrService.dlrClueCheckRepeat(queryCondition)).result();
	}

	@ApiOperation(value="店端线索保存",notes="店端线索保存")
	@RequestMapping(value="/cluedlrsave.do",method=RequestMethod.POST)
	public EntityResult<Map<String, Object>> clueDlrSave(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) ParamBase<Map<String, Object>> queryCondition) throws Exception{
		queryCondition.getParam().put("token", authentication);
		//		UserBusiEntity user = BusicenContext.getCurrentUserBusiInfo(authentication);
		return BusicenInvoker.doEntity(()->clueInfoDlrService.saveMap(queryCondition, authentication)).result();
	}

	@ApiOperation(value="店端线索查询",notes="店端线索查询）")
	@RequestMapping(value="/cluedlrbypage.do",method=RequestMethod.POST)
	public ListResult<Map<String, Object>> clueDlrByPage(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) ParamPage<Map<String, Object>> queryCondition) throws Exception{
		Assert.notNull(queryCondition.getParam(), "参数param不能为空");
		queryCondition.getParam().put("token", authentication);
		if(StringHelper.IsEmptyOrNull(queryCondition.getParam().get("dlrCodeIn")) && StringHelper.IsEmptyOrNull(queryCondition.getParam().get("dlrCode"))) {
			UserBusiEntity user = BusicenContext.getCurrentUserBusiInfo(authentication);
			if(user != null) {
				queryCondition.getParam().put("dlrCode", user.getDlrCode());
			}
		}
		String statusCodes = (String)queryCondition.getParam().get("statusCodes");
		if(!StringHelper.IsEmptyOrNull(statusCodes)) {
			queryCondition.getParam().put("statusCodeList", Arrays.asList(StringUtils.split(statusCodes, ",")));
		}
		return BusicenInvoker.doList(()->clueInfoDlrService.findByPage(queryCondition)).result();
	}
	@ApiOperation(value="店端线索详情",notes="店端线索详情）")
	@RequestMapping(value="/cluedlrbyid.do",method=RequestMethod.POST)
	public EntityResult<Map<String, Object>> clueDlrById(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) ParamBase<Map<String, Object>> queryCondition) throws Exception{
		return BusicenInvoker.doEntity(()->{
			Assert.notNull(queryCondition.getParam(), "参数param不能为空");
			queryCondition.getParam().put("token", authentication);
			String id = (String)queryCondition.getParam().get("id");
			String serverOrder = (String)queryCondition.getParam().get("serverOrder");
			if(StringUtils.isBlank(id) && StringUtils.isBlank(serverOrder)) {
				throw new BusicenException("id和serverOrder不能同时为空！");
			}
			return clueInfoDlrService.findById(id, serverOrder);
		}).result();
	}

	@ApiOperation(value = "店端线索导出", notes = "线索")
	@RequestMapping(value = "/exportdlrclue.do", method = RequestMethod.POST)
	public OptResult exportDlrClue(@RequestHeader(name = "authorization", required = false) String token,
			@RequestBody(required = false) ParamBase<Map<String, Object>> dataInfo, HttpServletResponse response) {
		return BusicenInvoker.doOpt(() -> clueInfoDlrService.exportDlrClue(dataInfo.getParam(), token, response)).result();
	}

	@ApiOperation(value = "店端线索导入", notes = "店端线索导入")
	@PostMapping(value = "/importcluedlrfromexcel.do")
	ListResult<String> importClueDlrFromExcel(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = true) MultipartFile uploadfile) {
		return BusicenInvoker.doList(() ->
		{
			ListResult<String> listResult = clueInfoDlrTemporaryService.importFromExcel(uploadfile, authentication);
			return listResult;
		}).result();
	}


	@ApiOperation(value="导入店端线索表更新批量处理和处理状态",notes="导入店端线索表更新批量处理和处理状态")
	@RequestMapping(value="/tempcluedlrupdatebatch",method=RequestMethod.POST)
	public OptResult tempClueDlrUpdateBatch(int pageSize) throws Exception{
		return BusicenInvoker.doOpt(()->{
			clueInfoDlrTemporaryService.tempClueDlrUpdateBatch(pageSize);
			return ResultHandler.updateOk();
		}).result();
	}

	@ApiOperation(value="单条临时表数据导入店端线索表",notes="单条临时表数据导入店端线索表")
	@RequestMapping(value="/insertcluedlrfromtemp",method=RequestMethod.POST)
	public OptResult insertClueDlrFromTemp(@RequestBody(required = false) Map<String, Object> temporaryMap) throws Exception{
		return clueInfoDlrTemporaryService.insertClueDlrFromTemp(temporaryMap);
	}

	@ApiOperation(value="店端线索导入查询",notes="店端线索导入查询")
	@RequestMapping(value= {"/cluedlrtemporarybypage.do", "/cluedlrtemporarybypage"},method=RequestMethod.POST)
	public ListResult<Map<String, Object>> clueDlrTemporyByPage(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) ParamPage<Map<String, Object>> queryCondition) throws Exception{
		return BusicenInvoker.doList(()->clueInfoDlrTemporaryService.findByPage(queryCondition)).result();
	}



}
