package com.ly.mp.csc.clue.idal.mapper;

import com.ly.mp.csc.clue.entities.SacReviewBak;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import java.util.Map;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 回访任务备份表 Mapper 接口
 * </p>
 *
 * @author ly-busicen
 * @since 2021-08-17
 */
public interface SacReviewBakMapper extends BaseMapper<SacReviewBak> {

	/**
	 * 插入
	 * @param mapParm
	 * @return
	 */
	public int insertSacReviewBak(@Param("param")Map<String, Object> mapParm);
	
	/**
	 * 更新
	 * @param mapParm
	 * @return
	 */
	public int updateSacReviewBak(@Param("param")Map<String, Object> mapParm);
}
