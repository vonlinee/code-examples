package com.ly.mp.csc.clue.service;

import java.util.Map;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.entities.SacEvaluationItem;

/**
 * <p>
 * 选择项表 服务类
 * </p>
 *
 * @author ly-linliq
 * @since 2021-10-14
 */
public interface ISacEvaluationItemService extends IService<SacEvaluationItem> {
	
	/**
	 * 选择项查询
	 * @author ly-linliq
	 * @param mapParam
	 * @param token
	 * @return
	 */
	public ListResult<Map<String, Object>> evaluationItemQueryList(ParamPage<Map<String, Object>> mapParam,String token);
	
	/**
	 * 选择保存
	 * @param mapParam
	 * @param token
	 * @return
	 */
	public OptResult evaluationItemSave(ParamBase<Map<String, Object>> mapParam);
}
