package com.ly.mp.csc.clue.service;

import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.csc.clue.entities.SacFieldMappingConfig;
import com.ly.mp.csc.clue.entities.in.FieldMappingIn;
import com.ly.mp.csc.clue.entities.out.FieldMappingOut;

/**
 * <p>
 * 扩展字段配置表 服务类
 * </p>
 *
 * @author ly-busicen
 * @since 2021-08-17
 */
public interface ISacFieldMappingConfigService extends IService<SacFieldMappingConfig> {

	/**
	 * 映射字段转换
	 * @param info
	 * @return
	 */
	FieldMappingOut tranField(FieldMappingIn info);

	/**
	 * 字段转换后返回MAP 返回的json字段对应键值 为extendsJson
	 * @param info
	 * @return 
	 */
	Map<String, Object> tranFieldToMap(FieldMappingIn info);
	
	/**
	 * 反转：将数据库字段转换为映射的参数字段
	 * 字段转换后返回MAP
	 * @param info
	 * @return 
	 */
	Map<String, Object> unTranFieldToMap(FieldMappingIn info);
	
	EntityResult<Map<String, Object>> tranFieldToMapTest(Map<String, Object> param);
	/**
	 * 按条件获取列表
	 * @param info
	 * @return
	 */
	public List<SacFieldMappingConfig> getList(FieldMappingIn info) ;

	/**
	 * 根据主键判断插入或更新
	 * @param info
	 * @return
	 */
	EntityResult<Map<String, Object>> sacFieldMappingConfigSave(Map<String, Object> mapParam, String token);

}
