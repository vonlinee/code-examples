package com.ly.mp.csc.clue.idal.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ly.mp.csc.clue.entities.RemoveRepeatConfig;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 去重规则配置表 Mapper 接口
 * </p>
 *
 * @author ly-linliq
 * @since 2021-09-03
 */
public interface RemoveRepeatConfigMapper extends BaseMapper<RemoveRepeatConfig> {

	/**
	* @Description: 潜客去重规则配置查询
	* @author: linliq
	* @date 2021/09/06 14:57:42
	* @param map
	* @return
	 */
	  public List<Map<String,Object>> selectRemoveRepeatConfig(Page<Map<String, Object>> page,@Param("param") Map<String,Object> map);
	  
	  /**
	  * @Description: 潜客去重规则配置新增
	  * @author: linliq
	  * @date 2021/09/06 15:47:19
	  * @param param
	  * @return
	   */
      public int insertRemoveRepeatConfig(@Param("param")Map<String,Object>param);
	  
      /**
      * @Description: 潜客去重规则配置修改
      * @author: linliq
      * @date 2021/09/06 15:47:35
      * @param param
      * @return
       */
	  public int updateRemoveRepeatConfig(@Param("param")Map<String,Object>param);
	  
	  /**
	  * @Description: 校验潜客去重规则配置是否已存在
	  * @author: linliq
	  * @date 2021/09/06 17:47:09
	  * @param param
	  * @return
	   */
	  int checkRepeat(@Param("param") Map<String,Object> param);
	  
	  int checkRemoveRepeatConfigExists(@Param("configId") String configId);
}
