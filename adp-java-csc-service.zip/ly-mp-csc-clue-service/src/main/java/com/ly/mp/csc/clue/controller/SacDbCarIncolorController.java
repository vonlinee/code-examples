package com.ly.mp.csc.clue.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.context.BusicenInvoker;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.csc.clue.service.ISacDbCarIncolorService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 车辆内饰颜色服务
 * @author ly-linliq
 *
 */
@Api(value = "车辆内饰颜色服务", tags = { "车辆内饰颜色服务" })
@RestController
@RequestMapping(value ="/ly/sac/carincolor", produces = { MediaType.APPLICATION_JSON_VALUE })
public class SacDbCarIncolorController {
	//注入服务
	@Autowired
	ISacDbCarIncolorService sacDbCarIncolorService;
					
	@ApiOperation(value="车辆内饰颜色查询", notes="车辆内饰颜色查询")
	@RequestMapping(value = "/carincolorquery.do", method = RequestMethod.POST)
	public ListResult<Map<String,Object>> carColorQuery(
			@RequestHeader(name = "authorization",required = false) String authentication,
			@RequestBody(required = false) ParamPage<Map<String, Object>> dataInfo){
		dataInfo.getParam().put("token", authentication);
		return BusicenInvoker.doList(()->sacDbCarIncolorService.carIncolorQuery(dataInfo)).result();
	}
}
