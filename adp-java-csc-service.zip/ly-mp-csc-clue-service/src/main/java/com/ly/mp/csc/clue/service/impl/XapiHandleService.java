package com.ly.mp.csc.clue.service.impl;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ly.mp.csc.clue.idal.mapper.XapiHandleServiceMapper;
import com.ly.mp.csc.clue.service.IXapiHandleService;

@Service
public class XapiHandleService implements IXapiHandleService {

	private static Logger logger = LoggerFactory.getLogger(XapiHandleService.class);
	@Autowired
	XapiHandleServiceMapper xapiHandleServiceMapper;


	/**
	 * 归档定时任务_查询数据
	 */
	@Override
	public List<Map<String, Object>> queryData(Map<String, Object> info) {
		try {
			return xapiHandleServiceMapper.queryData(info);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("XapiHandleService.queryData执行失败=>{},{}",info,e.toString());
			throw e;
		}
	}

	/**
	 * 归档定时任务_写入历史表
	 */
	@Override
	public int insertData(Map<String, Object> info) {
		try {
			return xapiHandleServiceMapper.insertData(info);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("XapiHandleService.insertData执行失败=>{},{}",info,e.toString());
			throw e;
		}
	}

	/**
	 * 归档定时任务_删除原数据
	 */
	@Override
	public int delData(Map<String, Object> info) {
		try {
			return xapiHandleServiceMapper.delData(info);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("XapiHandleService.delData执行失败=>{},{}",info,e.toString());
			throw e;
		}
	}

	
}
