package com.ly.mp.csc.clue.idal.mapper;

import com.ly.mp.csc.clue.entities.SacClueHatchPool;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 总部线索孵化池表 Mapper 接口
 * </p>
 *
 * @author ly-linliq
 * @since 2021-10-26
 */
public interface SacClueHatchPoolMapper extends BaseMapper<SacClueHatchPool> {

	/**
	 * 查找总部线索孵化池线索
	 * @param param
	 * @param page
	 * @return
	 */
	public List<Map<String, Object>> selectSacClueHatchPool(@Param("param") Map<String, Object> param,
			Page<Map<String, Object>> page);

	/**
	 * 新增总部孵化池线索
	 * @param param
	 * @return
	 */
	public int insertSacClueHatchPool(@Param("param") Map<String, Object> param);

	/**
	 * 更新总部孵化池线索
	 * @param param
	 * @return
	 */
	public int updateSacClueHatchPool(@Param("param") Map<String, Object> param);

}
