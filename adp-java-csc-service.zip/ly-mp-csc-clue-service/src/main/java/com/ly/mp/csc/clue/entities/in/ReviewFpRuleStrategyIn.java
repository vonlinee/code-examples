package com.ly.mp.csc.clue.entities.in;

import java.io.Serializable;

public class ReviewFpRuleStrategyIn implements Serializable {

    private static final long serialVersionUID = 1L;
    
    /**
     * 人员队列
     */
    private String personQueueCode;
    
    /**
     * 业务类型
     */
    private String businessType;
    
    /**
     * 渠道ID
     */
    private String channelId;
}
