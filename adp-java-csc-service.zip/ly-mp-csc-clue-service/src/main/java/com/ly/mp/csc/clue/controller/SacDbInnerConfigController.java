package com.ly.mp.csc.clue.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.context.BusicenInvoker;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.csc.clue.service.ISacDbInnerConfigService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Api(value = "系统内置配置", tags = { "系统内置配置" })
@RestController
@RequestMapping(value ="/ly/sac/innerconfig", produces = { MediaType.APPLICATION_JSON_VALUE })
public class SacDbInnerConfigController {
	
	@Autowired
	ISacDbInnerConfigService sacDbInnerConfigService;
	
	@ApiOperation(value="配置列表查询", notes="配置列表查询")
	@RequestMapping(value = "/queryConfigList.do", method = RequestMethod.POST)
	public ListResult<Map<String,Object>> queryConfigList(
			@RequestHeader(name = "authorization",required = false) String authentication,
			@RequestBody(required = false) ParamPage<Map<String, Object>> dataInfo){
		dataInfo.getParam().put("token", authentication);
		return BusicenInvoker.doList(()->sacDbInnerConfigService.queryConfigList(dataInfo,authentication)).result();
	}
}
