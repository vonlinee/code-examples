package com.ly.mp.csc.clue.idal.mapper;

import com.ly.mp.csc.clue.entities.SacClueHatchPoolHis;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 总部线索孵化池历史表 Mapper 接口
 * </p>
 *
 * @author ly-linliq
 * @since 2021-10-26
 */
public interface SacClueHatchPoolHisMapper extends BaseMapper<SacClueHatchPoolHis> {

      public int insertSacClueHatchPoolHis(@Param("param")Map<String,Object>param);
}
