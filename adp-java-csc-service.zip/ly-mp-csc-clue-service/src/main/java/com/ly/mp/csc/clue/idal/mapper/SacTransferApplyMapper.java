package com.ly.mp.csc.clue.idal.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.ly.mp.csc.clue.entities.SacTransferApply;


/**
 * 划转申请表 Mapper接口
 * t_sac_transfer_apply
 * @author ly-zhengzc
 * @since 2021-12-14
 */
public interface SacTransferApplyMapper extends BaseMapper<SacTransferApply> {

	/**
	 * 插入
	 * @param mapParm
	 * @return
	 */
	public int insertSacTransferApply(@Param("param")Map<String, Object> mapParm);
	/**
	 * 更新
	 * @param mapParm
	 * @return
	 */
	public int updateSacTransferApply(@Param("param")Map<String, Object> mapParm);
	/**
	 * 分页查询
	 * @param page
	 * @param param
	 * @return
	 */
	List<Map<String, Object>> selectByPage(IPage<Map<String, Object>> page, @Param("param")Map<String, Object> param);


	/**
	 * 划转申请单列表查询
	 * @param page
	 * @param param
	 * @return
	 */
	List<Map<String, Object>> selectApplyByPage(IPage<Map<String, Object>> page, @Param("param")Map<String, Object> param);

	/**
	 * 审核任务列表查询
	 * @param page
	 * @param param
	 * @return
	 */
	List<Map<String, Object>> selectAuditByPage(IPage<Map<String, Object>> page, @Param("param")Map<String, Object> param);
}
