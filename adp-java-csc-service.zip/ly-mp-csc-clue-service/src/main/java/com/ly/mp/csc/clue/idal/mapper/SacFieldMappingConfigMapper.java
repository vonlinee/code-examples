package com.ly.mp.csc.clue.idal.mapper;

import com.ly.mp.csc.clue.entities.SacFieldMappingConfig;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 扩展字段配置表 Mapper 接口
 * </p>
 *
 * @author ly-busicen
 * @since 2021-08-17
 */
public interface SacFieldMappingConfigMapper extends BaseMapper<SacFieldMappingConfig> {

	/**
	 * 插入
	 * @param mapParm
	 * @return
	 */
	public int insertSacFieldMappingConfig(@Param("param")Map<String, Object> mapParm);
	
	/**
	 * 更新
	 * @param mapParm
	 * @return
	 */
	public int updateSacFieldMappingConfig(@Param("param")Map<String, Object> mapParm);
	
	/**
	 * 字段映射关系查询
	 */
	List<Map<String, Object>> fileMappingList(@Param("param")Map<String, Object> param);
}
