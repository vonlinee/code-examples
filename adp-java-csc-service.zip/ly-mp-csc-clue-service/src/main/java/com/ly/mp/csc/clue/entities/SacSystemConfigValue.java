package com.ly.mp.csc.clue.entities;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.time.LocalDateTime;

/**
    * 系统配置值表
    */
@TableName(value = "t_sac_system_config_value")
public class SacSystemConfigValue {
    /**
     * 配置值ID
     */
    @TableId(value = "CONFIG_VALUE_ID", type = IdType.INPUT)
    private String configValueId;

    /**
     * 配置ID
     */
    @TableField(value = "CONFIG_ID")
    private String configId;

    /**
     * 所属组织编码，厂家为PV，店端为网点编码
     */
    @TableField(value = "ORG_CODE")
    private String orgCode;

    /**
     * 所属组织名称
     */
    @TableField(value = "ORG_NAME")
    private String orgName;

    /**
     * 值编码
     */
    @TableField(value = "VALUE_CODE")
    private String valueCode;

    /**
     * 值名称
     */
    @TableField(value = "VALUE_NAME")
    private String valueName;

    /**
     * 扩展字段1
     */
    @TableField(value = "COLUMN1")
    private String column1;

    /**
     * 扩展字段2
     */
    @TableField(value = "COLUMN2")
    private String column2;

    /**
     * 扩展字段3
     */
    @TableField(value = "COLUMN3")
    private String column3;

    /**
     * 扩展字段4
     */
    @TableField(value = "COLUMN4")
    private String column4;

    /**
     * 扩展字段5
     */
    @TableField(value = "COLUMN5")
    private String column5;

    /**
     * 厂商标识ID
     */
    @TableField(value = "OEM_ID")
    private String oemId;

    /**
     * 集团标识ID
     */
    @TableField(value = "GROUP_ID")
    private String groupId;

    /**
     * 创建人ID
     */
    @TableField(value = "CREATOR")
    private String creator;

    /**
     * 创建人
     */
    @TableField(value = "CREATED_NAME")
    private String createdName;

    /**
     * 创建日期
     */
    @TableField(value = "CREATED_DATE")
    private LocalDateTime createdDate;

    /**
     * 修改人ID
     */
    @TableField(value = "MODIFIER")
    private String modifier;

    /**
     * 修改人
     */
    @TableField(value = "MODIFY_NAME")
    private String modifyName;

    /**
     * 最后更新日期
     */
    @TableField(value = "LAST_UPDATED_DATE")
    private LocalDateTime lastUpdatedDate;

    /**
     * 是否可用
     */
    @TableField(value = "IS_ENABLE")
    private String isEnable;

    /**
     * 并发控制ID
     */
    @TableField(value = "UPDATE_CONTROL_ID")
    private String updateControlId;

    /**
     * 获取配置值ID
     *
     * @return CONFIG_VALUE_ID - 配置值ID
     */
    public String getConfigValueId() {
        return configValueId;
    }

    /**
     * 设置配置值ID
     *
     * @param configValueId 配置值ID
     */
    public void setConfigValueId(String configValueId) {
        this.configValueId = configValueId;
    }

    /**
     * 获取配置ID
     *
     * @return CONFIG_ID - 配置ID
     */
    public String getConfigId() {
        return configId;
    }

    /**
     * 设置配置ID
     *
     * @param configId 配置ID
     */
    public void setConfigId(String configId) {
        this.configId = configId;
    }

    /**
     * 获取所属组织编码，厂家为PV，店端为网点编码
     *
     * @return ORG_CODE - 所属组织编码，厂家为PV，店端为网点编码
     */
    public String getOrgCode() {
        return orgCode;
    }

    /**
     * 设置所属组织编码，厂家为PV，店端为网点编码
     *
     * @param orgCode 所属组织编码，厂家为PV，店端为网点编码
     */
    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }

    /**
     * 获取所属组织名称
     *
     * @return ORG_NAME - 所属组织名称
     */
    public String getOrgName() {
        return orgName;
    }

    /**
     * 设置所属组织名称
     *
     * @param orgName 所属组织名称
     */
    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    /**
     * 获取值编码
     *
     * @return VALUE_CODE - 值编码
     */
    public String getValueCode() {
        return valueCode;
    }

    /**
     * 设置值编码
     *
     * @param valueCode 值编码
     */
    public void setValueCode(String valueCode) {
        this.valueCode = valueCode;
    }

    /**
     * 获取值名称
     *
     * @return VALUE_NAME - 值名称
     */
    public String getValueName() {
        return valueName;
    }

    /**
     * 设置值名称
     *
     * @param valueName 值名称
     */
    public void setValueName(String valueName) {
        this.valueName = valueName;
    }

    /**
     * 获取扩展字段1
     *
     * @return COLUMN1 - 扩展字段1
     */
    public String getColumn1() {
        return column1;
    }

    /**
     * 设置扩展字段1
     *
     * @param column1 扩展字段1
     */
    public void setColumn1(String column1) {
        this.column1 = column1;
    }

    /**
     * 获取扩展字段2
     *
     * @return COLUMN2 - 扩展字段2
     */
    public String getColumn2() {
        return column2;
    }

    /**
     * 设置扩展字段2
     *
     * @param column2 扩展字段2
     */
    public void setColumn2(String column2) {
        this.column2 = column2;
    }

    /**
     * 获取扩展字段3
     *
     * @return COLUMN3 - 扩展字段3
     */
    public String getColumn3() {
        return column3;
    }

    /**
     * 设置扩展字段3
     *
     * @param column3 扩展字段3
     */
    public void setColumn3(String column3) {
        this.column3 = column3;
    }

    /**
     * 获取扩展字段4
     *
     * @return COLUMN4 - 扩展字段4
     */
    public String getColumn4() {
        return column4;
    }

    /**
     * 设置扩展字段4
     *
     * @param column4 扩展字段4
     */
    public void setColumn4(String column4) {
        this.column4 = column4;
    }

    /**
     * 获取扩展字段5
     *
     * @return COLUMN5 - 扩展字段5
     */
    public String getColumn5() {
        return column5;
    }

    /**
     * 设置扩展字段5
     *
     * @param column5 扩展字段5
     */
    public void setColumn5(String column5) {
        this.column5 = column5;
    }

    /**
     * 获取厂商标识ID
     *
     * @return OEM_ID - 厂商标识ID
     */
    public String getOemId() {
        return oemId;
    }

    /**
     * 设置厂商标识ID
     *
     * @param oemId 厂商标识ID
     */
    public void setOemId(String oemId) {
        this.oemId = oemId;
    }

    /**
     * 获取集团标识ID
     *
     * @return GROUP_ID - 集团标识ID
     */
    public String getGroupId() {
        return groupId;
    }

    /**
     * 设置集团标识ID
     *
     * @param groupId 集团标识ID
     */
    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    /**
     * 获取创建人ID
     *
     * @return CREATOR - 创建人ID
     */
    public String getCreator() {
        return creator;
    }

    /**
     * 设置创建人ID
     *
     * @param creator 创建人ID
     */
    public void setCreator(String creator) {
        this.creator = creator;
    }

    /**
     * 获取创建人
     *
     * @return CREATED_NAME - 创建人
     */
    public String getCreatedName() {
        return createdName;
    }

    /**
     * 设置创建人
     *
     * @param createdName 创建人
     */
    public void setCreatedName(String createdName) {
        this.createdName = createdName;
    }

    /**
     * 获取创建日期
     *
     * @return CREATED_DATE - 创建日期
     */
    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    /**
     * 设置创建日期
     *
     * @param createdDate 创建日期
     */
    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * 获取修改人ID
     *
     * @return MODIFIER - 修改人ID
     */
    public String getModifier() {
        return modifier;
    }

    /**
     * 设置修改人ID
     *
     * @param modifier 修改人ID
     */
    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    /**
     * 获取修改人
     *
     * @return MODIFY_NAME - 修改人
     */
    public String getModifyName() {
        return modifyName;
    }

    /**
     * 设置修改人
     *
     * @param modifyName 修改人
     */
    public void setModifyName(String modifyName) {
        this.modifyName = modifyName;
    }

    /**
     * 获取最后更新日期
     *
     * @return LAST_UPDATED_DATE - 最后更新日期
     */
    public LocalDateTime getLastUpdatedDate() {
        return lastUpdatedDate;
    }

    /**
     * 设置最后更新日期
     *
     * @param lastUpdatedDate 最后更新日期
     */
    public void setLastUpdatedDate(LocalDateTime lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }

    /**
     * 获取是否可用
     *
     * @return IS_ENABLE - 是否可用
     */
    public String getIsEnable() {
        return isEnable;
    }

    /**
     * 设置是否可用
     *
     * @param isEnable 是否可用
     */
    public void setIsEnable(String isEnable) {
        this.isEnable = isEnable;
    }

    /**
     * 获取并发控制ID
     *
     * @return UPDATE_CONTROL_ID - 并发控制ID
     */
    public String getUpdateControlId() {
        return updateControlId;
    }

    /**
     * 设置并发控制ID
     *
     * @param updateControlId 并发控制ID
     */
    public void setUpdateControlId(String updateControlId) {
        this.updateControlId = updateControlId;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", configValueId=").append(configValueId);
        sb.append(", configId=").append(configId);
        sb.append(", orgCode=").append(orgCode);
        sb.append(", orgName=").append(orgName);
        sb.append(", valueCode=").append(valueCode);
        sb.append(", valueName=").append(valueName);
        sb.append(", column1=").append(column1);
        sb.append(", column2=").append(column2);
        sb.append(", column3=").append(column3);
        sb.append(", column4=").append(column4);
        sb.append(", column5=").append(column5);
        sb.append(", oemId=").append(oemId);
        sb.append(", groupId=").append(groupId);
        sb.append(", creator=").append(creator);
        sb.append(", createdName=").append(createdName);
        sb.append(", createdDate=").append(createdDate);
        sb.append(", modifier=").append(modifier);
        sb.append(", modifyName=").append(modifyName);
        sb.append(", lastUpdatedDate=").append(lastUpdatedDate);
        sb.append(", isEnable=").append(isEnable);
        sb.append(", updateControlId=").append(updateControlId);
        sb.append("]");
        return sb.toString();
    }
}