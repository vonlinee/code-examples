package com.ly.mp.csc.clue.idal.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * com.ly.mp.csc.clue.idal.mapper.SacReviewDlrClueMapper
 * 回访任务
 *
 * @author zhouhao
 * @date 2021/8/20 9:04
 */
public interface SacReviewDlrClueMapper {

    /**
     * 本人待回访任务查询
     * @param page 分页参数
     * @param param 输入参数
     * @return List
     */
    List<Map<String, Object>> queryListMeReviewInfo(IPage<Map<String, Object>> page, @Param("param")Map<String, Object> param);

    /**
     * 本店待回访任务查询
     * @param page 分页参数
     * @param param 输入参数
     * @return List
     */
    List<Map<String, Object>> queryListByDlr(IPage<Map<String, Object>> page, @Param("param")Map<String, Object> param);

    
    /**
     * 待审核任务查询
     * @param page 分页参数
     * @param param 输入参数
     * @return List
     */
    List<Map<String, Object>> queryListAuditReviewInfo(IPage<Map<String, Object>> page, @Param("param")Map<String, Object> param);

    /**
     * 回访审核任务查询
     * @param page 分页参数
     * @param param 输入参数
     * @return List
     */
    List<Map<String, Object>> queryListAuditReviewRecordInfo(IPage<Map<String, Object>> page, @Param("param")Map<String, Object> param);

    /**
     * 回访记录查询
     * @param page 分页参数
     * @param param 输入参数
     * @return List
     */
    List<Map<String, Object>> queryReviewRecord(IPage<Map<String, Object>> page, @Param("param")Map<String, Object> param);

 
}