package com.ly.mp.csc.clue.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.context.BusicenInvoker;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.csc.clue.service.IRemoveRepeatConfigService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * @Description: 潜客去重规则配置
 * @author ly-linliq
 * @date 2021/09/03 15:20:16
 */
@Api(value = "潜客去重规则配置服务", tags = { "潜客去重规则配置服务" })
@RestController
@RequestMapping(value = "/ly/sac/removerepeatruleconfig", produces = { MediaType.APPLICATION_JSON_VALUE })
public class RemoveRepeatConfigController {
	//注入服务
	@Autowired
	IRemoveRepeatConfigService removeRepeatConfigService;

	@ApiOperation(value="潜客去重规则配置查询", notes="潜客去重规则配置查询")
	@RequestMapping(value = "/repeatruleconfigquery.do", method = RequestMethod.POST)
	public ListResult<Map<String,Object>> queryListRemoveRepeatConfig(
			@RequestHeader(name = "authorization",required = false) String authentication,
			@RequestBody(required = false) ParamPage<Map<String, Object>> dataInfo){
		dataInfo.getParam().put("token", authentication);
		return BusicenInvoker.doList(()->removeRepeatConfigService.queryListRemoveRepeatConfig(dataInfo)).result();
	}

	@ApiOperation(value="潜客去重规则配置保存", notes="潜客去重规则配置保存")
	@RequestMapping(value = "/repeatruleconfigsave.do", method = RequestMethod.POST)
	public  EntityResult<Map<String, Object>> repeatRuleConfigSave(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false)ParamBase<Map<String,Object>> dataInfo) throws Exception{
		dataInfo.getParam().put("token", authentication);
		dataInfo.getParam().put("isHead", true);
		return BusicenInvoker.doEntity(()->removeRepeatConfigService.repeatRuleConfigSave(dataInfo.getParam())).result();
	}
	@ApiOperation(value="线索去重规则配置查询", notes="线索去重规则配置查询")
	@RequestMapping(value = "/queryrepeatruleconfig.do", method = RequestMethod.POST)
	public ListResult<Map<String,Object>> queryRemoveRepeatConfigList(
			@RequestHeader(name = "authorization",required = false) String authentication,
			@RequestBody(required = false) ParamPage<Map<String, Object>> dataInfo){
		dataInfo.getParam().put("token", authentication);
		dataInfo.getParam().put("clueType", "dlrClue");
		return BusicenInvoker.doList(()->removeRepeatConfigService.queryListRemoveRepeatConfig(dataInfo)).result();
	}

	@ApiOperation(value="线索去重规则配置保存", notes="线索去重规则配置保存")
	@RequestMapping(value = "/saverepeatruleconfig.do", method = RequestMethod.POST)
	public  EntityResult<Map<String, Object>> saveRepeatRuleConfig(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false)ParamBase<Map<String,Object>> dataInfo) throws Exception{
		dataInfo.getParam().put("token", authentication);
		dataInfo.getParam().put("isHead", false);
		dataInfo.getParam().put("clueType", "dlrClue");
		return BusicenInvoker.doEntity(()->removeRepeatConfigService.repeatRuleConfigSave(dataInfo.getParam())).result();
	}

}
