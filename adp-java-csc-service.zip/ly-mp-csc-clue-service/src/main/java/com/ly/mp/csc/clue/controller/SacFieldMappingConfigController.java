package com.ly.mp.csc.clue.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.busi.base.context.BusicenInvoker;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.csc.clue.entities.SacFieldMappingConfig;
import com.ly.mp.csc.clue.entities.in.FieldMappingIn;
import com.ly.mp.csc.clue.service.ISacFieldMappingConfigService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Api(value = "扩展字段配置表", tags = { "扩展字段配置表" })
@RestController
@RequestMapping(value = "/ly/sac/fieldmappingconfig")
public class SacFieldMappingConfigController {

	@Autowired ISacFieldMappingConfigService configService;


	@ApiOperation(value="获取配置信息",notes="获取配置信息")
	@RequestMapping(value="/getlist.do",method=RequestMethod.POST)
	Object getList(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			String sourceTableCode, String billType, String businessType) throws Exception{
		FieldMappingIn info = new FieldMappingIn();
		info.setSourceTableCode(sourceTableCode);
		info.setBillType(billType);
		info.setBusinessType(businessType);
		List<SacFieldMappingConfig> list = configService.getList(info);
		return list;
	}


	@ApiOperation(value="转换参数", notes="转换参数")
	@RequestMapping(value = "/tranFieldToMapTest.do", method = RequestMethod.POST)
	public EntityResult<Map<String,Object>> tranFieldToMapTest(
			@RequestHeader(name = "authorization",required = false) String token,
			@RequestBody(required = false)ParamBase<Map<String,Object>> dataInfo){
			return BusicenInvoker.doEntity(()->configService.tranFieldToMapTest(dataInfo.getParam())).result();
	}
}
