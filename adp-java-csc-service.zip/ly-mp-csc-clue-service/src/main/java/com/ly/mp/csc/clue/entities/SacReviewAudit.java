package com.ly.mp.csc.clue.entities;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import com.baomidou.mybatisplus.annotation.FieldFill;


/**
 * <p>
 * 回访审核表
 * </p>
 *
 * @author ly-busicen
 * @since 2021-08-17
 */
@TableName("t_sac_review_audit")
public class SacReviewAudit implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 审核ID
     */
    @TableId("AUDIT_ID")
    private String auditId;

    /**
     * 回访ID
     */
    @TableField("REVIEW_ID")
    private String reviewId;

    /**
     * 所属组织
     */
    @TableField("ORG_CODE")
    private String orgCode;

    /**
     * 所属组织名称
     */
    @TableField("ORG_NAME")
    private String orgName;
    
    /**
     * 业务单号
     */
    @TableField("BILL_CODE")
    private String billCode;

    /**
     * 审核类型编码
     */
    @TableField("APPLY_TYPE_CODE")
    private String applyTypeCode;

    /**
     * 审核类型名称
     */
    @TableField("APPLY_TYPE_NAME")
    private String applyTypeName;

    /**
     * 申请原因
     */
    @TableField("APPLY_DESC")
    private String applyDesc;

    /**
     * 审核人员用户ID
     */
    @TableField("SH_PERSON_ID")
    private String shPersonId;

    /**
     * 审核人员名称
     */
    @TableField("SH_PERSON_NAME")
    private String shPersonName;

    /**
     * 审核意见
     */
    @TableField("SH_DESC")
    private String shDesc;

    /**
     * 审核时间
     */
    @TableField("SH_TIME")
    private LocalDateTime shTime;

    /**
     * 审核状态编码
     */
    @TableField("SH_STATUS")
    private String shStatus;

    /**
     * 审核状态名称
     */
    @TableField("SH_STATUS_NAME")
    private String shStatusName;

    /**
     * JSON扩展字段
     */
    @TableField("EXTENDS_JSON")
    private String extendsJson;

    /**
     * 厂商标识ID
     */
    @TableField("OEM_ID")
    private String oemId;

    /**
     * 集团标识ID
     */
    @TableField("GROUP_ID")
    private String groupId;

    /**
     * 创建人ID
     */
    @TableField(value = "CREATOR", fill = FieldFill.INSERT)
    private String creator;

    /**
     * 创建人
     */
    @TableField(value = "CREATED_NAME", fill = FieldFill.INSERT)
    private String createdName;

    /**
     * 创建日期
     */
    @TableField(value = "CREATED_DATE", fill = FieldFill.INSERT)
    private LocalDateTime createdDate;

    /**
     * 修改人ID
     */
    @TableField(value = "MODIFIER", fill = FieldFill.INSERT_UPDATE)
    private String modifier;

    /**
     * 修改人
     */
    @TableField(value = "MODIFY_NAME", fill = FieldFill.INSERT_UPDATE)
    private String modifyName;

    /**
     * 最后更新日期
     */
    @TableField(value = "LAST_UPDATED_DATE", fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime lastUpdatedDate;

    /**
     * 是否可用
     */
    @TableField("IS_ENABLE")
    private String isEnable;

    /**
     * 并发控制ID
     */
    @TableField(value = "UPDATE_CONTROL_ID", fill = FieldFill.INSERT_UPDATE)
    private String updateControlId;

    public String getAuditId() {
        return auditId;
    }

    public void setAuditId(String auditId) {
        this.auditId = auditId;
    }
    public String getReviewId() {
        return reviewId;
    }

    public void setReviewId(String reviewId) {
        this.reviewId = reviewId;
    }
    
    public String getOrgCode() {
		return orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public String getBillCode() {
        return billCode;
    }

    public void setBillCode(String billCode) {
        this.billCode = billCode;
    }
    public String getApplyTypeCode() {
        return applyTypeCode;
    }

    public void setApplyTypeCode(String applyTypeCode) {
        this.applyTypeCode = applyTypeCode;
    }
    public String getApplyTypeName() {
        return applyTypeName;
    }

    public void setApplyTypeName(String applyTypeName) {
        this.applyTypeName = applyTypeName;
    }
    public String getApplyDesc() {
        return applyDesc;
    }

    public void setApplyDesc(String applyDesc) {
        this.applyDesc = applyDesc;
    }
    public String getShPersonId() {
        return shPersonId;
    }

    public void setShPersonId(String shPersonId) {
        this.shPersonId = shPersonId;
    }
    public String getShPersonName() {
        return shPersonName;
    }

    public void setShPersonName(String shPersonName) {
        this.shPersonName = shPersonName;
    }
    public String getShDesc() {
        return shDesc;
    }

    public void setShDesc(String shDesc) {
        this.shDesc = shDesc;
    }
    public LocalDateTime getShTime() {
        return shTime;
    }

    public void setShTime(LocalDateTime shTime) {
        this.shTime = shTime;
    }
    public String getShStatus() {
        return shStatus;
    }

    public void setShStatus(String shStatus) {
        this.shStatus = shStatus;
    }
    public String getShStatusName() {
        return shStatusName;
    }

    public void setShStatusName(String shStatusName) {
        this.shStatusName = shStatusName;
    }
    public String getExtendsJson() {
        return extendsJson;
    }

    public void setExtendsJson(String extendsJson) {
        this.extendsJson = extendsJson;
    }
    public String getOemId() {
        return oemId;
    }

    public void setOemId(String oemId) {
        this.oemId = oemId;
    }
    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }
    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }
    public String getCreatedName() {
        return createdName;
    }

    public void setCreatedName(String createdName) {
        this.createdName = createdName;
    }
    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }
    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier;
    }
    public String getModifyName() {
        return modifyName;
    }

    public void setModifyName(String modifyName) {
        this.modifyName = modifyName;
    }
    public LocalDateTime getLastUpdatedDate() {
        return lastUpdatedDate;
    }

    public void setLastUpdatedDate(LocalDateTime lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }
    public String getIsEnable() {
        return isEnable;
    }

    public void setIsEnable(String isEnable) {
        this.isEnable = isEnable;
    }
    public String getUpdateControlId() {
        return updateControlId;
    }

    public void setUpdateControlId(String updateControlId) {
        this.updateControlId = updateControlId;
    }

    @Override
    public String toString() {
        return "SacReviewAudit{" +
        "auditId=" + auditId +
        ", reviewId=" + reviewId +
        ", orgCode=" + orgCode +
        ", orgName=" + orgName +
        ", billCode=" + billCode +
        ", applyTypeCode=" + applyTypeCode +
        ", applyTypeName=" + applyTypeName +
        ", applyDesc=" + applyDesc +
        ", shPersonId=" + shPersonId +
        ", shPersonName=" + shPersonName +
        ", shDesc=" + shDesc +
        ", shTime=" + shTime +
        ", shStatus=" + shStatus +
        ", shStatusName=" + shStatusName +
        ", extendsJson=" + extendsJson +
        ", oemId=" + oemId +
        ", groupId=" + groupId +
        ", creator=" + creator +
        ", createdName=" + createdName +
        ", createdDate=" + createdDate +
        ", modifier=" + modifier +
        ", modifyName=" + modifyName +
        ", lastUpdatedDate=" + lastUpdatedDate +
        ", isEnable=" + isEnable +
        ", updateControlId=" + updateControlId +
        "}";
    }
}
