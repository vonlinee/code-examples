package com.ly.mp.csc.clue.service.impl;

import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.busi.base.handler.BusicenUtils.SOU;
import com.ly.mp.busi.base.handler.ResultHandler;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.entities.SacReviewBak;
import com.ly.mp.csc.clue.idal.mapper.SacReviewBakMapper;
import com.ly.mp.csc.clue.service.ISacReviewBakService;


/**
 * <p>
 * 回访任务备份表 服务实现类
 * </p>
 *
 * @author ly-busicen
 * @since 2021-08-17
 */
@Service
public class SacReviewBakService extends ServiceImpl<SacReviewBakMapper, SacReviewBak> implements ISacReviewBakService {

private Logger log = LoggerFactory.getLogger(SacReviewBakService.class);
	
	@Autowired
	SacReviewBakMapper sacReviewBakMapper;

	/**
	 * 根据主键判断插入或更新
	 * @param info
	 * @return
	 */
	@Override
	@Transactional
	public EntityResult<Map<String, Object>> sacReviewBakSave(Map<String, Object> mapParam, String token){
		try {
			Boolean updateFlag = false;
		    if (!StringHelper.IsEmptyOrNull(mapParam.get("reviewId"))) {
			    QueryWrapper<SacReviewBak> wrapper = new QueryWrapper<>();
			    wrapper.lambda().eq(SacReviewBak::getReviewId, mapParam.get("reviewId"));
		    	if (list(wrapper).size() > 0) {
		    		updateFlag = true;
				}
			}
			if(!updateFlag){
				//新增
				if (StringHelper.IsEmptyOrNull(mapParam.get("reviewId"))) {
					//主键
					mapParam.put("reviewId",UUID.randomUUID().toString());
				}
				BusicenUtils.invokeUserInfo(mapParam, SOU.Save,token);
				sacReviewBakMapper.insertSacReviewBak(mapParam);
			}else{
				//更新
				BusicenUtils.invokeUserInfo(mapParam, SOU.Update,"");
				sacReviewBakMapper.updateSacReviewBak(mapParam);
			}
			return ResultHandler.updateOk(mapParam);
		} catch (Exception e) {
			log.error("sacReviewBakSave", e);
			throw e;
		} 
	}
	
}
