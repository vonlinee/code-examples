package com.ly.mp.csc.clue.service.impl;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

import org.apache.commons.beanutils.PropertyUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegist;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegistor;
import com.ly.bucn.component.interceptor.annotation.Interceptor;
import com.ly.bucn.component.message.Message;
import com.ly.bucn.component.strategy.runtime.ChooseContext;
import com.ly.mp.busi.base.constant.UserBusiEntity;
import com.ly.mp.busi.base.context.BusicenContext;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.busi.base.handler.BusicenUtils.SOU;
import com.ly.mp.busi.base.handler.MapUtil;
import com.ly.mp.busi.base.handler.OptResultBuilder;
import com.ly.mp.busi.base.handler.ResultHandler;
import com.ly.mp.busicen.rule.field.IFireFieldRule;
import com.ly.mp.busicen.rule.field.execution.ValidResultCtn;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.component.helper.SpringContextHolder;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.entities.SacReview;
import com.ly.mp.csc.clue.entities.SacReviewAudit;
import com.ly.mp.csc.clue.entities.SacReviewHis;
import com.ly.mp.csc.clue.enums.ReviewAuditStatusEnum;
import com.ly.mp.csc.clue.enums.ReviewAuditTypeEnum;
import com.ly.mp.csc.clue.enums.ReviewNodeEnum;
import com.ly.mp.csc.clue.enums.ReviewStatusEnum;
import com.ly.mp.csc.clue.helper.CacheDataFactory;
import com.ly.mp.csc.clue.idal.mapper.SacClueInfoDlrMapper;
import com.ly.mp.csc.clue.idal.mapper.SacReviewAuditMapper;
import com.ly.mp.csc.clue.service.ISacClueHatchPoolService;
import com.ly.mp.csc.clue.service.ISacReviewAuditService;
import com.ly.mp.csc.clue.service.ISacReviewHisService;
import com.ly.mp.csc.clue.service.ISacReviewService;
import com.ly.mp.csc.clue.service.ISacSystemConfigValueService;
import com.ly.mp.csc.clue.strategy.service.IShCancleBillStrategy;

/**
 * <p>
 * 回访审核表 服务实现类
 * </p>
 *
 * @author ly-busicen
 * @since 2021-08-17
 */
@Service
public class SacReviewAuditService extends ServiceImpl<SacReviewAuditMapper, SacReviewAudit>
implements ISacReviewAuditService, InterceptorWrapperRegist {

	private Logger log = LoggerFactory.getLogger(SacReviewAuditService.class);

	@Autowired
	SacReviewAuditMapper sacReviewAuditMapper;
	@Autowired
	ISacReviewService sacReviewService;
	@Autowired
	ISacReviewHisService sacReviewHisService;
	@Autowired
	ISacSystemConfigValueService sacSystemConfigValueService;
	@Autowired
	CacheDataFactory cacheDataFactory;
	@Autowired
	SacClueInfoDlrMapper sacClueInfoDlrMapper;
	@Autowired
	ISacClueHatchPoolService sacClueHatchPoolService;
	@Autowired
	Message message;
	@Autowired
	IFireFieldRule fireFieldRule;

	/**
	 * 根据主键判断插入或更新
	 *
	 * @param info
	 * @return
	 */
	@Override
	@Transactional(rollbackFor = Exception.class)
	public EntityResult<Map<String, Object>> sacReviewAuditSave(Map<String, Object> mapParam, String token) {
		try {
			Boolean updateFlag = false;
			if (!StringHelper.IsEmptyOrNull(mapParam.get("auditId"))) {
				QueryWrapper<SacReviewAudit> wrapper = new QueryWrapper<>();
				wrapper.lambda().eq(SacReviewAudit::getAuditId, mapParam.get("auditId"));
				if (list(wrapper).size() > 0) {
					updateFlag = true;
				}
			}
			if (!updateFlag) {
				// 新增
				if (StringHelper.IsEmptyOrNull(mapParam.get("auditId"))) {
					// 主键
					mapParam.put("auditId", UUID.randomUUID().toString());
				}
				BusicenUtils.invokeUserInfo(mapParam, SOU.Save, token);
				sacReviewAuditMapper.insertSacReviewAudit(mapParam);
			} else {
				// 更新
				BusicenUtils.invokeUserInfo(mapParam, SOU.Update, "");
				sacReviewAuditMapper.updateSacReviewAudit(mapParam);
			}
			return ResultHandler.updateOk(mapParam);
		} catch (Exception e) {
			log.error("sacReviewAuditSave", e);
			throw e;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public void regist(InterceptorWrapperRegistor registor) {
		// 切点编码要和切点表里面的保持一致
		registor.before("csc_clue_reviewaudit_valid", (context, model) -> {
			checkValidate((Map<String, Object>) context.data().getP()[0]);
		});
		//回访审核撤回前置
		registor.before("csc_clue_review_shenhecancle_valid", (context, model) -> {
			//参数校验
			fireFieldRule.fireRuleExcpt(context.data().getP()[0], "csc-clue-review-shcancle-check", "maindata");
		});

		registor.after("csc_clue_reviewaudit_msg", (context, model) -> {
			Map<String, Object> map = (Map<String, Object>) context.data().getP()[0];

			map.put("reviewId", context.data().getT().get("reviewId"));
			map.put("billCode", context.data().getT().get("billCode"));
			checkAfter(map);
		});
	}

	@Override
	@Interceptor("csc_clue_reviewaudit")
	@Transactional(rollbackFor = Exception.class)
	public OptResult reviewAudit(Map<String, Object> map, String token) {
		try {
			UserBusiEntity user = BusicenContext.getCurrentUserBusiInfo(token);
			Map<String, Object> queryMap = new HashMap<>();
			queryMap.put("auditId", map.get("auditId").toString());
			// 未审核
			queryMap.put("shStatus", "0");
			queryMap.put("orgCode", user.getDlrCode());
			Page<Map<String, Object>> page = new Page<Map<String, Object>>(-1, -1);
			List<Map<String, Object>> queryList = sacReviewAuditMapper.queryListAuditReviewInfo(page, queryMap);
			if (queryList == null || queryList.size() <= 0) {
				//return OptResultBuilder.createFail("该审核单[]" + map.get("auditId").toString() + "不存在！").build();
				throw BusicenException.create("该审核单[]" + map.get("auditId").toString() + "不存在！");
			}

			// 更新审核表
			// invokeUserInfo会把updateControlId更新掉
			String updateControlId = !StringHelper.IsEmptyOrNull(map.get("updateControlId"))
					? map.get("updateControlId").toString()
							: "";
					// 更新
					BusicenUtils.invokeUserInfo(map, SOU.Update, token);
					if (!StringHelper.IsEmptyOrNull(updateControlId)) {
						map.put("updateControlId", updateControlId);
					}
					map.put("shPersonId", user.getUserID());
					map.put("shPersonName", user.getEmpName());
					map.put("reviewId", queryList.get(0).get("reviewId").toString());
					map.put("shTime", LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
					sacReviewAuditMapper.updateSacReviewAudit(map);
					// 更新回访单
					// 回访ID
					map.put("reviewId", queryList.get(0).get("reviewId").toString());
					map.put("rUpdateControlId", queryList.get(0).get("rUpdateControlId").toString());
					map.put("applyTypeCode", queryList.get(0).get("applyTypeCode").toString());
					map.put("applyTypeName", queryList.get(0).get("applyTypeName").toString());
					updateReview(map, token);
					map.put("billCode", queryList.get(0).get("billCode").toString());
					map.put("assignStatus", queryList.get(0).get("assignStatus"));
					// 如果审核通过则先查看系统配置：是否需要回收线索(CLUE_RECYCLE_SWITCH)
					// 线索回收处理(厂商线索不回收，只回收店端的)
					if (ReviewAuditStatusEnum.ok.getResult().equals(map.get("shStatus").toString())
							&& "DLRCLUE".equals(map.get("billType"))) {
						recycleClueHandle(map, token);
					}
		} catch (Exception e) {
			log.error("reviewAudit:", e);
			throw e;
			// throw new BusicenException(message.get("CLUE-SYSTECONFIGVALUE-01"));
		}
		return OptResultBuilder.createOk().build();
	}

	//批量审核
	@Override
	@Transactional(rollbackFor = Exception.class)
	public OptResult reviewAuditBanch(Map<String, Object> map, String token) {
		try {

			//fireFieldRule.fireRuleExcpt(map, "csc-clue-review-check-0006", "maindata");

			if(StringHelper.IsEmptyOrNull(map.get("auditId"))){
				throw new BusicenException("审核ID不能为空！");	
			}
			map.put("article","csc-clue-review-check-0006");
			String[] idArr = map.get("auditId").toString().split(",");
			for(String auditId : idArr){
				map.put("auditId",auditId);
				//直接调用，前置后置会失效
				//reviewAudit(map,token);
				SpringContextHolder.getBean(ISacReviewAuditService.class).reviewAudit(map,token);
			}

		} catch (Exception e) {
			log.error("reviewAuditBanch:", e);
			throw e;
			// throw new BusicenException(message.get("CLUE-SYSTECONFIGVALUE-01"));
		}
		return OptResultBuilder.createOk().build();
	}

	/**
	 * 审核撤回
	 * @param map
	 * @param token
	 * @return
	 */
	@Override
	@Interceptor("csc_clue_review_shenhecancle")
	@Transactional(rollbackFor = Exception.class)
	public OptResult shenheCancle(Map<String, Object> map, String token) {
		try{
			UserBusiEntity user = BusicenContext.getCurrentUserBusiInfo(token);
			//校验
			Map<String, Object> queryMap = new HashMap<>();
			queryMap.put("auditId", map.get("auditId").toString());
			// 审核通过
			queryMap.put("shStatus", "1");
			queryMap.put("orgCode", user.getDlrCode());
			Page<Map<String, Object>> page = new Page<Map<String, Object>>(-1, -1);
			List<Map<String, Object>> queryList = sacReviewAuditMapper.checkAuditReviewInfo(page, queryMap);
			if (queryList == null || queryList.size() <= 0) {
				return OptResultBuilder.createFail("该审核单不存在！").build();
			}

			//获取回访单
			Map<String, Object> queryReviewMap = new HashMap<>();
			queryReviewMap.put("reviewId", queryList.get(0).get("reviewId"));
			QueryWrapper<SacReviewHis> hisWrap = new QueryWrapper<>();
			hisWrap.lambda().eq(SacReviewHis::getReviewId, queryList.get(0).get("reviewId").toString());
			SacReviewHis hisInfo = sacReviewHisService.getOne(hisWrap);
			if(hisInfo==null){
				return OptResultBuilder.createFail("对应的回访单不存在！").build();
			}

			//关联单据校验
			ChooseContext.chooseBeanOrDefault(hisInfo.getBillType().toLowerCase(), IShCancleBillStrategy.class).checkBill(hisInfo.getBillCode(),token);


			//新建回访单
			Map<String, Object> reviewMap = MapUtil.entityToMap(hisInfo);
			reviewMap.put("reviewId", UUID.randomUUID().toString());
			reviewMap.put("reviewStatus", ReviewStatusEnum.reviewing.getResult());
			reviewMap.put("reviewStatusName", ReviewStatusEnum.reviewing.getMsg());
			reviewMap.put("isCome", "0");
			if(reviewMap.containsKey("planComeTime")){
				reviewMap.remove("planComeTime");
			}
			if(reviewMap.containsKey("factComeTime")){
				reviewMap.remove("factComeTime");
			}
			if(reviewMap.containsKey("reviewTime")){
				reviewMap.remove("reviewTime");
			}

			sacReviewService.sacReviewSave(reviewMap, token);


			//更新审核单
			Map<String,Object> updateMap = new HashMap<>();
			updateMap.put("auditId", map.get("auditId").toString());
			updateMap.put("isEnable","0");
			sacReviewAuditSave(updateMap,token);

			//后置参数赋值
			map.put("reviewId", reviewMap.get("revieId"));
			map.put("billType", hisInfo.getBillType());
			map.put("billCode", hisInfo.getBillCode());
			map.put("assignStatus", hisInfo.getAssignStatus());
			map.put("assignTime", hisInfo.getAssignTime());
			map.remove("updateControlId");

			return OptResultBuilder.createOk().build();
		}catch (Exception e) {
			throw e;
		}
	}

	// 更新回访单
	private void updateReview(Map<String, Object> map, String token) {
		Map<String, Object> reviewMap = new HashMap<>();
		reviewMap.put("reviewId", map.get("reviewId").toString());
		// 获取用户信息并赋值
		UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
		reviewMap.put("modifier", userBusiEntity.getUserID());
		reviewMap.put("modifyName", userBusiEntity.getEmpName());
		reviewMap.put("updateControlId", map.get("rUpdateControlId").toString());
		reviewMap.put("reviewDesc", map.get("shDesc").toString() + "(审核人:" + userBusiEntity.getEmpName() + ")");
		// 1审核通过，2驳回
		if (ReviewAuditStatusEnum.ok.getResult().equals(map.get("shStatus").toString())) {
			// 审核通过
			reviewMap.put("reviewStatus", ReviewStatusEnum.end.getResult());
			reviewMap.put("reviewStatusName", ReviewStatusEnum.end.getMsg());
			if (ReviewAuditTypeEnum.defeat.getResult().equals(map.get("applyTypeCode").toString())) {
				reviewMap.put("nodeCode", ReviewNodeEnum.Defeated.getResult());
				reviewMap.put("nodeName", ReviewNodeEnum.Defeated.getMsg());
			} else if (ReviewAuditTypeEnum.notctrl.getResult().equals(map.get("applyTypeCode").toString())) {
				reviewMap.put("nodeCode", ReviewNodeEnum.Notctrled.getResult());
				reviewMap.put("nodeName", ReviewNodeEnum.Notctrled.getMsg());
			} else if (ReviewAuditTypeEnum.invalid.getResult().equals(map.get("applyTypeCode").toString())) {
				reviewMap.put("nodeCode", ReviewNodeEnum.Invalided.getResult());
				reviewMap.put("nodeName", ReviewNodeEnum.Invalided.getMsg() + "通过");
			}

		} else {
			// 驳回
			reviewMap.put("reviewStatus", ReviewStatusEnum.reviewing.getResult());
			reviewMap.put("reviewStatusName", ReviewStatusEnum.reviewing.getMsg());
			if (ReviewAuditTypeEnum.defeat.getResult().equals(map.get("applyTypeCode").toString())) {
				reviewMap.put("nodeCode", ReviewNodeEnum.Undefeat.getResult());
				reviewMap.put("nodeName", ReviewNodeEnum.Undefeat.getMsg());
			} else if (ReviewAuditTypeEnum.notctrl.getResult().equals(map.get("applyTypeCode").toString())) {
				reviewMap.put("nodeCode", ReviewNodeEnum.Unnotctrl.getResult());
				reviewMap.put("nodeName", ReviewNodeEnum.Unnotctrl.getMsg());
			} else if (ReviewAuditTypeEnum.invalid.getResult().equals(map.get("applyTypeCode").toString())) {
				reviewMap.put("nodeCode", ReviewNodeEnum.Uninvalid.getResult());
				reviewMap.put("nodeName", ReviewNodeEnum.Uninvalid.getMsg());
			}
		}
		// 更新回访表
		sacReviewService.sacReviewUpdate(reviewMap, token);

		QueryWrapper<SacReview> query1 = new QueryWrapper<>();
		query1.lambda().eq(SacReview::getReviewId, reviewMap.get("reviewId").toString());
		SacReview reviewInfo = sacReviewService.getOne(query1);

		// 删除回访任务
		if (ReviewAuditStatusEnum.ok.getResult().equals(map.get("shStatus").toString())) {
			deleteReview(reviewInfo.getReviewId());
		} else {
			// 回访历史表重置回访ID
			reviewInfo.setReviewId(UUID.randomUUID().toString());
		}
		// 插入回访历史表
		insertReviewHis(reviewInfo);

		// 用于更新线索
		map.put("nodeCode", reviewMap.get("nodeCode"));
		map.put("nodeName", reviewMap.get("nodeName"));
	}

	/**
	 * 插入回访历史记录
	 *
	 * @param reviewId
	 */
	private void insertReviewHis(SacReview reviewInfo) {
		// 异步
		CompletableFuture.runAsync(() -> {
			try {
				SacReviewHis reviewHis = new SacReviewHis();
				PropertyUtils.copyProperties(reviewHis, reviewInfo);
				sacReviewHisService.save(reviewHis);
			} catch (Exception e) {
				throw BusicenException.create(e.getMessage());
			}
		});

	}

	/**
	 * 删除回访任务
	 *
	 * @param reviewId
	 */
	private void deleteReview(String reviewId) {
		SacReview info = new SacReview();
		info.setReviewId(reviewId);
		sacReviewService.remove(new QueryWrapper<SacReview>(info));
	}

	public void checkAfter(Map<String, Object> mapParam) {

	}

	public void checkValidate(Map<String, Object> mapParam) {
		String article = (String) mapParam.get("article");
		ValidResultCtn fireRule = fireFieldRule.fireRule(mapParam, article, "maindata");
		String resMsg = fireRule.getNotValidMessage();
		if (!fireRule.isValid()) {
			throw new BusicenException(resMsg);
		}
	}

	/**
	 * 判断线索是否需要回收并做相应处理
	 *
	 * @param
	 */
	private void recycleClueHandle(Map<String, Object> map, String token) {
		// 如果审核通过则先查看系统配置：是否需要回收线索(CLUE_RECYCLE_SWITCH)
		String isRecycle = cacheDataFactory.querySysConfigValue("CLUE_RECYCLE_SWITCH", token);
		// 需要则回收线索到线索孵化池(厂商线索不回收，只回收店端的)
		if (!StringHelper.IsEmptyOrNull(isRecycle) && "1".equals(isRecycle) && "DLRCLUE".equals(map.get("billType"))) {
			// 根据店端线索单号查询线索
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("serverOrder", map.get("billCode"));
			Map<String, Object> dlrClueMap = sacClueInfoDlrMapper.selectMapById(paramMap);
			if(dlrClueMap==null) {
				throw new BusicenException("店端线索不存在");
			}
			// 参数设置
			dlrClueMap.put("clueDlrId", dlrClueMap.get("id"));
			dlrClueMap.put("token", token);
			OptResult result = sacClueHatchPoolService.scaClueHatchPoolSave(dlrClueMap);
			if ("0".equals(result.getResult())) {
				throw new BusicenException("店端线索回收失败");
			}
		}
	}
}
