package com.ly.mp.csc.clue.idal.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ly.mp.csc.clue.entities.SacChannelInfo;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * com.ly.mp.csc.clue.idal.mapper.SacChannelInfoMapper
 * 渠道信息
 * @author zhouhao
 * @date 2021/8/25 14:00
 */
public interface SacChannelInfoMapper extends BaseMapper<SacChannelInfo> {

    /**
     * 渠道信息查询
     * @param map 输出参数
     * @return List
     */
    List<Map<String,Object>> selectByAll(@Param("map") Map<String,Object> map);
    
    /**
     * 渠道信息管理查询
     * @param map
     * @return
     */
    List<Map<String,Object>> selectChannelByAll(Page<Map<String,Object>> page,@Param("map") Map<String,Object> map);

    /**
     * 渠道信息保存
     * @param map 输入参数
     * @return int
     */
    int insertChannel(@Param("map") Map<String,Object> map);

    /**
     * 校验渠道编码是否存在
     * @param param 输入参数
     * @return int
     */
    int checkChannelCodeRepeat(@Param("param") Map<String,Object> param);
    /**
     * 校验同级渠道名称是否重复
     * @param param 输入参数
     * @return int
     */
    int checkChannelInfoRepeat(@Param("param") Map<String,Object> param);
    

    /**
     * 渠道信息修改
     * @param map 输入参数
     * @return int
     */
    int updateById(@Param("updated")Map<String,Object> map);

    int countById(@Param("id")String id);
    
    /**
     * 渠道信息关系查下，根据渠道名称向上找渠道列表
     * @param map
     * @return
     */
    List<Map<String,Object>> queryChannelLinkByName(Page<Map<String,Object>> page,@Param("param") Map<String,Object> map);


	}