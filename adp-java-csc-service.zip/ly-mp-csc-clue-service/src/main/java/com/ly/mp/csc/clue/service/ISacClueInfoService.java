package com.ly.mp.csc.clue.service;

import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.entities.SacClueInfo;

/**
 * 总部线索表 服务类
 * @author ly-zhengzc
 * @since 2021-9-11
 *
 */
public interface ISacClueInfoService extends IService<SacClueInfo> {

	/**
	 * 总部线索分页查询
	 * @param paramPage
	 * @return
	 */
	public ListResult<Map<String, Object>> findByPage(ParamPage<Map<String, Object>> paramPage);

	public ListResult<Map<String, Object>> findDistinctDataByPage(ParamPage<Map<String, Object>> paramPage) ;
	/**
	 * 根据id获取对象
	 * @param id
	 * @return
	 */
	public EntityResult<Map<String, Object>> findById(String id, String serverOrder) ;

	/**
	 * 总部线索导出
	 * @param dataInfo
	 * @param token
	 * @param response
	 * @return
	 */
	OptResult exportclue(ParamBase<Map<String,Object>> dataInfo, String token,HttpServletResponse response);

	/**
	 * 总部线索更新
	 * @param param
	 * @param token
	 * @return
	 */
	public OptResult updateMap(Map<String, Object> param, String token) ;
	/**
	 * 总部线索保存
	 * @param clueParam
	 * @return
	 */
	public OptResult saveMap(ParamBase<Map<String, Object>> clueParam, String token) ;

	/**
	 * excel模板导出
	 * @param response
	 * @param pageCode
	 * @param token
	 * @return
	 */
	public OptResult excelTemplateExport(HttpServletResponse response, String pageCode, String token) ;
}
