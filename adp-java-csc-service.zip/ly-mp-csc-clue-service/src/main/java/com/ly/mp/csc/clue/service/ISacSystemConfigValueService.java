package com.ly.mp.csc.clue.service;

import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.entities.SacSystemConfigValue;

/**
 * com.ly.mp.csc.clue.service.ISacSystemConfigValueService
 * 系统配置值接口类
 * @author zhouhao
 * @date 2021/8/18 15:21
 */
public interface ISacSystemConfigValueService extends IService<SacSystemConfigValue>{

	/**
	 * com.ly.mp.csc.clue.service.ISacSystemConfigValueService
	 * 系统配置值保存
	 * @param map 输入参数
	 * @param token token
	 * @return com.ly.mp.component.entities.OptResult
	 * @author zhouhao
	 * @date 2021/8/18 15:20
	 */
	OptResult saveSysteConfigValueInfo(Map<String,Object> map, String token);

	/**
	 * com.ly.mp.csc.clue.service.ISacSystemConfigValueService
	 * 系统配置值查询
	 * @param map 输入参数
	 * @param token token
	 * @return com.ly.mp.component.entities.ListResult<java.util.Map<java.lang.String,java.lang.Object>>
	 * @author zhouhao
	 * @date 2021/8/18 15:20
	 */
	ListResult<Map<String,Object>> queryListSysteConfigValueInfo(ParamPage<Map<String,Object>> map, String token);
	
	/**
	 * 根据配置编码获取配置信息
	 * @param map
	 * @param token
	 * @return
	 */
	ListResult<Map<String,Object>> selectByConfigCode(ParamPage<Map<String,Object>> map, String token);

	/**
	 * 获取配置项信息
	 * @param param
	 * @return
	 */
	List<Map<String,Object>> selectConfigInfo(Map<String, Object> param);
	
	public String getConfigValue(String configCode, String orgCode, String token) ;
}
