package com.ly.mp.csc.clue.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegist;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegistor;
import com.ly.bucn.component.interceptor.annotation.Interceptor;
import com.ly.bucn.component.message.Message;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.constant.UserBusiEntity;
import com.ly.mp.busi.base.context.BusicenContext;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.busi.base.handler.OptResultBuilder;
import com.ly.mp.busicen.rule.field.IFireFieldRule;
import com.ly.mp.busicen.rule.field.execution.ValidResultCtn;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.entities.SacReviewOvertimeSet;
import com.ly.mp.csc.clue.idal.mapper.SacReviewOvertimeSetMapper;
import com.ly.mp.csc.clue.service.ISacReviewOvertimeSetService;
import com.ly.mp.csc.clue.service.ISacSystemConfigValueService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * com.ly.mp.csc.clue.service.impl.SacReviewOvertimeSetService
 * 回访超时规则服务实现类
 * @author zhouhao
 * @date 2021/8/18 15:38
 * Modification History:
 * Date               Author          Version            Description
 *---------------------------------------------------------------------*
 * 2021/9/13 14:28     linliq           v1.0.0       解决工作组保存报错问题
 */
@Service
public class SacReviewOvertimeSetService extends ServiceImpl<SacReviewOvertimeSetMapper, SacReviewOvertimeSet> implements ISacReviewOvertimeSetService, InterceptorWrapperRegist {

    @Autowired
    Message message;
    @Autowired
    IFireFieldRule fireFieldRule;
    @Autowired
    ISacSystemConfigValueService sacSystemConfigValueService;

    @Override
    public ListResult<Map<String,Object>> queryListReviewOvertimeSetInfo(ParamPage<Map<String,Object>> map, String token){
        ListResult<Map<String,Object>> result = new ListResult<Map<String,Object>>();
        try {
        	//查本组织的
        	UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
        	map.getParam().put("orgCode", userBusiEntity.getDlrCode());
        	
            int pageIndex=map.getPageIndex();
            int pageSize=map.getPageSize();

            Page<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);
            List<Map<String, Object>> list = baseMapper.queryListReviewOvertimeInfo(page, map.getParam());
            page.setRecords(list);
            result = BusicenUtils.page2ListResult(page);
        }catch (Exception e){
            e.printStackTrace();
            log.error("queryListSysteConfigValueInfo:",e);
        }
        return result;
    }

    @Override
    @Interceptor("csc_clue_savereviewovertimesetinfo")
    public OptResult saveReviewOvertimeSetInfo(Map<String,Object> map, String token){
        try {
        	//前置赋值
            boolean updateFlag = (boolean)map.get("updateFlag");
            
            //UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
            //前置已经赋值
            //map.put("orgCode",userBusiEntity.getDlrCode());
            //map.put("orgName",userBusiEntity.getDlrName());
            if(!updateFlag){
            	map.put("setId",StringHelper.GetGUID());
            	map.put("isEnable","1");
                BusicenUtils.invokeUserInfo(map, BusicenUtils.SOU.Save,token);
                if(baseMapper.insertReviewOvertimeSet(map)==0){
                    return OptResultBuilder.createFail().Msg(message.get("CLUE-SYSTECONFIGVALUE-02")).result("0").build();
                }
            }else{
            	BusicenUtils.invokeUserInfo(map, BusicenUtils.SOU.Update,token);
                int falg = baseMapper.updateBySetIdAndUpdateControlId(map);
                if(falg==0){
                    return OptResultBuilder.createFail().Msg(message.get("CLUE-SYSTECONFIGVALUE-03")).result("0").build();
                }
            }
        }catch (Exception e){
            e.printStackTrace();
            throw e;
            //throw new BusicenException(message.get("CLUE-SYSTECONFIGVALUE-01"));
        }
        return OptResultBuilder.createOk().build();
    }

    @Override
    public OptResult deleteReviewOvertimeSetInfo(Map<String,Object> map, String token){
        try {
        	ValidResultCtn fireRule = fireFieldRule.fireRule(map, "csc-clue-review-check-0009", "maindata");
            String resMsg = fireRule.getNotValidMessage();
            if (!fireRule.isValid()){
                throw new BusicenException(resMsg);
            }
            String setId = map.get("setId").toString();
            baseMapper.deleteById(setId);
        }catch (Exception e){
            e.printStackTrace();
            throw e;
            //throw new BusicenException(message.get("CLUE-SYSTECONFIGVALUE-01"));
        }
        return OptResultBuilder.createOk().build();
    }

    @SuppressWarnings("unchecked")
	@Override
    public void regist(InterceptorWrapperRegistor registor) {
        //切点编码要和切点表里面的保持一致
        registor.before("csc_clue_savereviewovertimesetinfo_valid", (context, model)->{
            checkValidate((Map<String,Object>)context.data().getP()[0]);
        });
        registor.before("csc_clue_savereviewovertimesetinfo_repeat", (context, model)->{
            checkRepeat((Map<String,Object>)context.data().getP()[0],(String)context.data().getP()[1]);
        });
        registor.before("csc_clue_savereviewovertimesetinfo_check", (context, model)->{
            checkRepeat1((Map<String,Object>)context.data().getP()[0],(String)context.data().getP()[1]);
        });
        registor.after("csc_clue_savereviewovertimesetinfo_msg", (context, model)->{
            checkAfter((Map<String,Object>)context.data().getP()[0]);
        });
    }

    public void checkValidate(Map<String,Object> mapParam)
    {
        ValidResultCtn fireRule = fireFieldRule.fireRule(mapParam, "csc-clue-review-check-0005", "maindata");
        String resMsg = fireRule.getNotValidMessage();
        if (!fireRule.isValid()){
            throw new BusicenException(resMsg);
        }
        //校验二级渠道不为空时,一级渠道是否为空
        if(!StringHelper.IsEmptyOrNull(mapParam.get("infoChanDCode"))&&StringHelper.IsEmptyOrNull(mapParam.get("infoChanMCode"))) {
        	throw new BusicenException(message.get("CSC-MESSAGE-01"));
        }
        //校验三级渠道不为空时,一二级渠道是否为空
        if(!StringHelper.IsEmptyOrNull(mapParam.get("infoChanDDCode"))) {
        	//一二级渠道
        	if(StringHelper.IsEmptyOrNull(mapParam.get("infoChanMCode"))&&StringHelper.IsEmptyOrNull(mapParam.get("infoChanDCode"))) {
        		throw new BusicenException(message.get("CSC-MESSAGE-03"));
        	}
        	//一级渠道校验
        	if(StringHelper.IsEmptyOrNull(mapParam.get("infoChanMCode"))) {
        		throw new BusicenException(message.get("CSC-MESSAGE-01"));
        	}
        	//二级渠道校验
        	if(StringHelper.IsEmptyOrNull(mapParam.get("infoChanDCode"))) {
        		throw new BusicenException(message.get("CSC-MESSAGE-02"));
        	}
        }
    }

    public void checkRepeat(Map<String,Object> mapParam,String token)
    {
        try {
        	UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
        	mapParam.put("orgCode",userBusiEntity.getDlrCode());
        	mapParam.put("orgName",userBusiEntity.getDlrName());
            
            boolean updateFlag = false;
            if(!StringHelper.IsEmptyOrNull(mapParam.get("setId"))){
                int size = baseMapper.countBySetId((String)mapParam.get("setId"));
                if (size > 0) {
                    updateFlag = true;
                }else {
                	throw new BusicenException(message.get("CLUE-REVIEWASSIGN-29"));
                }
            }
            mapParam.put("updateFlag",updateFlag);
        }catch(Exception ex)
        {
            throw ex;
        	//throw new BusicenException(message.get("CLUE-REVIEWOVERTIME-01"));
        }
    }
    public void checkRepeat1(Map<String,Object> mapParam,String token)
    {
    	UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
    	mapParam.put("orgCode",userBusiEntity.getDlrCode());
    	mapParam.put("orgName",userBusiEntity.getDlrName());
    	int check = baseMapper.checkReviewOvertime(mapParam);
        if(check>=1){
        	throw new BusicenException(message.get("CLUE-REVIEWASSIGN-14"));
        }
    }
    public void checkAfter(Map<String,Object> mapParam) {

    }
    
    /**
     * 获取匹配的超时规则
     * @param map
     * @param token
     * @return
     */
    @Override
    public List<Map<String,Object>> machOverTimeRule(Map<String,Object> map, String token){
        try {
        	//获取配置范围configRange：GLOBAL:全局，HOSTDLR:总部和店端，HOST:总部，DLR:店端
        	Map<String, Object> configParam = new HashMap<String, Object>();
        	configParam.put("configCode", "OVERTIME_SWITCH");
        	List<Map<String, Object>> configList =  sacSystemConfigValueService.selectConfigInfo(configParam);
        	if(configList!=null && configList.size()>0){
        		map.put("configRange",configList.get(0).get("configRange"));
        	}
            return baseMapper.machOverTimeRule(map);
        }catch (Exception e){
            e.printStackTrace();
            log.error("machOverTimeRule:",e);
            throw e;
        }
    }
    
    /**
     * 计算超时时间
     * @param map
     * @param token
     * @return
     */
    @Override
    public List<Map<String,Object>> queryBillOverTime(Map<String,Object> map, String token){
        try {
            return baseMapper.queryBillOverTime(map);
        }catch (Exception e){
            e.printStackTrace();
            log.error("queryBillOverTime:",e);
            throw e;
        }
    }
}
