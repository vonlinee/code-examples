package com.ly.mp.csc.clue.service;

import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.csc.clue.entities.DbCarIncolor;

import java.util.Map;

import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 内饰颜色 服务类
 * </p>
 *
 * @author ly-busicen
 * @since 2021-09-07
 */
public interface ISacDbCarIncolorService extends IService<DbCarIncolor> {
	
	public ListResult<Map<String, Object>> carIncolorQuery(ParamPage<Map<String, Object>> mapParam);
}
