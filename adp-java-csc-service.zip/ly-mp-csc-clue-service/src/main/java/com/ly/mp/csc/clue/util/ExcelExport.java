package com.ly.mp.csc.clue.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ly.bucn.component.message.Message;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.busi.base.excel.ExcelData;
import com.ly.mp.busi.base.excel.ExcelDataBuilder;
import com.ly.mp.busi.base.excel.ExcelExportUtil;
import com.ly.mp.busicen.rule.field.IFireFieldRule;
import com.ly.mp.busicen.rule.field.execution.ValidResultCtn;
import com.ly.mp.component.helper.SpringContextHolder;

@Component
public class ExcelExport {

	@Autowired
	public Message message;

	public IFireFieldRule fireFieldRule() {
		return SpringContextHolder.getBean(IFireFieldRule.class);
	}

	public void excelExport(String token, String title, HttpServletResponse response, List<Map<String, Object>> rows,
			List<Map<String, Object>> columnList) {
		try {
			// 处理网格列列表
			List<Map<String, Object>> newColumnList = new ArrayList<Map<String, Object>>();
			for (Map<String, Object> column : columnList) {
				// 字段校验
				ValidResultCtn fireRule = fireFieldRule().fireRule(column, "export-excel-check", "maindata");
				String resMsg = fireRule.getNotValidMessage();
				if (!fireRule.isValid()) {
					throw new BusicenException(resMsg);
				}
				// 将操作列去除
				if ("controlBtn".equals(column.get("prop")) || "操作".equals(column.get("label"))) {
					continue;
				}
				// 去除隐藏列
				if ("true".equals(column.get("hidden"))) {
					continue;
				}
				newColumnList.add(column);
			}

			String[][] columns = new String[newColumnList.size()][2];
			// 获取最新网格列数据，并放入columns数组中
			int j = 0;
			for (Map<String, Object> cloumn : newColumnList) {
				columns[j][0] = cloumn.get("prop").toString();
				columns[j][1] = cloumn.get("label").toString();
				j++;
			}

			ExcelData excelData = null;
			excelData = ExcelDataBuilder.create().title(title).columns(columns).data(rows).build();
			ExcelExportUtil.export(excelData, response);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}
}
