package com.ly.mp.csc.clue.service;

import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.csc.clue.entities.DbCarBrand;

import java.util.Map;

import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 车辆品牌 服务类
 * </p>
 *
 * @author ly-linliq
 * @since 2021-09-07
 */
public interface ISacDbCarBrandService extends IService<DbCarBrand> {

	/**
	 * 
	* @Description: 车辆品牌查询
	* @author: linliq
	* @date 2021/09/07 11:59:14
	* @param dataInfo
	* @return
	 */
	public ListResult<Map<String,Object>> carBrandQuery(ParamPage<Map<String, Object>> mapParam);
}
