package com.ly.mp.csc.clue.review;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.apache.commons.beanutils.PropertyUtils;
import org.springframework.transaction.annotation.Transactional;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ly.mp.busi.base.constant.UserBusiEntity;
import com.ly.mp.busi.base.context.BusicenContext;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.busi.base.handler.ResultHandler;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.helper.SpringContextHolder;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.entities.SacReview;
import com.ly.mp.csc.clue.entities.SacReviewAudit;
import com.ly.mp.csc.clue.entities.SacReviewHis;
import com.ly.mp.csc.clue.enums.ReviewAuditStatusEnum;
import com.ly.mp.csc.clue.enums.ReviewStatusEnum;
import com.ly.mp.csc.clue.service.ISacReviewAuditService;
import com.ly.mp.csc.clue.service.ISacReviewHisService;
import com.ly.mp.csc.clue.service.ISacReviewService;

/**
 * 回访基类
 * @author ly-shenyw
 *
 */
public abstract class AbstractClueReview {

	//[start] getBean
	public ISacReviewService sacReviewService(){
		return SpringContextHolder.getBean(ISacReviewService.class);
	}

	public ISacReviewHisService sacReviewHisService(){
		return SpringContextHolder.getBean(ISacReviewHisService.class);
	}

	public ISacReviewAuditService sacReviewAuditService(){
		return SpringContextHolder.getBean(ISacReviewAuditService.class);
	}
	
	public Executor asyncTaskExecutor(){
		//注入线程池的bean
		return SpringContextHolder.getBean("asyncTaskExecutor");
	};   
	//线程池
	//private static final ThreadPoolExecutor threadPool = new ThreadPoolExecutor(10,20,1,TimeUnit.MINUTES,new LinkedBlockingQueue<>(10));
	//[end]

	/**
	 * 初始化数据
	 * @param reviewMap
	 * @param token
	 */
	public void InitData(Map<String, Object> reviewMap,String token){
		try{

		}catch (Exception e) {
			throw e;
		}
	}

	/**
	 * 回访
	 * @param reviewMap
	 * @param token
	 * @return
	 */
	@Transactional(rollbackFor = Exception.class)
	public EntityResult<Map<String, Object>> review(Map<String, Object> reviewMap,String token){
		//获取用户信息并赋值
		UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
				
		//前置操作
		before(reviewMap,token);
		//更新回访任务
		SacReview reviewInfo = saveReview(reviewMap,token);
		//执行其他操作--子场景实现
		handle(reviewMap, token);
		
		//生成历史表的回访ID
		String reviewIdHis=UUID.randomUUID().toString();
		//回访人(当前处理人，因为回访人不一定是当前处理人)
		reviewInfo.setReviewPersonId(userBusiEntity.getUserID());
		reviewInfo.setReviewPersonName(userBusiEntity.getEmpName());
		if(ReviewStatusEnum.end.getResult().equals(reviewInfo.getReviewStatus())){
			reviewIdHis=reviewInfo.getReviewId();
		}
		//异步操作放在最后
		//插入回访历史记录
		insertReviewHis(reviewInfo,reviewIdHis);
		//返回结果
		return ResultHandler.updateOk(reviewMap);
	}

	/**
	 * 前置操作
	 * @param reviewMap
	 * @param token
	 */
	public abstract void before(Map<String, Object> reviewMap,String token);

	/**
	 * 最后执行其他操作
	 * @param reviewMap
	 * @return
	 */
	public abstract void handle(Map<String, Object> reviewMap,String token);

	/**
	 * 更新回访任务
	 * @param reviewMap
	 */
	public SacReview saveReview(Map<String, Object> reviewMap,String token){
		//实际到店时间
		String factComeTime=null;
		//是否到店
		String isCome="0";
		if(!StringHelper.IsEmptyOrNull(reviewMap.get("factComeTime"))){
			factComeTime=reviewMap.get("factComeTime").toString();
			isCome="1";

			//回访任务表不保存，只保存到历史表
			reviewMap.remove("factComeTime");
			reviewMap.remove("isCome");
		};

		//扩展字段转换
		String oldJsonStr="";
		if(!StringHelper.IsEmptyOrNull(reviewMap.get("oldJsonStr"))){
			oldJsonStr=reviewMap.get("oldJsonStr").toString();
		}
		Map<String, Object> newMap = sacReviewService().transFiled(oldJsonStr, reviewMap);

		//计算超时时间
		String overTime = sacReviewService().queryOverTime("2", reviewMap, token);
		newMap.put("overReviewTime", overTime);

		sacReviewService().sacReviewUpdate(newMap,token);
		QueryWrapper<SacReview> query1 = new QueryWrapper<>();
		query1.lambda().eq(SacReview::getReviewId, reviewMap.get("reviewId").toString());
		SacReview reviewInfo =  sacReviewService().getOne(query1);

		//下面的是历史表的其他参数
		//是否到店
		DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		if(!StringHelper.IsEmptyOrNull(factComeTime)){
			reviewInfo.setFactComeTime(LocalDateTime.parse(factComeTime, fmt));
		}
		reviewInfo.setIsCome(isCome);
		//实际回访实际
		reviewInfo.setReviewTime(LocalDateTime.now());
		return reviewInfo;
	}

	/**
	 * 插入回访历史记录
	 * @param reviewId
	 */
	public void insertReviewHis(SacReview reviewInfo,String reviewIdHis){
		//异步
		CompletableFuture.runAsync(() -> {
			try{
				System.out.println("当前线程：" + Thread.currentThread().getId());
				System.out.println("当前线程：" + Thread.currentThread().getName());
				SacReviewHis reviewHis = new SacReviewHis();
				PropertyUtils.copyProperties(reviewHis,reviewInfo);
				reviewHis.setReviewId(reviewIdHis);
				if(StringHelper.IsEmptyOrNull(reviewHis.getGroupId())){
					reviewHis.setGroupId("1");
				}
				if(StringHelper.IsEmptyOrNull(reviewHis.getOemId())){
					reviewHis.setOemId("1");
				}
				sacReviewHisService().save(reviewHis);
			}catch (Exception e) {
				throw BusicenException.create(e.getMessage());
			}
		},asyncTaskExecutor());

	}

	/**
	 * 删除回访任务
	 * @param reviewId
	 */
	public void deleteReview(String reviewId){
		SacReview info = new SacReview();
		info.setReviewId(reviewId);
		sacReviewService().remove(new QueryWrapper<SacReview>(info));
	}

	/**
	 * 校验是否存在未审核的记录
	 * @param reviewId
	 */
	public void checkAudit(String reviewId){
		QueryWrapper<SacReviewAudit> query = new QueryWrapper<>();
		query.lambda().eq(SacReviewAudit::getReviewId, reviewId);
		query.lambda().eq(SacReviewAudit::getShStatus, ReviewAuditStatusEnum.unAudit.getResult());
		int num = sacReviewAuditService().list(query).size();
		if(num>0){
			throw BusicenException.create("该回访单存在未审核的记录，请审核后再处理！");
		}
	}


}
