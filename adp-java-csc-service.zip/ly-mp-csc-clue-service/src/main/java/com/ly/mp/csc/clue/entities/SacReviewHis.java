package com.ly.mp.csc.clue.entities;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;


/**
 * <p>
 * 回访任务历史表
 * </p>
 *
 * @author ly-busicen
 * @since 2021-08-17
 */
@TableName("t_sac_review_his")
public class SacReviewHis implements Serializable {

	private static final long serialVersionUID = 1L;

    /**
     * 回访ID
     */
    @TableId("REVIEW_ID")
    private String reviewId;

    /**
     * 所属组织
     */
    @TableField("ORG_CODE")
    private String orgCode;

    /**
     * 所属组织名称
     */
    @TableField("ORG_NAME")
    private String orgName;

    /**
     * 回访单据类型
     */
    @TableField("BILL_TYPE")
    private String billType;

    /**
     * 回访单据类型名称
     */
    @TableField("BILL_TYPE_NAME")
    private String billTypeName;

    /**
     * 回访单据业务类型
     */
    @TableField("BUSINESS_TYPE")
    private String businessType;

    /**
     * 回访单据业务类型名称
     */
    @TableField("BUSINESS_TYPE_NAME")
    private String businessTypeName;

    /**
     * 一级信息来源编码
     */
    @TableField("INFO_CHAN_M_CODE")
    private String infoChanMCode;

    /**
     * 一级信息来源名称
     */
    @TableField("INFO_CHAN_M_NAME")
    private String infoChanMName;

    /**
     * 二级信息来源编码
     */
    @TableField("INFO_CHAN_D_CODE")
    private String infoChanDCode;

    /**
     * 二级信息来源名称
     */
    @TableField("INFO_CHAN_D_NAME")
    private String infoChanDName;

    /**
     * 三级信息来源编码
     */
    @TableField("INFO_CHAN_DD_CODE")
    private String infoChanDdCode;

    /**
     * 三级信息来源名称
     */
    @TableField("INFO_CHAN_DD_NAME")
    private String infoChanDdName;

    /**
     * 最低一级的信息来源编码
     */
    @TableField("CHANNEL_CODE")
    private String channelCode;

    /**
     * 最低一级的信息来源名称
     */
    @TableField("CHANNEL_NAME")
    private String channelName;

    /**
     * 关联业务单号
     */
    @TableField("BILL_CODE")
    private String billCode;

    /**
     * 计划回访时间
     */
    @TableField("PLAN_REVIEW_TIME")
    private LocalDateTime planReviewTime;

    /**
     * 实际回访时间
     */
    @TableField("REVIEW_TIME")
    private LocalDateTime reviewTime;

    /**
     * 上次回访时间
     */
    @TableField("LAST_REVIEW_TIME")
    private LocalDateTime lastReviewTime;

    /**
     * 超期回访时间(到这个时间算超期)
     */
    @TableField("OVER_REVIEW_TIME")
    private LocalDateTime overReviewTime;

    /**
     * 计划到店时间
     */
    @TableField("PLAN_COME_TIME")
    private LocalDateTime planComeTime;

    /**
     * 实际到店时间
     */
    @TableField("FACT_COME_TIME")
    private LocalDateTime factComeTime;

    /**
     * 是否到店
     */
    @TableField("IS_COME")
    private String isCome;

    /**
     * 分配状态
     */
    @TableField("ASSIGN_STATUS")
    private String assignStatus;

    /**
     * 分配状态名称
     */
    @TableField("ASSIGN_STATUS_NAME")
    private String assignStatusName;

    /**
     * 分配时间
     */
    @TableField("ASSIGN_TIME")
    private LocalDateTime assignTime;

    /**
     * 分配人用户ID
     */
    @TableField("ASSIGN_PERSON_ID")
    private String assignPersonId;

    /**
     * 分配人名称
     */
    @TableField("ASSIGN_PERSON_NAME")
    private String assignPersonName;

    /**
     * 回访人员用户ID
     */
    @TableField("REVIEW_PERSON_ID")
    private String reviewPersonId;

    /**
     * 回访人员名称
     */
    @TableField("REVIEW_PERSON_NAME")
    private String reviewPersonName;

    /**
     * 回访内容
     */
    @TableField("REVIEW_DESC")
    private String reviewDesc;

    /**
     * 回访状态编码
     */
    @TableField("REVIEW_STATUS")
    private String reviewStatus;

    /**
     * 回访状态名称
     */
    @TableField("REVIEW_STATUS_NAME")
    private String reviewStatusName;

    /**
     * 客户ID
     */
    @TableField("CUST_ID")
    private String custId;

    /**
     * 客户名称
     */
    @TableField("CUST_NAME")
    private String custName;

    /**
     * 客户手机号
     */
    @TableField("PHONE")
    private String phone;

    /**
     * 客户性别
     */
    @TableField("GENDER")
    private String gender;

    /**
     * 客户性别名称
     */
    @TableField("GENDER_NAME")
    private String genderName;

    /**
     * 接触状态编码
     */
    @TableField("TOUCH_STATUS")
    private String touchStatus;

    /**
     * 接触状态名称
     */
    @TableField("TOUCH_STATUS_NAME")
    private String touchStatusName;

    /**
     * 异常(战败失控)原因编码
     */
    @TableField("ERROR_REASON_CODE")
    private String errorReasonCode;

    /**
     * 异常(战败失控)原因名称
     */
    @TableField("ERROR_REASON_NAME")
    private String errorReasonName;

    /**
     * 节点编码
     */
    @TableField("NODE_CODE")
    private String nodeCode;

    /**
     * 节点名称
     */
    @TableField("NODE_NAME")
    private String nodeName;

    /**
     * 下发经销商编码
     */
    @TableField("SEND_DLR_CODE")
    private String sendDlrCode;

    /**
     * 下发经销商名称
     */
    @TableField("SEND_DLR_SHORT_NAME")
    private String sendDlrShortName;

    /**
     * 下发时间
     */
    @TableField("SEND_TIME")
    private LocalDateTime sendTime;

    /**
     * 意向级别编码
     */
    @TableField("INTEN_LEVEL_CODE")
    private String intenLevelCode;

    /**
     * 意向级别名称
     */
    @TableField("INTEN_LEVEL_NAME")
    private String intenLevelName;

    /**
     * 意向品牌编码
     */
    @TableField("INTEN_BRAND_CODE")
    private String intenBrandCode;

    /**
     * 意向品牌名称
     */
    @TableField("INTEN_BRAND_NAME")
    private String intenBrandName;

    /**
     * 意向车系编码
     */
    @TableField("INTEN_SERIES_CODE")
    private String intenSeriesCode;

    /**
     * 意向车系名称
     */
    @TableField("INTEN_SERIES_NAME")
    private String intenSeriesName;

    /**
     * 意向车型编码
     */
    @TableField("INTEN_CAR_TYPE_CODE")
    private String intenCarTypeCode;

    /**
     * 意向车型名称
     */
    @TableField("INTEN_CAR_TYPE_NAME")
    private String intenCarTypeName;

    /**
     * 扩展字段1
     */
    @TableField("COLUMN1")
    private String column1;

    /**
     * 扩展字段2
     */
    @TableField("COLUMN2")
    private String column2;

    /**
     * 扩展字段3
     */
    @TableField("COLUMN3")
    private String column3;

    /**
     * 扩展字段4
     */
    @TableField("COLUMN4")
    private String column4;

    /**
     * 扩展字段5
     */
    @TableField("COLUMN5")
    private String column5;

    /**
     * 扩展字段6
     */
    @TableField("COLUMN6")
    private String column6;

    /**
     * 扩展字段7
     */
    @TableField("COLUMN7")
    private String column7;

    /**
     * 扩展字段8
     */
    @TableField("COLUMN8")
    private String column8;

    /**
     * 扩展字段9
     */
    @TableField("COLUMN9")
    private String column9;

    /**
     * 扩展字段10
     */
    @TableField("COLUMN10")
    private String column10;

    /**
     * 扩展字段11
     */
    @TableField("COLUMN11")
    private String column11;

    /**
     * 扩展字段12
     */
    @TableField("COLUMN12")
    private String column12;

    /**
     * 扩展字段13
     */
    @TableField("COLUMN13")
    private String column13;

    /**
     * 扩展字段14
     */
    @TableField("COLUMN14")
    private String column14;

    /**
     * 扩展字段15
     */
    @TableField("COLUMN15")
    private String column15;

    /**
     * 扩展字段16
     */
    @TableField("COLUMN16")
    private String column16;

    /**
     * 扩展字段17
     */
    @TableField("COLUMN17")
    private String column17;

    /**
     * 扩展字段18
     */
    @TableField("COLUMN18")
    private String column18;

    /**
     * 扩展字段19
     */
    @TableField("COLUMN19")
    private String column19;

    /**
     * 扩展字段20
     */
    @TableField("COLUMN20")
    private String column20;

    /**
     * 大字段1
     */
    @TableField("BIG_COLUMN1")
    private String bigColumn1;

    /**
     * 大字段2
     */
    @TableField("BIG_COLUMN2")
    private String bigColumn2;

    /**
     * 大字段3
     */
    @TableField("BIG_COLUMN3")
    private String bigColumn3;

    /**
     * 大字段4
     */
    @TableField("BIG_COLUMN4")
    private String bigColumn4;

    /**
     * 大字段5
     */
    @TableField("BIG_COLUMN5")
    private String bigColumn5;

    /**
     * JSON扩展字段
     */
    @TableField("EXTENDS_JSON")
    private String extendsJson;

    /**
     * 厂商标识ID
     */
    @TableField("OEM_ID")
    private String oemId;

    /**
     * 集团标识ID
     */
    @TableField("GROUP_ID")
    private String groupId;

    /**
     * 创建人ID
     */
    @TableField(value = "CREATOR", fill = FieldFill.INSERT)
    private String creator;

    /**
     * 创建人
     */
    @TableField(value = "CREATED_NAME", fill = FieldFill.INSERT)
    private String createdName;

    /**
     * 创建日期
     */
    @TableField(value = "CREATED_DATE", fill = FieldFill.INSERT)
    private LocalDateTime createdDate;

    /**
     * 修改人ID
     */
    @TableField(value = "MODIFIER", fill = FieldFill.INSERT_UPDATE)
    private String modifier;

    /**
     * 修改人
     */
    @TableField(value = "MODIFY_NAME", fill = FieldFill.INSERT_UPDATE)
    private String modifyName;

    /**
     * 最后更新日期
     */
    @TableField(value = "LAST_UPDATED_DATE", fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime lastUpdatedDate;

    /**
     * 是否可用
     */
    @TableField("IS_ENABLE")
    private String isEnable;

    /**
     * 并发控制ID
     */
    @TableField(value = "UPDATE_CONTROL_ID", fill = FieldFill.INSERT_UPDATE)
    private String updateControlId;

    /**
     * 省份编码
     */
    @TableField("PROVINCE_CODE")
    private String provinceCode;

    /**
     * 省份名称
     */
    @TableField("PROVINCE_NAME")
    private String provinceName;

    /**
     * 城市编码
     */
    @TableField("CITY_CODE")
    private String cityCode;

    /**
     * 城市名称
     */
    @TableField("CITY_NAME")
    private String cityName;

    /**
     * 区县编码
     */
    @TableField("COUNTY_CODE")
    private String countyCode;

    /**
     * 区县名称
     */
    @TableField("COUNTY_NAME")
    private String countyName;

    public String getReviewId() {
        return reviewId;
    }

    public void setReviewId(String reviewId) {
        this.reviewId = reviewId;
    }
    public String getOrgCode() {
        return orgCode;
    }

    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }
    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }
    public String getBillType() {
        return billType;
    }

    public void setBillType(String billType) {
        this.billType = billType;
    }
    public String getBillTypeName() {
        return billTypeName;
    }

    public void setBillTypeName(String billTypeName) {
        this.billTypeName = billTypeName;
    }
    public String getBusinessType() {
        return businessType;
    }

    public void setBusinessType(String businessType) {
        this.businessType = businessType;
    }
    public String getBusinessTypeName() {
        return businessTypeName;
    }

    public void setBusinessTypeName(String businessTypeName) {
        this.businessTypeName = businessTypeName;
    }
    public String getInfoChanMCode() {
        return infoChanMCode;
    }

    public void setInfoChanMCode(String infoChanMCode) {
        this.infoChanMCode = infoChanMCode;
    }
    public String getInfoChanMName() {
        return infoChanMName;
    }

    public void setInfoChanMName(String infoChanMName) {
        this.infoChanMName = infoChanMName;
    }
    public String getInfoChanDCode() {
        return infoChanDCode;
    }

    public void setInfoChanDCode(String infoChanDCode) {
        this.infoChanDCode = infoChanDCode;
    }
    public String getInfoChanDName() {
        return infoChanDName;
    }

    public void setInfoChanDName(String infoChanDName) {
        this.infoChanDName = infoChanDName;
    }
    public String getInfoChanDdCode() {
        return infoChanDdCode;
    }

    public void setInfoChanDdCode(String infoChanDdCode) {
        this.infoChanDdCode = infoChanDdCode;
    }
    public String getInfoChanDdName() {
        return infoChanDdName;
    }

    public void setInfoChanDdName(String infoChanDdName) {
        this.infoChanDdName = infoChanDdName;
    }
    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }
    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }
    public String getBillCode() {
        return billCode;
    }

    public void setBillCode(String billCode) {
        this.billCode = billCode;
    }
    public LocalDateTime getPlanReviewTime() {
        return planReviewTime;
    }

    public void setPlanReviewTime(LocalDateTime planReviewTime) {
        this.planReviewTime = planReviewTime;
    }
    public LocalDateTime getReviewTime() {
        return reviewTime;
    }

    public void setReviewTime(LocalDateTime reviewTime) {
        this.reviewTime = reviewTime;
    }
    public LocalDateTime getLastReviewTime() {
        return lastReviewTime;
    }

    public void setLastReviewTime(LocalDateTime lastReviewTime) {
        this.lastReviewTime = lastReviewTime;
    }
    public LocalDateTime getOverReviewTime() {
        return overReviewTime;
    }

    public void setOverReviewTime(LocalDateTime overReviewTime) {
        this.overReviewTime = overReviewTime;
    }
    public LocalDateTime getPlanComeTime() {
        return planComeTime;
    }

    public void setPlanComeTime(LocalDateTime planComeTime) {
        this.planComeTime = planComeTime;
    }
    public LocalDateTime getFactComeTime() {
        return factComeTime;
    }

    public void setFactComeTime(LocalDateTime factComeTime) {
        this.factComeTime = factComeTime;
    }
    public String getIsCome() {
        return isCome;
    }

    public void setIsCome(String isCome) {
        this.isCome = isCome;
    }
    public String getAssignStatus() {
        return assignStatus;
    }

    public void setAssignStatus(String assignStatus) {
        this.assignStatus = assignStatus;
    }
    public String getAssignStatusName() {
        return assignStatusName;
    }

    public void setAssignStatusName(String assignStatusName) {
        this.assignStatusName = assignStatusName;
    }
    public LocalDateTime getAssignTime() {
        return assignTime;
    }

    public void setAssignTime(LocalDateTime assignTime) {
        this.assignTime = assignTime;
    }
    public String getAssignPersonId() {
        return assignPersonId;
    }

    public void setAssignPersonId(String assignPersonId) {
        this.assignPersonId = assignPersonId;
    }
    public String getAssignPersonName() {
        return assignPersonName;
    }

    public void setAssignPersonName(String assignPersonName) {
        this.assignPersonName = assignPersonName;
    }
    public String getReviewPersonId() {
        return reviewPersonId;
    }

    public void setReviewPersonId(String reviewPersonId) {
        this.reviewPersonId = reviewPersonId;
    }
    public String getReviewPersonName() {
        return reviewPersonName;
    }

    public void setReviewPersonName(String reviewPersonName) {
        this.reviewPersonName = reviewPersonName;
    }
    public String getReviewDesc() {
        return reviewDesc;
    }

    public void setReviewDesc(String reviewDesc) {
        this.reviewDesc = reviewDesc;
    }
    public String getReviewStatus() {
        return reviewStatus;
    }

    public void setReviewStatus(String reviewStatus) {
        this.reviewStatus = reviewStatus;
    }
    public String getReviewStatusName() {
        return reviewStatusName;
    }

    public void setReviewStatusName(String reviewStatusName) {
        this.reviewStatusName = reviewStatusName;
    }
    public String getCustId() {
        return custId;
    }

    public void setCustId(String custId) {
        this.custId = custId;
    }
    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }
    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }
    public String getGenderName() {
        return genderName;
    }

    public void setGenderName(String genderName) {
        this.genderName = genderName;
    }
    public String getTouchStatus() {
        return touchStatus;
    }

    public void setTouchStatus(String touchStatus) {
        this.touchStatus = touchStatus;
    }
    public String getTouchStatusName() {
        return touchStatusName;
    }

    public void setTouchStatusName(String touchStatusName) {
        this.touchStatusName = touchStatusName;
    }
    public String getErrorReasonCode() {
        return errorReasonCode;
    }

    public void setErrorReasonCode(String errorReasonCode) {
        this.errorReasonCode = errorReasonCode;
    }
    public String getErrorReasonName() {
        return errorReasonName;
    }

    public void setErrorReasonName(String errorReasonName) {
        this.errorReasonName = errorReasonName;
    }
    public String getNodeCode() {
        return nodeCode;
    }

    public void setNodeCode(String nodeCode) {
        this.nodeCode = nodeCode;
    }
    public String getNodeName() {
        return nodeName;
    }

    public void setNodeName(String nodeName) {
        this.nodeName = nodeName;
    }
    public String getSendDlrCode() {
        return sendDlrCode;
    }

    public void setSendDlrCode(String sendDlrCode) {
        this.sendDlrCode = sendDlrCode;
    }
    public String getSendDlrShortName() {
        return sendDlrShortName;
    }

    public void setSendDlrShortName(String sendDlrShortName) {
        this.sendDlrShortName = sendDlrShortName;
    }
    public LocalDateTime getSendTime() {
        return sendTime;
    }

    public void setSendTime(LocalDateTime sendTime) {
        this.sendTime = sendTime;
    }
    public String getIntenLevelCode() {
        return intenLevelCode;
    }

    public void setIntenLevelCode(String intenLevelCode) {
        this.intenLevelCode = intenLevelCode;
    }
    public String getIntenLevelName() {
        return intenLevelName;
    }

    public void setIntenLevelName(String intenLevelName) {
        this.intenLevelName = intenLevelName;
    }
    public String getIntenBrandCode() {
        return intenBrandCode;
    }

    public void setIntenBrandCode(String intenBrandCode) {
        this.intenBrandCode = intenBrandCode;
    }
    public String getIntenBrandName() {
        return intenBrandName;
    }

    public void setIntenBrandName(String intenBrandName) {
        this.intenBrandName = intenBrandName;
    }
    public String getIntenSeriesCode() {
        return intenSeriesCode;
    }

    public void setIntenSeriesCode(String intenSeriesCode) {
        this.intenSeriesCode = intenSeriesCode;
    }
    public String getIntenSeriesName() {
        return intenSeriesName;
    }

    public void setIntenSeriesName(String intenSeriesName) {
        this.intenSeriesName = intenSeriesName;
    }
    public String getIntenCarTypeCode() {
        return intenCarTypeCode;
    }

    public void setIntenCarTypeCode(String intenCarTypeCode) {
        this.intenCarTypeCode = intenCarTypeCode;
    }
    public String getIntenCarTypeName() {
        return intenCarTypeName;
    }

    public void setIntenCarTypeName(String intenCarTypeName) {
        this.intenCarTypeName = intenCarTypeName;
    }
    public String getColumn1() {
        return column1;
    }

    public void setColumn1(String column1) {
        this.column1 = column1;
    }
    public String getColumn2() {
        return column2;
    }

    public void setColumn2(String column2) {
        this.column2 = column2;
    }
    public String getColumn3() {
        return column3;
    }

    public void setColumn3(String column3) {
        this.column3 = column3;
    }
    public String getColumn4() {
        return column4;
    }

    public void setColumn4(String column4) {
        this.column4 = column4;
    }
    public String getColumn5() {
        return column5;
    }

    public void setColumn5(String column5) {
        this.column5 = column5;
    }
    public String getColumn6() {
        return column6;
    }

    public void setColumn6(String column6) {
        this.column6 = column6;
    }
    public String getColumn7() {
        return column7;
    }

    public void setColumn7(String column7) {
        this.column7 = column7;
    }
    public String getColumn8() {
        return column8;
    }

    public void setColumn8(String column8) {
        this.column8 = column8;
    }
    public String getColumn9() {
        return column9;
    }

    public void setColumn9(String column9) {
        this.column9 = column9;
    }
    public String getColumn10() {
        return column10;
    }

    public void setColumn10(String column10) {
        this.column10 = column10;
    }
    public String getColumn11() {
        return column11;
    }

    public void setColumn11(String column11) {
        this.column11 = column11;
    }
    public String getColumn12() {
        return column12;
    }

    public void setColumn12(String column12) {
        this.column12 = column12;
    }
    public String getColumn13() {
        return column13;
    }

    public void setColumn13(String column13) {
        this.column13 = column13;
    }
    public String getColumn14() {
        return column14;
    }

    public void setColumn14(String column14) {
        this.column14 = column14;
    }
    public String getColumn15() {
        return column15;
    }

    public void setColumn15(String column15) {
        this.column15 = column15;
    }
    public String getColumn16() {
        return column16;
    }

    public void setColumn16(String column16) {
        this.column16 = column16;
    }
    public String getColumn17() {
        return column17;
    }

    public void setColumn17(String column17) {
        this.column17 = column17;
    }
    public String getColumn18() {
        return column18;
    }

    public void setColumn18(String column18) {
        this.column18 = column18;
    }
    public String getColumn19() {
        return column19;
    }

    public void setColumn19(String column19) {
        this.column19 = column19;
    }
    public String getColumn20() {
        return column20;
    }

    public void setColumn20(String column20) {
        this.column20 = column20;
    }
    public String getBigColumn1() {
        return bigColumn1;
    }

    public void setBigColumn1(String bigColumn1) {
        this.bigColumn1 = bigColumn1;
    }
    public String getBigColumn2() {
        return bigColumn2;
    }

    public void setBigColumn2(String bigColumn2) {
        this.bigColumn2 = bigColumn2;
    }
    public String getBigColumn3() {
        return bigColumn3;
    }

    public void setBigColumn3(String bigColumn3) {
        this.bigColumn3 = bigColumn3;
    }
    public String getBigColumn4() {
        return bigColumn4;
    }

    public void setBigColumn4(String bigColumn4) {
        this.bigColumn4 = bigColumn4;
    }
    public String getBigColumn5() {
        return bigColumn5;
    }

    public void setBigColumn5(String bigColumn5) {
        this.bigColumn5 = bigColumn5;
    }
    public String getExtendsJson() {
        return extendsJson;
    }

    public void setExtendsJson(String extendsJson) {
        this.extendsJson = extendsJson;
    }
    public String getOemId() {
        return oemId;
    }

    public void setOemId(String oemId) {
        this.oemId = oemId;
    }
    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }
    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }
    public String getCreatedName() {
        return createdName;
    }

    public void setCreatedName(String createdName) {
        this.createdName = createdName;
    }
    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }
    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier;
    }
    public String getModifyName() {
        return modifyName;
    }

    public void setModifyName(String modifyName) {
        this.modifyName = modifyName;
    }
    public LocalDateTime getLastUpdatedDate() {
        return lastUpdatedDate;
    }

    public void setLastUpdatedDate(LocalDateTime lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }
    public String getIsEnable() {
        return isEnable;
    }

    public void setIsEnable(String isEnable) {
        this.isEnable = isEnable;
    }
    public String getUpdateControlId() {
        return updateControlId;
    }

    public void setUpdateControlId(String updateControlId) {
        this.updateControlId = updateControlId;
    }
    public String getProvinceCode() {
        return provinceCode;
    }

    public void setProvinceCode(String provinceCode) {
        this.provinceCode = provinceCode;
    }
    public String getProvinceName() {
        return provinceName;
    }

    public void setProvinceName(String provinceName) {
        this.provinceName = provinceName;
    }
    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }
    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }
    public String getCountyCode() {
        return countyCode;
    }

    public void setCountyCode(String countyCode) {
        this.countyCode = countyCode;
    }
    public String getCountyName() {
        return countyName;
    }

    public void setCountyName(String countyName) {
        this.countyName = countyName;
    }

    @Override
    public String toString() {
        return "SacReviewHis{" +
        "reviewId=" + reviewId +
        ", orgCode=" + orgCode +
        ", orgName=" + orgName +
        ", billType=" + billType +
        ", billTypeName=" + billTypeName +
        ", businessType=" + businessType +
        ", businessTypeName=" + businessTypeName +
        ", infoChanMCode=" + infoChanMCode +
        ", infoChanMName=" + infoChanMName +
        ", infoChanDCode=" + infoChanDCode +
        ", infoChanDName=" + infoChanDName +
        ", infoChanDdCode=" + infoChanDdCode +
        ", infoChanDdName=" + infoChanDdName +
        ", channelCode=" + channelCode +
        ", channelName=" + channelName +
        ", billCode=" + billCode +
        ", planReviewTime=" + planReviewTime +
        ", reviewTime=" + reviewTime +
        ", lastReviewTime=" + lastReviewTime +
        ", overReviewTime=" + overReviewTime +
        ", planComeTime=" + planComeTime +
        ", factComeTime=" + factComeTime +
        ", isCome=" + isCome +
        ", assignStatus=" + assignStatus +
        ", assignStatusName=" + assignStatusName +
        ", assignTime=" + assignTime +
        ", assignPersonId=" + assignPersonId +
        ", assignPersonName=" + assignPersonName +
        ", reviewPersonId=" + reviewPersonId +
        ", reviewPersonName=" + reviewPersonName +
        ", reviewDesc=" + reviewDesc +
        ", reviewStatus=" + reviewStatus +
        ", reviewStatusName=" + reviewStatusName +
        ", custId=" + custId +
        ", custName=" + custName +
        ", phone=" + phone +
        ", gender=" + gender +
        ", genderName=" + genderName +
        ", touchStatus=" + touchStatus +
        ", touchStatusName=" + touchStatusName +
        ", errorReasonCode=" + errorReasonCode +
        ", errorReasonName=" + errorReasonName +
        ", nodeCode=" + nodeCode +
        ", nodeName=" + nodeName +
        ", sendDlrCode=" + sendDlrCode +
        ", sendDlrShortName=" + sendDlrShortName +
        ", sendTime=" + sendTime +
        ", intenLevelCode=" + intenLevelCode +
        ", intenLevelName=" + intenLevelName +
        ", intenBrandCode=" + intenBrandCode +
        ", intenBrandName=" + intenBrandName +
        ", intenSeriesCode=" + intenSeriesCode +
        ", intenSeriesName=" + intenSeriesName +
        ", intenCarTypeCode=" + intenCarTypeCode +
        ", intenCarTypeName=" + intenCarTypeName +
        ", column1=" + column1 +
        ", column2=" + column2 +
        ", column3=" + column3 +
        ", column4=" + column4 +
        ", column5=" + column5 +
        ", column6=" + column6 +
        ", column7=" + column7 +
        ", column8=" + column8 +
        ", column9=" + column9 +
        ", column10=" + column10 +
        ", column11=" + column11 +
        ", column12=" + column12 +
        ", column13=" + column13 +
        ", column14=" + column14 +
        ", column15=" + column15 +
        ", column16=" + column16 +
        ", column17=" + column17 +
        ", column18=" + column18 +
        ", column19=" + column19 +
        ", column20=" + column20 +
        ", bigColumn1=" + bigColumn1 +
        ", bigColumn2=" + bigColumn2 +
        ", bigColumn3=" + bigColumn3 +
        ", bigColumn4=" + bigColumn4 +
        ", bigColumn5=" + bigColumn5 +
        ", extendsJson=" + extendsJson +
        ", oemId=" + oemId +
        ", groupId=" + groupId +
        ", creator=" + creator +
        ", createdName=" + createdName +
        ", createdDate=" + createdDate +
        ", modifier=" + modifier +
        ", modifyName=" + modifyName +
        ", lastUpdatedDate=" + lastUpdatedDate +
        ", isEnable=" + isEnable +
        ", updateControlId=" + updateControlId +
        ", provinceCode=" + provinceCode +
        ", provinceName=" + provinceName +
        ", cityCode=" + cityCode +
        ", cityName=" + cityName +
        ", countyCode=" + countyCode +
        ", countyName=" + countyName +
        "}";
    }
}
