package com.ly.mp.csc.clue.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;
import java.util.UUID;

import com.ly.mp.busicen.common.excel.ExcelData;
import com.ly.mp.busicen.common.excel.ExcelDataBuilder;
import com.ly.mp.busicen.common.excel.ExcelExportUtil;
import com.ly.mp.component.entities.OptResult;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegist;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegistor;
import com.ly.bucn.component.interceptor.annotation.Interceptor;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.constant.UserBusiEntity;
import com.ly.mp.busi.base.context.BusicenContext;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.busi.base.handler.BusicenUtils.SOU;
import com.ly.mp.busi.base.handler.ResultHandler;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.helper.StringHelper;
import com.ly.mp.csc.clue.entities.SacTransferApply;
import com.ly.mp.csc.clue.entities.in.FieldMappingIn;
import com.ly.mp.csc.clue.enums.ReviewAuditStatusEnum;
import com.ly.mp.csc.clue.enums.TransferAuditTypeEnum;
import com.ly.mp.csc.clue.idal.mapper.SacClueInfoDlrMapper;
import com.ly.mp.csc.clue.idal.mapper.SacReviewMapper;
import com.ly.mp.csc.clue.idal.mapper.SacTransferApplyMapper;
import com.ly.mp.csc.clue.idal.mapper.SacTransferAuditMapper;
import com.ly.mp.csc.clue.otherservice.ICscSysBaseDataService;
import com.ly.mp.csc.clue.service.ISacFieldMappingConfigService;
import com.ly.mp.csc.clue.service.ISacTransferApplyService;
import com.ly.mp.csc.clue.service.ISacTransferAuditService;

import javax.servlet.http.HttpServletResponse;


@Service
public class SacTransferApplyService extends ServiceImpl<SacTransferApplyMapper, SacTransferApply> implements ISacTransferApplyService,InterceptorWrapperRegist {

	private static Logger log = LoggerFactory.getLogger(SacTransferApplyService.class);
	@Autowired SacTransferApplyMapper sacTransferApplyMapper;
	@Autowired SacTransferAuditMapper sacTransferAuditMapper;

	@Autowired
	ICscSysBaseDataService cscSysBaseDataService;
	
	@SuppressWarnings("unchecked")
	@Override
	@Interceptor("sac_transfer_apply")
	@Transactional
	public EntityResult<Map<String, Object>> transferApply(Map<String, Object> mapParam, String token) {
		String applyId = UUID.randomUUID().toString();
		mapParam.put("applyId", applyId);
		mapParam.put("isEnable", "1");
		transFiled(null, mapParam);
		BusicenUtils.invokeUserInfo(mapParam, SOU.Save, token);
		sacTransferApplyMapper.insertSacTransferApply(mapParam);

		Map<String, Object> auditMap = (Map<String, Object>)mapParam.get("auditMap");
		auditMap.put("applyId", applyId);
		auditMap.put("auditId", UUID.randomUUID().toString());
		auditMap.put("isEnable", "1");

		BusicenUtils.invokeUserInfo(auditMap, SOU.Save, token);
		sacTransferAuditMapper.insertSacTransferAudit(auditMap);

		return ResultHandler.updateOk(queryByApplyId(applyId, token));
	}

	public Map<String, Object> queryByApplyId(String applyId, String token){
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("applyId", applyId);
		IPage<Map<String, Object>> page = new Page<Map<String, Object>>(1, 1);
		List<Map<String, Object>> list = baseMapper.selectApplyByPage(page, param);
		return list.get(0);
	}

	@Override
	public ListResult<Map<String, Object>> queryApplyList(ParamPage<Map<String, Object>> map,String token){
		ListResult<Map<String,Object>> result = new ListResult<Map<String,Object>>();
		try {
			int pageIndex=map.getPageIndex();
			int pageSize=map.getPageSize();
			IPage<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);
			transFiled(null ,map.getParam());
			List<Map<String, Object>> list = baseMapper.selectApplyByPage(page, map.getParam());
			for(int i=0;i<list.size();i++){
				Map<String, Object> infoMap = list.get(i);
				if(infoMap.get("extendsJson") != null) {
					unTransFiled(infoMap.get("extendsJson").toString(),infoMap);
				}
			}
			page.setRecords(list);
			result = BusicenUtils.page2ListResult(page);
		}catch (Exception e){
			e.printStackTrace();
			log.error("queryListReviewPlanInfo:",e);
			throw e;
		}
		return result;
	}

	@Override
	public ListResult<Map<String, Object>> queryAuditList(ParamPage<Map<String, Object>> map,String token) {
		Map<String, Object> param = map.getParam();
		String applyTypeCodes = (String)param.get("applyTypeCodes");
		// 总部、品牌大使applyTypeCodes传'99'
		if(StringUtils.isBlank(applyTypeCodes)) {
			throw BusicenException.create("applyTypeCodes不能为空！");
		}
		List<String> applyTypeCodeList = new ArrayList<>();
		for(String applyTypeCode: StringUtils.split(applyTypeCodes, ",")) {
			applyTypeCodeList.add(applyTypeCode);
		}
		
		applyTypeCodeList.add("-1");
		param.put("applyTypeCodeList", applyTypeCodeList);

		UserBusiEntity user = BusicenContext.getCurrentUserBusiInfo(token);
		param.put("dlrCode", user.getDlrCode());
		ListResult<Map<String,Object>> result = new ListResult<Map<String,Object>>();
		try {
			int pageIndex=map.getPageIndex();
			int pageSize=map.getPageSize();
			IPage<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);
			transFiled(null ,map.getParam());
			
			// 1-调入店审核，2-调出店审核，3-区域经理审核
			if (applyTypeCodeList.contains("3")) {
				//查询区域经理管辖的门店
				Map<String, Object> paramMap = new HashMap<>();
				paramMap.put("userId", user.getUserID());
				paramMap.put("pageIndex", -1);
				paramMap.put("pageSize", -1);
				ListResult<Map<String, Object>> managedDlrListResult = cscSysBaseDataService.querymanagedlr(token, paramMap);
				StringJoiner outDlrCodeList = new StringJoiner(",");
				if ("1".equals(managedDlrListResult.getResult())) {
					for(Map<String, Object> managedDlrMap : managedDlrListResult.getRows()) {
						outDlrCodeList.add((String) managedDlrMap.get("dlrCode"));
					}
				} else {
					throw new BusicenException("Feign调用BASE查询管辖门店失败!");
				}
				param.put("outDlrCodeList", outDlrCodeList.toString());
			}
			
			List<Map<String, Object>> list = baseMapper.selectAuditByPage(page, map.getParam());
			for(int i=0;i<list.size();i++){
				Map<String, Object> infoMap = list.get(i);
				if(infoMap.get("extendsJson") != null) {
					unTransFiled(infoMap.get("extendsJson").toString(),infoMap);
				}
			}
			page.setRecords(list);
			result = BusicenUtils.page2ListResult(page);
		}catch (Exception e){
			e.printStackTrace();
			log.error("queryListReviewPlanInfo:",e);
			throw e;
		}
		return result;
	}
	
	@Override
	public ListResult<Map<String, Object>> queryAuditHisList(ParamPage<Map<String, Object>> map,String token) {
		Map<String, Object> param = map.getParam();
		UserBusiEntity user = BusicenContext.getCurrentUserBusiInfo(token);
		param.put("dlrCode", user.getDlrCode());
		ListResult<Map<String,Object>> result = new ListResult<Map<String,Object>>();
		try {
			int pageIndex=map.getPageIndex();
			int pageSize=map.getPageSize();
			IPage<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);
			transFiled(null ,map.getParam());
			//只查当前登录人所审核的数据
			param.put("shPersonId", user.getUserID());
			List<Map<String, Object>> list = baseMapper.selectAuditByPage(page, map.getParam());
			for(int i=0;i<list.size();i++){
				Map<String, Object> infoMap = list.get(i);
				if(infoMap.get("extendsJson") != null) {
					unTransFiled(infoMap.get("extendsJson").toString(),infoMap);
				}
			}
			page.setRecords(list);
			result = BusicenUtils.page2ListResult(page);
		}catch (Exception e){
			e.printStackTrace();
			log.error("queryListReviewPlanInfo:",e);
			throw e;
		}
		return result;
	}


	@Autowired ISacTransferAuditService sacTransferAuditService;

	@Override
	public EntityResult<Map<String, Object>> sacTransferApplySave(Map<String, Object> mapParam, String token) {
		try {
			Boolean updateFlag = false;
			if (!StringHelper.IsEmptyOrNull(mapParam.get("applyId"))) {
				QueryWrapper<SacTransferApply> wrapper = new QueryWrapper<>();
				wrapper.lambda().eq(SacTransferApply::getApplyId, mapParam.get("applyId"));
				if (list(wrapper).size() > 0) {
					updateFlag = true;
				}
			}
			if (!updateFlag) {
				// 新增
				if (StringHelper.IsEmptyOrNull(mapParam.get("applyId"))) {
					// 主键
					mapParam.put("applyId", UUID.randomUUID().toString());
					mapParam.put("isEnable", "1");
				}
				BusicenUtils.invokeUserInfo(mapParam, SOU.Save, token);
				sacTransferApplyMapper.insertSacTransferApply(mapParam);
			} else {
				// 更新
				BusicenUtils.invokeUserInfo(mapParam, SOU.Update, token);
				sacTransferApplyMapper.updateSacTransferApply(mapParam);
			}
			QueryWrapper<SacTransferApply> wrapper = new QueryWrapper<>();
			wrapper.lambda().eq(SacTransferApply::getApplyId, mapParam.get("applyId"));
			return ResultHandler.updateOk(listMaps(wrapper).get(0));
		} catch (Exception e) {
			log.error("sacReviewSave", e);
			throw e;
		}
	}

	@Override
	public ListResult<Map<String, Object>> queryList(ParamPage<Map<String, Object>> map,String token){
		ListResult<Map<String,Object>> result = new ListResult<Map<String,Object>>();
		try {
			int pageIndex=map.getPageIndex();
			int pageSize=map.getPageSize();
			IPage<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);
			List<Map<String, Object>> list = baseMapper.selectByPage(page, map.getParam());
			page.setRecords(list);
			result = BusicenUtils.page2ListResult(page);
		}catch (Exception e){
			e.printStackTrace();
			log.error("queryListReviewPlanInfo:",e);
			throw e;
		}
		return result;
	}

	@Override
	public OptResult exportTransferapplydlrquery(ParamPage<Map<String, Object>> param, HttpServletResponse response, String authentication) throws Exception {
		String title = "划转申请单列表";// 导出文件名称
		ExcelData excelData = null;
		String[][] columns = new String[][]{
				{"custName", "客户姓名"},
				{"tmdPhone", "客户电话"},
				{"genderName", "性别"},
				{"intenCarTypeName", "意向车型"},
				{"outDlrName", "原门店名称"},
				{"outDlrCode", "原门店编码"},
				{"inDlrName", "现门店名称"},
				{"inDlrCode", "现门店编码"},
				{"channelName", "线索来源"},
				{"businessHeatName", "热度"},
				{"businessHeatName", "线索等级"},
				{"modifyName", "划转人"},
				{"createdDate", "划转时间"},
				{"clueCreatedDate", "线索创建时间"},
				{"shStatusName", "审核状态"},
		};
		ListResult<Map<String, Object>> result = this.queryApplyList(param, authentication);
		List<Map<String, Object>> list = result.getRows();

		excelData = ExcelDataBuilder.create().title(title).columns(columns).data(list).build();
		ExcelExportUtil.export(excelData, response);
		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void regist(InterceptorWrapperRegistor registor) {
		// 划转申请查重检查
		registor.before("sac_transfer_apply_check_repeat", (context, model) -> {
			Map<String, Object> transferApplyMap = (Map<String, Object>) context.data().getP()[0];
			// String token = (String) context.data().getP()[1];
			String phone = (String)transferApplyMap.get("phone");


			IPage<Map<String, Object>> page = new Page<Map<String, Object>>(1, Integer.MAX_VALUE);
			Map<String, Object> applyMap = new HashMap<>();
			applyMap.put("phone", phone);
			applyMap.put("isEnable", "1");
			applyMap.put("shStatus", ReviewAuditStatusEnum.unAudit.getResult());
			//			UserBusiEntity user = BusicenContext.getCurrentUserBusiInfo(token);
			//			if(user != null) {
			//				applyMap.put("creator", user.getUserID());
			//			}
			List<Map<String, Object>> list = sacTransferApplyMapper.selectApplyByPage(page, applyMap);
			if(list != null && !list.isEmpty()) {
				throw BusicenException.create(phone + "的划转申请已经存在，不能重复申请");
			}
		});

		// 划转申请数据检查
		registor.before("sac_transfer_apply_check_data", (context, model) -> {
			Map<String, Object> transferApplyMap = (Map<String, Object>) context.data().getP()[0];
			String token = (String) context.data().getP()[1];
			String phone = (String)transferApplyMap.get("phone");

			Map<String, Object> dlrClueMap = getDlrClueMapByPhone(phone);
			if(dlrClueMap == null) {
				throw BusicenException.create("该线索不存在!");
			}
			transferApplyMap.put("dlrClueMap", dlrClueMap);

			UserBusiEntity user = BusicenContext.getCurrentUserBusiInfo(token);
			if(user == null) {
				throw BusicenException.create("获取当前用户出错！");
			}
			if(user.getDlrCode() == null) {
				throw BusicenException.create("获取当前用户dlrCode出错！");
			}
			if(user.getDlrCode().equals(dlrClueMap.get("dlrCode"))) {
				throw BusicenException.create("该线索是本店线索，不需要申请！");
			}
		});

		// 划转申请-初始化相关信息
		registor.before("sac_transfer_apply_init", (context, model) -> {
			Map<String, Object> transferApplyMap = (Map<String, Object>) context.data().getP()[0];
			String token = (String) context.data().getP()[1];
			sacTransferApplyInit(transferApplyMap, token);
		});

		// 划转申请-初始化代理商相关信息
		// 移动到客制化拓展中
		//		registor.before("sac_transfer_apply_init_agency", (context, model) -> {
		//			Map<String, Object> transferApplyMap = (Map<String, Object>) context.data().getP()[0];
		// String token = (String) context.data().getP()[1];
		// 审核信息
		//			Map<String, Object> auditMap = (Map<String, Object>)transferApplyMap.get("auditMap");
		// 修改审核类型
		// auditMap.put("applyTypeCode", TransferAuditTypeEnum.outDlr.getResult());
		// auditMap.put("applyTypeName", TransferAuditTypeEnum.outDlr.getMsg());
		//		});


	}

	@SuppressWarnings("unchecked")
	private void sacTransferApplyInit(Map<String, Object> transferApplyMap, String token) {
		String phone = (String)transferApplyMap.get("phone");
		Map<String, Object> dlrClueMap = (Map<String, Object>)transferApplyMap.get("dlrClueMap");
		if(dlrClueMap == null) {
			throw BusicenException.create("不存在店端线索phone=" + phone);
		}
		// 业务单号
		transferApplyMap.put("billCode", dlrClueMap.get("serverOrder"));
		transferApplyMap.put("custId", dlrClueMap.get("custId"));
		transferApplyMap.put("custName", dlrClueMap.get("custName"));

		// json字段 TODO
		transferApplyMap.put("channelName", dlrClueMap.get("channelName"));
		transferApplyMap.put("planBuyDateName", dlrClueMap.get("planBuyDateName"));
		transferApplyMap.put("intenCarTypeName", dlrClueMap.get("intenCarTypeName"));
		transferApplyMap.put("intenLevelName", dlrClueMap.get("intenLevelName"));
		transferApplyMap.put("businessHeatName", dlrClueMap.get("businessHeatName"));
		transferApplyMap.put("businessHeatCode", dlrClueMap.get("businessHeatCode"));
		transferApplyMap.put("genderCode", dlrClueMap.get("genderCode"));
		transferApplyMap.put("genderName", dlrClueMap.get("genderName"));

		// 初始化调出店相关信息
		transferApplyMap.put("outDlrCode", dlrClueMap.get("dlrCode"));
		transferApplyMap.put("outDlrName", dlrClueMap.get("dlrShortName"));

		UserBusiEntity user = BusicenContext.getCurrentUserBusiInfo(token);
		if(user != null) {
			// 初始化调入店相关信息
			transferApplyMap.put("inDlrCode", user.getDlrCode());
			transferApplyMap.put("inDlrName", user.getDlrName());
		}

		Map<String, Object> auditMap = new HashMap<>();
		transferApplyMap.put("auditMap", auditMap);

		// 审核类型编码
		auditMap.put("applyTypeCode", TransferAuditTypeEnum.outDlr.getResult());
		auditMap.put("applyTypeName", TransferAuditTypeEnum.outDlr.getMsg());
		auditMap.put("shStatus", ReviewAuditStatusEnum.unAudit.getResult());
		auditMap.put("shStatusName", ReviewAuditStatusEnum.unAudit.getMsg());
	}

	@Autowired SacClueInfoDlrMapper clueInfoDlrMapper;
	@Autowired SacReviewMapper sacReviewMapper;
	private Map<String, Object> getDlrClueMapByPhone(String phone) {
		if (StringUtils.isBlank(phone)) {
			return null;
		}
		Page<Map<String, Object>> page = new Page<Map<String, Object>>(1, Integer.MAX_VALUE);
		Map<String, Object> param = new HashMap<>();
		param.put("phone", phone);
		param.put("ishost","host");
		List<Map<String, Object>> list = clueInfoDlrMapper.selectByPage(page, param);
		if (list == null || list.size() ==0) {
			return null;
		}
		return list.get(0);
	}

	private Map<String, Object> queryReviewRecord(String reviewId) {
		if (StringUtils.isBlank(reviewId)) {
			return null;
		}
		Page<Map<String, Object>> page = new Page<Map<String, Object>>(1, Integer.MAX_VALUE);
		Map<String, Object> param = new HashMap<>();
		param.put("reviewId", reviewId);
		List<Map<String, Object>> list = sacReviewMapper.queryReviewInfoById(page, param);
		if (list == null || list.size() ==0) {
			return null;
		}
		return list.get(0);
	}

	@Autowired
	ISacFieldMappingConfigService sacFieldMappingConfigService;

	/**
	 * 扩展字段转换
	 * 将参数转换为数据库的字段
	 * @param oldJson   原来保存的json
	 * @param 新的要保存的map
	 * @return
	 */
	private Map<String, Object> transFiled(String oldJson, Map<String, Object> map) {
		FieldMappingIn info = new FieldMappingIn();
		info.setSourceTableCode("t_sac_transfer_apply");
		info.setBillType("DLRCLUE");
		if (!StringHelper.IsEmptyOrNull(map.get("businessType"))) {
			info.setBusinessType(map.get("businessType").toString());
		} else {
			info.setBusinessType("-1");
		}
		info.setParam(map);
		info.setOldJson(oldJson);
		Map<String, Object> filedMap = sacFieldMappingConfigService.tranFieldToMap(info);
		if (filedMap != null && filedMap.size() > 0) {
			// 合并
			map.putAll(filedMap);
		}
		return map;
	}

	/**
	 * 回访表扩展字段转换 反转
	 * 将数据库的字段转换为映射的参数字段
	 * @param oldJson   原来保存的json
	 * @param 新的要保存的map
	 * @return
	 */
	private Map<String, Object> unTransFiled(String oldJson, Map<String, Object> map) {
		FieldMappingIn info = new FieldMappingIn();
		info.setSourceTableCode("t_sac_transfer_apply");
		info.setBillType("DLRCLUE");
		if (!StringHelper.IsEmptyOrNull(map.get("businessType"))) {
			info.setBusinessType(map.get("businessType").toString());
		} else {
			info.setBusinessType("-1");
		}
		info.setParam(map);
		info.setOldJson(oldJson);
		Map<String, Object> filedMap = sacFieldMappingConfigService.unTranFieldToMap(info);
		if (filedMap != null && filedMap.size() > 0) {
			// 合并
			map.putAll(filedMap);
		}
		return map;
	}

}
