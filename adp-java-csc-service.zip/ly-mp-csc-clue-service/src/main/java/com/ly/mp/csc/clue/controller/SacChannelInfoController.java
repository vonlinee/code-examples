package com.ly.mp.csc.clue.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.context.BusicenInvoker;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.service.ISacChannelInfoService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * com.ly.mp.csc.clue.controller.SacChannelInfoController
 * 渠道信息服务控制类
 * @author zhouhao
 * @date 2021/8/16 15:18
 */
@Api(value = "渠道信息服务", tags = { "渠道信息服务" })
@RestController
@RequestMapping(value = "/ly/sac/channelinfo", produces = { MediaType.APPLICATION_JSON_VALUE })
public class SacChannelInfoController {
	//注入服务
	@Autowired
	ISacChannelInfoService sacChannelInfoService;

	@ApiOperation(value="渠道信息（树形结构）查询", notes="渠道信息（树形结构）查询")
	@RequestMapping(value = "/querylist.do", method = RequestMethod.POST)
	public ListResult<Map<String,Object>> queryListChannelInfo(
			@RequestHeader(name = "authorization",required = false) String token,
			@RequestBody(required = false) ParamPage<Map<String, Object>> dataInfo){
		return BusicenInvoker.doList(()->sacChannelInfoService.queryListChannelInfo(dataInfo,token)).result();
	}

	@ApiOperation(value="渠道信息管理查询", notes="渠道信息管理查询")
	@RequestMapping(value = "/querylistchannel.do", method = RequestMethod.POST)
	public ListResult<Map<String,Object>> queryListChannel(
			@RequestHeader(name = "authorization",required = false) String token,
			@RequestBody(required = false) ParamPage<Map<String, Object>> dataInfo){
		return BusicenInvoker.doList(()->sacChannelInfoService.queryListChannel(dataInfo,token)).result();
	}


	@ApiOperation(value="渠道信息保存", notes="渠道信息保存")
	@RequestMapping(value = "/save.do", method = RequestMethod.POST)
	public OptResult saveChannelInfo(
			@RequestHeader(name = "authorization",required = false) String token,
			@RequestBody(required = true) ParamBase<Map<String,Object>> dataInfo){
		dataInfo.getParam().put("token", token);
		return BusicenInvoker.doOpt(()->sacChannelInfoService.saveChannelInfo(dataInfo.getParam(), token)).result();
	}
	
	@ApiOperation(value="渠道关系查询(根据渠道名称)", notes="渠道关系查询(根据渠道名称)")
	@RequestMapping(value = "/querychannellink", method = RequestMethod.POST)
	public ListResult<Map<String,Object>> queryChannelLinkByName(
			@RequestHeader(name = "authorization",required = false) String token,
			@RequestBody(required = false) ParamPage<Map<String, Object>> dataInfo){
		return BusicenInvoker.doList(()->sacChannelInfoService.queryChannelLinkByName(dataInfo,token)).result();
	}

}
