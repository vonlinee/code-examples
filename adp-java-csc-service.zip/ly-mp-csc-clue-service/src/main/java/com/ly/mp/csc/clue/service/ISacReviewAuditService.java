package com.ly.mp.csc.clue.service;

import com.ly.mp.component.entities.OptResult;
import com.ly.mp.csc.clue.entities.SacReviewAudit;
import com.baomidou.mybatisplus.extension.service.IService;

import com.ly.mp.component.entities.EntityResult;
import java.util.Map;

/**
 * <p>
 * 回访审核表 服务类
 * </p>
 *
 * @author ly-busicen
 * @since 2021-08-17
 */
public interface ISacReviewAuditService extends IService<SacReviewAudit> {

	
	/**
	 * 根据主键判断插入或更新
	 * @param info
	 * @return
	 */
	EntityResult<Map<String, Object>> sacReviewAuditSave(Map<String, Object> mapParam, String token);

    /**
     * 回访审核
     * @param map 输入参数
     * @param token token
     * @return OptResult
     */
    OptResult reviewAudit(Map<String, Object> map, String token);
    
    /**
     * 批量审核
     * @param map
     * @param token
     * @return
     */
    OptResult reviewAuditBanch(Map<String, Object> map, String token);
    
    /**
     * 审核撤回
     * @param map
     * @param token
     * @return
     */
    OptResult shenheCancle(Map<String, Object> map, String token);
	
}
