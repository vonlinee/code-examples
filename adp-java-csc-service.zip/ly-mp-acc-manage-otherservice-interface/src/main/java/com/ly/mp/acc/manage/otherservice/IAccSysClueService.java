package com.ly.mp.acc.manage.otherservice;

import java.util.Map;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;

public interface IAccSysClueService {

	/**
	 * 上传附件信息
	 * @param authentication
	 * @param queryCondition
	 * @return
	 */
	public EntityResult<Map<String, Object>> sacAttachmentAdd(String authentication,
			ParamBase<Map<String, Object>> queryCondition);

	/**
	 * 线索查重
	 * 
	 * @param mapParam
	 * @return
	 */
	public EntityResult<Map<String, Object>> clueDlrCheckRepeat(String authentication,
			ParamBase<Map<String, Object>> queryCondition);

	/**
	 * 店端线索保存
	 * 
	 * @param clueParam
	 * @return
	 */
	public EntityResult<Map<String, Object>> clueDlrSave(String authentication,
			ParamBase<Map<String, Object>> queryCondition);

	/**
	 * 配置列表查询
	 * 
	 * @param authentication
	 * @param paramPage
	 * @return
	 */
	public ListResult<Map<String, Object>> queryConfigList(String authentication,
			ParamPage<Map<String, Object>> paramPage);

	/**
	 * 根据门店编码查询城市大区信息
	 * 
	 * @param authentication
	 * @param paramBase
	 * @return
	 */
	public ListResult<Map<String, Object>> querycityinfobydlr(String authentication, Map<String, Object> dateInfo);

	/**
	 * 当前登录人所管辖门店查询
	 * 
	 * @param authentication
	 * @param paramBase
	 * @return
	 */
	public ListResult<Map<String, Object>> querymanagedlr(String authentication, Map<String, Object> dateInfo);

	/**
	 * 根据专营店编码获取token
	 * 
	 * @param dateInfo
	 * @return
	 */
	OptResult createMpTokenInfo(@RequestBody(required = false) Map<String, Object> dateInfo);

	/**
	 * 城市-门店关系查询
	 * 
	 * @param authentication
	 * @param dateInfo
	 * @return
	 */
	public ListResult<Map<String, Object>> querycitydlr(String authentication, Map<String, Object> dateInfo);

	/**
	 * 大区-城市关系查询
	 * 
	 * @param authentication
	 * @param dateInfo
	 * @return
	 */
	@PostMapping(value = "/ly/adp/base/clue/queryareacity.do")
	public ListResult<Map<String, Object>> queryAreaCityRelation(String authentication, Map<String, Object> dateInfo);

	/**
	 * 大区用户关系查询
	 * 
	 * @param authentication
	 * @param dateInfo
	 * @return
	 */
	@PostMapping(value = "/ly/adp/base/clue/queryuserarea.do")
	public ListResult<Map<String, Object>> queryUserAreaRelation(String authentication, Map<String, Object> dateInfo);

	/**
	 * 用户城市关系查询
	 * 
	 * @param authentication
	 * @param dateInfo
	 * @return
	 */
	@PostMapping(value = "/ly/adp/base/clue/queryusercity.do")
	public ListResult<Map<String, Object>> queryUserCityRelation(String authentication, Map<String, Object> dateInfo);

	/**
	 * 大区信息查询
	 * 
	 * @param authentication
	 * @param mapParam
	 * @return
	 */
	@PostMapping(value = "/ly/adp/base/areainfo/bigAreaInfoQuery.do")
	public ListResult<Map<String, Object>> bigAreaInfoQuery(String authentication,
			ParamPage<Map<String, Object>> mapParam);

	//根据FILE_PATH 查询OBS桶路径
	public String selectOBSFilePath(String authentication, String filePathm);
}
