package com.ly.mp.acc.manage.otherservice;

import java.util.Map;

public interface IAccSysOrgService {

	/**
	 * 根据dlrCode获取专营店信息
	 * @param token
	 * @param dlrCode
	 * @return
	 */
	public Map<String, Object> mdmDlrInfoFindAll(String token, String dlrCode) ;

	/**
	 * 构造用户token信息  Map的key userId,userName
	 * @param paramMap
	 * @return
	 */
	public String generateToken(Map<String, Object> paramMap) ;
}
