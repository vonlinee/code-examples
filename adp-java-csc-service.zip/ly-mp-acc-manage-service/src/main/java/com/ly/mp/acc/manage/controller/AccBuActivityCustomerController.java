package com.ly.mp.acc.manage.controller;


import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ly.mp.acc.manage.enums.ActivityCustomerEnum;
import com.ly.mp.acc.manage.service.IAccBuActivityCustomerService;
import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.context.BusicenInvoker;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.component.helper.StringHelper;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author ly-linliq
 * @since 2022-01-04
 */
@RestController
@Api(value = "活动顾客信息管理",tags = {"活动顾客信息管理"})
@RequestMapping("/ly/acc/activity/customer")
public class AccBuActivityCustomerController {
	@Autowired
	IAccBuActivityCustomerService accBuActivityCustomerService;
	
	@ApiOperation(value = "活动报名", notes = "活动报名")
	@RequestMapping(value = "/sacactivityregistersave", method = RequestMethod.POST)
	public OptResult sacActivityRegisterSave(@RequestHeader(name = "authorization", required = false) String authentication,
			@RequestBody(required = false) ParamBase<Map<String, Object>> mapParam) {
		if(!StringHelper.IsEmptyOrNull(authentication)) {
			mapParam.getParam().put("token", authentication);
		}
		mapParam.getParam().put("updateFlag", false);
		mapParam.getParam().put("status", ActivityCustomerEnum.apply.getResult());
//		mapParam.getParam().put("status", "apply");
		return BusicenInvoker.doOpt(() -> accBuActivityCustomerService.accBuActivityCustomerSave(mapParam.getParam())).result();
	}
	
	@ApiOperation(value = "活动报名取消", notes = "活动报名取消")
	@RequestMapping(value = "/sacactivityregistercancel", method = RequestMethod.POST)
	public OptResult sacActivityRegisterCancel(@RequestHeader(name = "authorization", required = false) String authentication,
			@RequestBody(required = false) ParamBase<Map<String, Object>> mapParam) {
		mapParam.getParam().put("token", authentication);
		mapParam.getParam().put("updateFlag", true);
		mapParam.getParam().put("status", ActivityCustomerEnum.cancel.getResult());
//		mapParam.getParam().put("status", "cancel");
		return BusicenInvoker.doOpt(() -> accBuActivityCustomerService.accBuActivityCustomerSave(mapParam.getParam())).result();
	}
	
	@ApiOperation(value = "活动报名签到", notes = "活动报名签到")
	@RequestMapping(value = "/sacactivityregistersignin", method = RequestMethod.POST)
	public OptResult sacActivityRegisterSignIn(@RequestHeader(name = "authorization", required = false) String authentication,
			@RequestBody(required = false) ParamBase<Map<String, Object>> mapParam) {
		mapParam.getParam().put("token", authentication);
		mapParam.getParam().put("updateFlag", true);
		mapParam.getParam().put("status", ActivityCustomerEnum.signIn.getResult());
//		mapParam.getParam().put("status", "signIn");
		return BusicenInvoker.doOpt(() -> accBuActivityCustomerService.accBuActivityCustomerSave(mapParam.getParam())).result();
	}
	
	@ApiOperation(value = "活动报名信息查询", notes = "活动报名信息查询")
	@RequestMapping(value = "/sacactivityregisterinfoquery.do", method = RequestMethod.POST)
	public ListResult<Map<String,Object>> sacActivityRegisterInfoQuery(@RequestHeader(name = "authorization", required = false) String authentication,
			@RequestBody(required = false) ParamPage<Map<String, Object>> mapParam) {
		mapParam.getParam().put("token", authentication);
		return BusicenInvoker.doList(() -> accBuActivityCustomerService.accBuActivityCustomerQuery(mapParam)).result();
	}
	
	@ApiOperation(value = "活动签到状态查询", notes = "活动签到状态查询")
	@RequestMapping(value = "/sacactivityregistersignInStatusquery.do", method = RequestMethod.POST)
	public ListResult<Map<String,Object>> sacActivityRegisterSignInStatusQuery(@RequestHeader(name = "authorization", required = false) String authentication,
			@RequestBody(required = false) ParamPage<Map<String, Object>> mapParam) {
		mapParam.getParam().put("token", authentication);
		return BusicenInvoker.doList(() -> accBuActivityCustomerService.accBuActivityCustomerQuery(mapParam)).result();
	}

}
