package com.ly.mp.acc.manage.enums;

public enum ActivityCustomerEnum {
	apply("Apply","报名"),
	signIn("SignIn","签到"),
	cancel("Cancel","取消报名");
	private String result;
	private String msg;
	private ActivityCustomerEnum(String result, String msg) {
		this.result = result;
		this.msg = msg;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
}
