package com.ly.mp.acc.manage.enums;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public enum PositionEnum {
	dlr("smart_sys_0010","店长"),
	bigman("smart_sys_0024","品牌大使"),
	areaManager("smart_sys_0100","区域市场支持经理"),
	areaInCharge("smart_sys_0013","区域负责人(区域经理)"),
	marketingDirector("smart_sys_0101","总部市场(市场总监)"),
	finance("smart_sys_0102","财务部门管理岗");

	private static Logger log = LoggerFactory.getLogger(PositionEnum.class);

	/**
	 * 通过岗位编码获取活动创建类型
	 * @param post
	 * @return
	 */
	public static ActivityCreateTypeEnum getCreateTypeEnum(String post) {
		if(PositionEnum.dlr.getResult().equals(post)) {
			return ActivityCreateTypeEnum.dlr;
		} else if(PositionEnum.bigman.getResult().equals(post)) {
			return ActivityCreateTypeEnum.bigman;
		} else if(PositionEnum.areaManager.getResult().equals(post)) {
			return ActivityCreateTypeEnum.area;
		}
		log.info("找不到对应的活动创建类型，post={}", post);
		return null;
	}

	private String result;
	private String msg;
	private PositionEnum(String result, String msg) {
		this.result = result;
		this.msg = msg;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}

}
