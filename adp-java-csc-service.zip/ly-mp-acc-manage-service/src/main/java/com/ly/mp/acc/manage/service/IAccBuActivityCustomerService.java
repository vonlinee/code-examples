package com.ly.mp.acc.manage.service;

import java.util.Map;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ly.mp.acc.manage.entities.AccBuActivityCustomer;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author ly-linliq
 * @since 2022-01-04
 */
public interface IAccBuActivityCustomerService extends IService<AccBuActivityCustomer> {

	/**
	 * 活动顾客查询
	 * @param mapParam
	 * @return
	 */
	ListResult<Map<String,Object>> accBuActivityCustomerQuery(ParamPage<Map<String, Object>> mapParam);
	
	/**
	 * 活动顾客信息保存
	 * @param mapParam
	 * @return
	 */
	OptResult accBuActivityCustomerSave(Map<String, Object> mapParam);
}
