package com.ly.mp.acc.manage.strategy;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ly.bucn.component.strategy.annotation.Strategy;
import com.ly.mp.acc.manage.entities.AccBuActivity;
import com.ly.mp.acc.manage.enums.ActivityHxStatusEnum;
import com.ly.mp.acc.manage.service.IAccBuActivityService;
import com.ly.mp.assembly.approve.entities.in.CommonAuditStategyIn;
import com.ly.mp.assembly.approve.enums.AuditStatusEnum;
import com.ly.mp.assembly.approve.strategy.ICommonAuditStategy;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.component.entities.EntityResult;

/**
 * 审核完成，更新活动状态
 * @author ly-zhengzc
 *
 */
@Strategy(isDefault=false,names="commonAuditStategyACTIONHX")
@Component
public class ActionHxAduitStategy implements ICommonAuditStategy {
	private static Logger logger = LoggerFactory.getLogger(ActionHxAduitStategy.class);
	@Autowired IAccBuActivityService accBuActivityService;

	@Override
	public void handle(CommonAuditStategyIn stategyParam, Map<String, Object> returnMap, String token) {

		logger.info("BillCode={}", stategyParam.getBillCode());
		logger.info("ShStatus={}", stategyParam.getShStatus());
		logger.info("NextAuditId={}", stategyParam.getNextAuditId());
		logger.info("NextNodeCode={}", stategyParam.getNextNodeCode());

		String activityId = stategyParam.getBillCode();
		QueryWrapper<AccBuActivity> wrap1 = new QueryWrapper<>();
		wrap1.lambda().eq(AccBuActivity::getActivityId, activityId);
		AccBuActivity vo = accBuActivityService.getOne(wrap1);
		Map<String, Object> activityMap = new HashMap<>();
		activityMap.put("activityId", activityId);
		activityMap.put("updateControlId", vo.getUpdateControlId());


		if(AuditStatusEnum.ok.getCode().equals(stategyParam.getShStatus())) {
			// 审核结束，没有下一个审核节点
			// if("End".equals(nextNodeCode)) {
			if(stategyParam.getNextAuditId() == null) {
				_updateStatus(token, activityMap, ActivityHxStatusEnum.audited);
			} else {
				if(ActivityHxStatusEnum.areaMgSh.getResult().equals(stategyParam.getNextNodeCode())) {
					_updateStatus(token, activityMap, ActivityHxStatusEnum.areaMgSh);
				} else if(ActivityHxStatusEnum.moneySh.getResult().equals(stategyParam.getNextNodeCode())) {
					_updateStatus(token, activityMap, ActivityHxStatusEnum.moneySh);
				}

			}
		} else if(AuditStatusEnum.bh.getCode().equals(stategyParam.getShStatus())) {
			// 活动被驳回
			activityMap.put("hxBhReason", returnMap.get("shDesc"));
			_updateStatus(token, activityMap, ActivityHxStatusEnum.bh);
		}
	}

	private void _updateStatus(String token, Map<String, Object> mapParam, ActivityHxStatusEnum statusEnum) {
		mapParam.put("hxStatusCode", statusEnum.getResult());
		mapParam.put("hxStatusName", statusEnum.getMsg());
		EntityResult<Map<String, Object>> result = accBuActivityService.accBuActivitySave(mapParam, token);
		if(!"1".equals(result.getResult())) {
			throw BusicenException.create("更新活动状态失败！");
		}
	}

}
