package com.ly.mp.acc.manage.enums;

import java.util.HashMap;
import java.util.Map;

/**
 * 活动创建类型
 * @author ly-zhengzc
 *
 */
public enum ActivityCreateTypeEnum {
	// APP/DLR/AREA/BIGMAN
	app("APP","APP"),
	dlr("DLR","店长自建"),
	area("AREA","区域市场新建"),
	bigman("BIGMAN","大使新建"),
	develop("DEVELOP","本地开发类");


	private static final Map<String, ActivityCreateTypeEnum> MAP = new HashMap<>();
	static {
		for (ActivityCreateTypeEnum season : values()) {
			MAP.put(season.result, season);
		}
	}
	public static ActivityCreateTypeEnum valueOfName(String name) {
		return MAP.get(name);
	}

	public static void main(String[] args) {
		ActivityCreateTypeEnum en = ActivityCreateTypeEnum.valueOfName("DLR");
		System.err.println(en);
	}

	private String result;
	private String msg;
	private ActivityCreateTypeEnum(String result, String msg) {
		this.result = result;
		this.msg = msg;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}

}
