package com.ly.mp.acc.manage.strategy.impl;

import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.ly.bucn.component.interceptor.InterceptorWrapperRegist;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegistor;
import com.ly.bucn.component.interceptor.annotation.Interceptor;
import com.ly.bucn.component.strategy.annotation.Strategy;
import com.ly.mp.acc.manage.entities.AccBuActivity;
import com.ly.mp.acc.manage.idal.mapper.AccBuActivityCustomerMapper;
import com.ly.mp.acc.manage.service.IAccBuActivityService;
import com.ly.mp.acc.manage.strategy.IAccBuActivityCustomerStrategy;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.busi.base.handler.BusicenUtils.SOU;
import com.ly.mp.busi.base.handler.MapUtil;
import com.ly.mp.busi.base.handler.OptResultBuilder;
import com.ly.mp.busicen.rule.field.IFireFieldRule;
import com.ly.mp.busicen.rule.field.execution.ValidResultCtn;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.component.helper.StringHelper;

/**
 * 取消报名
 * @author ly-linliq
 * @since 2022-02-10
 */
@Strategy(isDefault = false, names = "activityCustomerCancel")
@Component
public class AccBuActivityCustomerStrategyCancel implements IAccBuActivityCustomerStrategy, InterceptorWrapperRegist{

	private static Logger log = LoggerFactory.getLogger(AccBuActivityCustomerStrategyCancel.class);

	@Autowired
	IFireFieldRule fireFieldRule;
	@Autowired
	AccBuActivityCustomerMapper accBuActivityCustomerMapper;
	@Autowired
	IAccBuActivityService accBuActivityService;
	
	
	@Override
	@Transactional
	@Interceptor("acc_activity_customer_cancel")
	public OptResult handle(Map<String, Object> mapParam) {
		try {
			String token = String.valueOf(mapParam.get("token"));
			String isEnable="0";
			// 获取顾客列表
			List<Map<String, Object>> customerList = (List<Map<String, Object>>) mapParam.get("customerList");
			for (Map<String, Object> map : customerList) {
				map.put("isEnable", isEnable);
				map.put("oldIsEnable","1");
				BusicenUtils.invokeUserInfo(map, SOU.Update, token);
			}
			accBuActivityCustomerMapper.updateAccBuActivityCustomer(customerList);
		} catch (Exception e) {
			log.error("accBuActivityCustomerCancel", e);
			throw e;
		}
		return OptResultBuilder.createOk().build();
	}

	@Override
	public void regist(InterceptorWrapperRegistor registor) {
		// 校验字段
		registor.before("acc_activity_customer_cancel_valid", (context, model) -> {
			checkValidate((Map<String, Object>) context.data().getP()[0]);
		});
		//判断是否可以取消报名（根据活动可取消报名时间值列表判断）
		registor.before("acc_activity_customer_cancel_iscan", (context, model) -> {
			checkIsCanCancle((Map<String, Object>) context.data().getP()[0]);
		});
	}

	public void checkValidate(Map<String, Object> mapParam) {
		try {
			List<Map<String, Object>> customerList = (List<Map<String, Object>>) mapParam.get("customerList");
			for (Map<String, Object> map : customerList) {
				ValidResultCtn fireRule = fireFieldRule.fireRule(map, "acc-manage-activity-cancel-check", "maindata");
				String resMsg = fireRule.getNotValidMessage();
				if (!fireRule.isValid()) {
					throw new BusicenException(resMsg);
				}
			}
		} catch (Exception e) {
			log.error("accBuActivityCustomerCancelCheckValidate", e);
			throw e;
		}
	}
	public void checkIsCanCancle(Map<String, Object> mapParam){
		try {
			//先根据活动id查询活动信息
			List<Map<String, Object>> customerList = (List<Map<String, Object>>) mapParam.get("customerList");
			String activityId=String.valueOf(customerList.get(0).get("activityId"));
			Map<String,Object> activityInfoMap=accBuActivityService.getById(activityId, null).getRows();
			mapParam.put("activityInfo",activityInfoMap);
			AccBuActivity activityInfo=BusicenUtils.map2Object(activityInfoMap, AccBuActivity.class);
			if(activityInfo==null) {
				throw new BusicenException("活动不存在");
			}
			//判断当前时间是否在可取消范围内
			Calendar date = Calendar.getInstance();
			//date格式化
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			//Localdatetime格式化
			DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			String dateString = simpleDateFormat.format(date.getTime());
			//最晚取消报名时间
//			String a=activityInfo.getBeginTime().plusHours(-1*Integer.valueOf(activityInfo.getApplyCancelTimeCode()))
			int minute=0;
			if(!StringHelper.IsEmptyOrNull(activityInfo.getApplyCancelTimeCode())) {
				minute=Integer.valueOf(activityInfo.getApplyCancelTimeCode());
			}
			//如果值为-1，代表不可取消
			if(minute==-1) {
				throw new BusicenException("该活动不可取消报名");
			}
			String lastestCancleTime=df.format(activityInfo.getBeginTime().plusMinutes(-1*minute));
			if(simpleDateFormat.parse(dateString).after(simpleDateFormat.parse(lastestCancleTime))) {
				throw new BusicenException("无法取消报名，当前时间已过可取消报名时间");
			}
		}catch (Exception e) {
			log.error("acc_activity_customer_cancel_iscan", e);
			throw new BusicenException(e.getMessage());
		}
	}
	
}
