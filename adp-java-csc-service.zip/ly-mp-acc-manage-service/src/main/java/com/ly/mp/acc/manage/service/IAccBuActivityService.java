package com.ly.mp.acc.manage.service;

import java.util.Map;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ly.mp.acc.manage.entities.AccBuActivity;
import com.ly.mp.acc.manage.enums.ActivityAttachmentEnum;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;

/**
 * 活动表 服务类
 * t_acc_bu_activity
 * @author ly-zhengzc
 * @since 2021-12-30
 */
public interface IAccBuActivityService extends IService<AccBuActivity> {

	/**
	 * 保存记录
	 * @param mapParam
	 * @param token
	 * @return
	 */
	public EntityResult<Map<String, Object>> accBuActivitySave(Map<String, Object> mapParam, String token);

	/**
	 * 分页查询
	 * @param mapParam
	 * @param token
	 * @return
	 */
	public ListResult<Map<String, Object>> accBuActivityQueryList(ParamPage<Map<String, Object>> map,String token);

	/**
	 * 
	 * @param paramPage
	 * @param token
	 * @return
	 */
	public ListResult<Map<String, Object>> getActivityPage(ParamPage<Map<String, Object>> paramPage, String token);

	public EntityResult<Map<String, Object>>  getActivityCreateType(String token) ;
	/**
	 * 创建活动-暂存
	 * @param mapParam
	 * @param token
	 * @return
	 */
	public EntityResult<Map<String, Object>> temporarySave(Map<String, Object> mapParam, String token) ;

	public EntityResult<Map<String, Object>> updateActivityStatus(Map<String, Object> activityMap, String token) ;

	/**
	 * 创建活动-提交
	 * @param mapParam
	 * @param token
	 * @return
	 */
	public EntityResult<Map<String, Object>> submit(Map<String, Object> mapParam, String token) ;

	/**
	 * 活动复制
	 * @param mapParam
	 * @param token
	 * @return
	 */
	public EntityResult<Map<String, Object>> copy(Map<String, Object> mapParam, String token) ;

	/**
	 * 活动总结
	 * @param mapParam
	 * @param token
	 * @return
	 */
	public EntityResult<Map<String, Object>> summary(Map<String, Object> mapParam, String token) ;

	/**
	 * 核销
	 * @param mapParam
	 * @param token
	 * @return
	 */
	public EntityResult<Map<String, Object>> hx(Map<String, Object> mapParam, String token) ;

	/**
	 * 资源分配
	 * @param mapParam
	 * @param token
	 * @return
	 */
	public EntityResult<Map<String, Object>> allocateResources(Map<String, Object> mapParam, String token) ;

	/**
	 * 根据activityId获取活动信息
	 * @param activityId
	 * @param token
	 * @return
	 */
	public EntityResult<Map<String, Object>> getById(String activityId, String token) ;

	/**
	 * 逻辑删除
	 * @param activityId
	 * @param token
	 * @return
	 */
	public EntityResult<Map<String, Object>> delete(String activityId, String token) ;

	/**
	 * 取消活动
	 * @param activityId
	 * @param token
	 * @return
	 */
	public OptResult cancel(String activityId, String token) ;

	/**
	 * 活动日历查询
	 * @param mapParam
	 * @return
	 */
	public ListResult<Map<String, Object>> accBuActivityCalenderQueryList(ParamPage<Map<String, Object>> mapParam);

	/**
	 * 活动日历查询-按周统计
	 * @param mapParam
	 * @return
	 */
	public ListResult<Map<String, Object>> accBuActivityCalenderQueryByWeekList(ParamPage<Map<String, Object>> mapParam);

	/**
	 * 设置附件信息
	 * @param activityMap
	 * @param activityAttachmentEnum
	 */
	public void setActivityAttachment(Map<String, Object> activityMap, ActivityAttachmentEnum activityAttachmentEnum) ;

	/**
	 * 活动小类查询
	 * @param mapParam
	 * @return
	 */
	public ListResult<Map<String, Object>> queryAcsSmallType(ParamPage<Map<String, Object>> mapParam);

	/**
	 * 活动状态更新定时调用
	 */
	public void updateActivityStatusDistJob();

	public void dealCityAndRegion(Map<String, Object> activityMap, String dlrCode, String token) ;

	/**
	 * 保存记录
	 * @param mapParam
	 * @param token
	 * @return
	 */
	public EntityResult<Map<String, Object>> sacAccBuActivitySave(Map<String, Object> mapParam, String token);
}
