package com.ly.mp.acc.manage.enums;

import java.util.HashMap;
import java.util.Map;

public enum ActivityReleaseStatusEnum {
	unReleased("0","未发布"),
	released("1","已发布");


	// private static Logger logger = LoggerFactory.getLogger(ActivityReleaseStatusEnum.class);
	private static final Map<String, ActivityReleaseStatusEnum> MAP = new HashMap<>();
	static {
		for (ActivityReleaseStatusEnum season : values()) {
			MAP.put(season.result, season);
		}
	}
	public static ActivityReleaseStatusEnum valueOfResult(String result) {
		return MAP.get(result);
	}

	private String result;
	private String msg;
	private ActivityReleaseStatusEnum(String result, String msg) {
		this.result = result;
		this.msg = msg;
	}

	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}

}
