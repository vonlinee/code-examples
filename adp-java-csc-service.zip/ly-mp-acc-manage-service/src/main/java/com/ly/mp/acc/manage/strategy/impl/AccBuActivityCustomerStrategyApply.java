package com.ly.mp.acc.manage.strategy.impl;

import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.ly.bucn.component.interceptor.InterceptorWrapperRegist;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegistor;
import com.ly.bucn.component.interceptor.annotation.Interceptor;
import com.ly.bucn.component.strategy.annotation.Strategy;
import com.ly.mp.acc.manage.entities.AccBuActivity;
import com.ly.mp.acc.manage.idal.mapper.AccBuActivityCustomerMapper;
import com.ly.mp.acc.manage.otherservice.IAccSysClueService;
import com.ly.mp.acc.manage.service.IAccBuActivityService;
import com.ly.mp.acc.manage.strategy.IAccBuActivityCustomerStrategy;
import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.busi.base.constant.UserBusiEntity;
import com.ly.mp.busi.base.context.BusicenContext;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.busi.base.handler.BusicenUtils.SOU;
import com.ly.mp.busi.base.handler.OptResultBuilder;
import com.ly.mp.busicen.rule.field.IFireFieldRule;
import com.ly.mp.busicen.rule.field.execution.ValidResultCtn;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.component.helper.StringHelper;

/**
 * 报名
 * @author ly-linliq
 * @since 2022-02-10
 */
@Strategy(isDefault = false, names = "activityCustomerApply")
@Component
public class AccBuActivityCustomerStrategyApply implements IAccBuActivityCustomerStrategy, InterceptorWrapperRegist {
	private static Logger log = LoggerFactory.getLogger(AccBuActivityCustomerStrategyApply.class);

	@Autowired
	IFireFieldRule fireFieldRule;
	@Autowired
	AccBuActivityCustomerMapper accBuActivityCustomerMapper;
	@Autowired
	IAccSysClueService accClueInfoDlrService;
	@Autowired
	IAccBuActivityService accBuActivityService;
	@Autowired
	IAccSysClueService accSysClueService;
	
	@Override
	@Interceptor("acc_activity_customer_apply")
	@Transactional(rollbackFor = Exception.class)
	public OptResult handle(Map<String, Object> mapParam) {
		String token = String.valueOf(mapParam.get("token"));
		// 获取顾客列表
		List<Map<String, Object>> customerList = (List<Map<String, Object>>) mapParam.get("customerList");
		for (Map<String, Object> map : customerList) {
			// 主键
			if (StringHelper.IsEmptyOrNull(map.get("activityCustomerId"))) {
				map.put("activityCustomerId", StringHelper.GetGUID());
			}
			// 默认可用
			if (StringHelper.IsEmptyOrNull(map.get("isEnable"))) {
				map.put("isEnable", "1");
			}
			// 默认未签到
			if (StringHelper.IsEmptyOrNull(map.get("isCheckIn"))) {
				map.put("isCheckIn", "0");
			}
			BusicenUtils.invokeUserInfo(map, SOU.Save, token);
		}
		int result = accBuActivityCustomerMapper.insertAccBuActivityCustomer(customerList);
		if (result < customerList.size()) {
			return OptResultBuilder.createFail().build();
		}
		return OptResultBuilder.createOk().build();
	}

	@Override
	@SuppressWarnings("unchecked")
	public void regist(InterceptorWrapperRegistor registor) {
		// 校验字段
		registor.before("acc_activity_customer_apply_valid", (context, model) -> {
			checkValidate((Map<String, Object>) context.data().getP()[0]);
		});
		//判断是否可报名
		registor.before("acc_activity_customer_apply_iscan", (context, model) -> {
			checkIsCanApply((Map<String, Object>) context.data().getP()[0]);
		});
		// 查重
		registor.before("acc_activity_customer_apply_repeat", (context, model) -> {
			checkRepeat((Map<String, Object>) context.data().getP()[0]);
		});
		// 判断线索存不存在，存在则新建线索
		registor.before("acc_activity_customer_apply_dlrcheck", (context, model) -> {
			checkDlr((Map<String, Object>) context.data().getP()[0]);
		});
		
	}

	public void checkValidate(Map<String, Object> mapParam) {
		try {
			List<Map<String, Object>> customerList = (List<Map<String, Object>>) mapParam.get("customerList");
			for (Map<String, Object> map : customerList) {
				ValidResultCtn fireRule = fireFieldRule.fireRule(map, "acc-manage-activity-apply-check", "maindata");
				String resMsg = fireRule.getNotValidMessage();
				if (!fireRule.isValid()) {
					throw new BusicenException(resMsg);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error("accBuActivityCustomerApplyCheckValidate", e);
			throw e;
		}
	}

	public void checkRepeat(Map<String, Object> mapParam) {
		try {
			List<Map<String, Object>> customerList = (List<Map<String, Object>>) mapParam.get("customerList");
			for (Map<String, Object> map : customerList) {
				int count = accBuActivityCustomerMapper.checkRepeat(map);
				if (count > 0) {
					throw new BusicenException("您已预约该活动");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error("accBuActivityCustomerApplyCheckRepeat", e);
			throw e;
		}
	}
	public void checkDlr(Map<String, Object> mapParam) {
		try {
			String token="";
			//先获取token
			if(!StringHelper.IsEmptyOrNull(mapParam.get("dlrCode"))) {
				Map<String,Object> param=new HashMap<String, Object>();
				param.put("dlrCode", mapParam.get("dlrCode"));
				OptResult result=accSysClueService.createMpTokenInfo(param);
				if("1".equals(result.getResult())) {
					token=result.getMsg();
					mapParam.put("token", token);
				}
			}
			if(!StringHelper.IsEmptyOrNull(token)) {
				List<Map<String, Object>> customerList = (List<Map<String, Object>>) mapParam.get("customerList");
				for (Map<String, Object> map : customerList) {
	            	ParamBase<Map<String, Object>> mapParamBase = new ParamBase<Map<String, Object>>();
	    			Map<String, Object> param = new HashMap<String, Object>();
	    			param.put("phone", map.get("customerPhone"));
	    			param.put("token", String.valueOf(mapParam.get("token")));
	    			mapParamBase.setParam(param);
	    			// 先查询线索是否存在，存在则存线索单号与顾客id
	    			Map<String, Object> clue = (Map<String, Object>) accClueInfoDlrService.clueDlrCheckRepeat(token, mapParamBase).getRows();
	    			
	    			Map<String, Object> dlrClue = new HashMap<String, Object>();
	    			// 不存在则新增线索,map为空时并没有分配内存，所以不能对其put操作
	    			if (clue == null) {
	    				// 根据token获取当前用户信息
	    				UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
	    				ParamBase<Map<String, Object>> newParamBase = new ParamBase<Map<String, Object>>();
	    				Map<String, Object> newParam = new HashMap<String, Object>();
	    				newParam.put("custName", map.get("customerName"));
	    				newParam.put("phone", map.get("customerPhone"));
	    				newParam.put("activityId", map.get("activityId"));
	    				newParam.put("genderCode", map.get("customerSexCode"));
	    				newParam.put("genderName", map.get("customerSexName"));
	    				newParam.put("intenLevelCode", mapParam.get("intenLevelCode"));
    					newParam.put("intenLevelName", mapParam.get("intenLevelName"));
        				newParam.put("infoChanMName", mapParam.get("infoChanMName"));
        				
        				newParam.put("systemSource", map.get("systemSource"));
        				
	    				newParamBase.setParam(newParam);
	 
	    				EntityResult<Map<String, Object>> newClueResult=accClueInfoDlrService.clueDlrSave(token, newParamBase);
	    				if("0".equals(newClueResult.getResult())) {
	    					throw new BusicenException("新建线索失败:"+newClueResult.getMsg());
	    				}
	    				
	    				mapParam.putAll(newClueResult.getRows());
	    			}else {
	    				mapParam.putAll(clue);
	    			}
	            }
			}
		} catch (Exception e) {
			log.error("acc_activity_customer_apply_dlrcheck", e);
			throw e;
		}
	}
	public void checkIsCanApply(Map<String, Object> mapParam) {
		try {
			// 先根据活动id查询活动信息
			List<Map<String, Object>> customerList = (List<Map<String, Object>>) mapParam.get("customerList");
			String activityId = String.valueOf(customerList.get(0).get("activityId"));
			AccBuActivity activityInfo = accBuActivityService.getById(activityId);
			if (activityInfo == null) {
				throw new BusicenException("活动不存在");
			}
			//dlrCodew为空时，将活动所属门店查出来
			if(StringHelper.IsEmptyOrNull(mapParam.get("dlrCode"))) {
				String[] dlrCodeList=activityInfo.getDlrCode().split(",");
				//只对只有一个门店的活动新建线索
				if(dlrCodeList.length==1) {
					mapParam.put("dlrCode", activityInfo.getDlrCode());
				}
			}
			//活动履历需要用到这几个字段
			mapParam.put("activityName", activityInfo.getActivityName());
			mapParam.put("beginTime", activityInfo.getBeginTime());
			mapParam.put("endTime", activityInfo.getEndTime());
			// 判断当前时间是否在可报名时间范围内
			Calendar date = Calendar.getInstance();
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			String dateString = "";
			// 判断applyTime有没有值，没有的话就用当前日期
			if (!StringHelper.IsEmptyOrNull(mapParam.get("applyTime"))) {
				dateString = String.valueOf(mapParam.get("applyTime"));
			} else {
				dateString = simpleDateFormat.format(date.getTime());
			}
			// 最晚报名时间
			String lastestApplyTime="";
			//本地开发活动最晚报名时间取活动结束时间
			if ("DEVELOP".equals(activityInfo.getCreateTypeCode())) {
				lastestApplyTime=df.format(activityInfo.getEndTime());
			}else {
				lastestApplyTime = df.format(activityInfo.getApplyEndTime());
			}
			if (simpleDateFormat.parse(dateString).after(simpleDateFormat.parse(lastestApplyTime))) {
				throw new BusicenException("无法报名，当前时间已过可报名时间");
			}
		} catch (Exception e) {
			log.error("acc_activity_customer_apply_iscan", e);
			throw new BusicenException(e.getMessage());
		}
	}

}
