package com.ly.mp.acc.manage.service.impl;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegist;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegistor;
import com.ly.bucn.component.interceptor.annotation.Interceptor;
import com.ly.mp.acc.manage.entities.AccBuActivity;
import com.ly.mp.acc.manage.enums.ActivityAddressEnum;
import com.ly.mp.acc.manage.enums.ActivityAttachmentEnum;
import com.ly.mp.acc.manage.enums.ActivityCreateTypeEnum;
import com.ly.mp.acc.manage.enums.ActivityHxStatusEnum;
import com.ly.mp.acc.manage.enums.ActivityReleaseStatusEnum;
import com.ly.mp.acc.manage.enums.ActivityStatusEnum;
import com.ly.mp.acc.manage.idal.mapper.AccBuActivityMapper;
import com.ly.mp.acc.manage.otherservice.IAccSysClueService;
import com.ly.mp.acc.manage.otherservice.IAccSysOrgService;
import com.ly.mp.acc.manage.service.IAccBuActivityService;
import com.ly.mp.acc.manage.strategy.ActionAduitStategy;
import com.ly.mp.assembly.approve.entities.CommonAudit;
import com.ly.mp.assembly.approve.entities.in.FieldMappingIn;
import com.ly.mp.assembly.approve.service.ICommonAuditService;
import com.ly.mp.assembly.approve.service.IFieldMappingConfigService;
import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.constant.UserBusiEntity;
import com.ly.mp.busi.base.context.BusicenContext;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.busi.base.handler.BusicenUtils.SOU;
import com.ly.mp.busi.base.handler.MapUtil;
import com.ly.mp.busi.base.handler.ResultHandler;
import com.ly.mp.busicen.rule.field.IFireFieldRule;
import com.ly.mp.busicen.rule.field.execution.ValidResultCtn;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.component.helper.StringHelper;


@Service
public class AccBuActivityService extends ServiceImpl<AccBuActivityMapper, AccBuActivity> implements IAccBuActivityService, InterceptorWrapperRegist {


	private static Logger log = LoggerFactory.getLogger(AccBuActivityService.class);

	@Autowired IFireFieldRule fireFieldRule;

	@Autowired AccBuActivityMapper accBuActivityMapper;
	//@Autowired SacAttachmentMapper sacAttachmentMapper;

	@Autowired IFieldMappingConfigService sacFieldMappingConfigService;
	@Autowired IAccBuActivityService accBuActivityService;
	@Autowired ICommonAuditService commonAuditService;
	@Autowired IAccSysOrgService accSysOrgService;
	@Autowired IAccSysClueService accSysClueService;

	@Override
	public EntityResult<Map<String, Object>> accBuActivitySave(Map<String, Object> mapParam, String token) {
		// 详细地址 置空处理
		if("".equals(mapParam.get("dlrAddressDetail"))) {
			mapParam.put("dlrAddressDetail", "#empty");
		}
		// 去掉空字符串
		MapUtil.removeNullValue(mapParam);
		if("#empty".equals(mapParam.get("dlrAddressDetail"))) {
			mapParam.put("dlrAddressDetail", "");
		}

		try {
			Boolean updateFlag = false;
			if (!StringHelper.IsEmptyOrNull(mapParam.get("activityId"))) {
				QueryWrapper<AccBuActivity> wrapper = new QueryWrapper<>();
				wrapper.lambda().eq(AccBuActivity::getActivityId, mapParam.get("activityId"));
				List<AccBuActivity> list = list(wrapper);
				if (list.size() > 0) {
					updateFlag = true;
					String updateControlId = (String)mapParam.get("updateControlId");
					if(updateControlId == null) {
						throw BusicenException.create("updateControlId不能为空！");
					}
					if(!StringUtils.equals(list.get(0).getUpdateControlId(), updateControlId)) {
						throw BusicenException.create("该记录是旧数据，请刷新后提交！");
					}
				}
			}

			if (!updateFlag) {
				// 新增
				if (StringHelper.IsEmptyOrNull(mapParam.get("activityId"))) {
					// 主键
					mapParam.put("activityId", UUID.randomUUID().toString());
				}
				BusicenUtils.invokeUserInfo(mapParam, SOU.Save, token);
				mapParam.put("isEnable", "1");
				if(mapParam.get("budget") == null) {
					mapParam.put("budget", "0");
				}
				transFiled(null, mapParam);
				accBuActivityMapper.insertAccBuActivity(mapParam);
			} else {
				// 更新
				BusicenUtils.invokeUserInfo(mapParam, SOU.Update, token);
				transFiled((String)mapParam.get("extendsJson"), mapParam);
				int updateCount = accBuActivityMapper.updateAccBuActivity(mapParam);
				if(updateCount == 0) {
					throw BusicenException.create("更新失败！");
				}
			}
			//			QueryWrapper<AccBuActivity> wrapper = new QueryWrapper<>();
			//			wrapper.lambda().eq(AccBuActivity::getActivityId, mapParam.get("activityId"));
			return ResultHandler.updateOk(mapParam);
		} catch (Exception e) {
			log.error("sacReviewSave", e);
			throw e;
		}
	}

	@Override
	public ListResult<Map<String, Object>> accBuActivityQueryList(ParamPage<Map<String, Object>> paramPage, String token){
		ListResult<Map<String,Object>> result = new ListResult<Map<String,Object>>();
		try {
			int pageIndex=paramPage.getPageIndex();
			int pageSize=paramPage.getPageSize();
			transFiled(null, paramPage.getParam());
			IPage<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);
			List<Map<String, Object>> list = baseMapper.selectByPage(page, paramPage.getParam());
			unTransFiled(list);
			page.setRecords(list);
			result = BusicenUtils.page2ListResult(page);
		}catch (Exception e){
			e.printStackTrace();
			log.error("queryListReviewPlanInfo:",e);
			throw e;
		}
		return result;
	}

	@Override
	public ListResult<Map<String, Object>> getActivityPage(ParamPage<Map<String, Object>> paramPage, String token){
		ListResult<Map<String,Object>> result = new ListResult<Map<String,Object>>();
		try {
			int pageIndex=paramPage.getPageIndex();
			int pageSize=paramPage.getPageSize();
			IPage<Map<String, Object>> page = new Page<Map<String, Object>>(pageIndex, pageSize);

			Map<String, Object> activityMap = paramPage.getParam();
			String inCreateTypeCode = (String)activityMap.get("inCreateTypeCode");
			if(StringUtils.isNotBlank(inCreateTypeCode)) {
				activityMap.put("inCreateTypeCodeList", StringUtils.split(inCreateTypeCode, ","));
			}
			String inStatusCode = (String)activityMap.get("inStatusCode");
			if(StringUtils.isNotBlank(inStatusCode)) {
				activityMap.put("inStatusCodeList", StringUtils.split(inStatusCode, ","));
			}
			List<Map<String, Object>> list = baseMapper.selectActivityPage(page, paramPage.getParam());
			ActivityStatusEnum.dealActivityStatus(list);
			page.setRecords(list);
			result = BusicenUtils.page2ListResult(page);
		}catch (Exception e){
			e.printStackTrace();
			log.error("queryListReviewPlanInfo:",e);
			throw e;
		}
		return result;
	}

	@Override
	public EntityResult<Map<String, Object>> getActivityCreateType(String token) {
		UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
		ActivityCreateTypeEnum createTypeEnum = _getActivityCreateType(userBusiEntity.getPosCode(), token);
		Map<String, Object> map = new HashMap<String, Object>();
		if(createTypeEnum != null) {
			map.put("code", createTypeEnum.getResult());
			map.put("name", createTypeEnum.getMsg());
		}
		return ResultHandler.updateOk(map);
	}

	@Transactional
	@Override
	public EntityResult<Map<String, Object>> temporarySave(Map<String, Object> mapParam, String token) {
		_initialActivity(mapParam, token);
		ValidResultCtn fireRule = fireFieldRule.fireRule(mapParam, "activity-temp-save-check", "maindata");
		String resMsg = fireRule.getNotValidMessage();
		if (!fireRule.isValid()){
			throw new BusicenException(resMsg);
		}
		mapParam.put("statusCode", ActivityStatusEnum.tempSave.getResult());
		mapParam.put("statusName", ActivityStatusEnum.tempSave.getMsg());
		return accBuActivitySave(mapParam, token);
	}

	@Transactional
	@Interceptor("acc_activity_submit")
	@Override
	public EntityResult<Map<String, Object>> submit(Map<String, Object> activityMap, String token) {
		_checkSubmitField(activityMap);
		_checkRepeat(activityMap);
		_checkAddressType(activityMap);
		return accBuActivitySave(activityMap, token);
	}

	@Override
	@Interceptor("acc_activity_update_status")
	public EntityResult<Map<String, Object>> updateActivityStatus(Map<String, Object> activityMap, String token) {
		return accBuActivityService.accBuActivitySave(activityMap, token);
	}

	@Override
	public EntityResult<Map<String, Object>> copy(Map<String, Object> mapParam, String token) {

		if(mapParam == null || mapParam.get("activityId") == null) {
			throw BusicenException.create("activityId不能为空");
		}
		String activityId = (String)mapParam.get("activityId");
		Map<String, Object> dbActivityMap = accBuActivityMapper.selectActivityById(mapParam);
		if(dbActivityMap == null) {
			throw BusicenException.create("记录不存在！");
		}
		unTransFiled(dbActivityMap);
		dbActivityMap.remove("activityId");
		// 删除实际花费、传播渠道数量、传播量、附件信息
		dbActivityMap.remove("column18");
		dbActivityMap.remove("column19");
		dbActivityMap.remove("column20");
		dbActivityMap.remove("column21");
		dbActivityMap.remove("actualCost");
		dbActivityMap.remove("attachment");
		dbActivityMap.remove("spreadNum");
		dbActivityMap.remove("spreadChannelNum");

		// 删除活动审批信息
		dbActivityMap.remove("statusCode");
		dbActivityMap.remove("statusName");

		// 删除活动核销信息
		dbActivityMap.remove("hxStatusCode");
		dbActivityMap.remove("hxStatusName");
		dbActivityMap.remove("actualCost");
		dbActivityMap.remove("fapiao");
		dbActivityMap.remove("bhReason");
		dbActivityMap.remove("hxBhReason");

		// 活动情况
		dbActivityMap.remove("activitySituation");
		// 大使分配资源
		dbActivityMap.remove("resourceAdviser");
		dbActivityMap.remove("resourceCar");
		dbActivityMap.remove("resourceSupportedTimeStart");
		dbActivityMap.remove("resourceSupportedTimeEnd");

		for(int i = 1; i <= 20; i++) {
			dbActivityMap.remove("column" + i);
		}

		String createTypeCode = (String)dbActivityMap.get("createTypeCode");
		if(!ActivityCreateTypeEnum.develop.getResult().equals(createTypeCode)) {
			dbActivityMap.remove("createTypeCode");
			dbActivityMap.remove("createTypeName");
		}
		EntityResult<Map<java.lang.String, Object>> entityResult = accBuActivityService.temporarySave(dbActivityMap, token);

		// 复制活动附件
		copyAttachment(token, activityId, dbActivityMap,ActivityAttachmentEnum.detail);
		copyAttachment(token, activityId, dbActivityMap,ActivityAttachmentEnum.fapiao);
		// 活动拍照图片不要复制 2022-3-18
		// copyAttachment(token, activityId, dbActivityMap,ActivityAttachmentEnum.situation);
		return entityResult;
	}

	// 复制活动附件
	private void copyAttachment(String token, String activityId, Map<String, Object> dbActivityMap, ActivityAttachmentEnum activityAttachmentEnum) {
		List<Map<String, Object>> _getActivityAttachmentList = _getActivityAttachmentList(activityId, activityAttachmentEnum);
		for(Map<String, Object> attachmentMap : _getActivityAttachmentList) {
			ParamBase<Map<String, Object>> paramBase = new ParamBase<Map<String,Object>>();
			paramBase.setParam(attachmentMap);
			attachmentMap.remove("attachmentId");
			attachmentMap.put("billId", dbActivityMap.get("activityId"));
			accSysClueService.sacAttachmentAdd(token, paramBase);
		}
	}

	@Override
	@Transactional
	@Interceptor("acc_activity_hx")
	public EntityResult<Map<String, Object>> hx(Map<String, Object> mapParam, String token) {
		try {
			Assert.isTrue(!StringHelper.IsEmptyOrNull(mapParam.get("activityId")), "activityId不能为空");
			Assert.isTrue(!StringHelper.IsEmptyOrNull(mapParam.get("actualCost")), "actualCost不能为空");
		} catch (Exception e) {
			throw BusicenException.create(e.getMessage());
		}
		AccBuActivity vo = this.getById((String)mapParam.get("activityId"));
		if(vo == null) {
			throw BusicenException.create("记录不存在！");
		}

		Map<String, Object> updateMap = new HashMap<>();
		updateMap.put("activityId", mapParam.get("activityId"));
		updateMap.put("updateControlId", mapParam.get("updateControlId"));
		updateMap.put("actualCost", mapParam.get("actualCost"));
		updateMap.put("fapiao", mapParam.get("fapiao"));
		updateMap.put("hxStatusCode", ActivityHxStatusEnum.newStatus.getResult());
		updateMap.put("hxStatusName", ActivityHxStatusEnum.newStatus.getMsg());
		mapParam.clear();
		mapParam.putAll(updateMap);
		return accBuActivitySave(mapParam, token);
	}

	@Override
	public EntityResult<Map<String, Object>> summary(Map<String, Object> mapParam, String token) {
		if(mapParam == null || mapParam.get("activityId") == null) {
			throw BusicenException.create("activityId不能为空");
		}
		if(mapParam == null || mapParam.get("updateControlId") == null) {
			throw BusicenException.create("updateControlId不能为空");
		}
		if(mapParam == null || mapParam.get("activitySituation") == null) {
			throw BusicenException.create("activitySituation不能为空");
		}
		Map<String, Object> activityMap = new HashMap<String, Object>();
		activityMap.put("activityId", mapParam.get("activityId"));
		activityMap.put("updateControlId", mapParam.get("updateControlId"));
		activityMap.put("activitySituation", mapParam.get("activitySituation"));
		return accBuActivitySave(activityMap, token);
	}

	@Override
	public EntityResult<Map<String, Object>> allocateResources(Map<String, Object> mapParam, String token) {
		try {
			Assert.isTrue(!StringHelper.IsEmptyOrNull(mapParam.get("activityId")), "activityId不能为空");
			Assert.isTrue(!StringHelper.IsEmptyOrNull(mapParam.get("resourceAdviser")), "resourceAdviser不能为空");
			Assert.isTrue(!StringHelper.IsEmptyOrNull(mapParam.get("resourceCar")), "resourceCar不能为空");
			Assert.isTrue(!StringHelper.IsEmptyOrNull(mapParam.get("resourceSupportedTimeStart")), "resourceSupportedTimeStart不能为空");
			Assert.isTrue(!StringHelper.IsEmptyOrNull(mapParam.get("resourceSupportedTimeEnd")), "resourceSupportedTimeEnd不能为空");
		} catch (Exception e) {
			throw BusicenException.create(e.getMessage());
		}
		AccBuActivity vo = this.getById((String)mapParam.get("activityId"));
		if(vo == null) {
			throw BusicenException.create("记录不存在！");
		}
		Map<String, Object> updateMap = new HashMap<>();
		updateMap.put("activityId", mapParam.get("activityId"));
		updateMap.put("updateControlId", mapParam.get("updateControlId"));
		updateMap.put("resourceAdviser", mapParam.get("resourceAdviser"));
		updateMap.put("resourceCar", mapParam.get("resourceCar"));
		updateMap.put("resourceSupportedTimeStart", mapParam.get("resourceSupportedTimeStart"));
		updateMap.put("resourceSupportedTimeEnd", mapParam.get("resourceSupportedTimeEnd"));
		return accBuActivitySave(updateMap, token);
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public EntityResult<Map<String, Object>> delete(String activityId, String token) {
		if (StringHelper.IsEmptyOrNull(activityId)){
			throw new BusicenException("activityId不能为空！");
		}
		Map<String, Object> mapParam = new HashMap<>();
		mapParam.put("activityId", activityId);
		mapParam.put("isEnable", "0");

		int updateFlag = baseMapper.updateAccBuActivity(mapParam);
		if(updateFlag == 0) {
			throw new BusicenException("删除活动失败！");
		}
		_cancleAudit(activityId, token);
		Map<String, Object> map = baseMapper.selectActivityById(mapParam);
		unTransFiled(map);
		return ResultHandler.updateOk(map);
	}

	// 活动审批取消
	private void _cancleAudit(String activityId, String token) {
		QueryWrapper<CommonAudit> queryWrapper = new QueryWrapper<CommonAudit>();
		queryWrapper.eq("bill_type", "ACTION").eq("bill_code", activityId).eq("is_enable", 1).eq("sh_status", 0);
		CommonAudit commonAudit = commonAuditService.getOne(queryWrapper);
		if(commonAudit == null) {
			log.info("需要取消的活动审核记录不存在:activityId=" + activityId);
			//			throw BusicenException.create("活动审核记录不存在");
			return;
		}
		HashMap<String, Object> updateMap = new HashMap<String, Object>();
		updateMap.put("auditId", commonAudit.getAuditId());
		OptResult cancleAudit = commonAuditService.cancleAudit(updateMap, token);
		if("0".equals(cancleAudit.getResult())) {
			throw BusicenException.create("活动审核记录取消失败");
		}
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	@Interceptor("acc_activity_cancel")
	public OptResult cancel(String activityId, String token) {
		if (StringHelper.IsEmptyOrNull(activityId)){
			throw new BusicenException("activityId不能为空！");
		}
		Map<String, Object> mapParam = new HashMap<>();
		mapParam.put("activityId", activityId);
		mapParam.put("statusCode", ActivityStatusEnum.cancel.getResult());
		mapParam.put("statusName", ActivityStatusEnum.cancel.getMsg());
		mapParam.put("releaseStatusCode", "0");
		mapParam.put("releaseStatusName", "未发布");
		int updateFlag = baseMapper.updateAccBuActivity(mapParam);
		if(updateFlag == 0) {
			throw new BusicenException("取消活动失败！");
		}

		_cancleAudit(activityId, token);

		Map<String, Object> map = baseMapper.selectActivityById(mapParam);
		unTransFiled(map);
		return ResultHandler.updateOk();
	}

	@Override
	public EntityResult<Map<String, Object>> getById(String activityId, String token) {
		if (StringHelper.IsEmptyOrNull(activityId)){
			throw new BusicenException("activityId不能为空！");
		}
		Map<String, Object> mapParam = new HashMap<>();
		mapParam.put("activityId", activityId);
		Map<String, Object> map = baseMapper.selectActivityById(mapParam);
		unTransFiled(map);
		ActivityStatusEnum.dealActivityStatus(map);
		// 获取活动详情页图片
		//_setActivityDetailPageList(activityId, map);
		return ResultHandler.updateOk(map);
	}

	// 获取活动详情页图片
	@Override
	public void setActivityAttachment(Map<String, Object> activityMap, ActivityAttachmentEnum activityAttachmentEnum) {
		List<Map<String, Object>> list = _getActivityAttachmentList((String)activityMap.get("activityId"), activityAttachmentEnum);
		activityMap.put(activityAttachmentEnum.getResult() + "AttachementList", list);
	}

	private List<Map<String, Object>> _getActivityAttachmentList(String activityId, ActivityAttachmentEnum activityAttachmentEnum) {
		Page<Map<String, Object>> page = new Page<Map<String, Object>>(-1, -1);
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("billId", activityId);
		paramMap.put("isEnable", "1");
		paramMap.put("billType", activityAttachmentEnum.getResult());
		List<Map<String, Object>> list = baseMapper.selectAttachmentByPage(page, paramMap);
		return list;
	}

	public Map<String, Object> transFiled(String oldJson, Map<String, Object> map) {
		FieldMappingIn info = new FieldMappingIn();
		info.setSourceTableCode("t_acc_bu_activity");
		info.setBillType("DLRCLUE");
		if (!StringHelper.IsEmptyOrNull(map.get("businessType"))) {
			info.setBusinessType(map.get("businessType").toString());
		} else {
			info.setBusinessType("-1");
		}
		info.setParam(map);
		info.setOldJson(oldJson);
		Map<String, Object> filedMap = sacFieldMappingConfigService.tranFieldToMap(info);
		if (filedMap != null && filedMap.size() > 0) {
			// 合并
			map.putAll(filedMap);
		}
		return map;
	}

	private void unTransFiled(List<Map<String, Object>> list) {
		for(int i=0;i<list.size();i++){
			unTransFiled(list.get(i));
		}
	}

	private void unTransFiled(Map<String, Object> infoMap) {
		if(infoMap == null || infoMap.isEmpty()) {
			return;
		}
		String extendsJson="";
		if(!StringHelper.IsEmptyOrNull(infoMap.get("extendsJson"))){
			infoMap.putAll(JSON.parseObject(infoMap.get("extendsJson").toString()));
			extendsJson=infoMap.get("extendsJson").toString();
		}
		unTransFiled(extendsJson,infoMap);
	}
	/**
	 * 回访表扩展字段转换 反转
	 * 将数据库的字段转换为映射的参数字段
	 * @param oldJson   原来保存的json
	 * @param 新的要保存的map
	 * @return
	 */
	private Map<String, Object> unTransFiled(String oldJson, Map<String, Object> map) {
		FieldMappingIn info = new FieldMappingIn();
		info.setSourceTableCode("t_acc_bu_activity");
		info.setBillType("DLRCLUE");
		if (!StringHelper.IsEmptyOrNull(map.get("businessType"))) {
			info.setBusinessType(map.get("businessType").toString());
		} else {
			info.setBusinessType("-1");
		}
		info.setParam(map);
		info.setOldJson(oldJson);
		Map<String, Object> filedMap = sacFieldMappingConfigService.unTranFieldToMap(info);
		if (filedMap != null && filedMap.size() > 0) {
			// 合并
			map.putAll(filedMap);
		}
		return map;
	}

	/**
	 * 活动日历查询
	 */
	@Override
	public ListResult<Map<String, Object>> accBuActivityCalenderQueryList(ParamPage<Map<String, Object>> mapParam) {
		ListResult<Map<String, Object>> result=new ListResult<Map<String,Object>>();
		try {
			//需要先查其负责的专营店(根据权限查询)
			if ("1".equals(mapParam.getParam().get("isDefault"))) {
				// 根据token去查询该用户的权限
				userAuthorityQuery(mapParam);
			} else {
				// 参数处理
				paramHandle(mapParam);
			}
			Page<Map<String, Object>> page = new Page<Map<String, Object>>(mapParam.getPageIndex(),mapParam.getPageSize());
			List<Map<String, Object>> list = accBuActivityMapper.accBuActivityCalenderQuery(mapParam.getParam(),page);
			page.setRecords(list);
			result = BusicenUtils.page2ListResult(page);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("accBuActivityCalenderQueryList", e);
			throw e;
		}
		return result;
	}

	/**
	 * 活动日历查询——根据活动地点查询(门店/户外)
	 */
	@Override
	public ListResult<Map<String, Object>> accBuActivityCalenderQueryByWeekList(ParamPage<Map<String, Object>> mapParam) {
		ListResult<Map<String, Object>> result=new ListResult<Map<String,Object>>();
		try {
			//不是总部的时候需要先查其负责的专营店
			if ("1".equals(mapParam.getParam().get("isDefault"))) {
				// 根据token去查询该用户的权限
				userAuthorityQuery(mapParam);
			} else {
				// 参数处理
				paramHandle(mapParam);
			}
			Page<Map<String, Object>> page = new Page<Map<String, Object>>(mapParam.getPageIndex(),mapParam.getPageSize());
			List<Map<String, Object>> list = accBuActivityMapper.accBuActivityCalenderQueryByWeek(mapParam.getParam(),page);
			page.setRecords(list);
			result = BusicenUtils.page2ListResult(page);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("accBuActivityCalenderQueryByWeekList", e);
			throw e;
		}
		return result;
	}
	public void userAuthorityQuery(ParamPage<Map<String, Object>> mapParam){
		//根据token获取岗位信息
		String token=String.valueOf(mapParam.getParam().get("token"));
		UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
		//根据userId查相应负责的专营店
		Map<String,Object> param=new HashMap<String, Object>();
		param.put("pageIndex", 1);
		param.put("pageSize", -1);
		param.put("userId", userBusiEntity.getUserID());
		ListResult<Map<String, Object>> list=accSysClueService.querymanagedlr(token,param);
		if(list.getRows().size()>0) {
			String dlrCodeString=list.getRows().stream().map(u->String.valueOf(u.get("dlrCode"))).collect(Collectors.joining(","));
			mapParam.getParam().put("dlrCodeString", dlrCodeString);
		}

	}

	@SuppressWarnings("unchecked")
	public void paramHandle(ParamPage<Map<String, Object>> mapParam) {
		//门店空间数组
		if(!StringHelper.IsEmptyOrNull(mapParam.getParam().get("dlrSpaceCodeList"))) {
			List<Map<String, Object>> dlrSpaceCodeList=(List<Map<String, Object>>) mapParam.getParam().get("dlrSpaceCodeList");
			if(dlrSpaceCodeList.size()>0) {
				String dlrSpaceCodeString = dlrSpaceCodeList.stream().map(u->u.get("dlrSpaceCode").toString()).collect(Collectors.joining(","));
				mapParam.getParam().put("dlrSpaceCodeString", dlrSpaceCodeString);
			}
		}
		//门店所属区域数组
		if(!StringHelper.IsEmptyOrNull(mapParam.getParam().get("dlrRegionCodeList"))) {
			List<Map<String, Object>> dlrRegionCodeList=(List<Map<String, Object>>) mapParam.getParam().get("dlrRegionCodeList");
			if(dlrRegionCodeList.size()>0) {
				String dlrRegionCodeString = dlrRegionCodeList.stream().map(u->u.get("dlrRegionCode").toString()).collect(Collectors.joining(","));
				mapParam.getParam().put("dlrRegionCodeString", dlrRegionCodeString);
			}
		}
		//门店所属城市数组
		if(!StringHelper.IsEmptyOrNull(mapParam.getParam().get("dlrCityCodeList"))) {
			List<Map<String, Object>> dlrCityCodeList=(List<Map<String, Object>>) mapParam.getParam().get("dlrCityCodeList");
			if(dlrCityCodeList.size()>0) {
				String dlrCityCodeString = dlrCityCodeList.stream().map(u->u.get("dlrCityCode").toString()).collect(Collectors.joining(","));
				mapParam.getParam().put("dlrCityCodeString", dlrCityCodeString);
			}
		}
		//门店数组
		if(!StringHelper.IsEmptyOrNull(mapParam.getParam().get("dlrCodeList"))) {
			List<Map<String, Object>> dlrCodeList=(List<Map<String, Object>>) mapParam.getParam().get("dlrCodeList");
			if(dlrCodeList.size()>0) {
				String dlrCodeString = dlrCodeList.stream().map(u->u.get("dlrCode").toString()).collect(Collectors.joining(","));
				mapParam.getParam().put("dlrCodeString", dlrCodeString);
			}
		}
	}

	private ActivityCreateTypeEnum _getActivityCreateType(String post, String token) {
		List<String> postList = Arrays.asList(StringUtils.split(post, ","));
		//获取岗位
		ParamPage<Map<String, Object>> paramPage = new ParamPage<>();
		paramPage.setPageIndex(-1);
		paramPage.setPageSize(-1);
		Map<String, Object> confiParam = new HashMap<>();
		confiParam.put("configCode", "POST_AND_ACTIVITY_CREATE_TYPE");
		paramPage.setParam(confiParam);
		ListResult<Map<String, Object>> listReuslt = accSysClueService.queryConfigList(token, paramPage);
		if(listReuslt!=null && listReuslt.getRows()!=null && listReuslt.getRows().size()>0){
			for(Map<String, Object> map: listReuslt.getRows()) {
				log.info("{}", map);
				String configValueCode = (String)map.get("configValueCode");
				String column1 = (String)map.get("column1");
				log.info("configValueCode={}", configValueCode);
				log.info("column1={}", column1);
				if(postList.contains(configValueCode)) {
					return ActivityCreateTypeEnum.valueOfName((String)map.get("column1"));
				}
			}
		}
		return null;
	}

	@Override
	@SuppressWarnings("unchecked")
	public void regist(InterceptorWrapperRegistor registor) {
		registor.before("acc_activity_submit_initial", (context, model) -> {
			Map<String, Object> activityMap = (Map<String, Object>)context.data().getP()[0];
			String token = (String)context.data().getP()[1];
			_initialActivity(activityMap, token);
		});

		// 活动提交后生成审批记录
		registor.after("acc_activity_submit_aduit", (context, model) -> {
			Map<String, Object> activityMap = (Map<String, Object>)context.data().getP()[0];
			String token = (String)context.data().getP()[1];

			String createTypeCode = (String)activityMap.get("createTypeCode");
			Map<String, Object> auditMap = new HashMap<>();
			auditMap.putAll(activityMap);
			// 活动创建类型
			auditMap.put("billType", "ACTION");
			auditMap.put("billTypeName", "活动");

			// 业务类型
			auditMap.put("businessType", createTypeCode);
			auditMap.put("businessTypeName", activityMap.get("createTypeName"));

			auditMap.put("billCode", activityMap.get("activityId"));
			EntityResult<Map<String, Object>> result = commonAuditService.apply(auditMap, token);
			if("1".equals(result.getResult())) {
				Map<String, Object> rows = result.getRows();
				if("End".equals(rows.get("nodeCode"))) {
					ActionAduitStategy.setStatusByEndNodeCode(activityMap);
					// TODO updateStatus
					EntityResult<Map<java.lang.String, Object>> entityResult = accBuActivityService.updateActivityStatus(activityMap, token);
					if("0".equals(entityResult.getResult())) {
						log.info("更新活动状态出错！{}", entityResult.getMsg());
						throw BusicenException.create("更新活动状态出错！");
					}
				} else {
					// unaudit
					// activityMap.put("statusCode", ActivityStatusEnum.audited.getResult());
					// activityMap.put("statusName", ActivityStatusEnum.audited.getMsg());
				}
			} else {
				log.info("申请活动审批出错！{}", result.getMsg());
				throw BusicenException.create("申请活动审批出错！");
			}
		});
		// 活动提交后生成核销审批记录
		registor.after("acc_activity_hx_aduit", (context, model) -> {
			Map<String, Object> activityMap = (Map<String, Object>)context.data().getP()[0];
			String token = (String)context.data().getP()[1];

			Map<String, Object> auditMap = new HashMap<>();
			auditMap.putAll(activityMap);
			// 活动创建类型
			auditMap.put("billType", "ACTIONHX");
			auditMap.put("billTypeName", "活动核销");

			// 业务类型
			auditMap.put("businessType", "-1");
			auditMap.put("businessTypeName", "全部");

			auditMap.put("billCode", activityMap.get("activityId"));
			EntityResult<Map<String, Object>> result = commonAuditService.apply(auditMap, token);
			if("1".equals(result.getResult())) {
				Map<String, Object> rows = result.getRows();
				String nodeCode = (String)rows.get("nodeCode");

				if(ActivityHxStatusEnum.areaSh.getResult().equals(nodeCode)) {
					activityMap.put("hxStatusCode", ActivityHxStatusEnum.areaSh.getResult());
					activityMap.put("hxStatusName", ActivityHxStatusEnum.areaSh.getMsg());
				} else if(ActivityHxStatusEnum.areaMgSh.getResult().equals(nodeCode)) {
					activityMap.put("hxStatusCode", ActivityHxStatusEnum.areaMgSh.getResult());
					activityMap.put("hxStatusName", ActivityHxStatusEnum.areaMgSh.getMsg());
				} else if(ActivityHxStatusEnum.moneySh.getResult().equals(nodeCode)) {
					activityMap.put("hxStatusCode", ActivityHxStatusEnum.moneySh.getResult());
					activityMap.put("hxStatusName", ActivityHxStatusEnum.moneySh.getMsg());
				} else if("End".equals(nodeCode)) {
					activityMap.put("hxStatusCode", ActivityHxStatusEnum.audited.getResult());
					activityMap.put("hxStatusName", ActivityHxStatusEnum.audited.getMsg());
				}
				accBuActivitySave(activityMap, token);
			}
		});
	}



	// TODO
	private void _initialActivity(Map<String, Object> activityMap, String token) {
		String dlrSupportedCode = (String)activityMap.get("dlrSupportedCode");
		String dlrSupportedShortName = (String)activityMap.get("dlrSupportedShortName");

		// 所属门店
		activityMap.put("dlrCode", dlrSupportedCode);
		activityMap.put("dlrShortName", dlrSupportedShortName);

		UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
		if(StringUtils.isNotBlank(token) && userBusiEntity != null) {
			String createTypeCode = (String)activityMap.get("createTypeCode");
			ActivityCreateTypeEnum createTypeEnum = getActivityCreateTypeEnum(createTypeCode, token);
			activityMap.put("createTypeCode", createTypeEnum.getResult());
			activityMap.put("createTypeName", createTypeEnum.getMsg());

			// 如果是 店长自建(DLR)，取当前登录人所属门店
			if(StringUtils.isBlank(dlrSupportedCode)) {
				// 所属门店
				activityMap.put("dlrCode", userBusiEntity.getDlrCode());
				activityMap.put("dlrShortName", userBusiEntity.getDlrName());
			}
			String dlrCode = (String)activityMap.get("dlrCode");
			dealCityAndRegion(activityMap, dlrCode, token);
		}

		_dealAreaUsedLengthOfTime(activityMap);

		// 不使用适用值列表 2022-3-17
		//		String tipsTimeCode = (String)activityMap.get("tipsTimeCode");
		//		if(StringUtils.isNotBlank(tipsTimeCode) ) {
		//			activityMap.put("tipsTimeName", String.format("开始前%s小时", tipsTimeCode));
		//		}

		activityMap.put("statusCode", ActivityStatusEnum.unaudit.getResult());
		activityMap.put("statusName", ActivityStatusEnum.unaudit.getMsg());
		activityMap.put("releaseStatusCode", ActivityReleaseStatusEnum.unReleased.getResult());
		activityMap.put("releaseStatusName", ActivityReleaseStatusEnum.unReleased.getMsg());
	}

	private String getDateStr(Map<String, Object> activityMap, String key) {
		Object object = activityMap.get(key);
		if(object instanceof String) {
			return (String)object;
		}
		if(object instanceof Timestamp) {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			return sdf.format((Timestamp)object);
		}
		return null;
	}
	// 处理 场地使用时长
	private void _dealAreaUsedLengthOfTime(Map<String, Object> activityMap) {
		String dlrAreaUsedStartTime = getDateStr(activityMap, "dlrAreaUsedStartTime");
		String dlrAreaUsedEndTime = getDateStr(activityMap, "dlrAreaUsedEndTime");
		if(StringUtils.isNotBlank(dlrAreaUsedStartTime) && StringUtils.isNotBlank(dlrAreaUsedEndTime)) {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			try {
				Date startDate = sdf.parse(dlrAreaUsedStartTime);
				Date endDate = sdf.parse(dlrAreaUsedEndTime);

				long time = endDate.getTime() - startDate.getTime();
				if(time < 0 ) {
					throw BusicenException.create("场地使用开始时间 不能大于 场地使用结束时间");
				}

				// 场地使用时长 （单位：小时）
				long hour = time / (1000 * 60 * 60);
				if(hour * 1000 * 60 * 60 == time) {
					activityMap.put("dlrAreaUsedLengthOfTime", "" + hour);
				} else {
					// 不够一小时，按一小时算
					activityMap.put("dlrAreaUsedLengthOfTime", "" + (hour + 1));
				}
				log.info("dlrAreaUsedStartTime={},dlrAreaUsedEndTime={},hour={},", dlrAreaUsedStartTime, dlrAreaUsedEndTime, hour);
			} catch (ParseException e) {
				throw BusicenException.create("场地使用开始时间和场地使用结束时间格式不对（yyyy-MM-dd HH:mm:ss）");
			}
		}
	}

	public ActivityCreateTypeEnum getActivityCreateTypeEnum(String createTypeCode, String token) {
		ActivityCreateTypeEnum createTypeEnum = null;
		if(ActivityCreateTypeEnum.app.getResult().equals(createTypeCode)) {
			createTypeEnum = ActivityCreateTypeEnum.app;
		} else if(ActivityCreateTypeEnum.develop.getResult().equals(createTypeCode)) {
			createTypeEnum=ActivityCreateTypeEnum.develop;
		} else {
			UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(token);
			if(userBusiEntity == null) {
				throw BusicenException.create("找不到当前用户！");
			}
			if ("2".equals(userBusiEntity.getOrgType())){
				createTypeEnum=ActivityCreateTypeEnum.dlr;
			}else {
				createTypeEnum = _getActivityCreateType(userBusiEntity.getPosCode(), token);
			}
		}
		log.info("createTypeEnum={}",createTypeEnum);
		// 岗位编码
		if(createTypeEnum == null) {
			throw BusicenException.create("该人员所处岗位不能创建活动！");
		}
		return createTypeEnum;
	}

	/**
	 *  处理城市字段和大区字段
	 *  dlrCityCode dlrCityName dlrRegionCode dlrRegionName
	 * @param activityMap
	 * @param token
	 * @param dlrCode
	 */
	@Override
	public void dealCityAndRegion(Map<String, Object> activityMap, String dlrCode, String token) {
		if(StringUtils.isNoneBlank(dlrCode)) {
			String dlrCityCode = "";
			String dlrCityName = "";
			String dlrRegionCode = "";
			String dlrRegionName = "";
			String[] dlrCodeArray = StringUtils.split(dlrCode, ",");
			for(String temDlrCode: dlrCodeArray) {
				if(StringUtils.isBlank(temDlrCode)) {
					continue;
				}
				Map<String, Object> info = new HashMap<>();
				info.put("pageIndex", 1);
				info.put("pageSize", 1);
				info.put("dlrCode", temDlrCode);
				ListResult<Map<String, Object>> listResult = accSysClueService.querycityinfobydlr(token, info);
				if("0".equals(listResult.getResult())) {
					throw BusicenException.create("根据门店编码查询城市大区信息出错：" + listResult.getMsg());
				}
				Map<String, Object> orgDlrMap = null;
				if(listResult.getRows() != null && !listResult.getRows().isEmpty()) {
					orgDlrMap = listResult.getRows().get(0);
				}
				log.info("orgDlrMap={}",orgDlrMap);
				if(orgDlrMap != null) {
					dlrCityCode += orgDlrMap.get("cityId") + ",";
					dlrCityName += orgDlrMap.get("cityName") + ",";
					String bigAreaId = (String)orgDlrMap.get("areaId");
					if(bigAreaId != null) {
						// 正常数据只有一个值，异常数据多个值用逗号分隔
						//dlrRegionCode += bigAreaId + ",";
						dlrRegionCode += StringUtils.split(bigAreaId, ",")[0] + ",";
					}
					String bigAreaName = (String)orgDlrMap.get("areaName");
					if(bigAreaName != null) {
						// dlrRegionName += bigAreaName + ",";
						dlrRegionName += StringUtils.split(bigAreaName, ",")[0] + ",";
					}
				}
			}
			if(dlrCityCode.length() >= 1 && StringUtils.endsWith(dlrCityCode, ",")) {
				activityMap.put("dlrCityCode", dlrCityCode.subSequence(0, dlrCityCode.length() -1));
			}
			if(dlrCityName.length() >= 1 && StringUtils.endsWith(dlrCityName, ",")) {
				activityMap.put("dlrCityName", dlrCityName.subSequence(0, dlrCityName.length() -1));
			}
			if(dlrRegionCode.length() >= 1 && StringUtils.endsWith(dlrRegionCode, ",")) {
				activityMap.put("dlrRegionCode", dlrRegionCode.subSequence(0, dlrRegionCode.length() -1));
			}
			if(dlrRegionName.length() >= 1 && StringUtils.endsWith(dlrRegionName, ",")) {
				activityMap.put("dlrRegionName", dlrRegionName.subSequence(0, dlrRegionName.length() -1));
			}
		}
	}

	private void _checkSubmitField(Map<String, Object> activityMap) {
		ValidResultCtn fireRule = null;
		// 类型，长度校验
		fireRule = fireFieldRule.fireRule(activityMap, "activity-temp-save-check", "maindata");
		String resMsg = fireRule.getNotValidMessage();
		if (!fireRule.isValid()){
			throw new BusicenException(resMsg);
		}

		String createTypeCode = (String)activityMap.get("createTypeCode");
		if(ActivityCreateTypeEnum.develop.getResult().equals(createTypeCode)) {
			// 开发类活动
			fireRule = fireFieldRule.fireRule(activityMap, "activity-submit-develop-check", "maindata");
		} else {
			fireRule = fireFieldRule.fireRule(activityMap, "activity-submit-check", "maindata");
		}
		resMsg = fireRule.getNotValidMessage();
		if (!fireRule.isValid()){
			throw new BusicenException(resMsg);
		}
	}

	/**
	 * 相同门店，不能有相同时间段的活动
	 * @param activityMap
	 */
	private void _checkRepeat(Map<String, Object> activityMap) {
		String dlrCode = (String)activityMap.get("dlrCode");
		String createTypeCode = (String)activityMap.get("createTypeCode");
		if(StringUtils.isBlank(dlrCode)) {
			return;
		}
		//  本地开发类不需要校验
		if(ActivityCreateTypeEnum.develop.getResult().equals(createTypeCode)) {
			return;
		}

		String beginTime = (String)activityMap.get("dlrAreaUsedStartTime");
		String endTime = (String)activityMap.get("dlrAreaUsedEndTime");
		String dlrSpaceCode = (String)activityMap.get("dlrSpaceCode");
		Map<String, Object> checkRepeatMap = new HashMap<String, Object>();
		checkRepeatMap.put("dlrCode", dlrCode);
		checkRepeatMap.put("dlrAreaUsedStartTime", beginTime);
		checkRepeatMap.put("dlrAreaUsedEndTime", endTime);
		checkRepeatMap.put("dlrSpaceCode", dlrSpaceCode);
		List<Map<String, Object>> list = baseMapper.activityRepeat(checkRepeatMap);
		if(list.isEmpty()) {
			// 没有重复
			return;
		}
		String activityId = (String)activityMap.get("activityId");
		if(StringUtils.isNotBlank(activityId)) {
			if(list.size() == 1 && StringUtils.equals(activityId, (String)list.get(0).get("activityId"))) {
				// 没有重复
				return;
			}
		}

		String repeatTip = list.stream().map(u->u.get("activityName").toString()).collect(Collectors.joining(","));
		log.info("营销店的活动时间有重复: {}, ", repeatTip);
		//		throw BusicenException.create("该营销店的活动时间与其他活动有重叠！[活动开始时间=" + beginTime + " —— 活动结束时间=" + endTime + "]" + "冲突的活动有" + repeatTip);
		throw BusicenException.create("该活动与["+repeatTip+"]时间冲突");

	}

	private void _checkAddressType(Map<String, Object> mapParam) {
		// 活动地点编码
		String addressTypeCode = (String)mapParam.get("addressTypeCode");
		if(ActivityAddressEnum.dlr.getResult().equals(addressTypeCode)) {
			if(StringHelper.IsEmptyOrNull(mapParam.get("dlrSpaceCode"))) {
				throw BusicenException.create("你已选择活动地点" + ActivityAddressEnum.dlr.getMsg() + ",门店空间不能为空！");
			}
			if(StringHelper.IsEmptyOrNull(mapParam.get("dlrAreaUsedStartTime"))) {
				throw BusicenException.create("你已选择活动地点" + ActivityAddressEnum.dlr.getMsg() + ",场地使用开始时间不能为空！");
			}
			if(StringHelper.IsEmptyOrNull(mapParam.get("dlrAreaUsedLengthOfTime"))) {
				throw BusicenException.create("你已选择活动地点" + ActivityAddressEnum.dlr.getMsg() + ",场地使用时长不能为空！");
			}
		} else if(ActivityAddressEnum.gps.getResult().equals(addressTypeCode)) {
			if(StringHelper.IsEmptyOrNull(mapParam.get("dlrAddressDetail"))) {
				throw BusicenException.create("你已选择活动地点" + ActivityAddressEnum.gps.getMsg() + ",具体地址不能为空！");
			}
		}
	}

	/**
	 * 活动小类查询
	 */
	@Override
	public ListResult<Map<String, Object>> queryAcsSmallType(ParamPage<Map<String, Object>> paramPage) {
		try {
			IPage<Map<String, Object>> page = new Page<>(paramPage.getPageIndex(), paramPage.getPageSize());
			List<Map<String, Object>> list = accBuActivityMapper.queryAcsSmallType(page, paramPage.getParam());
			page.setRecords(list);
			return BusicenUtils.page2ListResult(page);
		} catch (Exception e) {
			log.error("queryAcsSmallType:", e);
			throw e;
		}
	}

	/**
	 * 活动状态更新定时调用
	 */
	@Override
	public void updateActivityStatusDistJob() {
		//先查询已经审核通过且到了发布时间（活动类型为非app活动）的活动
		IPage<Map<String, Object>> page = new Page<>(1, 100);
		List<Map<String, Object>> list =accBuActivityMapper.queryNeedRealseActivity(page,null);
		if(list.size()>0) {
			//调用状态更新方法
			for(Map<String,Object> map:list) {
				map.put("releaseStatusCode", ActivityReleaseStatusEnum.released.getResult());
				map.put("releaseStatusName", ActivityReleaseStatusEnum.released.getMsg());
				updateActivityStatus(map, null);
			}
		}

	}

	@Override
	public EntityResult<Map<String, Object>> sacAccBuActivitySave(Map<String, Object> mapParam, String token) {
		try {
			if (StringHelper.IsEmptyOrNull(mapParam.get("activityId"))) {
				mapParam.put("activityId", UUID.randomUUID().toString());
				BusicenUtils.invokeUserInfo(mapParam, SOU.Save, token);
				transFiled(null, mapParam);
				accBuActivityMapper.insertAccBuActivity(mapParam);
			} else {
				// 更新
				BusicenUtils.invokeUserInfo(mapParam, SOU.Update, token);
				transFiled((String)mapParam.get("extendsJson"), mapParam);
				int updateCount = accBuActivityMapper.updateAccBuActivity(mapParam);
				if(updateCount == 0) {
					throw BusicenException.create("更新失败！");
				}
			}
			return ResultHandler.updateOk(mapParam);
		} catch (Exception e) {
			log.error("sacAccBuActivitySave", e);
			throw e;
		}
	}
}
