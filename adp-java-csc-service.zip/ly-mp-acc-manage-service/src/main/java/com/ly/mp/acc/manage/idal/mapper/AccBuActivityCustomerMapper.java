package com.ly.mp.acc.manage.idal.mapper;

import com.ly.mp.acc.manage.entities.AccBuActivityCustomer;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author ly-linliq
 * @since 2022-01-04
 */
public interface AccBuActivityCustomerMapper extends BaseMapper<AccBuActivityCustomer> {

	/**
	 * 新增活动顾客
	 * @param param
	 * @return
	 */
	public int insertAccBuActivityCustomer(@Param("paramList") List<Map<String, Object>> param);

	/**
	 * 修改活动顾客相关信息
	 * @param param
	 * @return
	 */
	public int updateAccBuActivityCustomer(@Param("paramList") List<Map<String, Object>> param);
	
	/**
	 * 查重
	 * @param param
	 * @return
	 */
	public int checkRepeat(@Param("param") Map<String, Object> param);
	
	/**
	 * 查询活动顾客
	 * @param param
	 * @param page
	 * @return
	 */
	public List<Map<String,Object>> selectAccBuActivityCustomer(@Param("param") Map<String, Object> param,IPage<Map<String, Object>> page);

	int checkSmallType(@Param("param") Map<String, Object> param);

	int updateSmallType(@Param("param") Map<String, Object> param);

	int insertSmallType(@Param("param") Map<String, Object> param);

	int updateAppId(@Param("param") Map<String, Object> param);
}
