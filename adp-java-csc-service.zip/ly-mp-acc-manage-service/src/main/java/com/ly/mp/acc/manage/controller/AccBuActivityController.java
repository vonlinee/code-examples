package com.ly.mp.acc.manage.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.*;

import com.ly.mp.acc.manage.enums.ActivityAttachmentEnum;
import com.ly.mp.acc.manage.enums.ActivityCreateTypeEnum;
import com.ly.mp.acc.manage.enums.ActivityReleaseStatusEnum;
import com.ly.mp.acc.manage.enums.ActivityStatusEnum;
import com.ly.mp.acc.manage.otherservice.IAccSysClueService;
import com.ly.mp.acc.manage.otherservice.IAccSysOrgService;
import com.ly.mp.acc.manage.service.IAccBuActivityService;
import com.ly.mp.assembly.approve.service.ICommonAuditService;
import com.ly.mp.bucn.pack.entity.ParamBase;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.constant.UserBusiEntity;
import com.ly.mp.busi.base.context.BusicenContext;
import com.ly.mp.busi.base.context.BusicenInvoker;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Api(value = "活动表", tags = { "活动表" })
@RestController
@RequestMapping(value = "/ly/acc/activity")
public class AccBuActivityController {

	private static Logger logger = LoggerFactory.getLogger(AccBuActivityController.class);

	@Autowired IAccBuActivityService accBuActivityService;
	@Autowired IAccSysOrgService accSysOrgService;
	@Autowired IAccSysClueService accSysClueService;

	// ================================================ start
	@ApiOperation(value="活动列表",notes="活动列表）")
	@RequestMapping(value="/getactivitypage.do",method=RequestMethod.POST)
	public ListResult<Map<String, Object>> getActivityPage(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) ParamPage<Map<String, Object>> queryCondition) throws Exception{
		return BusicenInvoker.doList(()->{
			UserBusiEntity userBusiEntity = BusicenContext.getCurrentUserBusiInfo(authentication);
			Map<String, Object> activityMap = queryCondition.getParam();
			logger.info("dlrCode={}", userBusiEntity.getDlrCode());
			logger.info("dlrNamee={}", userBusiEntity.getDlrName());
			logger.info("orgType={}", userBusiEntity.getOrgType());
			logger.info("userId={}", userBusiEntity.getUserID());
			logger.info("userName={}", userBusiEntity.getUserName());
			// orgType == 1 (专营店)  orgType == 0 (总部)
			String orgType = userBusiEntity.getOrgType();
			activityMap.put("orCreator", userBusiEntity.getUserID()==null? "-1": userBusiEntity.getUserID());
			if("1".equals(orgType)) {
				activityMap.put("queryType", "0");//0门店，1大使、大区，2总部
				activityMap.put("orDlrCode", userBusiEntity.getDlrCode());
			} else if("0".equals(orgType)) {
				activityMap.put("queryType", "1");//0门店，1大使、大区，2总部
				activityMap.put("orDlrCode", StringUtils.join(_getUserDlrCodeList(authentication, userBusiEntity.getUserID()), ","));
			}

			_filterStatusCode(activityMap);
			activityMap.put("isEnable", "1");
			return accBuActivityService.getActivityPage(queryCondition, authentication);
		}).result();
	}

	private void _filterStatusCode(Map<String, Object> activityMap) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String strDate = sdf.format(new Date());
		if(ActivityStatusEnum.audited.getResult().equals(activityMap.get("statusCode")) ) {
			activityMap.put("statusCode", ActivityStatusEnum.audited.getResult());
			//已审核有两个:已审核、活动中心已审核
			activityMap.put("statusName",String.valueOf(activityMap.get("statusName")));
			activityMap.put("releaseStatusCode", ActivityReleaseStatusEnum.unReleased.getResult());
			activityMap.put("endTimeStart", strDate);
		} else if(ActivityStatusEnum.unaudit.getResult().equals(activityMap.get("statusCode")) ) {
			activityMap.put("statusCode", ActivityStatusEnum.unaudit.getResult());
			//待审核有两个:待审核、待活动中心审核
			activityMap.put("statusName",String.valueOf(activityMap.get("statusName")));
		} else if(ActivityStatusEnum.bh.getResult().equals(activityMap.get("statusCode")) ) {
			activityMap.put("statusCode", ActivityStatusEnum.bh.getResult());
			//驳回有两个:驳回、活动中心驳回
			activityMap.put("statusName",String.valueOf(activityMap.get("statusName")));
		} else if(ActivityStatusEnum.released.getResult().equals(activityMap.get("statusCode")) ) {
			activityMap.put("statusCode", ActivityStatusEnum.audited.getResult());
			activityMap.put("statusName","");
			activityMap.put("releaseStatusCode", ActivityReleaseStatusEnum.released.getResult());
			activityMap.put("endTimeStart", strDate);
		} else if(ActivityStatusEnum.end.getResult().equals(activityMap.get("statusCode")) ) {
			activityMap.put("statusCode", ActivityStatusEnum.audited.getResult());
			activityMap.put("statusName","");
			activityMap.put("releaseStatusCode", ActivityReleaseStatusEnum.released.getResult());
			activityMap.put("endTimeEnd", strDate);
		}

	}

	@ApiOperation(value="活动列表-查询全部",notes="活动列表-查询全部）")
	@RequestMapping(value="/getactivityallpage.do",method=RequestMethod.POST)
	public ListResult<Map<String, Object>> getActivityAllPage(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) ParamPage<Map<String, Object>> queryCondition) throws Exception{
		return BusicenInvoker.doList(()->{
			Map<String, Object> activityMap = queryCondition.getParam();
			activityMap.put("queryType", "2");//0门店，1大使、大区，2总部
			activityMap.put("isEnable", "1");
			_filterStatusCode(activityMap);
			return accBuActivityService.getActivityPage(queryCondition, authentication);
		}).result();
	}

	@ApiOperation(value="创建活动-获取创建活动类型",notes="创建活动-获取创建活动类型")
	@RequestMapping(value="/getactivitycreatetype.do",method=RequestMethod.POST)
	public EntityResult<Map<String, Object>> getActivityCreateType(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication) throws Exception{
		return BusicenInvoker.doEntity(()->accBuActivityService.getActivityCreateType(authentication)).result();
	}

	@ApiOperation(value="创建活动-暂存",notes="创建活动-暂存")
	@RequestMapping(value="/temporarysave.do",method=RequestMethod.POST)
	public EntityResult<Map<String, Object>> temporarySave(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) ParamBase<Map<String, Object>> queryCondition) throws Exception{
		return BusicenInvoker.doEntity(()->accBuActivityService.temporarySave(queryCondition.getParam(), authentication)).result();
	}

	@ApiOperation(value="创建活动-提交",notes="创建活动-提交")
	@RequestMapping(value="/submit.do",method=RequestMethod.POST)
	public EntityResult<Map<String, Object>> submit(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) ParamBase<Map<String, Object>> queryCondition) throws Exception{
		return BusicenInvoker.doEntity(()->accBuActivityService.submit(queryCondition.getParam(), authentication)).result();
	}

	@ApiOperation(value="创建活动-本地开发类",notes="创建活动-本地开发类")
	@RequestMapping(value="/submitdevelop.do",method=RequestMethod.POST)
	public EntityResult<Map<String, Object>> submitDevelop(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) ParamBase<Map<String, Object>> queryCondition) throws Exception{
		return BusicenInvoker.doEntity(()->{
			Map<String, Object> activityMap = queryCondition.getParam();
			activityMap.put("createTypeCode", ActivityCreateTypeEnum.develop.getResult());
			activityMap.put("createTypeName", ActivityCreateTypeEnum.develop.getMsg());
			return accBuActivityService.submit(queryCondition.getParam(), authentication);
		}).result();
	}

	@ApiOperation(value="发起核销",notes="发起核销")
	@RequestMapping(value="/hx.do",method=RequestMethod.POST)
	public EntityResult<Map<String, Object>> hx(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) ParamBase<Map<String, Object>> queryCondition) throws Exception{
		return BusicenInvoker.doEntity(()->accBuActivityService.hx(queryCondition.getParam(), authentication)).result();
	}

	@ApiOperation(value="活动总结",notes="活动总结")
	@RequestMapping(value="/summary.do",method=RequestMethod.POST)
	public EntityResult<Map<String, Object>> summary(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) ParamBase<Map<String, Object>> queryCondition) throws Exception{
		return BusicenInvoker.doEntity(()->{
			return accBuActivityService.summary(queryCondition.getParam(), authentication);
		}).result();
	}

	//	@ApiOperation(value="分配资源",notes="分配资源")
	//	@RequestMapping(value="/allocateresources.do",method=RequestMethod.POST)
	//	public EntityResult<Map<String, Object>> allocateResources(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
	//			@RequestBody(required = false) ParamBase<Map<String, Object>> queryCondition) throws Exception{
	//		return BusicenInvoker.doEntity(()->accBuActivityService.allocateResources(queryCondition.getParam(), authentication)).result();
	//	}

	@ApiOperation(value="活动复制",notes="活动复制")
	@RequestMapping(value="/copy.do",method=RequestMethod.POST)
	public EntityResult<Map<String, Object>> copy(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) ParamBase<Map<String, Object>> queryCondition) throws Exception{
		return BusicenInvoker.doEntity(()->{
			return accBuActivityService.copy(queryCondition.getParam(), authentication);
		}).result();
	}


	@ApiOperation(value="活动列表-活动查看",notes="活动列表-活动查看")
	@RequestMapping(value="/getbyid.do",method=RequestMethod.POST)
	public EntityResult<Map<String, Object>> getById(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) ParamBase<Map<String, Object>> queryCondition) throws Exception{
		return BusicenInvoker.doEntity(()->{
			Assert.notNull(queryCondition.getParam(), "参数param不能为空");
			EntityResult<Map<String, Object>> entityResult = accBuActivityService.getById((String)queryCondition.getParam().get("activityId"), authentication);
			if("1".equals(entityResult.getResult())) {
				Map<String, Object> activityMap = entityResult.getRows();
				if(activityMap != null ) {
					accBuActivityService.setActivityAttachment(activityMap, ActivityAttachmentEnum.detail);
					accBuActivityService.setActivityAttachment(activityMap, ActivityAttachmentEnum.situation);
					accBuActivityService.setActivityAttachment(activityMap, ActivityAttachmentEnum.fapiao);
				}
			}
			return entityResult;
		}).result();
	}

	@ApiOperation(value="活动列表-逻辑删除",notes="活动列表-逻辑删除")
	@RequestMapping(value="/delete.do",method=RequestMethod.POST)
	public EntityResult<Map<String, Object>> delete(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) ParamBase<Map<String, Object>> queryCondition) throws Exception{
		return BusicenInvoker.doEntity(()->{
			Assert.notNull(queryCondition.getParam(), "参数param不能为空");
			return accBuActivityService.delete((String)queryCondition.getParam().get("activityId"), authentication);
		}).result();
	}

	@ApiOperation(value="活动列表-取消活动",notes="活动列表-取消活动")
	@RequestMapping(value="/cancel.do",method=RequestMethod.POST)
	public OptResult cancel(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) ParamBase<Map<String, Object>> queryCondition) throws Exception{
		return BusicenInvoker.doOpt(()->{
			Assert.notNull(queryCondition.getParam(), "参数param不能为空");
			return accBuActivityService.cancel((String)queryCondition.getParam().get("activityId"), authentication);
		}).result();
	}

	@ApiOperation(value="活动日历查询(场地,门店,日期)",notes="活动日历查询")
	@RequestMapping(value="/calenderquery.do",method=RequestMethod.POST)
	public ListResult<Map<String, Object>> accBuActivityCalenderQueryList(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) ParamPage<Map<String, Object>> queryCondition) throws Exception{
		queryCondition.getParam().put("token", authentication);
		return BusicenInvoker.doList(()->accBuActivityService.accBuActivityCalenderQueryList(queryCondition)).result();
	}

	@ApiOperation(value="活动日历查询(按周)",notes="活动日历查询")
	@RequestMapping(value="/calenderquerybyweek.do",method=RequestMethod.POST)
	public ListResult<Map<String, Object>> accBuActivityCalenderQueryByWeekList(@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) ParamPage<Map<String, Object>> queryCondition) throws Exception{
		queryCondition.getParam().put("token", authentication);
		return BusicenInvoker.doList(()->accBuActivityService.accBuActivityCalenderQueryByWeekList(queryCondition)).result();
	}


	@Autowired ICommonAuditService commonAuditService;

	@ApiOperation(value="test",notes="")
	@RequestMapping(value="/test.do",method=RequestMethod.POST)
	Object test(@RequestHeader(HttpHeaders.AUTHORIZATION) String token,
			String dlrCode) throws Exception{
		Map<String, Object> orgDlrInfo = accSysOrgService.mdmDlrInfoFindAll(token, dlrCode);
		return orgDlrInfo;
	}


	/**
	 * 根据userId获取负责的门店编码
	 * @param authentication
	 * @param userBusiEntity
	 * @return
	 */
	private List<String> _getUserDlrCodeList(String authentication, String userId) {
		List<String> dlrCodeList = new ArrayList<String>();
		HashMap<String, Object> querymanagedlrMap = new HashMap<>();
		querymanagedlrMap.put("userId", userId);
		querymanagedlrMap.put("pageIndex", -1);
		querymanagedlrMap.put("pageSize", -1);
		ListResult<Map<String, Object>> dlrListResult = accSysClueService.querymanagedlr(authentication, querymanagedlrMap);
		logger.info("querymanagedlr={}", dlrListResult);
		if("1".equals(dlrListResult.getResult())) {
			List<Map<String, Object>> rows = dlrListResult.getRows();
			for(Map<String, Object> map: rows) {
				dlrCodeList.add((String)map.get("dlrCode"));
			}
		}
		if(dlrCodeList.isEmpty()) {
			dlrCodeList.add("-1");
		}
		return dlrCodeList;
	}

	@ApiOperation(value = "活动小类查询", notes = "活动小类查询")
	@RequestMapping(value = "/queryacsmalltype.do", method = RequestMethod.POST)
	public ListResult<Map<String, Object>> queryAcsSmallType(
			@RequestHeader(HttpHeaders.AUTHORIZATION) String authentication,
			@RequestBody(required = false) ParamPage<Map<String, Object>> queryCondition) throws Exception {
		queryCondition.getParam().put("token", authentication);
		return BusicenInvoker.doList(() -> accBuActivityService.queryAcsSmallType(queryCondition)).result();
	}

	@ApiOperation(value = "活动维护", notes = "活动维护")
	@PostMapping(value = "/sacAccBuActivitySave.do")
	public EntityResult<Map<String, Object>> sacAccBuActivitySave(@RequestHeader(com.google.common.net.HttpHeaders.AUTHORIZATION) String authentication, @RequestBody(required = false) Map<String, Object> dateInfo){
		return com.ly.mp.busicen.common.context.BusicenInvoker.doEntity(() -> {return accBuActivityService.sacAccBuActivitySave(dateInfo,authentication);}).result();
	}
}
