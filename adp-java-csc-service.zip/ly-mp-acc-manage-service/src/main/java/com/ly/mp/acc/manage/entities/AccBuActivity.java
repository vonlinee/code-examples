package com.ly.mp.acc.manage.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

/**
 * 活动表 <br>
 * t_acc_bu_activity <br>
 *
 * @author ly-zhengzc
 * @since 2022-1-11
 */
@TableName(value = "t_acc_bu_activity")
public class AccBuActivity implements Serializable {
	private static final long serialVersionUID = 1L;

	/** 活动主键 */
	@TableId("ACTIVITY_ID")
	private String activityId;
	/** 活动名称 */
	@TableField("ACTIVITY_NAME")
	private String activityName;
	/** 活动目的 */
	@TableField("ACTIVITY_PURPOSE")
	private String activityPurpose;
	/** 活动创建类型编码 */
	@TableField("CREATE_TYPE_CODE")
	private String createTypeCode;
	/** 活动创建类型名称 */
	@TableField("CREATE_TYPE_NAME")
	private String createTypeName;
	/** 活动状态编码 */
	@TableField("STATUS_CODE")
	private String statusCode;
	/** 活动状态名称 */
	@TableField("STATUS_NAME")
	private String statusName;
	/** 活动发布状态编码 */
	@TableField("RELEASE_STATUS_CODE")
	private String releaseStatusCode;
	/** 活动发布状态名称 */
	@TableField("RELEASE_STATUS_NAME")
	private String releaseStatusName;
	/** 经销商编码 */
	@TableField("DLR_CODE")
	private String dlrCode;
	/** 经销商名称 */
	@TableField("DLR_SHORT_NAME")
	private String dlrShortName;

	/** 支持门店名称 */
	@TableField("DLR_SUPPORTED_SHORT_NAME")
	private String dlrSupportedShortName;
	/** 支持门店编码 */
	@TableField("DLR_SUPPORTED_CODE")
	private String dlrSupportedCode;

	/** 门店城市编码 */
	@TableField("DLR_CITY_CODE")
	private String dlrCityCode;
	/** 门店城市名称 */
	@TableField("DLR_CITY_NAME")
	private String dlrCityName;
	/** 门店区域编码 */
	@TableField("DLR_REGION_CODE")
	private String dlrRegionCode;
	/** 门店区域名称 */
	@TableField("DLR_REGION_NAME")
	private String dlrRegionName;
	/** 门店空间编码 */
	@TableField("DLR_SPACE_CODE")
	private String dlrSpaceCode;
	/** 门店空间名称 */
	@TableField("DLR_SPACE_NAME")
	private String dlrSpaceName;
	/** 场地使用开始时间 */
	@TableField("DLR_AREA_USED_START_TIME")
	private LocalDateTime dlrAreaUsedStartTime;
	/** 场地使用结束时间 */
	@TableField("DLR_AREA_USED_END_TIME")
	private LocalDateTime dlrAreaUsedEndTime;
	/** 场地使用时长 */
	@TableField("DLR_AREA_USED_LENGTH_OF_TIME")
	private Integer dlrAreaUsedLengthOfTime;
	/** 具体地址 */
	@TableField("DLR_ADDRESS_DETAIL")
	private String dlrAddressDetail;
	/** 活动地点编码 */
	@TableField("ADDRESS_TYPE_CODE")
	private String addressTypeCode;
	/** 活动地点名称 */
	@TableField("ADDRESS_TYPE_NAME")
	private String addressTypeName;
	/** 活动类型编码 */
	@TableField("ACTIVITY_TYPE_CODE")
	private String activityTypeCode;
	/** 活动类型名称 */
	@TableField("ACTIVITY_TYPE_NAME")
	private String activityTypeName;
	/** 活动子类型编码 */
	@TableField("ACTIVITY_SUBTYPE_CODE")
	private String activitySubtypeCode;
	/** 活动子类型名称 */
	@TableField("ACTIVITY_SUBTYPE_NAME")
	private String activitySubtypeName;
	/** 活动资源编码 */
	@TableField("ACTIVITY_RESOURCE_CODE")
	private String activityResourceCode;
	/** 活动资源名称 */
	@TableField("ACTIVITY_RESOURCE_NAME")
	private String activityResourceName;
	/** 活动提示时间编码 */
	@TableField("TIPS_TIME_CODE")
	private String tipsTimeCode;
	/** 活动提示时间名称 */
	@TableField("TIPS_TIME_NAME")
	private String tipsTimeName;
	/** 取消报名时间编码 */
	@TableField("APPLY_CANCEL_TIME_CODE")
	private String applyCancelTimeCode;
	/** 取消报名时间名称 */
	@TableField("APPLY_CANCEL_TIME_NAME")
	private String applyCancelTimeName;
	/** 支持人数 */
	@TableField("NUMBER_OF_PERSON_SUPPORTED")
	private Integer numberOfPersonSupported;
	/** 试驾车支持 */
	@TableField("TEST_DRIVE_SUPPORTED")
	private String testDriveSupported;
	/** 活动预算 */
	@TableField("BUDGET")
	private BigDecimal budget;
	/** 活动预算明细 */
	@TableField("BUDGET_DETAIL")
	private String budgetDetail;
	/** 活动开始时间 */
	@TableField("BEGIN_TIME")
	private LocalDateTime beginTime;
	/** 活动结束时间 */
	@TableField("END_TIME")
	private LocalDateTime endTime;
	/** 报名结束时间 */
	@TableField("APPLY_END_TIME")
	private LocalDateTime applyEndTime;
	/** 活动发布时间 */
	@TableField("PUBLISH_TIME")
	private LocalDateTime publishTime;
	/** 活动封面 */
	@TableField("ACTIVITY_COVER_PAGE_URL")
	private String activityCoverPageUrl;
	/** 活动介绍 */
	@TableField("ACTIVITY_INTRODUCTION")
	private String activityIntroduction;
	/** 温馨提示 */
	@TableField("ACTIVITY_KINDLY_REMINDER")
	private String activityKindlyReminder;

	/** 资源分配顾问 */
	@TableField("resource_adviser")
	private String resourceAdviser;
	/** 资源分配车辆 */
	@TableField("resource_car")
	private String resourceCar;
	/** 资源分配支持时间开始 */
	@TableField("resource_supported_time_start")
	private LocalDateTime resourceSupportedTimeStart;
	/** 资源分配支持时间结束 */
	@TableField("resource_supported_time_end")
	private LocalDateTime resourceSupportedTimeEnd;

	/** 核销状态名称 */
	@TableField("HX_STATUS_NAME")
	private String hxStatusName;
	/** 核销状态编码 */
	@TableField("HX_STATUS_CODE")
	private String hxStatusCode;
	/** 上传发票 */
	@TableField("FAPIAO")
	private String fapiao;
	/** 实际费用 */
	@TableField("ACTUAL_COST")
	private BigDecimal actualCost;
	/** 扩展字段1 */
	@TableField("COLUMN1")
	private String column1;
	/** 扩展字段2 */
	@TableField("COLUMN2")
	private String column2;
	/** 扩展字段3 */
	@TableField("COLUMN3")
	private String column3;
	/** 扩展字段4 */
	@TableField("COLUMN4")
	private String column4;
	/** 扩展字段5 */
	@TableField("COLUMN5")
	private String column5;
	/** 扩展字段6 */
	@TableField("COLUMN6")
	private String column6;
	/** 扩展字段7 */
	@TableField("COLUMN7")
	private String column7;
	/** 扩展字段8 */
	@TableField("COLUMN8")
	private String column8;
	/** 扩展字段9 */
	@TableField("COLUMN9")
	private String column9;
	/** 扩展字段10 */
	@TableField("COLUMN10")
	private String column10;

	/** 扩展字段11 */
	@TableField("COLUMN11")
	private String column11;
	/** 扩展字段12 */
	@TableField("COLUMN12")
	private String column12;
	/** 扩展字段13 */
	@TableField("COLUMN13")
	private String column13;
	/** 扩展字段14 */
	@TableField("COLUMN14")
	private String column14;
	/** 扩展字段15 */
	@TableField("COLUMN15")
	private String column15;
	/** 扩展字段16 */
	@TableField("COLUMN16")
	private String column16;
	/** 扩展字段17 */
	@TableField("COLUMN17")
	private String column17;
	/** 扩展字段18 */
	@TableField("COLUMN18")
	private String column18;
	/** 扩展字段19 */
	@TableField("COLUMN19")
	private String column19;
	/** 扩展字段20 */
	@TableField("COLUMN20")
	private String column20;
	/**
	 * 扩展字段21
	 */
	@TableField("COLUMN21")
	private String column21;

	/**
	 * 扩展字段22
	 */
	@TableField("COLUMN22")
	private String column22;

	/**
	 * 扩展字段23
	 */
	@TableField("COLUMN23")
	private String column23;

	/**
	 * 扩展字段24
	 */
	@TableField("COLUMN24")
	private String column24;

	/**
	 * 扩展字段25
	 */
	@TableField("COLUMN25")
	private String column25;

	/**
	 * 扩展字段26
	 */
	@TableField("COLUMN26")
	private String column26;

	/**
	 * 扩展字段27
	 */
	@TableField("COLUMN27")
	private String column27;

	/**
	 * 扩展字段28
	 */
	@TableField("COLUMN28")
	private String column28;

	/**
	 * 扩展字段29
	 */
	@TableField("COLUMN29")
	private String column29;

	/**
	 * 扩展字段30
	 */
	@TableField("COLUMN30")
	private String column30;

	/** JSON扩展字段 */
	@TableField("EXTENDS_JSON")
	private String extendsJson;
	/** 厂商标识ID */
	@TableField("OEM_ID")
	private String oemId;
	/** 集团标识ID */
	@TableField("GROUP_ID")
	private String groupId;
	/** 创建人ID */
	@TableField("CREATOR")
	private String creator;
	/** 创建人 */
	@TableField("CREATED_NAME")
	private String createdName;
	/** 创建日期 */
	@TableField("CREATED_DATE")
	private LocalDateTime createdDate;
	/** 修改人ID */
	@TableField("MODIFIER")
	private String modifier;
	/** 修改人 */
	@TableField("MODIFY_NAME")
	private String modifyName;
	/** 最后更新日期 */
	@TableField("LAST_UPDATED_DATE")
	private LocalDateTime lastUpdatedDate;
	/** 是否可用 */
	@TableField("IS_ENABLE")
	private String isEnable;
	/** 并发控制ID */
	@TableField("UPDATE_CONTROL_ID")
	private String updateControlId;
	public String getActivityId() {
		return activityId;
	}
	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}
	public String getActivityName() {
		return activityName;
	}
	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
	public String getCreateTypeCode() {
		return createTypeCode;
	}
	public void setCreateTypeCode(String createTypeCode) {
		this.createTypeCode = createTypeCode;
	}
	public String getCreateTypeName() {
		return createTypeName;
	}
	public void setCreateTypeName(String createTypeName) {
		this.createTypeName = createTypeName;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusName() {
		return statusName;
	}
	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}
	public String getReleaseStatusCode() {
		return releaseStatusCode;
	}
	public void setReleaseStatusCode(String releaseStatusCode) {
		this.releaseStatusCode = releaseStatusCode;
	}
	public String getReleaseStatusName() {
		return releaseStatusName;
	}
	public void setReleaseStatusName(String releaseStatusName) {
		this.releaseStatusName = releaseStatusName;
	}
	public String getDlrCode() {
		return dlrCode;
	}
	public void setDlrCode(String dlrCode) {
		this.dlrCode = dlrCode;
	}
	public String getDlrShortName() {
		return dlrShortName;
	}
	public void setDlrShortName(String dlrShortName) {
		this.dlrShortName = dlrShortName;
	}
	public String getDlrSupportedShortName() {
		return dlrSupportedShortName;
	}
	public void setDlrSupportedShortName(String dlrSupportedShortName) {
		this.dlrSupportedShortName = dlrSupportedShortName;
	}
	public String getDlrSupportedCode() {
		return dlrSupportedCode;
	}
	public void setDlrSupportedCode(String dlrSupportedCode) {
		this.dlrSupportedCode = dlrSupportedCode;
	}
	public String getDlrCityCode() {
		return dlrCityCode;
	}
	public void setDlrCityCode(String dlrCityCode) {
		this.dlrCityCode = dlrCityCode;
	}
	public String getDlrCityName() {
		return dlrCityName;
	}
	public void setDlrCityName(String dlrCityName) {
		this.dlrCityName = dlrCityName;
	}
	public String getDlrRegionCode() {
		return dlrRegionCode;
	}
	public void setDlrRegionCode(String dlrRegionCode) {
		this.dlrRegionCode = dlrRegionCode;
	}
	public String getDlrRegionName() {
		return dlrRegionName;
	}
	public void setDlrRegionName(String dlrRegionName) {
		this.dlrRegionName = dlrRegionName;
	}
	public String getDlrSpaceCode() {
		return dlrSpaceCode;
	}
	public void setDlrSpaceCode(String dlrSpaceCode) {
		this.dlrSpaceCode = dlrSpaceCode;
	}
	public String getDlrSpaceName() {
		return dlrSpaceName;
	}
	public void setDlrSpaceName(String dlrSpaceName) {
		this.dlrSpaceName = dlrSpaceName;
	}
	public LocalDateTime getDlrAreaUsedStartTime() {
		return dlrAreaUsedStartTime;
	}
	public void setDlrAreaUsedStartTime(LocalDateTime dlrAreaUsedStartTime) {
		this.dlrAreaUsedStartTime = dlrAreaUsedStartTime;
	}
	public LocalDateTime getDlrAreaUsedEndTime() {
		return dlrAreaUsedEndTime;
	}
	public void setDlrAreaUsedEndTime(LocalDateTime dlrAreaUsedEndTime) {
		this.dlrAreaUsedEndTime = dlrAreaUsedEndTime;
	}
	public Integer getDlrAreaUsedLengthOfTime() {
		return dlrAreaUsedLengthOfTime;
	}
	public void setDlrAreaUsedLengthOfTime(Integer dlrAreaUsedLengthOfTime) {
		this.dlrAreaUsedLengthOfTime = dlrAreaUsedLengthOfTime;
	}
	public String getDlrAddressDetail() {
		return dlrAddressDetail;
	}
	public void setDlrAddressDetail(String dlrAddressDetail) {
		this.dlrAddressDetail = dlrAddressDetail;
	}
	public String getAddressTypeCode() {
		return addressTypeCode;
	}
	public void setAddressTypeCode(String addressTypeCode) {
		this.addressTypeCode = addressTypeCode;
	}
	public String getAddressTypeName() {
		return addressTypeName;
	}
	public void setAddressTypeName(String addressTypeName) {
		this.addressTypeName = addressTypeName;
	}
	public String getActivityTypeCode() {
		return activityTypeCode;
	}
	public void setActivityTypeCode(String activityTypeCode) {
		this.activityTypeCode = activityTypeCode;
	}
	public String getActivityTypeName() {
		return activityTypeName;
	}
	public void setActivityTypeName(String activityTypeName) {
		this.activityTypeName = activityTypeName;
	}
	public String getActivitySubtypeCode() {
		return activitySubtypeCode;
	}
	public void setActivitySubtypeCode(String activitySubtypeCode) {
		this.activitySubtypeCode = activitySubtypeCode;
	}
	public String getActivitySubtypeName() {
		return activitySubtypeName;
	}
	public void setActivitySubtypeName(String activitySubtypeName) {
		this.activitySubtypeName = activitySubtypeName;
	}
	public String getActivityResourceCode() {
		return activityResourceCode;
	}
	public void setActivityResourceCode(String activityResourceCode) {
		this.activityResourceCode = activityResourceCode;
	}
	public String getActivityResourceName() {
		return activityResourceName;
	}
	public void setActivityResourceName(String activityResourceName) {
		this.activityResourceName = activityResourceName;
	}
	public String getTipsTimeCode() {
		return tipsTimeCode;
	}
	public void setTipsTimeCode(String tipsTimeCode) {
		this.tipsTimeCode = tipsTimeCode;
	}
	public String getTipsTimeName() {
		return tipsTimeName;
	}
	public void setTipsTimeName(String tipsTimeName) {
		this.tipsTimeName = tipsTimeName;
	}
	public String getApplyCancelTimeCode() {
		return applyCancelTimeCode;
	}
	public void setApplyCancelTimeCode(String applyCancelTimeCode) {
		this.applyCancelTimeCode = applyCancelTimeCode;
	}
	public String getApplyCancelTimeName() {
		return applyCancelTimeName;
	}
	public void setApplyCancelTimeName(String applyCancelTimeName) {
		this.applyCancelTimeName = applyCancelTimeName;
	}
	public Integer getNumberOfPersonSupported() {
		return numberOfPersonSupported;
	}
	public void setNumberOfPersonSupported(Integer numberOfPersonSupported) {
		this.numberOfPersonSupported = numberOfPersonSupported;
	}
	public String getTestDriveSupported() {
		return testDriveSupported;
	}
	public void setTestDriveSupported(String testDriveSupported) {
		this.testDriveSupported = testDriveSupported;
	}
	public BigDecimal getBudget() {
		return budget;
	}
	public void setBudget(BigDecimal budget) {
		this.budget = budget;
	}
	public String getBudgetDetail() {
		return budgetDetail;
	}
	public void setBudgetDetail(String budgetDetail) {
		this.budgetDetail = budgetDetail;
	}
	public LocalDateTime getBeginTime() {
		return beginTime;
	}
	public void setBeginTime(LocalDateTime beginTime) {
		this.beginTime = beginTime;
	}
	public LocalDateTime getEndTime() {
		return endTime;
	}
	public void setEndTime(LocalDateTime endTime) {
		this.endTime = endTime;
	}
	public LocalDateTime getApplyEndTime() {
		return applyEndTime;
	}
	public void setApplyEndTime(LocalDateTime applyEndTime) {
		this.applyEndTime = applyEndTime;
	}
	public LocalDateTime getPublishTime() {
		return publishTime;
	}
	public void setPublishTime(LocalDateTime publishTime) {
		this.publishTime = publishTime;
	}
	public String getActivityCoverPageUrl() {
		return activityCoverPageUrl;
	}
	public void setActivityCoverPageUrl(String activityCoverPageUrl) {
		this.activityCoverPageUrl = activityCoverPageUrl;
	}
	public String getActivityIntroduction() {
		return activityIntroduction;
	}
	public void setActivityIntroduction(String activityIntroduction) {
		this.activityIntroduction = activityIntroduction;
	}
	public String getActivityKindlyReminder() {
		return activityKindlyReminder;
	}
	public void setActivityKindlyReminder(String activityKindlyReminder) {
		this.activityKindlyReminder = activityKindlyReminder;
	}
	public String getResourceAdviser() {
		return resourceAdviser;
	}
	public void setResourceAdviser(String resourceAdviser) {
		this.resourceAdviser = resourceAdviser;
	}
	public String getResourceCar() {
		return resourceCar;
	}
	public void setResourceCar(String resourceCar) {
		this.resourceCar = resourceCar;
	}
	public LocalDateTime getResourceSupportedTimeStart() {
		return resourceSupportedTimeStart;
	}
	public void setResourceSupportedTimeStart(LocalDateTime resourceSupportedTimeStart) {
		this.resourceSupportedTimeStart = resourceSupportedTimeStart;
	}
	public LocalDateTime getResourceSupportedTimeEnd() {
		return resourceSupportedTimeEnd;
	}
	public void setResourceSupportedTimeEnd(LocalDateTime resourceSupportedTimeEnd) {
		this.resourceSupportedTimeEnd = resourceSupportedTimeEnd;
	}
	public String getHxStatusName() {
		return hxStatusName;
	}
	public void setHxStatusName(String hxStatusName) {
		this.hxStatusName = hxStatusName;
	}
	public String getHxStatusCode() {
		return hxStatusCode;
	}
	public void setHxStatusCode(String hxStatusCode) {
		this.hxStatusCode = hxStatusCode;
	}
	public String getFapiao() {
		return fapiao;
	}
	public void setFapiao(String fapiao) {
		this.fapiao = fapiao;
	}
	public BigDecimal getActualCost() {
		return actualCost;
	}
	public void setActualCost(BigDecimal actualCost) {
		this.actualCost = actualCost;
	}
	public String getColumn1() {
		return column1;
	}
	public void setColumn1(String column1) {
		this.column1 = column1;
	}
	public String getColumn2() {
		return column2;
	}
	public void setColumn2(String column2) {
		this.column2 = column2;
	}
	public String getColumn3() {
		return column3;
	}
	public void setColumn3(String column3) {
		this.column3 = column3;
	}
	public String getColumn4() {
		return column4;
	}
	public void setColumn4(String column4) {
		this.column4 = column4;
	}
	public String getColumn5() {
		return column5;
	}
	public void setColumn5(String column5) {
		this.column5 = column5;
	}
	public String getColumn6() {
		return column6;
	}
	public void setColumn6(String column6) {
		this.column6 = column6;
	}
	public String getColumn7() {
		return column7;
	}
	public void setColumn7(String column7) {
		this.column7 = column7;
	}
	public String getColumn8() {
		return column8;
	}
	public void setColumn8(String column8) {
		this.column8 = column8;
	}
	public String getColumn9() {
		return column9;
	}
	public void setColumn9(String column9) {
		this.column9 = column9;
	}
	public String getColumn10() {
		return column10;
	}
	public void setColumn10(String column10) {
		this.column10 = column10;
	}
	public String getColumn11() {
		return column11;
	}
	public void setColumn11(String column11) {
		this.column11 = column11;
	}
	public String getColumn12() {
		return column12;
	}
	public void setColumn12(String column12) {
		this.column12 = column12;
	}
	public String getColumn13() {
		return column13;
	}
	public void setColumn13(String column13) {
		this.column13 = column13;
	}
	public String getColumn14() {
		return column14;
	}
	public void setColumn14(String column14) {
		this.column14 = column14;
	}
	public String getColumn15() {
		return column15;
	}
	public void setColumn15(String column15) {
		this.column15 = column15;
	}
	public String getColumn16() {
		return column16;
	}
	public void setColumn16(String column16) {
		this.column16 = column16;
	}
	public String getColumn17() {
		return column17;
	}
	public void setColumn17(String column17) {
		this.column17 = column17;
	}
	public String getColumn18() {
		return column18;
	}
	public void setColumn18(String column18) {
		this.column18 = column18;
	}
	public String getColumn19() {
		return column19;
	}
	public void setColumn19(String column19) {
		this.column19 = column19;
	}
	public String getColumn20() {
		return column20;
	}
	public void setColumn20(String column20) {
		this.column20 = column20;
	}
	public String getColumn21() {
		return column21;
	}

	public void setColumn21(String column21) {
		this.column21 = column21;
	}
	public String getColumn22() {
		return column22;
	}

	public void setColumn22(String column22) {
		this.column22 = column22;
	}
	public String getColumn23() {
		return column23;
	}

	public void setColumn23(String column23) {
		this.column23 = column23;
	}
	public String getColumn24() {
		return column24;
	}

	public void setColumn24(String column24) {
		this.column24 = column24;
	}
	public String getColumn25() {
		return column25;
	}

	public void setColumn25(String column25) {
		this.column25 = column25;
	}
	public String getColumn26() {
		return column26;
	}

	public void setColumn26(String column26) {
		this.column26 = column26;
	}
	public String getColumn27() {
		return column27;
	}

	public void setColumn27(String column27) {
		this.column27 = column27;
	}
	public String getColumn28() {
		return column28;
	}

	public void setColumn28(String column28) {
		this.column28 = column28;
	}
	public String getColumn29() {
		return column29;
	}

	public void setColumn29(String column29) {
		this.column29 = column29;
	}
	public String getColumn30() {
		return column30;
	}

	public void setColumn30(String column30) {
		this.column30 = column30;
	}
	public String getExtendsJson() {
		return extendsJson;
	}
	public void setExtendsJson(String extendsJson) {
		this.extendsJson = extendsJson;
	}
	public String getOemId() {
		return oemId;
	}
	public void setOemId(String oemId) {
		this.oemId = oemId;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public String getCreator() {
		return creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public String getCreatedName() {
		return createdName;
	}
	public void setCreatedName(String createdName) {
		this.createdName = createdName;
	}
	public LocalDateTime getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}
	public String getModifier() {
		return modifier;
	}
	public void setModifier(String modifier) {
		this.modifier = modifier;
	}
	public String getModifyName() {
		return modifyName;
	}
	public void setModifyName(String modifyName) {
		this.modifyName = modifyName;
	}
	public LocalDateTime getLastUpdatedDate() {
		return lastUpdatedDate;
	}
	public void setLastUpdatedDate(LocalDateTime lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}
	public String getIsEnable() {
		return isEnable;
	}
	public void setIsEnable(String isEnable) {
		this.isEnable = isEnable;
	}
	public String getUpdateControlId() {
		return updateControlId;
	}
	public void setUpdateControlId(String updateControlId) {
		this.updateControlId = updateControlId;
	}
	public String getActivityPurpose() {
		return activityPurpose;
	}
	public void setActivityPurpose(String activityPurpose) {
		this.activityPurpose = activityPurpose;
	}
}
