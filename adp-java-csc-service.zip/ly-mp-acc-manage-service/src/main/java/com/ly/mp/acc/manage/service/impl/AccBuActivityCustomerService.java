package com.ly.mp.acc.manage.service.impl;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegist;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegistor;
import com.ly.bucn.component.interceptor.annotation.Interceptor;
import com.ly.bucn.component.strategy.runtime.ChooseContext;
import com.ly.mp.acc.manage.entities.AccBuActivityCustomer;
import com.ly.mp.acc.manage.idal.mapper.AccBuActivityCustomerMapper;
import com.ly.mp.acc.manage.service.IAccBuActivityCustomerService;
import com.ly.mp.acc.manage.strategy.IAccBuActivityCustomerStrategy;
import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.busicen.rule.field.IFireFieldRule;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.component.helper.StringHelper;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author ly-linliq
 * @since 2022-01-04
 */
@Service
public class AccBuActivityCustomerService extends ServiceImpl<AccBuActivityCustomerMapper, AccBuActivityCustomer> implements IAccBuActivityCustomerService,InterceptorWrapperRegist {

	private static Logger log = LoggerFactory.getLogger(AccBuActivityCustomerService.class);
	
	@Autowired
	IFireFieldRule fireFieldRule;
	@Autowired
	AccBuActivityCustomerMapper accBuActivityCustomerMapper;
	
	
	@Override
	public ListResult<Map<String, Object>> accBuActivityCustomerQuery(ParamPage<Map<String, Object>> mapParam) {
		ListResult<Map<String, Object>> result=new ListResult<Map<String,Object>>();
		try {
			//默认查询未被取消预约的客户信息
			if(StringHelper.IsEmptyOrNull(mapParam.getParam().get("isEnable"))) {
				mapParam.getParam().put("isEnable", "1");
			}
			Page<Map<String, Object>> page = new Page<Map<String, Object>>(mapParam.getPageIndex(),mapParam.getPageSize());
			List<Map<String, Object>> list = accBuActivityCustomerMapper.selectAccBuActivityCustomer(mapParam.getParam(),page);
			page.setRecords(list);
			result = BusicenUtils.page2ListResult(page);
		} catch (Exception e) {
			log.error("accBuActivityCustomerQuery", e);
			throw e;
		}
		return result;
	}
	@Override
	@Interceptor("acc_activity_customer_save")
	public OptResult accBuActivityCustomerSave(Map<String, Object> mapParam) {
		String strategyCode="activityCustomer"+String.valueOf(mapParam.get("status"));	
		return ChooseContext.chooseBeanOrDefault(strategyCode, IAccBuActivityCustomerStrategy.class).handle(mapParam);
	}
	

	@Override
	@SuppressWarnings("unchecked")
	public void regist(InterceptorWrapperRegistor registor) {
		// 校验字段
		registor.before("acc_activity_customer_save_valid", (context, model) -> {
			checkValidate((Map<String, Object>) context.data().getP()[0]);
		});
	}

	public void checkValidate(Map<String, Object> mapParam) {
		try {
			List<Map<String, Object>> customerList = (List<Map<String, Object>>) mapParam.get("customerList");
			if(customerList.size()<=0) {
				throw new BusicenException("顾客列表不能为空");
			}
		} catch (Exception e) {
			log.error("accBuActivityCustomerSaveCheckValidate", e);
			throw e;
		}
	}
}
