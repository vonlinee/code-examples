package com.ly.mp.acc.manage.strategy;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ly.bucn.component.strategy.annotation.Strategy;
import com.ly.mp.acc.manage.enums.ActivityCreateTypeEnum;
import com.ly.mp.acc.manage.enums.ActivityReleaseStatusEnum;
import com.ly.mp.acc.manage.enums.ActivityStatusEnum;
import com.ly.mp.acc.manage.service.IAccBuActivityService;
import com.ly.mp.assembly.approve.entities.in.CommonAuditStategyIn;
import com.ly.mp.assembly.approve.enums.AuditStatusEnum;
import com.ly.mp.assembly.approve.strategy.ICommonAuditStategy;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.helper.StringHelper;

/**
 * 审核完成，更新活动状态
 * @author ly-zhengzc
 *
 */
@Strategy(isDefault=false,names="commonAuditStategyACTION")
@Component
public class ActionAduitStategy implements ICommonAuditStategy {

	private static Logger logger = LoggerFactory.getLogger(ActionAduitStategy.class);
	@Autowired IAccBuActivityService accBuActivityService;

	@Override
	public void handle(CommonAuditStategyIn stategyParam, Map<String, Object> returnMap, String token) {
		logger.info("returnMap={}", returnMap);
		String activityId = stategyParam.getBillCode();
		Map<String,Object> activityInfoMap=accBuActivityService.getById(activityId,token).getRows();
		Map<String, Object> updateActivityMap = new LinkedHashMap<>();
		updateActivityMap.put("activityId", activityId);
		updateActivityMap.put("updateControlId", activityInfoMap.get("updateControlId"));
		updateActivityMap.put("createTypeCode", activityInfoMap.get("createTypeCode"));
		updateActivityMap.put("numOfApplicationOfApps", activityInfoMap.get("numOfApplicationOfApps"));
		updateActivityMap.put("appActivityId", activityInfoMap.get("appActivityId"));
		if(AuditStatusEnum.ok.getCode().equals(stategyParam.getShStatus())) {
			// 审核结束，没有下一个审核节点
			String nextNodeCode = stategyParam.getNextNodeCode();
			logger.info("nextNodeCode={}", nextNodeCode);
			_updateFromBigMan(updateActivityMap, returnMap, token);

			if("End".equals(nextNodeCode)) {
				setStatusByEndNodeCode(updateActivityMap);
				_updateActivityStatus(token, updateActivityMap);
				// BigManSh
			} else {
				logger.info("活动审批更新，{}", returnMap);
				_updateActivity(token, updateActivityMap);
			}
			// throw BusicenException.create("ee");
		} else if(AuditStatusEnum.bh.getCode().equals(stategyParam.getShStatus())) {
			// 活动被驳回
			_setStatusCode(updateActivityMap, ActivityStatusEnum.bh);
			updateActivityMap.put("bhReason", returnMap.get("shDesc"));
			_updateActivityStatus(token, updateActivityMap);
		}
	}

	// 更新大使审批时 分配活动资源
	private void _updateFromBigMan(Map<String, Object> updateActivityMap, Map<String, Object> returnMap, String token) {
		if(!StringHelper.IsEmptyOrNull(returnMap.get("resourceAdviser"))) {
			updateActivityMap.put("resourceAdviser", returnMap.get("resourceAdviser"));
		}
		if(!StringHelper.IsEmptyOrNull(returnMap.get("resourceCar"))) {
			updateActivityMap.put("resourceCar", returnMap.get("resourceCar"));
		}

		if(!StringHelper.IsEmptyOrNull(returnMap.get("resourceSupportedTimeStart"))) {
			updateActivityMap.put("resourceSupportedTimeStart", returnMap.get("resourceSupportedTimeStart"));
		}
		if(!StringHelper.IsEmptyOrNull(returnMap.get("resourceSupportedTimeEnd"))) {
			updateActivityMap.put("resourceSupportedTimeEnd", returnMap.get("resourceSupportedTimeEnd"));
		}

		HashSet<String> dlrCodeSet = new HashSet<String>();
		HashSet<String> dlrShortNameSet = new HashSet<String>();
		if(!StringHelper.IsEmptyOrNull(returnMap.get("dlrCode"))) {
			dlrCodeSet.addAll(Arrays.asList(StringUtils.split((String)returnMap.get("dlrCode"), ",")));
		}
		if(!StringHelper.IsEmptyOrNull(returnMap.get("dlrShortName"))) {
			dlrShortNameSet.addAll(Arrays.asList(StringUtils.split((String)returnMap.get("dlrShortName"), ",")));
		}
		if(!StringHelper.IsEmptyOrNull(returnMap.get("dlrSupportedCode"))) {
			updateActivityMap.put("dlrSupportedCode", returnMap.get("dlrSupportedCode"));
			dlrCodeSet.addAll(Arrays.asList(StringUtils.split((String)returnMap.get("dlrSupportedCode"), ",")));
			updateActivityMap.put("dlrCode", StringUtils.join(dlrCodeSet, ","));
		}
		if(!StringHelper.IsEmptyOrNull(returnMap.get("dlrSupportedShortName"))) {
			updateActivityMap.put("dlrSupportedShortName", returnMap.get("dlrSupportedShortName"));
			dlrShortNameSet.addAll(Arrays.asList(StringUtils.split((String)returnMap.get("dlrSupportedShortName"), ",")));
			updateActivityMap.put("dlrShortName", StringUtils.join(dlrShortNameSet, ","));
		}
		accBuActivityService.dealCityAndRegion(updateActivityMap, (String)updateActivityMap.get("dlrCode"), token);
	}

	// 结束节点修改活动状态
	public static void setStatusByEndNodeCode(Map<String, Object> activityMap) {
		String createTypeCode = (String)activityMap.get("createTypeCode");
		if(ActivityCreateTypeEnum.develop.getResult().equals(createTypeCode)) {
			// 本地开发类直接发布
			_setRelease(activityMap);
			_setStatusCode(activityMap, ActivityStatusEnum.audited);
		} else if(ActivityCreateTypeEnum.app.getResult().equals(createTypeCode)) {
			_setStatusCode(activityMap, ActivityStatusEnum.audited);
		} else {
			// APP报名人数>0,则ADP审核通过后，状态为待活动中心审核；如果APP报名人数=0，则ADP审核通过后，状态为已审核
			if(StringHelper.IsEmptyOrNull(activityMap.get("numOfApplicationOfApps"))||"0".equals(activityMap.get("numOfApplicationOfApps"))) {
				// app报名人数为0，则审核通过
				_setStatusCode(activityMap, ActivityStatusEnum.audited);
			}else {
				_setStatusCode(activityMap, ActivityStatusEnum.unaudit_app);
			}
		}
	}

	private static void _setStatusCode(Map<String, Object> activityMap, ActivityStatusEnum activityStatusEnum) {
		activityMap.put("statusCode", activityStatusEnum.getResult());
		activityMap.put("statusName", activityStatusEnum.getMsg());
	}

	private static void _setRelease(Map<String, Object> activityMap) {
		activityMap.put("releaseStatusCode", ActivityReleaseStatusEnum.released.getResult());
		activityMap.put("releaseStatusName", ActivityReleaseStatusEnum.released.getMsg());
	}

	private void _updateActivityStatus(String token, Map<String, Object> activityMap) {
		EntityResult<Map<String, Object>> result = accBuActivityService.updateActivityStatus(activityMap, token);
		if(!"1".equals(result.getResult())) {
			throw BusicenException.create("更新活动状态失败！");
		}
	}
	private void _updateActivity(String token, Map<String, Object> activityMap) {
		EntityResult<Map<String, Object>> result = accBuActivityService.accBuActivitySave(activityMap, token);
		if(!"1".equals(result.getResult())) {
			throw BusicenException.create("更新活动状态失败！");
		}
	}
}
