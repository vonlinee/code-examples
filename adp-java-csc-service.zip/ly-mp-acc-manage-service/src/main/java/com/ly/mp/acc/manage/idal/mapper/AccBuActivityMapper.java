package com.ly.mp.acc.manage.idal.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.ly.mp.acc.manage.entities.AccBuActivity;


/**
 * 活动表 Mapper接口
 * t_acc_bu_activity
 * @author ly-zhengzc
 * @since 2021-12-30
 */
public interface AccBuActivityMapper extends BaseMapper<AccBuActivity> {

	/**
	 * 插入
	 * @param mapParm
	 * @return
	 */
	public int insertAccBuActivity(@Param("param")Map<String, Object> mapParm);
	/**
	 * 更新
	 * @param mapParm
	 * @return
	 */
	public int updateAccBuActivity(@Param("param")Map<String, Object> mapParm);
	/**
	 * 分页查询
	 * @param page
	 * @param param
	 * @return
	 */
	List<Map<String, Object>> selectByPage(IPage<Map<String, Object>> page, @Param("param")Map<String, Object> param);
	List<Map<String, Object>> selectActivityPage(IPage<Map<String, Object>> page, @Param("param")Map<String, Object> param);
	List<Map<String, Object>> activityRepeat(@Param("param")Map<String, Object> param);
	Map<String, Object> selectActivityById(@Param("param")Map<String, Object> param);

	/**
	 * 活动日历查询
	 * @param page
	 * @param param
	 * @return
	 */
	List<Map<String, Object>> accBuActivityCalenderQuery(@Param("param")Map<String, Object> param,IPage<Map<String, Object>> page);
	/**
	 * 活动日历查询(根据活动地点)
	 * @param page
	 * @param param
	 * @return
	 */
	List<Map<String, Object>> accBuActivityCalenderQueryByWeek(@Param("param")Map<String, Object> param,IPage<Map<String, Object>> page);

	/**
	 * 附件查找
	 * @param page
	 * @param param
	 * @return
	 */
	List<Map<String, Object>> selectAttachmentByPage(IPage<Map<String, Object>> page, @Param("param")Map<String, Object> param);

	/**
	 * 查询活动小类
	 * @param page
	 * @param param
	 * @return
	 */
	List<Map<String, Object>> queryAcsSmallType(IPage<Map<String, Object>> page, @Param("param")Map<String, Object> param);
	/**
	 * 查询需要更新发布状态的活动
	 * 
	 */
	List<Map<String, Object>> queryNeedRealseActivity(IPage<Map<String, Object>> page, @Param("param")Map<String, Object> param);
}
