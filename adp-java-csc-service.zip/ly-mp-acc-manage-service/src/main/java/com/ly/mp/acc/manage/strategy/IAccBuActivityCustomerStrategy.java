package com.ly.mp.acc.manage.strategy;

import java.util.Map;

import com.ly.mp.component.entities.OptResult;

public interface IAccBuActivityCustomerStrategy {
	OptResult handle(Map<String, Object> mapParam);
}
