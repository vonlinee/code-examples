package com.ly.mp.acc.manage.enums;

/**
 * 核销状态
 * @author ly-zhengzc
 *
 */
public enum ActivityHxStatusEnum {

	newStatus("New","新建"),
	areaSh("AreaSh","待区域市场支持经理审核"),
	areaMgSh("AreaMgSh","待区域负责人审核"),
	moneySh("MoneySh","待财务审核"),
	bh("bh","驳回"),
	audited("audited","审核通过");

	private String result;
	private String msg;
	private ActivityHxStatusEnum(String result, String msg) {
		this.result = result;
		this.msg = msg;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}

}
