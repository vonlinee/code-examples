package com.ly.mp.acc.manage.enums;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public enum ActivityStatusEnum {
	tempSave("0","暂存"),
	unaudit("1","待审核"),
	unaudit_app("1","待活动中心审核"),
	audited("2","已审核"),
	audited_app("2","活动中心审核通过"),
	bh("3","驳回"),
	bh_app("3","活动中心驳回"),
	cancel("4","已取消"),
	released("5","已发布"),
	end("6","已结束");


	private static Logger logger = LoggerFactory.getLogger(ActivityStatusEnum.class);
	//	private static final Map<String, ActivityStatusEnum> MAP = new HashMap<>();
	//	static {
	//		for (ActivityStatusEnum season : values()) {
	//			MAP.put(season.result, season);
	//		}
	//	}
	//	public static ActivityStatusEnum valueOfResult(String result) {
	//		return MAP.get(result);
	//	}
	public static String getEndStatus(ActivityReleaseStatusEnum releaseEnum, LocalDateTime endTime, String statusCode) {
		logger.info("endTime={}, {}", endTime, LocalDateTime.now().compareTo(endTime)>= 1);
		if(ActivityStatusEnum.cancel.getResult().equals(statusCode)) {
			return ActivityStatusEnum.cancel.getResult();
		}
		if(ActivityReleaseStatusEnum.released == releaseEnum && LocalDateTime.now().compareTo(endTime) >= 1) {
			return ActivityStatusEnum.end.getResult();
		}
		return statusCode;
	}
	public static void dealActivityStatus(Map<String, Object> map) {
		Timestamp endTime = (Timestamp)map.get("endTime");
		if(endTime == null) {
			return ;
		}
		ActivityReleaseStatusEnum releaseStatusEnum = ActivityReleaseStatusEnum.valueOfResult((String)map.get("releaseStatusCode"));
		String statusCode = (String)map.get("statusCode");
		statusCode = getEndStatus(releaseStatusEnum, endTime.toLocalDateTime(), statusCode);

		if(ActivityStatusEnum.end.getResult().equals(statusCode)) {
			map.put("statusCode", ActivityStatusEnum.end.getResult());
			map.put("statusName", ActivityStatusEnum.end.getMsg());
		} else if(!ActivityStatusEnum.cancel.getResult().equals(statusCode) && ActivityReleaseStatusEnum.released == releaseStatusEnum) {
			map.put("statusCode", ActivityStatusEnum.released.getResult());
			map.put("statusName", ActivityStatusEnum.released.getMsg());
		}
	}

	public static void dealActivityStatus(List<Map<String, Object>> list) {
		for(Map<String, Object> map : list) {
			dealActivityStatus(map);
		}
	}

	private String result;
	private String msg;
	private ActivityStatusEnum(String result, String msg) {
		this.result = result;
		this.msg = msg;
	}

	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}

}
