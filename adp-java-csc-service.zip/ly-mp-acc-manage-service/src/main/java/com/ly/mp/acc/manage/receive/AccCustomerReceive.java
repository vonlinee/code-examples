package com.ly.mp.acc.manage.receive;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.ibm.icu.util.Calendar;
import com.ly.bucn.component.cloud.rpc.model.CldParam;
import com.ly.bucn.component.cloud.rpc.model.CldResult;
import com.ly.bucn.component.cloud.rpc.provider.CldHandlerRegist;
import com.ly.bucn.component.cloud.rpc.provider.CldHandlerRegistor;
import com.ly.mp.acc.manage.entities.AccBuActivity;
import com.ly.mp.acc.manage.enums.ActivityCreateTypeEnum;
import com.ly.mp.acc.manage.enums.ActivityCustomerEnum;
import com.ly.mp.acc.manage.enums.ActivityReleaseStatusEnum;
import com.ly.mp.acc.manage.enums.ActivityStatusEnum;
import com.ly.mp.acc.manage.idal.mapper.AccBuActivityCustomerMapper;
import com.ly.mp.acc.manage.otherservice.IAccSysClueService;
import com.ly.mp.acc.manage.otherservice.IAccSysOrgService;
import com.ly.mp.acc.manage.receive.util.AccParseUtil;
import com.ly.mp.acc.manage.service.IAccBuActivityCustomerService;
import com.ly.mp.acc.manage.service.IAccBuActivityService;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.OptResult;
import com.ly.mp.component.helper.JsonUtils;
import com.ly.mp.component.helper.StringHelper;

/**
 * 处理活动中台传过来的活动报名数据，并返回结果
 * @author ly-linliq
 *
 */
@Component
public class AccCustomerReceive implements CldHandlerRegistor{

	private Logger logger = LoggerFactory.getLogger(AccCustomerReceive.class);
	@Autowired
	IAccBuActivityService accBuActivityService;
	@Autowired
	IAccBuActivityCustomerService accBuActivityCustomerService;

	@Autowired
	AccBuActivityCustomerMapper accBuActivityCustomerMapper;

	@Override
	public void regist(CldHandlerRegist regist) {
		//活动报名信息：将接口表中的报名数据插入业务表，并返回处理结果
		regist.regist("ADP_ACC_DBJOB_001", this::ADP_ACC_DBJOB_001_001);
		//活动签到信息：将接口表中的报名数据插入业务表，并返回处理结果
		regist.regist("ADP_ACC_DBJOB_002", this::ADP_ACC_DBJOB_002_001);
		//活动取消报名信息：将接口表中的取消报名数据插入业务表，并返回处理结果
		regist.regist("ADP_ACC_DBJOB_004", this::ADP_ACC_DBJOB_004_001);
		// 活动信息：将接口表中的活动信息数据插入业务表，并返回处理结果
		regist.regist("ADP_ACC_DBJOB_003_001", this::ADP_ACC_DBJOB_003_001);
		// 活动发布
		regist.regist("ADP_ACC_DBJOB_003_002", this::ADP_ACC_DBJOB_003_002);
		// 活动删除
		regist.regist("ADP_ACC_DBJOB_003_003", this::ADP_ACC_DBJOB_003_003);
		// 活动状态
		regist.regist("ADP_ACC_DBJOB_003_004", this::ADP_ACC_DBJOB_003_004);
		// 活动审批状态
		regist.regist("ADP_ACC_DBJOB_003_005", this::ADP_ACC_DBJOB_003_005);

		regist.regist("ADP_ACC_DBJOB_005", this::ADP_ACC_DBJOB_005);
		regist.regist("ADP_ACC_DBJOB_006", this::ADP_ACC_DBJOB_006);
	}
	public CldResult ADP_ACC_DBJOB_001_001(CldParam<Map<String,Object>> mapParam) {
		OptResult result=new OptResult();
		try {
			//参数转换
			Map<String,Object> param=new HashMap<String, Object>();
			param.put("customerName", mapParam.getParam().get("customerName"));
			param.put("customerId", mapParam.getParam().get("customerId"));
			param.put("customerPhone", mapParam.getParam().get("customerPhone"));
			param.put("activityId", mapParam.getParam().get("activityId"));
			param.put("applyTime", mapParam.getParam().get("applyTime"));
			param.put("isEnable", "1");
			param.put("systemSource", "ADP-ACTIVITY");
			List<Map<String,Object>> customerList=new ArrayList<Map<String,Object>>();
			customerList.add(param);
			Map<String,Object> newMapParam=new HashMap<String, Object>();
			newMapParam.put("customerList", customerList);
			newMapParam.put("status", ActivityCustomerEnum.apply.getResult());
			newMapParam.put("intenLevelCode", "L2");
			newMapParam.put("intenLevelName", "L2");
			newMapParam.put("infoChanMName", "活动报名");
			//调用报名信息保存方法
			result=accBuActivityCustomerService.accBuActivityCustomerSave(newMapParam);
		} catch (Exception e) {
			logger.error("ADP_ACC_DBJOB_001_001", e);
			StringWriter errlog=new StringWriter();
			e.printStackTrace(new PrintWriter(errlog));
			result.setMsg(errlog.toString());
			result.setResult("0");
			return new CldResult(result);
		}
		return new CldResult(result);
	}

	public CldResult ADP_ACC_DBJOB_002_001(CldParam<Map<String,Object>> mapParam) {
		OptResult result=new OptResult();
		try {
			//参数转换
			Map<String,Object> param=new HashMap<String, Object>();
			param.put("customerId", mapParam.getParam().get("customerId"));
			param.put("activityId", mapParam.getParam().get("activityId"));
			param.put("isEnable", "1");
			List<Map<String,Object>> customerList=new ArrayList<Map<String,Object>>();
			customerList.add(param);
			Map<String,Object> newMapParam=new HashMap<String, Object>();
			newMapParam.put("customerList", customerList);
			newMapParam.put("status", ActivityCustomerEnum.signIn.getResult());
			//调用报名信息保存方法
			result=accBuActivityCustomerService.accBuActivityCustomerSave(newMapParam);
		} catch (Exception e) {
			logger.error("ADP_ACC_DBJOB_001_002", e);
			StringWriter errlog=new StringWriter();
			e.printStackTrace(new PrintWriter(errlog));
			result.setMsg(errlog.toString());
			result.setResult("0");
			return new CldResult(result);
		}
		return new CldResult(result);
	}
	public CldResult ADP_ACC_DBJOB_004_001(CldParam<Map<String,Object>> mapParam) {
		OptResult result=new OptResult();
		try {
			//参数转换
			Map<String,Object> param=new HashMap<String, Object>();
			param.put("customerId", mapParam.getParam().get("customerId"));
			param.put("activityId", mapParam.getParam().get("activityId"));
			param.put("isEnable", "1");
			List<Map<String,Object>> customerList=new ArrayList<Map<String,Object>>();
			customerList.add(param);
			Map<String,Object> newMapParam=new HashMap<String, Object>();
			newMapParam.put("customerList", customerList);
			newMapParam.put("status", ActivityCustomerEnum.cancel.getResult());
			//标记是否需要传活动报名取消数据给活动中心，若活动中心传来的取消报名数据，不需要执行acc_activity_customer_cancel_send这个后置
			newMapParam.put("isNeedSend", "0");
			//调用报名信息保存方法
			result=accBuActivityCustomerService.accBuActivityCustomerSave(newMapParam);
		} catch (Exception e) {
			logger.error("ADP_ACC_DBJOB_004_001", e);
			StringWriter errlog=new StringWriter();
			e.printStackTrace(new PrintWriter(errlog));
			result.setMsg(errlog.toString());
			result.setResult("0");
			return new CldResult(result);
		}
		return new CldResult(result);
	}

	@Autowired IAccSysClueService accSysClueService;
	@Autowired IAccSysOrgService accSysOrgService;
	//	private String _generateTokenByUserId(String userId) {
	//		Map<String, Object> paramMap = new HashMap<String, Object>();
	//		paramMap.put("userId", userId);
	//		return accSysOrgService.generateToken(paramMap);
	//	}
	private String _generateTokenByUserName(String userName) {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("userName", userName);
		return accSysOrgService.generateToken(paramMap);
	}


	// TODO 
	public CldResult ADP_ACC_DBJOB_003_001(CldParam<Map<String,Object>> mapParam) {
		OptResult result=new OptResult();
		try {
			logger.info("ADP_ACC_DBJOB_003_001.mapParam={}", mapParam);
			Map<String, Object> interfaceMap = mapParam.getParam();
			//参数转换
			Map<String,Object> activityMap = new LinkedHashMap<String, Object>();
			String activityId = (String)interfaceMap.get("id");
			activityMap.put("activityId", activityId);
			activityMap.put("appActivityId", activityId);
			//activityMap.put("appActivityId", interfaceMap.get("appActivityId"));

			AccBuActivity vo = accBuActivityService.getById(activityId);
			// 获取token
			// app 的用户名 a001
			String token = _generateTokenByUserName("a001");
			// 更新操作
			if(vo != null) {
				// TODO 先删除原来活动和审核任务，然后再重新发起
				EntityResult<Map<String, Object>> optResult = accBuActivityService.delete(activityId, token);
				if("0".equals(optResult.getResult())) {
					throw BusicenException.create("活动记录更新出错" + interfaceMap.get("activityId") + optResult.getMsg());
				}
				activityMap.put("updateControlId", optResult.getRows().get("updateControlId"));
			}
			activityMap.put("createTypeCode", ActivityCreateTypeEnum.app.getResult());
			activityMap.put("createTypeName", ActivityCreateTypeEnum.app.getMsg());

			activityMap.put("activityName", interfaceMap.get("subject"));

			// 活动地址类型		 1	线上		 2	GPS详细地址 		3	门店
			//			activityMap.put("addressTypeCode", "1");
			//			activityMap.put("addressTypeName", "线上");

			activityMap.put("dlrAddressDetail", interfaceMap.get("activityLocation"));

			// [{"carType":"hx11","num":10,"count":10}]
			// ==> [{"testDriveTypeCode":"BX11","testDriveTypeName":"BX11","count":11}]
			String cars = (String)interfaceMap.get("cars");
			if(StringUtils.isNotBlank(cars)) {
				activityMap.put("testDriveSupported", cars.replace("carType", "testDriveTypeCode").replace("carName", "testDriveTypeName"));
			}

			activityMap.put("activityIntroduction", interfaceMap.get("contents"));

			// app报名人数
			activityMap.put("numOfApplicationOfApps", interfaceMap.get("maxticketsCount"));
			activityMap.put("numOfApplicationOffline", "0");

			// activityMap.put("showPictureTimeLimitName", interfaceMap.get("momentDays"));
			activityMap.put("activityCoverPageUrl", interfaceMap.get("photo"));
			activityMap.put("activityKindlyReminder", interfaceMap.get("reminder"));
			activityMap.put("applyIdentityLimit", interfaceMap.get("roles"));


			// code1,name1	{"code":"1440","name":"开始前1天"}
			_dealJsonObject(activityMap, "tipsTimeCode", "tipsTimeName", (String)interfaceMap.get("noticeMins"));
			// 晒图限制时间:  {"code":"14","name":"结束后2周内"}
			_dealJsonObject(activityMap, "showPictureTimeLimitCode", "showPictureTimeLimitName", (String)interfaceMap.get("momentDays"));
			// 支持门店  {"code":"s0001","name":"门店001"}
			_dealJsonObject(activityMap, "dlrSupportedCode", "dlrSupportedShortName", (String)interfaceMap.get("storeInfo"));

			// 门店空间 [{"code":"场地001","name":"场地001"},{"code":"场地002","name":"场地002"}]
			_dealJsonArray(activityMap, "dlrSpaceCode", "dlrSpaceName", (String)interfaceMap.get("spaces"));

			// {"code":"0","name":"开始前均可取消"}
			_dealJsonObject(activityMap, "applyCancelTimeCode", "applyCancelTimeName", (String)interfaceMap.get("cancelDeadline"));

			// 活动大类: 2,非市场
			String categoryCode = (String)interfaceMap.get("categoryCode");
			if(StringUtils.isNotBlank(categoryCode)) {
				activityMap.put("activityTypeCode", StringUtils.split(categoryCode, ",")[0]);
				activityMap.put("activityTypeName", StringUtils.split(categoryCode, ",")[1]);
			} else {
				activityMap.put("activityTypeCode", "2");
				activityMap.put("activityTypeName", "非市场");
			}

			// 活动小类:		[{"code":"0107799099121639424","name":"游戏"},{"code":"9999999999999999999","name":"其他类"}]
			_dealJsonArray(activityMap, "activitySubtypeCode", "activitySubtypeName", (String)interfaceMap.get("typesCode"));
			// 活动资源 [{\"code\":\"展具001 \",\"name\":\"展具001 \"}]
			_dealJsonArray(activityMap, "activityResourceCode", "activityResourceName", (String)interfaceMap.get("tools"));



			// [{"price":20,"num":1,"name":"成人票"},{"price":60,"num":3,"name":"家庭票"}]
			// ==> [{"ticketTypeCode":"1","ticketTypeName":"家庭","score":66,"num":null}]
			String tickets = (String)interfaceMap.get("tickets");
			if(StringUtils.isNotBlank(tickets)) {
				// activityMap.put("ticketTypeAndScore", tickets);
				activityMap.put("ticketTypeAndScore", tickets
						.replace("code", "ticketTypeCode")
						.replace("name", "ticketTypeName")
						.replace("price", "score"));
			}

			activityMap.put("budget", AccParseUtil.parseDouble(interfaceMap, "activityBudget"));

			// 支持人数
			activityMap.put("numberOfPersonSupported", AccParseUtil.parseInteger(interfaceMap, "resources"));



			// 场地使用时长
			Integer duration = AccParseUtil.parseInteger(interfaceMap, "duration");
			activityMap.put("dlrAreaUsedLengthOfTime", duration);

			// 场地使用开始时间
			Date spacesTime = AccParseUtil.parseDate(interfaceMap, "spacesTime");
			if(spacesTime != null) {
				activityMap.put("dlrAreaUsedStartTime",interfaceMap.get("spacesTime"));

				Calendar cal = Calendar.getInstance();
				cal.setTime(spacesTime);
				cal.add(Calendar.HOUR, duration);
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				activityMap.put("dlrAreaUsedEndTime",sdf.format(cal.getTime()));
			}
			// activityMap.put("dlrAreaUsedStartTime", AccParseUtil.getDate(interfaceMap, "spacesTime"));

			activityMap.put("applyEndTime", AccParseUtil.getDate(interfaceMap, "joinEndDate"));
			activityMap.put("beginTime", AccParseUtil.getDate(interfaceMap, "startDate"));
			activityMap.put("endTime", AccParseUtil.getDate(interfaceMap, "endDate"));

			activityMap.put("isEnable", "1");

			logger.info("ADP_ACC_DBJOB_003_001.activityMap={}", activityMap);
			EntityResult<Map<String, Object>> entityResult = accBuActivityService.submit(activityMap, token);
			if("1".equals(entityResult.getResult())) {
				result.setResult("1");
			}
		} catch (Exception e) {
			logger.error("ADP_ACC_DBJOB_003_001", e);
			StringWriter errlog=new StringWriter();
			e.printStackTrace(new PrintWriter(errlog));
			result.setMsg(errlog.toString());
			result.setResult("0");
			return new CldResult(result);
		}
		return new CldResult(result);
	}

	@SuppressWarnings("unchecked")
	private void _dealJsonArray(Map<String, Object> activityMap, String attrCode, String attrName, String jsonArrayStr) {
		if(StringUtils.isBlank(jsonArrayStr)) {
			return;
		}
		List<Map<String, Object>> tmpList = JsonUtils.nonDefaultMapper().fromJson(jsonArrayStr, List.class);
		List<String> codeList = new ArrayList<String>();
		List<String> nameList = new ArrayList<String>();
		for(Map<String, Object> map: tmpList) {
			codeList.add((String)map.get("code"));
			nameList.add((String)map.get("name"));
		}
		activityMap.put(attrCode, StringUtils.join(codeList, ","));
		activityMap.put(attrName, StringUtils.join(nameList, ","));
	}

	@SuppressWarnings("unchecked")
	private void _dealJsonObject(Map<String, Object> activityMap, String attrCode, String attrName, String jsonObjectStr) {
		if(StringUtils.isBlank(jsonObjectStr)) {
			return;
		}
		Map<String, Object> tmpMap = JsonUtils.nonDefaultMapper().fromJson(jsonObjectStr, Map.class);
		activityMap.put(attrCode, tmpMap.get("code"));
		activityMap.put(attrName, tmpMap.get("name"));
	}

	// 更新活动发布状态
	public CldResult ADP_ACC_DBJOB_003_002(CldParam<Map<String,Object>> mapParam) {
		OptResult result=new OptResult();
		try {
			Map<String, Object> interfaceMap = mapParam.getParam();
			logger.info("ADP_ACC_DBJOB_003_002.mapParam={}", interfaceMap);
			// 10 已发布 20 未发布
			if(!"10".equals(interfaceMap.get("releaseStatus"))) {
				result.setMsg("20 未发布");
				result.setResult("1");
				return new CldResult(result);
			}
			//参数转换
			Map<String,Object> activityMap = new HashMap<String, Object>();
			activityMap.put("activityId", interfaceMap.get("activityId"));

			AccBuActivity vo = accBuActivityService.getById((String)interfaceMap.get("activityId"));
			// 更新操作
			if(vo == null) {
				throw BusicenException.create("不存在活动activityId=" + interfaceMap.get("activityId"));
			}

			// h5Url
			if(interfaceMap.get("h5Url") != null) {
				activityMap.put("h5Url", interfaceMap.get("h5Url"));
			}

			if(interfaceMap.get("signUrl") != null) {
				activityMap.put("signUrl", interfaceMap.get("signUrl"));
			}


			if(ActivityCreateTypeEnum.app.getResult().equals(vo.getCreateTypeCode())) {
				activityMap.put("releaseStatusCode", ActivityReleaseStatusEnum.released.getResult());
				activityMap.put("releaseStatusName", ActivityReleaseStatusEnum.released.getMsg());
			} else {
				// 不更新发布状态
			}
			activityMap.put("updateControlId", vo.getUpdateControlId());
			logger.info("ADP_ACC_DBJOB_003_002.activityMap={}", activityMap);

			EntityResult<Map<String, Object>> entityResult = accBuActivityService.accBuActivitySave(activityMap, null);
			if("0".equals(entityResult.getResult())) {
				throw BusicenException.create("活动记录更新出错" + interfaceMap.get("activityId") + entityResult.getMsg());
			}

		} catch (Exception e) {
			logger.error("ADP_ACC_DBJOB_003_002", e);
			StringWriter errlog=new StringWriter();
			e.printStackTrace(new PrintWriter(errlog));
			result.setMsg(errlog.toString());
			result.setResult("0");
			return new CldResult(result);
		}
		return new CldResult(result);
	}

	// 标识活动 已删除
	public CldResult ADP_ACC_DBJOB_003_003(CldParam<Map<String,Object>> mapParam) {
		OptResult result=new OptResult();
		try {
			logger.info("ADP_ACC_DBJOB_003_003.mapParam={}", mapParam);
			Map<String, Object> interfaceMap = mapParam.getParam();
			//参数转换
			Map<String,Object> activityMap = new HashMap<String, Object>();
			String activityId = (String)interfaceMap.get("activityId");
			activityMap.put("activityId", activityId);
			AccBuActivity vo = accBuActivityService.getById(activityId);
			// 更新操作
			if(vo == null) {
				throw BusicenException.create("不存在活动activityId=" + interfaceMap.get("activityId"));
			}

			String token = null;
			EntityResult<Map<String, Object>> optResult = accBuActivityService.delete(activityId, token);
			if("0".equals(optResult.getResult())) {
				throw BusicenException.create("活动记录更新出错" + interfaceMap.get("activityId") + optResult.getMsg());
			}
			logger.info("ADP_ACC_DBJOB_003_003.activityMap={}", activityMap);
		} catch (Exception e) {
			logger.error("ADP_ACC_DBJOB_003_003", e);
			StringWriter errlog=new StringWriter();
			e.printStackTrace(new PrintWriter(errlog));
			result.setMsg(errlog.toString());
			result.setResult("0");
			return new CldResult(result);
		}
		return new CldResult(result);
	}

	// 更新活动状态
	public CldResult ADP_ACC_DBJOB_003_004(CldParam<Map<String,Object>> mapParam) {
		OptResult result=new OptResult();
		try {
			logger.info("ADP_ACC_DBJOB_003_004.mapParam={}", mapParam);
			Map<String, Object> interfaceMap = mapParam.getParam();
			//参数转换
			Map<String,Object> activityMap = new HashMap<String, Object>();
			activityMap.put("activityId", interfaceMap.get("activityId"));

			AccBuActivity vo = accBuActivityService.getById((String)interfaceMap.get("activityId"));
			// 更新操作
			if(vo == null) {
				throw BusicenException.create("不存在活动activityId=" + interfaceMap.get("activityId"));
			}
			activityMap.put("updateControlId", vo.getUpdateControlId());

			String activityStatus = (String)interfaceMap.get("activityStatus");
			logger.info("更新状态为activityStatus={}", activityStatus);

			// 30:审核拒绝 	20:审核通过 	10:待审核
			if(StringUtils.equals("30", activityStatus)) {
				activityMap.put("statusCode", ActivityStatusEnum.bh_app.getResult());
				activityMap.put("statusName", ActivityStatusEnum.bh_app.getMsg());
			} else if(StringUtils.equals("20", activityStatus)) {
				activityMap.put("statusCode", ActivityStatusEnum.audited_app.getResult());
				activityMap.put("statusName", ActivityStatusEnum.audited_app.getMsg());
			} else if(StringUtils.equals("10", activityStatus)) {
				activityMap.put("statusCode", ActivityStatusEnum.unaudit_app.getResult());
				activityMap.put("statusName", ActivityStatusEnum.unaudit_app.getMsg());
			}
			if(activityMap.get("statusCode") != null) {
				EntityResult<Map<String, Object>> entityResult = accBuActivityService.accBuActivitySave(activityMap, null);
				if("0".equals(entityResult.getResult())) {
					throw BusicenException.create("活动记录更新出错" + interfaceMap.get("activityId") + entityResult.getMsg());
				}
			}
			logger.info("ADP_ACC_DBJOB_003_004.activityMap={}", activityMap);
		} catch (Exception e) {
			logger.error("ADP_ACC_DBJOB_003_004", e);
			StringWriter errlog=new StringWriter();
			e.printStackTrace(new PrintWriter(errlog));
			result.setMsg(errlog.toString());
			result.setResult("0");
			return new CldResult(result);
		}
		return new CldResult(result);
	}

	// 更新活动审批状态
	public CldResult ADP_ACC_DBJOB_003_005(CldParam<Map<String,Object>> mapParam) {
		OptResult result=new OptResult();
		try {
			logger.info("ADP_ACC_DBJOB_003_005.mapParam={}", mapParam);
			Map<String, Object> interfaceMap = mapParam.getParam();
			//参数转换
			Map<String,Object> activityMap = new HashMap<String, Object>();
			String activityId = (String)interfaceMap.get("id");
			activityMap.put("activityId", activityId);

			AccBuActivity vo = accBuActivityService.getById(activityId);
			// 更新操作
			if(vo == null) {
				throw BusicenException.create("不存在活动activityId=" + activityId);
			}
			activityMap.put("updateControlId", vo.getUpdateControlId());

			String auditStatus = (String)interfaceMap.get("auditStatus");
			logger.info("更新状态为auditStatus={}", auditStatus);
			// 30:审核拒绝 20:审核通 过 10:待审核  -1:APP取消提交审核
			if(StringUtils.equals("30", auditStatus)) {
				activityMap.put("statusCode", ActivityStatusEnum.bh_app.getResult());
				activityMap.put("statusName", ActivityStatusEnum.bh_app.getMsg());
				activityMap.put("releaseStatusCode", ActivityReleaseStatusEnum.unReleased.getMsg());
				activityMap.put("releaseStatusName", ActivityReleaseStatusEnum.unReleased.getMsg());
			} else if(StringUtils.equals("20", auditStatus)) {
				activityMap.put("statusCode", ActivityStatusEnum.audited_app.getResult());
				activityMap.put("statusName", ActivityStatusEnum.audited_app.getMsg());
			} else if(StringUtils.equals("10", auditStatus)) {
				// 
			} else if(StringUtils.equals("-1", auditStatus)) {
				// -1:APP取消提交审核 将活动状态is_enable更新为0,同时删除审核任务
				accBuActivityService.delete(activityId, null);
				return new CldResult(result);
			}

			logger.info("更新状态为activityStatus={}", auditStatus);
			if(activityMap.get("statusCode") != null) {
				EntityResult<Map<String, Object>> entityResult = accBuActivityService.accBuActivitySave(activityMap, null);
				if("0".equals(entityResult.getResult())) {
					throw BusicenException.create("活动记录更新出错" + activityId + entityResult.getMsg());
				}
			}
			logger.info("ADP_ACC_DBJOB_003_005.activityMap={}", activityMap);
		} catch (Exception e) {
			logger.error("ADP_ACC_DBJOB_003_005", e);
			StringWriter errlog=new StringWriter();
			e.printStackTrace(new PrintWriter(errlog));
			result.setMsg(errlog.toString());
			result.setResult("0");
			return new CldResult(result);
		}
		return new CldResult(result);
	}

	public CldResult ADP_ACC_DBJOB_005(CldParam<Map<String,Object>> mapParam) {
		OptResult result=new OptResult();
		try {
			//参数转换
			Map<String,Object> param=new HashMap<String, Object>();
			//List<Map<String,Object>>  list = mapParam.getParam().get("firstTypes");
			param.put("BIG_TYPE_ID","2");
			param.put("BIG_TYPE_NAME","非市场活动");
			List<Map<String,Object>> smallTypeList=(List<Map<String,Object>>) JSON.parse(mapParam.getParam().get("secondTypes").toString());
			if(!StringHelper.IsEmptyOrNull(smallTypeList)){
				for(Map<String,Object> map:smallTypeList){
					param.put("SMALL_TYPE_ID",map.get("id"));
					param.put("SMALL_TYPE_NAME",map.get("name"));
					int i=accBuActivityCustomerMapper.checkSmallType(param);
					if(i>0){

						accBuActivityCustomerMapper.updateSmallType(param);
					}else{
						param.put("UPDATE_CONTROL_ID", UUID.randomUUID().toString());
						accBuActivityCustomerMapper.insertSmallType(param);
					}

				}
				result.setResult("1");
			}

		} catch (Exception e) {
			logger.error("ADP_ACC_DBJOB_005", e);
			StringWriter errlog=new StringWriter();
			e.printStackTrace(new PrintWriter(errlog));
			result.setMsg(errlog.toString());
			result.setResult("0");
			return new CldResult(result);
		}
		return new CldResult(result);
	}

	public CldResult ADP_ACC_DBJOB_006(CldParam<Map<String,Object>> mapParam) {
		OptResult result=new OptResult();
		try {
			Map<String,Object> param =mapParam.getParam();
			if(!StringHelper.IsEmptyOrNull(param)){
				int i=accBuActivityCustomerMapper.updateAppId(param);
			}
			result.setResult("1");

		} catch (Exception e) {
			logger.error("ADP_ACC_DBJOB_006", e);
			StringWriter errlog=new StringWriter();
			e.printStackTrace(new PrintWriter(errlog));
			result.setMsg(errlog.toString());
			result.setResult("0");
			return new CldResult(result);
		}
		return new CldResult(result);
	}

}
