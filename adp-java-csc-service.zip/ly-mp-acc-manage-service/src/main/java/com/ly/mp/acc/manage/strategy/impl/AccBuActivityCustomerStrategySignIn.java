package com.ly.mp.acc.manage.strategy.impl;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ly.bucn.component.interceptor.InterceptorWrapperRegist;
import com.ly.bucn.component.interceptor.InterceptorWrapperRegistor;
import com.ly.bucn.component.interceptor.annotation.Interceptor;
import com.ly.bucn.component.strategy.annotation.Strategy;
import com.ly.mp.acc.manage.idal.mapper.AccBuActivityCustomerMapper;
import com.ly.mp.acc.manage.strategy.IAccBuActivityCustomerStrategy;
import com.ly.mp.busi.base.context.BusicenException;
import com.ly.mp.busi.base.handler.BusicenUtils;
import com.ly.mp.busi.base.handler.BusicenUtils.SOU;
import com.ly.mp.busi.base.handler.OptResultBuilder;
import com.ly.mp.busicen.rule.field.IFireFieldRule;
import com.ly.mp.busicen.rule.field.execution.ValidResultCtn;
import com.ly.mp.component.entities.OptResult;

/**
 * 签到
 * @author ly-linliq
 * @since 2022-02-10
 */
@Strategy(isDefault = false, names = "activityCustomerSignIn")
@Component
public class AccBuActivityCustomerStrategySignIn implements IAccBuActivityCustomerStrategy, InterceptorWrapperRegist {

	private static Logger log = LoggerFactory.getLogger(AccBuActivityCustomerStrategySignIn.class);

	@Autowired
	IFireFieldRule fireFieldRule;
	@Autowired
	AccBuActivityCustomerMapper accBuActivityCustomerMapper;

	@Override
	@Interceptor("acc_activity_customer_signin")
	public OptResult handle(Map<String, Object> mapParam) {
		try {
			String token = String.valueOf(mapParam.get("token"));
			String isCheckIn = "1";
			// 获取顾客列表
			List<Map<String, Object>> customerList = (List<Map<String, Object>>) mapParam.get("customerList");
			for (Map<String, Object> map : customerList) {
				map.put("isCheckIn", isCheckIn);
				map.put("oldIsEnable","1");
				BusicenUtils.invokeUserInfo(map, SOU.Update, token);
			}
			accBuActivityCustomerMapper.updateAccBuActivityCustomer(customerList);
		} catch (Exception e) {
			log.error("accBuActivityCustomerSignIn", e);
			throw e;
		}
		return OptResultBuilder.createOk().build();
	}

	@Override
	public void regist(InterceptorWrapperRegistor registor) {
		// 校验字段
		registor.before("acc_activity_customer_sign_valid", (context, model) -> {
			checkValidate((Map<String, Object>) context.data().getP()[0]);
		});

	}

	public void checkValidate(Map<String, Object> mapParam) {
		try {
			List<Map<String, Object>> customerList = (List<Map<String, Object>>) mapParam.get("customerList");
			for (Map<String, Object> map : customerList) {
				ValidResultCtn fireRule = fireFieldRule.fireRule(map, "acc-manage-activity-sign-check", "maindata");
				String resMsg = fireRule.getNotValidMessage();
				if (!fireRule.isValid()) {
					throw new BusicenException(resMsg);
				}
			}
		} catch (Exception e) {
			log.error("accBuActivityCustomerSignInCheckValidate", e);
			throw e;
		}
	}
}
