package com.ly.mp.acc.manage.receive.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ly.mp.busi.base.context.BusicenException;

public class AccParseUtil {

	private static Logger logger = LoggerFactory.getLogger(AccParseUtil.class);
	public static Date parseDate(Map<String,Object> interfaceMap, String key) {
		String strDateTime = (String)interfaceMap.get(key);
		if(StringUtils.isBlank(strDateTime)) {
			return null;
		}
		try {
			if(strDateTime.length() == 19) {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				return sdf.parse(strDateTime);
			}
			if(strDateTime.length() == 10) {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				return sdf.parse(strDateTime);
			}
			throw BusicenException.create("时间格式不符合要求(yyyy-MM-dd HH:mm:ss / yyyy-MM-dd)," + key + ":" + strDateTime);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw BusicenException.create("时间格式不符合要求(yyyy-MM-dd HH:mm:ss / yyyy-MM-dd)," + key + ":" + strDateTime);
		}
	}

	public static String getDate(Map<String,Object> interfaceMap, String key) {
		parseDate(interfaceMap, key);
		return (String)interfaceMap.get(key);
	}

	public static Integer parseInteger(Map<String,Object> interfaceMap, String key) {
		String strInteger = (String)interfaceMap.get(key);
		if(StringUtils.isBlank(strInteger)) {
			return null;
		}
		try {
			return Integer.parseInt(strInteger);
		} catch (Exception e) {
			throw BusicenException.create("请输入整数，" + key + ":" + strInteger);
		}
	}

	public static Double parseDouble(Map<String,Object> interfaceMap, String key) {
		String strDouble = (String)interfaceMap.get(key);
		if(StringUtils.isBlank(strDouble)) {
			return null;
		}
		try {
			return Double.parseDouble(strDouble);
		} catch (Exception e) {
			throw BusicenException.create("请输入浮点数，" + key + ":" + strDouble);
		}
	}

}
