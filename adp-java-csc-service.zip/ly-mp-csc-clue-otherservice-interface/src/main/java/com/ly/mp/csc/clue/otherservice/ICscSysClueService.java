package com.ly.mp.csc.clue.otherservice;

import java.util.Map;

import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.ListResult;

public interface ICscSysClueService {

	public ListResult<Map<String, Object>> carSeriesQuery(ParamPage<Map<String, Object>> dataInfo) ;
}
