package com.ly.mp.csc.clue.otherservice;

import java.util.Map;

import org.springframework.web.bind.annotation.RequestBody;

import com.ly.mp.bucn.pack.entity.ParamPage;
import com.ly.mp.component.entities.EntityResult;
import com.ly.mp.component.entities.ListResult;
import com.ly.mp.component.entities.OptResult;

/**
 * 基础服务接口
 * @author ly-zhengzc
 *
 */
public interface ICscSysBaseDataService {

	/**
	 *  单号生成服务
	 * @param dlrId
	 * @param billTypeId
	 * @param token
	 * @return
	 */
	public ListResult<Map<String, Object>> generateOrderCode(String dlrId, String billTypeId, String token) ;
	/**
	 * 单号生成服务(屏蔽认证)
	 * @param dlrId
	 * @param billTypeId
	 * @return
	 */
	public ListResult<Map<String, Object>> generateOrderCodeNoToken(String dlrId, String billTypeId);

	public ListResult<Map<String, Object>> mdslookupvaluefindbypage(String lookupTypeCode, String token) ;
	/**
	 * 试驾车保存
	 * @param authentication
	 * @param param
	 * @return
	 */
	public EntityResult<Map<String, Object>> inset(String authentication,ParamPage<Map<String, Object>> param);
	
	/**
	 * 当前登录人所管辖门店查询
	 * @param authentication
	 * @param paramBase
	 * @return
	 */
	public ListResult<Map<String,Object>> querymanagedlr(String authentication, Map<String, Object> dateInfo);
	

}
